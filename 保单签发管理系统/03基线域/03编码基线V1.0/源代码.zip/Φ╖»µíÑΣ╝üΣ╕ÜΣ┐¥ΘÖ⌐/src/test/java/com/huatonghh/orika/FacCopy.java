package com.huatonghh.orika;

import lombok.Data;

/**
 * @author : Sun
 * @program : enterprise-insurance-back
 * @description :
 * @create : 2019-11-18 20:03
 **/
@Data
public class FacCopy {
    private String name1;
    private String age1;
}
