package com.huatonghh.orika;

import lombok.Data;

import java.util.Date;

/**
 * @author : Sun
 * @program : enterprise-insurance-back
 * @description :
 * @create : 2019-11-18 20:03
 **/
@Data
public class SS {
    private String ssName;
}
