package com.huatonghh.oa;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

@WebService(targetNamespace = "http://ws.standard.ft.com/", name = "TB_STA_gongsiService")
public interface GongSiService {

    @WebMethod
    @WebResult(name = "return")
    String selectAll(@WebParam(name = "arg0") String arg0);

}
