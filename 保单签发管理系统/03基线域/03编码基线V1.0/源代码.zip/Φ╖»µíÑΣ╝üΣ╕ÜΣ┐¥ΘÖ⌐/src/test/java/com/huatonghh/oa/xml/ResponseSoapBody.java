package com.huatonghh.oa.xml;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import lombok.Data;

/**
 * Description : <soap:Body>节点</soap:Body>
 * @author : Sun
 * @date : 2019/10/11 15:59
 * @version : 1.0
 */
@Data
@XStreamAlias("soap:Body")
public class ResponseSoapBody {

    @XStreamAlias("ns2:selectAllResponse")
    private ResponseNsTwoSelectAll responseNsTwoSelectAll;

}
