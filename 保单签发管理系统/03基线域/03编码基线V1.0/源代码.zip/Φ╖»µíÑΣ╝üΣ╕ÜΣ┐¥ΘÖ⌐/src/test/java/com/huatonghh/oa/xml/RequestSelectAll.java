package com.huatonghh.oa.xml;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import lombok.Data;

/**
 * Description : <selectAll>节点</selectAll>
 * @author : Sun
 * @date : 2019/10/11 16:01
 * @version : 1.0
 */
@Data
public class RequestSelectAll {

    @XStreamAsAttribute
    private String xmlns;

    @XStreamAlias("arg0")
    private RequestArgZero argZero;
    

}
