package com.huatonghh.xstream;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamConverter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import lombok.Data;

/**
 * @author : Sun
 * @program : enterprise-insurance-back
 * @description :
 * @create : 2019-11-20 17:56
 **/
@Data
public class Student{
    String name;
    String age;

    @XStreamConverter(value=StudentConverter1.class)
    @XStreamAsAttribute
    String teacher;
}

