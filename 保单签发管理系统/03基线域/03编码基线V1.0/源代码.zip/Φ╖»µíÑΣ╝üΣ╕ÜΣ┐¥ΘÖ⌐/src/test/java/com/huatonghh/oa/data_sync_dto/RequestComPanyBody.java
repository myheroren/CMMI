package com.huatonghh.oa.data_sync_dto;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * Description : 公司 Body体
 * @author : Sun
 * @date : 2019/10/11 15:38
 * @version : 1.0
 */
@Data
public class RequestComPanyBody {
    /** 查询类型标识值 */
    @JsonProperty(value = "WorkType")
    @JSONField(name ="WorkType")
    private String workType;

    /** 查询人员 */
    @JsonProperty(value = "EMPLOYEE_ID")
    @JSONField(name ="EMPLOYEE_ID")
    private String employeeId;

    /** 查询姓名 */
    @JsonProperty(value = "EMPLOYEE_NAME")
    @JSONField(name ="EMPLOYEE_NAME")
    private String employeeName;

    /** 查询公司ID */
    @JsonProperty(value = "ComPanyId")
    @JSONField(name ="ComPanyId")
    private String comPanyId;

    /** 查询部门ID */
    @JsonProperty(value = "DeptId")
    @JSONField(name ="DeptId")
    private String deptId;


}
