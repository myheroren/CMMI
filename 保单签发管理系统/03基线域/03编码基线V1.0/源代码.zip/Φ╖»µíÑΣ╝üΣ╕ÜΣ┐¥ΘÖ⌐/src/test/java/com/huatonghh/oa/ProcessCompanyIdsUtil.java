package com.huatonghh.oa;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.lang.Console;
import com.huatonghh.authority.service.dto.EiDepartDto;
import org.junit.Ignore;
import org.junit.Test;

import java.util.List;

/**
 * Description :
 * @author : Sun
 * @date : 2019/10/14 11:51
 * @version : 1.0
 */
@Ignore
public class ProcessCompanyIdsUtil {

    /**
     * Description : 组装公司ids
     * @author : Sun
     * @date : 2019/10/14 11:43
     */
    @Test
    public void processCompanyIds() {
        /*EiDepartDto ei1 = new EiDepartDto(15, "企业保险-交投集团", 0);
        EiDepartDto ei2 = new EiDepartDto(16, "企业保险-财务公司", 15);
        EiDepartDto ei3 = new EiDepartDto(17, "企业保险-二级公司1", 15);
        EiDepartDto ei4 = new EiDepartDto(18, "企业保险-三级及以下公司1-1", 17);
        EiDepartDto ei5 = new EiDepartDto(19, "企业保险-二级公司2", 15);
        EiDepartDto ei6 = new EiDepartDto(21, "企业保险-三级及以下公司2-2", 19);
        EiDepartDto ei7 = new EiDepartDto(44, "哈哈", 0);
        EiDepartDto ei8 = new EiDepartDto(62, "ewrqwe ", 0);
        EiDepartDto ei9 = new EiDepartDto(63, "fdafsdfdsaf", 44);
        List<EiDepartDto> list = CollUtil.newArrayList(ei1, ei2, ei3, ei4, ei5, ei6, ei7, ei8, ei9);

        list = recursiveProcess(new EiDepartDto(0, "光明顶", 1000, ""), list);
        Console.log(list);*/
    }


    /**
     * Description : 递归组装ids
     * @author : Sun
     * @date : 2019/10/14 15:38
     */
    public List<EiDepartDto>  recursiveProcess(EiDepartDto e, List<EiDepartDto> list) {
        for (EiDepartDto child : list) {
            if(e.getId().equals(child.getParentId())) {
                child.setIds(e.getIds() + child.getId() + ";");
                list = recursiveProcess(child, list);
            }
        }
        return list;
    }



}
