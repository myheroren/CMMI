package com.huatonghh.oa.data_sync_dto;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * Description : 请求报文头部定义
 * @author : Sun
 * @date : 2019/10/11 15:38
 * @version : 1.0
 */
@Data
public class RequestShead {

    /** 请求方系统编号 */
    @JsonProperty(value = "requestId")
    @JSONField(name ="requestId")
    private String requestId;

    /** 目标系统编号 */
    private String targetId;

    /** 服务编号 */
    private String serviceId;

    /** 消息发送时间戳 */
    private String timestamp;

    /** 交易流水号 */
    private String seqNo;

    /** 全局交易流水号 */
    private String transNo;



}
