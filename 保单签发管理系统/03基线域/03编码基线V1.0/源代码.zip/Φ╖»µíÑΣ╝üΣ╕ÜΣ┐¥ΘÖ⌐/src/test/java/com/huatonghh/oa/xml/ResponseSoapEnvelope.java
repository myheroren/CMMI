package com.huatonghh.oa.xml;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import lombok.Data;

/**
 * Description : <soap:Envelope>节点</soap:Envelope>
 * @author : Sun
 * @date : 2019/10/11 15:59
 * @version : 1.0
 */
@Data
@XStreamAlias("soap:Envelope")
public class ResponseSoapEnvelope {

    @XStreamAsAttribute
    @XStreamAlias("xmlns:soap")
    private String xmlns;

    @XStreamAlias("soap:Body")
    private ResponseSoapBody responseSoapBody;



}
