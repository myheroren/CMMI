package com.huatonghh.oa.xml;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import lombok.Data;

/**
 * Description : <soapenv:Envelope>节点</soapenv:Envelope>
 * @author : Sun
 * @date : 2019/10/11 15:59
 * @version : 1.0
 */
@Data
@XStreamAlias("soapenv:Envelope")
public class RequestSoapenvEnvelope {

    @XStreamAsAttribute
    @XStreamAlias("xmlns:soapenv")
    private String xmlnsSoapenv;

    @XStreamAsAttribute
    @XStreamAlias("xmlns:xsd")
    private String xmlnsXsd;

    @XStreamAsAttribute
    @XStreamAlias("xmlns:xsi")
    private String xmlnsXsi;

    @XStreamAlias("soapenv:Body")
    private RequestSoapenvBody soapenvBody;



}
