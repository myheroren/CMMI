package com.huatonghh.oa.data_sync_dto;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * Description : 公司 反参，将此对象转为Json
 *
 * @author : Sun
 * @date : 2019/10/11 15:38
 * @version : 1.0
 */
@Data
public class ResponseCompany {

    @JsonProperty(value = "SHEAD")
    @JSONField(name ="SHEAD")
    private ResponseShead responseShead;

}
