package com.huatonghh.orika;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.lang.Console;
import ma.glasnost.orika.MappingContext;
import ma.glasnost.orika.converter.BidirectionalConverter;
import ma.glasnost.orika.metadata.Type;
import org.springframework.util.unit.DataUnit;

import java.util.Date;

/**
 * @author : Sun
 * @description : 
 * @date : 2019/11/20 10:21
 * @version : 1.0
 */
public class MyConverter extends BidirectionalConverter<Date,String> {

    @Override
    public String convertTo(Date source, Type<String> destinationType, MappingContext mappingContext) {
        Console.log(1);
        return source.toString();
    }

    @Override
    public Date convertFrom(String source, Type<Date> destinationType, MappingContext mappingContext) {
        Console.log(2);
        return DateUtil.date();
    }
}
