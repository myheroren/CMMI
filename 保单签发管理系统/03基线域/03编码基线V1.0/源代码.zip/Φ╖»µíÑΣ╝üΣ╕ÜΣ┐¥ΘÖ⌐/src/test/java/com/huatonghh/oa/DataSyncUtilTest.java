package com.huatonghh.oa;

import cn.hutool.core.lang.Console;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import lombok.Data;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.junit.Ignore;
import org.junit.Test;

import java.io.IOException;
import java.util.List;


@Ignore
public class DataSyncUtilTest {

    @Test
    public void simpleWrite() {
        /*String jsonStr = "{\"B\":\"value2\",\"c\":\"value3\",\"a\":\"value1\"}";
        JSONObject jsonObject = JSONUtil.parseObj(jsonStr);
        A a = JSONUtil.toBean(jsonObject, A.class);
        Console.log(a);*/
        String casHtml = HttpUtil.get("http://47.112.107.16:10000/cas/login?service=https://huatonghh.cn/new_enterprise_insurance_front/login");
        Console.log(casHtml);
    }

    @Data
    class A {
        @JSONField(name ="B")
        @JsonProperty(value = "B")
        private String b;
        private String c;
        private String a;

    }




    //json字符串-简单对象型
    private static final String  JSON_OBJ_STR = "{\"studentName\":\"lily\",\"studentAge\":12}";

    //json字符串-数组类型
    private static final String  JSON_ARRAY_STR = "[{\"studentName\":\"lily\",\"studentAge\":12},{\"studentName\":\"lucy\",\"studentAge\":15}]";

    //复杂格式json字符串
    private static final String  COMPLEX_JSON_STR = "{\"teacher_name\":\"crystall\",\"teacherAge\":27,\"course\":{\"courseName\":\"english\",\"code\":1270},\"students\":[{\"studentName\":\"lily\",\"studentAge\":12},{\"studentName\":\"lucy\",\"studentAge\":15}]}";



    /**
     * Description : json <=> JavaBean
     * @author : Sun
     * @date : 2019/10/11 9:34
     */
    @Test
    public void jsonToJavaBean() {
        Teacher teacher = JSONObject.parseObject(COMPLEX_JSON_STR, Teacher.class);

        System.out.println(teacher.getTeacherName());
        System.out.println(teacher.getCourse().getCourseName());
        System.out.println(teacher.getStudents().get(1).getStudentName());

        //转成json字符串
        String jsonString = JSONObject.toJSONString(teacher);
        System.out.println(jsonString);
    }

    @Data
    static class Teacher {
        @JsonProperty(value = "teacher_name")
        @JSONField(name ="teacher_name")
        private String teacherName;
        private Integer teacherAge;
        private Course course;
        private List<Student> students;

        public Teacher(String teacherName, Integer teacherAge, Course course, List<Student> students) {
            this.teacherName = teacherName;
            this.teacherAge = teacherAge;
            this.course = course;
            this.students = students;
        }

        public Teacher() {
        }

        @Override
        public String toString() {
            return "Teacher{" +
                "teacherName='" + teacherName + '\'' +
                ", teacherAge=" + teacherAge +
                ", course=" + course +
                ", students=" + students +
                '}';
        }
    }


    @Data
    static class Course {

        private String courseName;
        private Integer code;

        public Course() {
        }

        public Course(String courseName, Integer code) {
            this.courseName = courseName;
            this.code = code;
        }

        @Override
        public String toString() {
            return "Course{" +
                "courseName='" + courseName + '\'' +
                ", code=" + code +
                '}';
        }
    }


    @Data
    static class Student {

        private String studentName;
        private Integer studentAge;

        public Student() {
        }

        public Student(String studentName, Integer studentAge) {
            this.studentName = studentName;
            this.studentAge = studentAge;
        }

        @Override
        public String toString() {
            return "Student{" +
                "studentName='" + studentName + '\'' +
                ", studentAge=" + studentAge +
                '}';
        }
    }



    /**
     * Description : 1.根据json请求webservice，代码正确，但是无法用于交投OA对接
     * @author : Sun
     * @date : 2019/10/11 9:36
     */
    @Test
    public void webserviceTest() {
        String s = "{\"SHEAD\":{\"requestId\":\"people\",\"targetId\":\"CSS\",\"serviceId\":\"XXService\",\"timestamp\":\"2019-10-09 19:47:53\",\"userId\":\"test\",\"password\":\"test\",\"seqNo\":\"ICM2016101011050100200001\",\"transNo\":\"GICM2016101011050100200001\"},\"Body\":{\"WorkType\":\"All\"}}";

        String s1 = "{\"Body\":{\"EMPLOYEE_NAME\":\"潘磊\",\"WorkType\":\"CodeCheck\",\"EMPLOYEE_ID\":\"8235\"},\"SHEAD\":{\"serviceId\":\"TB_STA_gongsiService\",\"targetId\": \"HR\",\"requestId\":\"people\"}}";
        try {
            // 接口地址
            // 代理工厂
            JaxWsProxyFactoryBean jaxWsProxyFactoryBean = new JaxWsProxyFactoryBean();
            // 设置代理地址
            jaxWsProxyFactoryBean.setAddress("http://8.8.1.28:16601/services/TB_STA_gongsiService");
            // 设置接口类型
            jaxWsProxyFactoryBean.setServiceClass(GongSiService.class);
            //
            GongSiService cs = (GongSiService) jaxWsProxyFactoryBean.create();
            // 调用代理接口的方法调用并返回结果
            String result = cs.selectAll(s1);
            System.out.println("返回结果:" + result);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
    

    /**
     * Description : 1.POST请求直接获取交投OA数据，使用Nginx转发
     * @author : Sun
     * @date : 2019/10/11 9:37
     */
    @Test
    public void test() throws IOException {
        String json = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><soapenv:Body><selectAll xmlns=\"http://service.ws.standard.ft.com/\"><arg0 xmlns=\"\">{\"Body\":{\"EMPLOYEE_NAME\":\"潘磊\",\"WorkType\":\"CodeCheck\",\"EMPLOYEE_ID\":\"8235\"},\"SHEAD\":{\"serviceId\":\"TB_STA_gongsiService\",\"targetId\": \"HR\",\"requestId\":\"people\"}}</arg0></selectAll></soapenv:Body></soapenv:Envelope>";

        HttpResponse execute = HttpRequest.post("http://localhost/oa/services/TB_STA_gongsiService")
//            .setProxy(new Proxy(Proxy.Type.HTTP, new InetSocketAddress("127.0.0.1", 8087)))
            .body(json)
            .execute();

        Console.log(execute.body());

        /*String responseJson = "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body><ns2:selectAllResponse xmlns:ns2=\"http://service.ws.standard.ft.com/\"><return>{\"SHEAD\":{\"arrayList\":\"[{\"bIRTHDATEss\":\"1984年04月\",\"c_COMPANY_HID\":\"a660caa6c4aa4037bab67590e05ffdbf\",\"c_COMPANY_NAME\":\"广西计算中心有限责任公司\",\"c_DEPT_HID\":\"de1bf9f296954ec1bb9b4968d79d030a\",\"c_DEPT_NAME\":\"综合部\",\"c_DYXLSXZYss\":\"广西师范大学/教育经济与管理\",\"c_EMPLOYEE_NAME\":\"潘磊\",\"c_First_Work_Date\":\"2010年07月\",\"c_GENDER\":\"男\",\"c_JOIN_DATE\":\"9年\",\"c_NATIVEPLACE\":\"广西桂林市\",\"c_POSITION_HID\":\"5d37b06dd3f84e289227aee508b333c0\",\"c_POSITION_NAME\":\"综合部主任兼董事会秘书\",\"c_POSITION_NAMESS\":\"广西计算中心有限责任公司/综合部主任兼董事会秘书\",\"c_ZGXLSXZYss\":\"广西师范大学/教育经济与管理\",\"c_ZYJSZGss\":\"高级经济师\",\"nATION\":\"汉族\",\"pOLITYss\":\"中共党员\"}]\",\"ftpPath\":\"ftp://8.8.5.73:21/d506bbcf1f14422ca4dc42fd62f92673.xls\",\"requestId\":\"people\",\"ret\":\"[{\"retCode\":\"000000\",\"retMessage\":\"成功\"}]\",\"retType\":\"Y\",\"serviceId\":\"TB_STA_gongsiService\",\"targetId\":\"HR\"}}</return></ns2:selectAllResponse></soap:Body></soap:Envelope>";
        String responseJson1 = "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">1</soap:Envelope>";
        Document docResult=XmlUtil.readXML(responseJson1);
        Object value = XmlUtil.getByXPath("//soap:Envelope", docResult, XPathConstants.STRING);
        Console.log(value);*/
        /*Document xml = XmlUtil.createXml();
        String s = XmlUtil.toStr(xml);
        Console.log(s);*/
    }


    /**
     * Description : JavaBean <=> 复杂XML
     * @author : Sun
     * @date : 2019/10/11 9:38
     */
    @Test
    public void test1() {
        Person bean =new Person("张三","李四","王五","赵六", new Sun("sunsunsunsun"));
        XStream xstream = new XStream();
//        xstream.omitField(Person.class, "friends");//把字段节点隐藏
        //序列化
//        xstream.alias("entity.Person", Person.class);//给List类型指定别名为china
        xstream.autodetectAnnotations(true);//自动检测注解

        String xml = xstream.toXML(bean);
        System.out.println(xml);

        XStream xstream1 = new XStream();
        xstream1.processAnnotations(Person.class);//应用Person类的注解
//        xstream.alias("entity.Person", Person.class);
//        String xml1 = "<?xml version=\"1.0\" ?><entity.Person><id1>张三</id1><name>李四</name><gender>王五</gender><birthday>赵六</birthday></entity.Person>";
//        String xml1 = "<?xml version=\"1.0\" ?><entity.Person name=\"李四\"><id1>张三</id1><gender>王五</gender><birthday>赵六</birthday></entity.Person>";
        String xml1 = "<?xml version=\"1.0\" ?><entity.Person name=\"李四\"><id1>张三</id1><gender>王五</gender><birthday>赵六</birthday><entity.sun:yes><sun:name>sunsunsunsun</sun:name></entity.sun:yes></entity.Person>";
        Person person1 = (Person) xstream1.fromXML(xml1);
        System.out.println(person1);
    }

    @Data
    @XStreamAlias("entity.Person")
    static class Person {
        @XStreamAlias("id1")
        private String id;

        @XStreamAsAttribute
        private String name;
        private String gender;
        private String birthday;

        @XStreamAlias("entity.sun:yes")
        private Sun sun;

        public Person(String id, String name, String gender, String birthday, Sun sun) {
            this.id = id;
            this.name = name;
            this.gender = gender;
            this.birthday = birthday;
            this.sun = sun;
        }

    }

    @Data
//    @XStreamAlias("entity.sun")
    static class Sun {
        @XStreamAlias("sun:name")
        private String sunName;

        public Sun(String sunName) {
            this.sunName = sunName;
        }
    }

}



