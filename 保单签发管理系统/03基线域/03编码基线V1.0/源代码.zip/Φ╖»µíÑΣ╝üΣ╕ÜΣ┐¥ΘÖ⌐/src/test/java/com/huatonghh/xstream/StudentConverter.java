package com.huatonghh.xstream;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;

/**
 * @author : Sun
 * @program : enterprise-insurance-back
 * @description :
 * @create : 2019-11-20 17:57
 **/
public class StudentConverter implements Converter {
    public boolean canConvert(Class clazz) {
        return clazz.equals(Student.class);
    }
    public void marshal(Object value, HierarchicalStreamWriter writer,
                        MarshallingContext context) {
        Student student = (Student ) value;
        writer.startNode("name");
        writer.setValue(student.getName());
        writer.endNode();
        writer.startNode("age");
        writer.setValue(student.getAge());
        writer.endNode();
        writer.startNode("teacher");
        String teacher = student.getTeacher();
        if(teacher == null)
            writer.setValue("");
        else
            writer.setValue(teacher);
        writer.endNode();
    }
    public Object unmarshal(HierarchicalStreamReader reader,
                            UnmarshallingContext context) {
        Student student = new Student();
        student.setName(reader.getNodeName());
        student.setAge(reader.getNodeName());
        student.setTeacher(reader.getNodeName());
        return student;
    }
}




