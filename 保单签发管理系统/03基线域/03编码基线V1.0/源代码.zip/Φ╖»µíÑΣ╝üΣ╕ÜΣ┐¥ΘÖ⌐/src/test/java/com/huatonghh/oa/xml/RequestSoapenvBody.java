package com.huatonghh.oa.xml;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import lombok.Data;

/**
 * Description : <soapenv:Body>节点</soapenv:Body>
 * @author : Sun
 * @date : 2019/10/11 16:01
 * @version : 1.0
 */
@Data
public class RequestSoapenvBody {

    @XStreamAlias("selectAll")
    private RequestSelectAll selectAll;

}
