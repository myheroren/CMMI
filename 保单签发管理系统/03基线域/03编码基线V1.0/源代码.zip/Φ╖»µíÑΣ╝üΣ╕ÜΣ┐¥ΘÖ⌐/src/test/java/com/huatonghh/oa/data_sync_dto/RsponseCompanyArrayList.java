package com.huatonghh.oa.data_sync_dto;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * Description :
 * @author : Sun
 * @date : 2019/10/11 17:21
 * @version : 1.0
 */
@Data
public class RsponseCompanyArrayList {

    @JsonProperty(value = "c_hid")
    @JSONField(name ="c_hid")
    private String cHid;

    @JsonProperty(value = "c_level")
    @JSONField(name ="c_level")
    private String cLevel;

    @JsonProperty(value = "c_name")
    @JSONField(name ="c_name")
    private String cName;

    @JsonProperty(value = "c_superior_hid")
    @JSONField(name ="c_superior_hid")
    private String cSuperiorHid;

    @JsonProperty(value = "type")
    @JSONField(name ="type")
    private String type;

}
