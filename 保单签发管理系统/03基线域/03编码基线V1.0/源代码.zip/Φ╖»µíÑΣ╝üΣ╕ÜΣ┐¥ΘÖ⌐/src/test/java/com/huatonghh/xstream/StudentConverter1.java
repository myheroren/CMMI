package com.huatonghh.xstream;

import com.thoughtworks.xstream.converters.SingleValueConverter;

public class StudentConverter1 implements SingleValueConverter {
    @Override
    public String toString(Object o) {

        return null;
    }

    @Override
    public Object fromString(String s) {
        return null;
    }

    @Override
    public boolean canConvert(Class aClass) {
        return false;
    }
}




