package com.huatonghh.xstream;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;

/**
 * @author : Sun
 * @program : enterprise-insurance-back
 * @description :
 * @create : 2019-11-20 17:57
 **/
public class App1{
    public static void main(String args[]) {
//        XStream stream = new XStream(new StaxDriver());
//        Student st = new Student();
//        st.setName("ABC");
//        st.setAge("21");
////        stream.registerConverter(new StudentConverter());
////        stream.registerConverter(new StudentConverter1());
////        stream.alias("student", Student.class);
//        System.out.println(stream.toXML(st));

    }

}
