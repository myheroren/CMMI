package com.huatonghh.orika;

import lombok.Data;

import java.util.Date;

/**
 * @author : Sun
 * @program : enterprise-insurance-back
 * @description :
 * @create : 2019-11-18 20:03
 **/
@Data
public class MapperCopy {
    private String name;
    private Date age;
    private SS ss;
    private SSS sss;
}
