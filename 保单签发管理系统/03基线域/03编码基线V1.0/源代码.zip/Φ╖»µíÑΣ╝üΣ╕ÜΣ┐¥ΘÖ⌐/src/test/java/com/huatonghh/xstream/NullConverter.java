package com.huatonghh.xstream;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author : Sun
 * @description : 
 * @date : 2019/11/20 17:32
 * @version : 1.0
 */
public class NullConverter implements Converter {
    private Map<Class<?>, List<String>> attributes = null;

    public void regAttribute(Class<?> type, String attribute) {
        if (null == attributes) {
            attributes = new HashMap<>();
        }

        List value = attributes.get(type);
        if (null == value)
        {
        value = new ArrayList<String>();
        attributes.put(type, value);
        }

        value.add(attribute);
    }

    @Override
    public void marshal(Object o, HierarchicalStreamWriter hierarchicalStreamWriter, MarshallingContext marshallingContext) {

    }

    @Override
    public Object unmarshal(HierarchicalStreamReader hierarchicalStreamReader, UnmarshallingContext unmarshallingContext) {
        return null;
    }

    @Override
    public boolean canConvert(Class aClass) {
        return false;
    }
}
