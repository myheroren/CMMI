package com.huatonghh.oa.xml;

import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamConverter;
import com.thoughtworks.xstream.annotations.XStreamOmitField;
import com.thoughtworks.xstream.converters.basic.BooleanConverter;
import com.thoughtworks.xstream.converters.extended.ToAttributedValueConverter;
import lombok.Data;

/**
 * Description : <arg0>节点</arg0>
 * @author : Sun
 * @date : 2019/10/11 16:01
 * @version : 1.0
 */
@Data
@XStreamConverter(value= ToAttributedValueConverter.class, strings={"reqeust"})
public class RequestArgZero {

    @XStreamAsAttribute
    private String xmlns;

    // request无节点，其为RequestArgZero的值
    private String reqeust;

    
    

}
