package com.huatonghh.oa.data_sync_dto;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * Description : 请求报文头部定义
 * @author : Sun
 * @date : 2019/10/11 15:38
 * @version : 1.0
 */
@Data
public class ResponseShead {

    private List<RsponseCompanyArrayList> arrayList;

    /** 请求方系统编号 */
    @JsonProperty(value = "requestId")
    @JSONField(name ="requestId")
    private String requestId;

    /** 目标系统编号 */
    private String targetId;

    /** 服务编号 */
    private String serviceId;

    /** 消息发送时间戳 */
    private String timestamp;

    /** 交易流水号 */
    private String seqNo;

    /** 全局交易流水号 */
    private String transNo;

    /** 返回类型 */
    private String retType;

    /** 返回信息集 */
    private List<ResponseRet> ret;

    /** 返回代码 */
    private String retCode;

    /** 返回的技术/业务响应信息 */
    private String retMessage;

}
