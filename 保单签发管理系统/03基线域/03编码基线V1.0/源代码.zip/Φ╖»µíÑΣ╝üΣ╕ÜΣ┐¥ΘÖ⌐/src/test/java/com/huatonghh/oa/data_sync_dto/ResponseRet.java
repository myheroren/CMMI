package com.huatonghh.oa.data_sync_dto;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * Description :
 * @author : Sun
 * @date : 2019/10/11 17:19
 * @version : 1.0
 */
@Data
public class ResponseRet {

    private String retCode;

    private String retMessage;

}
