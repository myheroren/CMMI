package com.huatonghh.oa;

import cn.hutool.core.lang.Console;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import com.alibaba.fastjson.JSONObject;
import com.huatonghh.authority.domain.EiDepart;
import com.huatonghh.authority.repository.EiDepartRepository;
import com.huatonghh.oa.data_sync_dto.RequestComPanyBody;
import com.huatonghh.oa.data_sync_dto.RequestCompany;
import com.huatonghh.oa.data_sync_dto.RequestShead;
import com.huatonghh.oa.data_sync_dto.ResponseCompany;
import com.huatonghh.oa.xml.*;
import com.thoughtworks.xstream.XStream;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;


/**
 * Description : 数据同步
 * @author : Sun
 * @date : 2019/10/11 15:30
 * @version : 1.0
 */
@Ignore
public class DataSyncTest {

    @Autowired
    private EiDepartRepository eiDepartRepository;

    @Test
    public void syncComPanyData() {
        // 1.生成请求Json
        RequestCompany request = new RequestCompany();
        // 1.1组装Body
        RequestComPanyBody body = new RequestComPanyBody();
        body.setWorkType("All");
        request.setComPanyBody(body);

        // 1.2组装SHEAD
        RequestShead shead = new RequestShead();
        shead.setServiceId("TB_STA_gongsiService");
        shead.setTargetId("HR");
        shead.setRequestId("people");
        request.setSheadRequest(shead);

        String jsonString = JSONObject.toJSONString(request);
        System.out.println(jsonString);

        // 2.将Json封装，并由实体转化成ws xml
        XStream xstream = new XStream();
        xstream.autodetectAnnotations(true);//自动检测注解

        RequestArgZero argZero = new RequestArgZero();
        argZero.setXmlns("");
        argZero.setReqeust(jsonString);

        RequestSelectAll selectAll = new RequestSelectAll();
        selectAll.setArgZero(argZero);
        selectAll.setXmlns("http://service.ws.standard.ft.com/");

        RequestSoapenvBody soapenvBody = new RequestSoapenvBody();
        soapenvBody.setSelectAll(selectAll);

        RequestSoapenvEnvelope soapenv = new RequestSoapenvEnvelope();
        soapenv.setXmlnsXsi("http://www.w3.org/2001/XMLSchema-instance");
        soapenv.setXmlnsSoapenv("http://schemas.xmlsoap.org/soap/envelope/");
        soapenv.setXmlnsXsd("http://www.w3.org/2001/XMLSchema");
        soapenv.setSoapenvBody(soapenvBody);

        String xml = xstream.toXML(soapenv);
        System.out.println(xml);

        // 3.对xml进行post请求
        HttpResponse execute = HttpRequest.post("http://localhost/oa/services/TB_STA_gongsiService")
            .body(xml)
            .execute();
        String response = execute.body();
        Console.log(response);

        // 4.接收反参，解析xml为对象
        XStream xstreamResponse = new XStream();
        xstreamResponse.processAnnotations(ResponseSoapEnvelope.class);//应用ResponseSoapEnvelope类的注解
        ResponseSoapEnvelope responseSoapEnvelope = (ResponseSoapEnvelope) xstreamResponse.fromXML(response);

        // 5.根据对象获取【return】的值
        String resqonseBody = responseSoapEnvelope.getResponseSoapBody().getResponseNsTwoSelectAll().getReturnJson();
        Console.log(resqonseBody);

        // 6.将【return】的Json串解析为JavaBean
        String replaceLeft = resqonseBody.replaceAll("\"\\[", "[");
        String replaceRight = replaceLeft.replaceAll("]\"", "]");
        ResponseCompany responseCompany = JSONObject.parseObject(replaceRight, ResponseCompany.class);

        // 7.根据JavaBean获取相应信息
        Console.log(responseCompany.toString());

    }

}
