package com.huatonghh.policy.service.dto.project;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigInteger;
import java.util.Date;

/**
 * @author : hao.wang
 * @date :  2019/8/27
 * description:
 */
@Data
@ApiModel("项目")
public class ProjectDTO {
    private static final long serialVersionUID=430727415364768647L;
    @ApiModelProperty(value = "保险项目编号,如PR20200928001")
    private String projNo;

    @ApiModelProperty(value = "ins_plan的保险计划编号")
    private String planNo;

    @ApiModelProperty(value = "保险项目名称")
    private String projName;

    @ApiModelProperty(value = "发起公司")
    private String startCompany;

    @ApiModelProperty(value = "发起公司")
    private String startCompanyName;

    @ApiModelProperty(value = "发起人")
    private String startUser;

    @ApiModelProperty(value = "保险类别")
    private String riskKind;

    @ApiModelProperty(value = "预估保险金额")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger estAmount;

    @ApiModelProperty(value = "预估总保费")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger estPremium;

    @ApiModelProperty(value = "合同工期")
    private Integer duration;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "归属保险公司")
    private String belongCompany;

    @ApiModelProperty(value = "授权文件名")
    private String fileName;

    @ApiModelProperty(value = "授权文件Id")
    private Integer fileId;

    @ApiModelProperty(value = "保险计划状态，0暂存,1审核中,2被驳回,3审核完成,4招标完成")
    private Byte status;

    @ApiModelProperty(value = "创建时间",example = "2020-10-01 12:18:48")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    @ApiModelProperty(value = "更新时间",example = "2020-10-01 12:18:48")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    @ApiModelProperty(value = "关联保单号")
    private String policyNo;

}
