package com.huatonghh.message.service.sender;

import com.huatonghh.message.po.dto.MessageThirdPartyDTO;
import org.springframework.stereotype.Service;

/**
 * @author wanggl
 * @date 2020-11-02 20:37
 */
@Service
public class SmsSender implements MessageSender {
    @Override
    public boolean sendMessage(MessageThirdPartyDTO message) {
        return false;
    }
}
