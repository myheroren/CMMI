package com.huatonghh.authority.domain;

import lombok.Data;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author : Sun
 * @description : 交投集团-用户-数据库映射实体
 * @date : 2019/11/4 19:42
 * @version : 1.0
 */
@Entity
@Table(name = "ei_user_hr")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Data
public class EiHrUser implements Serializable {

    private static final long serialVersionUID = -597649964085048405L;

    @Id
    private String id;

    @Column(name = "account_id")
    private String userName;

    @Column(name = "employee_no")
    private String employeeNo;

    @Column(name = "employee_name")
    private String name;

    @Column(name = "is_valid")
    private Boolean valid;

}
