package com.huatonghh.authority.repository;

import com.huatonghh.authority.domain.EiWorkFlow;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/30
 */
public interface EiWorkFlowRepository extends JpaRepository<EiWorkFlow, Integer> {
}
