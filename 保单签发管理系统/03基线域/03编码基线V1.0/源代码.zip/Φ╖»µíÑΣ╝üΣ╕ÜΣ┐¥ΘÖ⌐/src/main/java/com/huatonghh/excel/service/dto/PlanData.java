package com.huatonghh.excel.service.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import lombok.Data;

/**
 * @author : hao.wang
 * @version : 1.0
 * @description : 计划导出
 * @date : 2019/12/14
 */
@Data
@ContentRowHeight(20)
@HeadRowHeight(20)
@ColumnWidth(15)
public class PlanData {
    @ExcelProperty(value = "计划编号", index = 0)
    private String planNo;
    @ExcelProperty(value = "计划名称", index = 1)
    private String planName;
    @ExcelProperty(value = "计划类别", index = 2)
    private String planType;
    @ExcelProperty(value = "发起公司", index = 3)
    private String startCompanyName;
    @ExcelProperty(value = "发起人", index = 4)
    private String startUserName;
    @ExcelProperty(value = "计划保费合计（元）", index = 5)
    private String estTotalPremium;
    @ExcelProperty(value = "项目编号", index = 6)
    private String projNo;
    @ExcelProperty(value = "险种类别", index = 7)
    private String riskKind;
    @ExcelProperty(value = "投保数量", index = 8)
    private Integer insureNumber;
    @ExcelProperty(value = "预计保额（元）", index = 9)
    private String estAmount;
    @ExcelProperty(value = "预计保费（元）", index = 10)
    private String estPremium;
    @ExcelProperty(value = "状态", index = 11)
    private String mainStatus;
    @ExcelProperty(value = "环节", index = 12)
    private String currentTache;
    @ExcelProperty(value = "备注", index = 13)
    private String remark;

}
