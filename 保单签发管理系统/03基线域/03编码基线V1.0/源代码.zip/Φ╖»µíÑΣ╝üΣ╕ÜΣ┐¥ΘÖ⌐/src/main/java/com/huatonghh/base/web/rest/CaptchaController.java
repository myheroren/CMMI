package com.huatonghh.base.web.rest;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.hutool.captcha.CaptchaUtil;
import cn.hutool.captcha.LineCaptcha;
import cn.hutool.core.util.IdUtil;
import com.google.code.kaptcha.Producer;
import com.huatonghh.common.constant.CommonConstants;
import com.huatonghh.common.constant.enums.StatusEnum;
import com.huatonghh.common.service.RedisService;
import com.huatonghh.common.util.hutool.Base64;
import com.huatonghh.common.util.hutool.IdUtils;
import com.huatonghh.common.util.hutool.VerifyCodeUtils;
import com.huatonghh.common.util.system.ApiResponse;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static java.lang.System.out;

/**
 * 验证码操作处理
 * 
 * @author ruoyi
 */
@RestController
@RequestMapping("/api/captcha/v1")
@Api(tags="23、验证码", value = "验证码 生成")
@Slf4j
//@AllArgsConstructor
public class CaptchaController
{
    @Autowired
    private RedisService redisService;

    @Resource(name = "captchaProducer")
    private Producer captchaProducer;

    @Resource(name = "captchaProducerMath")
    private Producer captchaProducerMath;


    /**
     * 生成验证码
     */
    @GetMapping("/captchaImage")
    public ApiResponse getCode(HttpServletResponse response) throws IOException
    {
        // 生成随机字串
        String verifyCode = VerifyCodeUtils.generateVerifyCode(4);
        // 唯一标识
        String uuid = IdUtils.simpleUUID();
        String verifyKey = CommonConstants.CAPTCHA_CODE_KEY + uuid;
        redisService.set(verifyKey, verifyCode.toLowerCase());
        redisService.setExpireTime(verifyKey, CommonConstants.CAPTCHA_EXPIRATION, TimeUnit.MINUTES);

        // 生成图片
        int w = 111, h = 36;
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        VerifyCodeUtils.outputImage(w, h, stream, verifyCode);
        try
        {
            Map<String,Object> map = new HashMap<>();

            map.put("verifyuuid", uuid);
            map.put("img", Base64.encode(stream.toByteArray()));
            log.debug("verifyuuid:"+ uuid);
            log.debug("verifyCode:"+  verifyCode);
            return ApiResponse.ofSuccess(map);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return ApiResponse.ofStatus(StatusEnum.INTERNAL_SERVER_ERROR);
        }
        finally
        {
            stream.close();
        }
    }

    /**
     * 验证码生成
     */
    @GetMapping(value = "/captchaImg/{type}")
    public ApiResponse getKaptchaImage(HttpServletRequest request, HttpServletResponse response,@PathVariable(value = "type") String type)
    {

        try
        {
            // 生成随机字串
            String verifyCode = VerifyCodeUtils.generateVerifyCode(4);
            String uuid = IdUtils.simpleUUID();
            String verifyKey = CommonConstants.CAPTCHA_CODE_KEY + uuid;

            String capStr = null;
            String code = null;
            BufferedImage bi = null;
            if ("math".equals(type))
            {
                String capText = captchaProducerMath.createText();
                capStr = capText.substring(0, capText.lastIndexOf("@"));
                code = capText.substring(capText.lastIndexOf("@") + 1);
                bi = captchaProducerMath.createImage(capStr);
            }
            else if ("char".equals(type))
            {
                capStr = code = captchaProducer.createText();
                bi = captchaProducer.createImage(capStr);
            }
            redisService.set(verifyKey, capStr.toLowerCase());
            redisService.setExpireTime(verifyKey, CommonConstants.CAPTCHA_EXPIRATION, TimeUnit.MINUTES);
            //io流
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            //写入流中
            ImageIO.write(bi, "jpg", baos);
            //转换成字节
            byte[] bytes = baos.toByteArray();
            //转换成base64串
            String png_base64 =  Base64.encode(bytes).trim();

            Map<String,Object> map = new HashMap<>();

            map.put("verifyuuid", uuid);
//            map.put("code", code);
            map.put("img", png_base64);
            log.debug("verifyuuid: "+ uuid);
            log.debug("verifyCode: "+code);
            return ApiResponse.ofSuccess(map);

        }
        catch (Exception e)
        {
            e.printStackTrace();
            return ApiResponse.ofStatus(StatusEnum.INTERNAL_SERVER_ERROR);
        }
        finally
        {
            if (out != null)
            {
                out.close();
            }
        }

    }


    /**
     * @author Sun
     * @description 生成验证码
     * @date 2019/11/5 21:14
     * @return com.huatonghh.common.util.system.ApiResponse
     **/
    @GetMapping(value = "/captcha")
    public ApiResponse captcha() {
        // 定义图形验证码的长、宽、验证码字符数、干扰线宽度
        LineCaptcha captcha = CaptchaUtil.createLineCaptcha(100, 50, 4, 4);
        // 验证图形验证码的有效性，返回boolean值
        String captchaCode = captcha.getCode();

        // 存入缓存
        String simpleUUID = IdUtil.simpleUUID();
        String verifyKey = CommonConstants.CAPTCHA_CODE_KEY + simpleUUID;
        redisService.set(verifyKey, captchaCode);
        redisService.setExpireTime(verifyKey, CommonConstants.CAPTCHA_EXPIRATION, TimeUnit.MINUTES);

        // 定义验证码、img图片
        Map<String,Object> map = new HashMap<>(16);
        map.put("verifyuuid", simpleUUID);
        map.put("img", captcha.getImageBase64());
        log.debug("verifyuuid: "+ simpleUUID);
        log.debug("verifyCode: "+captchaCode);
        return ApiResponse.ofSuccess(map);
    }


}
