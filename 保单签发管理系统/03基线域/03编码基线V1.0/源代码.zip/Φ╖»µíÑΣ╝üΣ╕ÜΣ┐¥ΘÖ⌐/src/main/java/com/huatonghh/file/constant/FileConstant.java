package com.huatonghh.file.constant;

/**
 * @author : Sun
 * @description : 文件常亮类文件注释
 * @date : 2019/11/5 21:23
 * @version : 1.0
 */
public final class FileConstant {

    /** 支持在线预览的后缀 */
    public static final String EXTENSION_DOC  = "doc";
    public static final String EXTENSION_XLS  = "xls";
    public static final String EXTENSION_PPT  = "ppt";
    public static final String EXTENSION_DOCX  = "docx";
    public static final String EXTENSION_XLSX  = "xlsx";
    public static final String EXTENSION_PPTX  = "pptx";

    /** 浏览器可直接预览的后缀 */
    public static final String EXTENSION_TXT  = "^[(txt)|(xml)|(sql)]+$";
    public static final String EXTENSION_JPG  = "^[(jpg)|(jpeg)|(png)|(gif)]+$";
    public static final String EXTENSION_PDF  = "^[(pdf)]+$";

    public static final String VIEW_OFFICEAPPS  = "https://view.officeapps.live.com/op/view.aspx?src=";

    public FileConstant() {
    }
}
