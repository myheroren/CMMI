package com.huatonghh.fund.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

@Entity
@Table(name = "ei_ins_fund")
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel("基金")
public class EiInsFund implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    @ApiModelProperty("主键")
    private Integer id;

    /**
     * 所属保险公司
     */
    @Column(name = "belong_company")
    @ApiModelProperty("所属保险公司")
    private Integer belongCompany;

    /**
     * 总额
     */
    @Column(name = "total")
    @ApiModelProperty("基金总额")
    private BigDecimal total;

    /**
     * 已使用的
     */
    @Column(name = "used")
    @ApiModelProperty("使用基金数")
    private BigDecimal used;

    /**
     * 剩余的
     */
    @Column(name = "leftover")
    @ApiModelProperty("使用基金数")
    private BigDecimal left;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    @ApiModelProperty("记录时间")
    private Date createTime;

    /**
     * 备注
     */
    @Column(name = "remark")
    @ApiModelProperty("备注")
    private String remark;

}
