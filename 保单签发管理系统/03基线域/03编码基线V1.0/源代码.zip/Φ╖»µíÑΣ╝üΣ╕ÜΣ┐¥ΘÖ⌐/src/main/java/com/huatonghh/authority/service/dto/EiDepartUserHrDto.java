package com.huatonghh.authority.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author : Sun
 * @description : 交投集团-部门公司-数据库映射实体
 * @date : 2019/11/4 19:41
 * @version : 1.0
 */

@ApiModel(value = "公司、部门，用户,同步")
@Data
public class EiDepartUserHrDto implements Serializable {

    private static final long serialVersionUID = 2382896980380725919L;

    @ApiModelProperty(value = "用户所属公司")
    private String companyId;


    @ApiModelProperty(value = "用户所属部门")
    private String departId;

    @ApiModelProperty(value = "用户ID")
    private String userId;


}
