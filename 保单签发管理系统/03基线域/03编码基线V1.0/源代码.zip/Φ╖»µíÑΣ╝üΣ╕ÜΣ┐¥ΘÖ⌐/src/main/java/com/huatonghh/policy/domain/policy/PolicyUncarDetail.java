package com.huatonghh.policy.domain.policy;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

/**
 * Description : 保单详细信息-非车
 *
 * @author : Sun
 * @version : 1.0
 * @date : 2019/8/31 14:01
 */
@Entity
@Table(name = "policy_uncar_detail")
@Data
public class PolicyUncarDetail implements Serializable {

    private static final long serialVersionUID = 8107940585756947653L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private BigInteger id;

    @Column(name = "policy_no")
    private String policyNo;
    /**
     * 险种
     */
    @Column(name = "main_risk_duty")
    private String mainRiskDuty;
    /**
     * 总保额
     */
    @Column(name = "total_amount")
    private BigInteger totalAmount;
    /**
     * 手续费比例
     */
    @Column(name = "fee_prop")
    private String feeProp;
    /**
     * 签单日期
     */
    @Column(name = "issue_date")
    private Date issueDate;
    /**
     * 共保
     */
    @Column(name = "coinsurance_detail")
    private String coinsuranceDetail;
    /**
     * 实收日期
     */
    @Column(name = "paid_in_date")
    private Date paidInDate;

    @Column(name = "payment_type")
    private Byte paymentType;
    /**
     * 所属标段
     */
    @Column(name = "subordinate_bid")
    private String subordinateBid;
    /**
     * 工程名称
     */
    @Column(name = "engineering_name")
    private String engineeringName;
    /**
     * 保证期间
     */
    @Column(name = "guaranty_period")
    private String guarantyPeriod;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_time")
    private Date updateTime;

}
