package com.huatonghh.policy.repository;

import com.huatonghh.policy.domain.project.ProjectRelationEntity;
import com.huatonghh.policy.domain.project.ProjectRelationEntityPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @date : 2019/9/3
 */
@Transactional(rollbackFor = RuntimeException.class)
public interface ProjectRelationRepository extends JpaRepository<ProjectRelationEntity, ProjectRelationEntityPK> {

    /**
     * 根据汇总后项目编号找到汇总前的编号
     *
     * @param parentProjectNo 汇总后项目编号
     * @return 汇总前项目编号列表
     */
    @Query(value = "select r.child_project_no from ins_project_relation r where r.is_valid = 1 and r.parent_project_no = :parentProjectNo", nativeQuery = true)
    List<BigInteger> findProjectsByParentProjectNo(@Param("parentProjectNo") BigInteger parentProjectNo);


    List<ProjectRelationEntity> findAllByChildProjectNo(BigInteger childProjectNo);

    /**
     * 根据汇总前计划查一条记录
     *
     * @param childProjectNo
     * @param valid
     * @return
     */
    List<ProjectRelationEntity> findAllByChildProjectNoAndValid(BigInteger childProjectNo, Boolean valid);

    @Modifying
    @Query("update ProjectRelationEntity r set r.valid = :valid where r.childProjectNo = :childProjectNo")
    void update(@Param("valid") Boolean valid, @Param("childProjectNo") BigInteger childProjectNo);

    @Modifying
    @Query(value = "update ins_project_relation r set r.is_valid = :valid where r.child_project_no IN(\n" +
        "select p.proj_no from ins_project p where p.plan_no = :planNo" +
        ")",nativeQuery = true)
    void batchUpdate(@Param("valid") Boolean valid, @Param("planNo") BigInteger planNo);
}
