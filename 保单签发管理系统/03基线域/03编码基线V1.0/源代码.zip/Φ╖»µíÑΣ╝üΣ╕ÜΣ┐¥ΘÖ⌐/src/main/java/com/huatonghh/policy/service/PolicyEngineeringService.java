package com.huatonghh.policy.service;

import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.policy.domain.policy.PolicyEngineering;
import com.huatonghh.policy.repository.policy.PolicyEngineeringRepository;
import com.huatonghh.policy.service.dto.policy.PolicyEngineeringDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

/**
 * description: 工程险
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/22
 */
@Slf4j
@Service
@AllArgsConstructor
public class PolicyEngineeringService {

    private final PolicyEngineeringRepository engineeringRepository;

    private final ModelMapper modelMapper;

    public void save(@Valid PolicyEngineeringDTO engineeringDTO) {
        if (null == engineeringDTO) {
            return;
        }
        if (null == engineeringDTO.getId()) {
            if (null != this.findByPolicyNo(engineeringDTO.getPolicyNo())) {
                throw new BusinessException("已存在该保单");
            }
            engineeringRepository.save(modelMapper.map(engineeringDTO, PolicyEngineering.class));
        } else {
            PolicyEngineering old = this.checkExist(engineeringDTO.getId());
            PolicyEngineering engineeringNew = modelMapper.map(engineeringDTO, PolicyEngineering.class);
            if (!engineeringNew.equals(old)) {
                engineeringRepository.save(engineeringNew);
            }
        }
    }

    public PolicyEngineeringDTO findByPolicyNo(String policyNo) {
        List<PolicyEngineering> entities = engineeringRepository.findAllByPolicyNo(policyNo);
        if (null == entities || entities.isEmpty()) {
            return null;
        }
        return modelMapper.map(entities.get(0), PolicyEngineeringDTO.class);
    }

    public PolicyEngineering checkExist(BigInteger id) {
        Optional<PolicyEngineering> op = engineeringRepository.findById(id);
        if (op.isPresent()) {
            return op.get();
        }
        throw new BusinessException("数据不存在");
    }


}
