package com.huatonghh.policy.domain.policy.modify;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

/**
 * Description : 保单基本信息（车、非车）
 * @author : Sun
 * @date : 2019/8/31 14:01
 * @version : 1.0
 */
@Entity
@Table(name = "policy_main_modify")
@Data
public class PolicyMainModify implements Serializable {

    private static final long serialVersionUID = -4483461902206656052L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private BigInteger id;

    @Column(name = "policy_no")
    private String policyNo;

    @Column(name = "car_uncar_flag")
    private Byte carUncarFlag;

    @Column(name = "insurance_category")
    private String insuranceCategory;

    @Column(name = "kind_code")
    private String kindCode;

    @Column(name = "holder_name")
    private String holderName;

    @Column(name = "insured_name")
    private String insuredName;

    @Column(name = "project_no")
    private BigInteger projectNo;

    @Column(name = "start_company")
    private String startCompany;

    @Column(name = "belong_company")
    private String belongCompany;

    @Column(name = "total_premium")
    private BigInteger totalPremium;

    @Column(name = "policy_bgn_time")
    private Date policyBgnTime;

    @Column(name = "policy_end_time")
    private Date policyEndTime;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_time")
    private Date updateTime;

    @Column(name = "belong_company_person")
    private String belongCompanyPerson;

    @Column(name = "belong_company_phone")
    private String belongCompanyPhone;

    @Column(name = "status")
    private Byte status;

}
