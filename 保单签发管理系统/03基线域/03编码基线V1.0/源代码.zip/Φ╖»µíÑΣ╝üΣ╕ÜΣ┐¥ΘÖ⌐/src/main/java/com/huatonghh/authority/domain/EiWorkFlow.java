package com.huatonghh.authority.domain;


import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/30
 */
@Entity
@Table(name = "ei_work_flow")
@Data
public class EiWorkFlow {
    @Id
    private Integer level;
    private String description;
}
