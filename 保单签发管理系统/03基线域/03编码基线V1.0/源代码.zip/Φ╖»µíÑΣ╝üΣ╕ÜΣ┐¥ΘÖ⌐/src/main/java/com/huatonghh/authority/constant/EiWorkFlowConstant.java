package com.huatonghh.authority.constant;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/11
 */
public class EiWorkFlowConstant {
    public final static Integer WORK_FLOW_DEFAULT = 0;
    public final static Integer WORK_FLOW_LEADER = 1;
    public final static Integer WORK_FLOW_MANAGER = 2;
    public final static Integer WORK_FLOW_STAFF = 3;

    public static final Integer ROLE_THIRD_STAFF = 12;
    public static final Integer ROLE_THIRD_MANAGER = 10024;
    public static final Integer ROLE_THIRD_LEADER = 11;
    public static final Integer ROLE_SECOND_STAFF = 22;
    public static final Integer ROLE_SECOND_MANAGER = 10023;
    public static final Integer ROLE_SECOND_LEADER = 21;
    public static final Integer ROLE_FINANCE_STAFF = 32;
    public static final Integer ROLE_FINANCE_MANAGER = 10022;
    public static final Integer ROLE_FINANCE_LEADER = 31;
}
