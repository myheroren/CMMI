package com.huatonghh.ins_authority.domain;

import lombok.Data;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * @author : Sun
 * @description : 交投集团-权限菜单-数据库映射实体
 * @date : 2019/11/4 19:27
 * @version : 1.0
 */
@Entity
@Table(name = "ei_ins_authority")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Data
public class EiInsAuthority implements Serializable {

    private static final long serialVersionUID = -5839773663770401957L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "component")
    private String component;

    @Column(name = "name")
    private String name;

    @Column(name = "valid_status")
    private String status;

    @Column(name = "title")
    private String title;

    @Column(name = "icon")
    private String icon;

    @Column(name = "visible")
    private Boolean visible;

    @Column(name = "parent_id")
    private Integer parentId;

    @Column(name = "sort_number")
    private Integer sortNumber;

    @Override
    public String toString() {
        return "EiAuthority{" +
            "id=" + id +
            ", component='" + component + '\'' +
            '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof EiInsAuthority)) {
            return false;
        }
        EiInsAuthority that = (EiInsAuthority) o;
        return Objects.equals(id, that.id) &&
            Objects.equals(component, that.component);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, component);
    }

}
