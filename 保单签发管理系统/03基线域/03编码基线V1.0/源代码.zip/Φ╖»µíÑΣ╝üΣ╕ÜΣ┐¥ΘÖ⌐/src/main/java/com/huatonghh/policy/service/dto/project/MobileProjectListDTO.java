package com.huatonghh.policy.service.dto.project;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigInteger;

/**
 * description: 移动端计划列表
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2020/1/6
 */
@Data
@ApiModel("移动端计划、项目列表")
public class MobileProjectListDTO {
    @ApiModelProperty(value = "流程id")
    private String processId;
    @ApiModelProperty(value = "任务id")
    private String taskId;
    @ApiModelProperty(value = "计划编号")
    @JsonSerialize(using = ToStringSerializer.class)
    private String projNo;
    @ApiModelProperty("项目类别 1计划外项目，2计划内项目汇总前,3计划内项目汇总后,4中标项目")
    private Byte projType;
    @ApiModelProperty("发起公司id")
    private String startCompany;
    @ApiModelProperty("发起公司名字")
    private String startCompanyName;
    @ApiModelProperty("前端显示状态")
    private Byte mainStatus;
    @ApiModelProperty("预估总保费")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger estPremium;
    @ApiModelProperty("预估总保额")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger estAmount;
    @ApiModelProperty("保险类别")
    private String riskKind;
}
