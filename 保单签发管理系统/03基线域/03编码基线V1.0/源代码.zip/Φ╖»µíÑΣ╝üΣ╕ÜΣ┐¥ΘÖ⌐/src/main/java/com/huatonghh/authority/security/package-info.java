/**
 * Spring Security configuration.
 */
package com.huatonghh.authority.security;
