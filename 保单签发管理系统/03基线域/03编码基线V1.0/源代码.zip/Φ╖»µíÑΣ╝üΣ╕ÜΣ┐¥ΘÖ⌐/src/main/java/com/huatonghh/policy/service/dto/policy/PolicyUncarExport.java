package com.huatonghh.policy.service.dto.policy;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author wanggl
 * @date 2020-11-09 09:32
 */
@ContentRowHeight(16)
@HeadRowHeight(18)
@HeadFontStyle(fontHeightInPoints = 12)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PolicyUncarExport implements Serializable {

    @ExcelIgnore
    private static final long serialVersionUID = 328942504767190443L;

    @ExcelProperty(value = "保单号")
    private String policyNo;

    @ExcelProperty(value = "项目组织")
    private String projectName;

    @ExcelProperty(value = "保险公司")
    private String belongCompany;

    @ExcelProperty(value = "投保人")
    private String holderName;

    @ExcelProperty(value = "被保人")
    private String insuredName;

    @ExcelProperty(value = "险种名称")
    private String kindCode;

    @ExcelProperty(value = "保险起期")
    @DateTimeFormat(value = "yyyy-MM-dd")
    private Date policyBgnTime;

    @ExcelProperty(value = "保险止期")
    @DateTimeFormat(value = "yyyy-MM-dd")
    private Date policyEndTime;

    @ExcelProperty(value = "保费")
    private String totalPremium;

    @ExcelProperty(value = "状态")
    private String status;

}
