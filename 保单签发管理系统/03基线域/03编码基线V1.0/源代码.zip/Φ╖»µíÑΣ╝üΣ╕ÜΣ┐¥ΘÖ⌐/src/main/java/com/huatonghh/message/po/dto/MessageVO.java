package com.huatonghh.message.po.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.google.common.base.MoreObjects;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author wanggl
 * @date 2020-11-03 10:31
 */
@ApiModel("消息视图对象")
public class MessageVO implements Serializable {

    private static final long serialVersionUID = -3987228587322191228L;

    @ApiModelProperty(value = "消息id", position = 1)
    private Long id;

    @ApiModelProperty(value = "消息业务编号", position = 2)
    private String serviceCode;

    @ApiModelProperty(value = "消息来源", position = 3)
    private String source;

    @ApiModelProperty(value = "消息类型", position = 4)
    private String type;

    @ApiModelProperty(value = "标题", position = 5)
    private String title;

    @ApiModelProperty(value = "内容", position = 6)
    private String content;

    @ApiModelProperty(value = "路径", position = 7)
    private String path;

    @ApiModelProperty(value = "url", position = 8)
    private String url;

    @ApiModelProperty(value = "发送者", position = 9)
    private String sender;

    @ApiModelProperty(value = "用户编号", position = 10)
    private String userCode;

    @ApiModelProperty(value = "已读（0==未读，1==已读）", position = 11)
    private Byte read;

    @ApiModelProperty(value = "已读时间", position = 12)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime readTime;

    @ApiModelProperty(value = "创建时间", position = 13)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    public MessageVO() {
    }

    public MessageVO(Long id, String serviceCode, String source, String type, String title, String content, String path, String url, String sender, String userCode, Byte read, LocalDateTime readTime, LocalDateTime createTime) {
        this.id = id;
        this.serviceCode = serviceCode;
        this.source = source;
        this.type = type;
        this.title = title;
        this.content = content;
        this.path = path;
        this.url = url;
        this.sender = sender;
        this.userCode = userCode;
        this.read = read;
        this.readTime = readTime;
        this.createTime = createTime;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public Byte getRead() {
        return read;
    }

    public void setRead(Byte read) {
        this.read = read;
    }

    public LocalDateTime getReadTime() {
        return readTime;
    }

    public void setReadTime(LocalDateTime readTime) {
        this.readTime = readTime;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
            .add("id", id)
            .add("serviceCode", serviceCode)
            .add("source", source)
            .add("type", type)
            .add("title", title)
            .add("content", content)
            .add("path", path)
            .add("url", url)
            .add("sender", sender)
            .add("userCode", userCode)
            .add("read", read)
            .add("readTime", readTime)
            .add("createTime", createTime)
            .toString();
    }
}
