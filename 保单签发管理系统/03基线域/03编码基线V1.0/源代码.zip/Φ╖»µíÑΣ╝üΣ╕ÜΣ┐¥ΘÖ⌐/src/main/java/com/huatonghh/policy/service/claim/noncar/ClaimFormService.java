package com.huatonghh.policy.service.claim.noncar;

import cn.hutool.core.util.StrUtil;
import com.huatonghh.authority.domain.EiDepart;
import com.huatonghh.authority.service.EiDepartService;
import com.huatonghh.base.service.BaseCodeService;
import com.huatonghh.common.repository.DynamicQuery;
import com.huatonghh.common.util.DateFormatUtil;
import com.huatonghh.common.util.hutool.MoneyUtils;
import com.huatonghh.ins_authority.domain.EiInsDepart;
import com.huatonghh.ins_authority.service.EiInsDepartService;
import com.huatonghh.policy.constant.ClaimConstant;
import com.huatonghh.policy.service.PolicyService;
import com.huatonghh.policy.service.dto.claim.form.*;
import com.huatonghh.policy.service.dto.claim.noncar.ClaimFormQuery;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.Lists;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author : wh
 * description : 理赔报表
 * @version : 1.0
 * @date : 2020/3/10 01:36
 */
@Service
@Slf4j
@AllArgsConstructor
public class ClaimFormService {

    private final DynamicQuery dynamicQuery;

    private final PolicyService policyService;

    private final UnCarClaimService claimService;

    private final ModelMapper modelMapper;

    private final EiDepartService eiDepartService;

    private final EiInsDepartService insDepartService;

    private final BaseCodeService baseCodeService;

    public List<ClaimDetailFormDTO> detailForm(ClaimFormQuery query) {
        if (null == query.getPageNo()) {
            query.setPageNo(1);
            query.setPageSize(100000);
        }
        StringBuilder sql = this.getClaimDetailField();
        this.condition(sql, query);
        List<ClaimDetailFormDTO> list = this.listClaimByQuery(sql, query.getPageNo(), query.getPageSize());
        if (null == list || list.isEmpty()) {
            return null;
        }
        list.forEach(dto -> {
            if (null != dto.getPayAmount()) {
                dto.setCompensateEnd("是");
            } else {
                dto.setCompensateEnd("否");
            }
        });
        return list;
    }

    private StringBuilder getClaimDetailField() {
        return new StringBuilder("select m.insured_name insuredName\n" +
            ", e.eng_type engType \n" +
            ", c.accident_time accidentTime\n" +
            ", c.address\n" +
            ", c.accident_reason accidentReason\n" +
            ", c.pre_loss_amount  preLossAmount\n" +
            ", c.insure_type insureType\n" +
            ", c.claim_begin_date claimBeginDate\n" +
            ", c.report_name reportName\n" +
            ", c.ask_for_amount askForAmount\n" +
            ", c.receive_name receiveName\n" +
            ", c.receive_time receiveTime\n" +
            ", c.pay_amount payAmount\n" +
            ", c.claim_status claimStatus" +
            " FROM policy_uncar_claim c ,policy_main m,policy_engineering e" +
            " where 1=1 and c.policy_no = m.policy_no\n" +
            "and m.policy_no = e.policy_no");
    }

    private void condition(StringBuilder sql, ClaimFormQuery query) {
        if (null != query.getBeginTime() && null != query.getEndTime()) {
            sql.append(StrUtil.format(" AND c.create_time BETWEEN '{}' AND '{}' ", DateFormatUtil.dateToStr(query.getBeginTime(), "yyyy-MM-dd"), DateFormatUtil.dateToStr(query.getEndTime(), "yyyy-MM-dd")));
        }
    }

    private List<ClaimDetailFormDTO> listClaimByQuery(StringBuilder sqlBuild, Integer pageNum, Integer pageSize) {
        if (pageNum == null || pageSize == null) {
            log.info("根据条件查列表:{}", sqlBuild);
            return dynamicQuery.nativeQueryListModel(ClaimDetailFormDTO.class, sqlBuild.toString());
        } else {
            sqlBuild.append(" limit ?1, ?2 ");
            log.info("根据条件查列表:{}", sqlBuild);
            return dynamicQuery.nativeQueryListModel(ClaimDetailFormDTO.class, sqlBuild.toString(), (pageNum - 1) * pageSize, pageSize);
        }
    }

    public List<ClaimHighwayFormDTO> gatherForm(ClaimFormQuery query) {
        if (null == query.getPageNo()) {
            query.setPageNo(1);
            query.setPageSize(100000);
        }
        /*
        1、查出所有项目
        2、项目在这段时间的理赔
         */
        // 已经根据项目名称、类别分组的保单
        List<ClaimHighwayPolicyDTO> list = policyService.allEngPolicy();
        if (null == list || list.isEmpty()) {
            return null;
        }
        List<ClaimHighwayFormDTO> result = Lists.newArrayList();
        // 理赔
        for (ClaimHighwayPolicyDTO policy : list) {
            ClaimHighwayFormDTO dto = new ClaimHighwayFormDTO();
            modelMapper.map(policy, dto);
            EngClaimQuery claimQuery = new EngClaimQuery();
            modelMapper.map(query, claimQuery);
            claimQuery.setPolicyNos(policy.getPolicyNos());
            List<ClaimHighwayDetailDTO> claimDetails = claimService.allEngClaim(claimQuery);
            Long countClaim = claimService.getCountClaim(claimQuery, null);
            Long countGetClaim = claimService.getCountClaim(claimQuery, ClaimConstant.CLAIM_STATUS_DOWN + "");
            if (null == claimDetails || claimDetails.isEmpty()) {
                break;
            } else {
                ClaimHighwayDetailDTO detailDTO = claimDetails.get(0);
                // 索赔次数
                dto.setCountApply(Integer.valueOf(detailDTO.getCountApply().toString()));
                // 出险次数,除了报案
                dto.setCountClaim(Integer.valueOf(countClaim.toString()));
                dto.setCountGetClaim(Integer.valueOf(countGetClaim.toString()));

                // 损失额/估损金额
                BigDecimal preLossAmount = detailDTO.getPreLossAmount();
                if (null != preLossAmount) {
                    dto.setPreLossAmount(new BigInteger(preLossAmount.toString()));
                }
                // 赔偿额
                BigDecimal payAmount = detailDTO.getPayAmount();
                if (null != payAmount) {
                    dto.setPayAmount(new BigInteger(payAmount.toString()));
                }
                // 索赔金额
                BigDecimal askForAmount = detailDTO.getAskForAmount();
                if (null != payAmount) {
                    dto.setAskForAmount(new BigInteger(askForAmount.toString()));
                }
                // 获赔额占保费比率
                if (null != policy.getTotalPremium() && null != dto.getPayAmount()) {
                    dto.setRatePremium(MoneyUtils.rate(dto.getPayAmount(), new BigInteger(policy.getTotalPremium().toString())));
                }
                // 获赔额占索赔比率
                if (null != detailDTO.getAskForAmount()) {
                    dto.setRatePremium(MoneyUtils.rate(dto.getAskForAmount(), new BigInteger(detailDTO.getAskForAmount().toString())));
                }
            }
            result.add(dto);
        }


        return result;
    }

    /**
     * 标段统计表
     *
     * @param query 查询
     * @return 标段统计
     */
    public List<ClaimHighwayBidFormDTO> bidForm(ClaimFormQuery query) {
        if (null == query.getPageNo()) {
            query.setPageNo(1);
            query.setPageSize(100000);
        }
        StringBuilder sql = getClaimBidField();
        this.condition(sql, query);
        List<ClaimHighwayBidDTO> list = this.listClaimBidByQuery(sql, query.getPageNo(), query.getPageSize());
        if (null == list || list.isEmpty()) {
            return null;
        }
        List<ClaimHighwayBidFormDTO> results = Lists.newArrayList();
        // 根据标段分类
        Map<String, List<ClaimHighwayBidDTO>> map =
            list.stream().collect(Collectors.groupingBy(ClaimHighwayBidDTO::getBelongBid));

        map.forEach((bid, dtoList) -> {
            ClaimHighwayBidDTO d = dtoList.get(0);
            ClaimHighwayBidFormDTO form = new ClaimHighwayBidFormDTO();

            form.setBelongBid(bid);
            form.setAllInsured("是");

            if (null != d.getEngType()) {
                String engName = baseCodeService.queryCodeName("eng_type", d.getEngType() + "");
                form.setEngType(d.getEngType() + "");
                form.setEngTypeName(engName);
            }
            // 保险公司名字
            if (StringUtils.isBlank(d.getBelongCompanyName()) && StringUtils.isNotBlank(d.getBelongCompany())) {
                Optional<EiInsDepart> byId = insDepartService.findById(Integer.valueOf(d.getBelongCompany()));
                byId.ifPresent(depart -> form.setBelongCompanyName(depart.getName()));
            }
            // 发起公司
            if (StringUtils.isNotBlank(d.getStartCompany())) {
                Optional<EiDepart> byId = eiDepartService.findById(d.getStartCompany());
                byId.ifPresent(depart -> form.setStartCompanyName(depart.getName()));
            }

            BigInteger totalPremium = BigInteger.ZERO;
            BigInteger totalAmount = BigInteger.ZERO;
            BigInteger payAmount = BigInteger.ZERO;
            BigInteger preLossAmount = BigInteger.ZERO;
            BigInteger askForAmount = BigInteger.ZERO;
            // 赔偿次数
            int countGetClaim = 0;
            int countClaim = 0;

            for (ClaimHighwayBidDTO dto : dtoList) {
                if (null != dto.getTotalPremium()) {
                    totalPremium = totalPremium.add(dto.getTotalPremium());
                }
                if (null != dto.getAskForAmount()) {
                    askForAmount = askForAmount.add(dto.getAskForAmount());
                }
                if (null != dto.getPreLossAmount()) {
                    preLossAmount = preLossAmount.add(dto.getPreLossAmount());
                }
                if (null != dto.getPayAmount()) {
                    payAmount = payAmount.add(dto.getPayAmount());
                }
                if (null != dto.getTotalAmount()) {
                    totalAmount = totalAmount.add(dto.getTotalAmount());
                }
                // 理赔状态
                Byte claimStatus = dto.getClaimStatus();
                if (ClaimConstant.CLAIM_STATUS_DOWN.equals(claimStatus)) {
                    countGetClaim++;
                }
                // 不是报案。其他都是立案和立案后
                if (!ClaimConstant.CLAIM_STATUS_REPORT.equals(claimStatus)) {
                    countClaim++;
                }
            }
            // 钱相关的需要分转元
            form.setTotalAmount(MoneyUtils.cent2Yuan(totalAmount));
            form.setTotalPremium(MoneyUtils.cent2Yuan(totalPremium));
            form.setAskForAmount(MoneyUtils.cent2Yuan(askForAmount));
            form.setPreLossAmount(MoneyUtils.cent2Yuan(preLossAmount));
            form.setPayAmount(MoneyUtils.cent2Yuan(payAmount));
            // 索赔次数
            form.setCountApply(dtoList.size());
            // 赔偿次数
            form.setCountGetClaim(countGetClaim);
            // 出险次数
            form.setCountClaim(countClaim);
            results.add(form);
        });
        return results;
    }

    private List<ClaimHighwayBidDTO> listClaimBidByQuery(StringBuilder sqlBuild, Integer pageNum, Integer pageSize) {
        if (pageNum == null || pageSize == null) {
            log.info("根据条件查列表:{}", sqlBuild);
            return dynamicQuery.nativeQueryListModel(ClaimHighwayBidDTO.class, sqlBuild.toString());
        } else {
            sqlBuild.append(" limit ?1, ?2 ");
            log.info("根据条件查列表:{}", sqlBuild);
            return dynamicQuery.nativeQueryListModel(ClaimHighwayBidDTO.class, sqlBuild.toString(), (pageNum - 1) * pageSize, pageSize);
        }
    }

    private StringBuilder getClaimBidField() {
        return new StringBuilder("select distinct c.report_id reportId" +
            " ,m.start_company startCompany " +
            " ,e.eng_type engType" +
            " ,e.belong_bid belongBid" +
            " ,m.belong_company belongCompany" +
            " ,m.belong_company_name belongCompanyName" +
            " ,m.total_premium totalPremium" +
            " ,c.claim_status claimStatus" +
            " ,c.claim_begin_date claimBeginDate" +
            " ,c.pre_loss_amount preLossAmount" +
            " ,c.ask_for_amount askForAmount" +
            " ,c.pay_amount payAmount" +
            " ,m.total_amount totalAmount" +

            " from policy_uncar_claim c,policy_main m,policy_engineering e" +
            " WHERE 1=1" +
            " and c.policy_no = m.policy_no" +
            " and c.policy_no = e.policy_no" +
            " and c.insure_type = '1' ");
    }
}
