package com.huatonghh.base.domain;

import lombok.Data;

import javax.persistence.*;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/7
 */
@Entity
@Table(name = "base_status_relation")
@Data
public class BaseStatusRelation {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String currentStatus;
    private String operation;
    private String nextStatus;
    private String remark;
}
