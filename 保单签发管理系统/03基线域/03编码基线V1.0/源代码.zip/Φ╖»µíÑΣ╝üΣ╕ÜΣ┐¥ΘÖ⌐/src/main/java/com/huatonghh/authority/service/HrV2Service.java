package com.huatonghh.authority.service;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.lang.Console;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import com.alibaba.fastjson.JSONObject;
import com.huatonghh.authority.service.dto.EiDepartDto;
import com.huatonghh.authority.service.dto.EiUserDto;
import com.huatonghh.authority.service.dto.hr.request.SheadRequest;
import com.huatonghh.authority.service.dto.hr.request.depart.DepartBody;
import com.huatonghh.authority.service.dto.hr.request.depart.DepartRequest;
import com.huatonghh.authority.service.dto.hr.request.xml.XmlArgZero;
import com.huatonghh.authority.service.dto.hr.request.xml.XmlSelectAll;
import com.huatonghh.authority.service.dto.hr.request.xml.XmlSoapenvBody;
import com.huatonghh.authority.service.dto.hr.request.xml.XmlSoapenvEnvelope;
import com.huatonghh.authority.service.dto.hr.response.depart.DepartArrayList;
import com.huatonghh.authority.service.dto.hr.response.depart.DepartResponse;
import com.huatonghh.authority.service.dto.hr.response.employee.EmployeeArrayList;
import com.huatonghh.authority.service.dto.hr.response.employee.EmployeeResponse;
import com.huatonghh.authority.service.dto.hr.response.xml.XmlSoapEnvelope;
import com.thoughtworks.xstream.XStream;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Sun
 * @description 人力资源数据对接-业务层
 * @date 2019/11/27 16:02
 **/
@Service
@Slf4j
@AllArgsConstructor
public class HrV2Service {


    /**
     * @author Sun
     * @description 组装请求报文
     * @date 2019/11/29 9:37
     * @param departBody: 部门实体
     * @return java.lang.String
     **/
    public String processDepartXml(DepartBody departBody) {
        // 组装请求公司JSON报文
        String departRequestJson = processDepartRequestJson(departBody);
        // 将Json封装，并由实体转化成ws xml, 自动检测注解
        return processXml(departRequestJson);
    }


    /**
     * @author Sun
     * @description 请求，获取反参
     * @date 2019/11/27 17:54
     * @param requestXml:
     * @return java.lang.String
     **/
    private String departHttpRequestPost(String requestXml) {
        // 对xml进行post请求
        String responseXMl = httpRequestPost(requestXml);
        // 接收反参，解析xml为对象，并应用ResponseSoapEnvelope类的注解
        Console.log("responseXMl:");
        Console.log(responseXMl);
        return parseResponseXml(responseXMl);
    }


    /**
     * @author Sun
     * @description 组装请求公司JSON报文
     * @date 2019/11/27 17:55
     * @param departBody:
     * @return java.lang.String
     **/
    private String processDepartRequestJson(DepartBody departBody) {
        SheadRequest sheadJson = new SheadRequest();
        sheadJson.setServiceId("TB_STA_gongsiService");
        sheadJson.setTargetId("HR");
        sheadJson.setRequestId("people");

        DepartRequest requestJson = new DepartRequest();
        requestJson.setDepartBody(departBody);
        requestJson.setSheadRequest(sheadJson);
        String requestJsonString = JSONObject.toJSONString(requestJson);
        log.info("process请求Json串：", requestJsonString);
        return requestJsonString;
    }


    /**
     * @author Sun
     * @description 获取结果集转化Dto实体
     * @date 2019/11/27 17:55
     * @param departResponse:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiDepartDto>
     **/
    private List<EiDepartDto> processDepartDtoList(DepartResponse departResponse, String type) {
        List<EiDepartDto> eiDepartDtoList = CollUtil.newArrayList();
        // 获取结果集转化实体
        List<DepartArrayList> departHrList = departResponse.getSheadResponse().getArrayList();

        // 根据响应的Json对象，获取保存实体对象集合
        if(departHrList != null && departHrList.size() > 0) {
            eiDepartDtoList = departHrList.stream().map(depart -> {
                EiDepartDto departDto = new EiDepartDto();
                departDto.setId(depart.getCHid());
                departDto.setName(depart.getCName());
                departDto.setLevel(depart.getCLevel());
                departDto.setParentId(depart.getCSuperiorHid());
                departDto.setType(type);
                return departDto;
            }).collect(Collectors.toList());
        }
        return eiDepartDtoList;
    }


    /**
     * @author Sun
     * @description 根据JSON组装通用请求xml报文,将Json封装，并由实体转化成ws xml, 自动检测注解
     * @date 2019/11/27 16:03
     * @param requestJsonString:
     * @return java.lang.String
     **/
    private String processXml(String requestJsonString) {
        XStream xstream = new XStream();
        xstream.autodetectAnnotations(true);

        XmlArgZero xmlArgZero = new XmlArgZero();
        xmlArgZero.setXmlns("");
        xmlArgZero.setJsonRequest(requestJsonString);

        XmlSelectAll xmlSelectAll = new XmlSelectAll();
        xmlSelectAll.setXmlArgZero(xmlArgZero);
        xmlSelectAll.setXmlns("http://service.ws.standard.ft.com/");

        XmlSoapenvBody xmlSoapenvBody = new XmlSoapenvBody();
        xmlSoapenvBody.setXmlSelectAll(xmlSelectAll);

        XmlSoapenvEnvelope xmlSoapenvEnvelope = new XmlSoapenvEnvelope();
        xmlSoapenvEnvelope.setXmlnsXsi("http://www.w3.org/2001/XMLSchema-instance");
        xmlSoapenvEnvelope.setXmlnsSoapenv("http://schemas.xmlsoap.org/soap/envelope/");
        xmlSoapenvEnvelope.setXmlnsXsd("http://www.w3.org/2001/XMLSchema");
        xmlSoapenvEnvelope.setXmlSoapenvBody(xmlSoapenvBody);

        String requestXml = xstream.toXML(xmlSoapenvEnvelope);
        log.info("process请求XML串：", requestXml);
        return requestXml;
    }


    /**
     * @author Sun
     * @description 对xml进行post请求，返回响应XML串
     * @date 2019/11/27 16:03
     * @param requestXml :
     * @return java.lang.String
     **/
    private String httpRequestPost(String requestXml) {
//        HttpResponse execute = HttpRequest.post("http://localhost/oa/services/TB_STA_gongsiService")
        HttpResponse execute = HttpRequest.post("http://8.8.1.28:16601/services/TB_STA_gongsiService")
            .body(requestXml)
            .execute();
        String responseXMl = execute.body();
        log.info("get响应XML串：", responseXMl);
        return responseXMl;
    }


    /**
     * @author Sun
     * @description 接收反参，解析xml为对象，并返回jsonResponse
     * @date 2019/11/27 16:04
     * @param responseXMl:
     * @return java.lang.String
     **/
    private String parseResponseXml(String responseXMl) {
        XStream xstreamResponse = new XStream();
        xstreamResponse.processAnnotations(XmlSoapEnvelope.class);
        xstreamResponse.setClassLoader(XmlSoapEnvelope.class.getClassLoader());
        XmlSoapEnvelope xmlSoapEnvelope = (XmlSoapEnvelope) xstreamResponse.fromXML(responseXMl);

        // 根据对象获取【return】的值
        String responseBody = xmlSoapEnvelope.getXmlSoapBody().getXmlNsSelectAllResponse().getJsonResponse();

        // 将【return】的Json串解析为JavaBean
        String replaceLeft = responseBody.replaceAll("\"\\[", "[");
        String replaceRight = replaceLeft.replaceAll("]\"", "]");
        log.info("get响应JSON串：", replaceRight);
        return replaceRight;
    }


    /**
     * @author Sun
     * @description 请求及接收反参业务处理：公司
     * @date 2019/11/27 17:23
     * @param requestXml1:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiDepartDto>
     **/
    public List<EiDepartDto> businessProcessRequest(String requestXml1, String type) {
        // 请求，获取反参
        String responseJson1 = departHttpRequestPost(requestXml1);

        // 根据JavaBean获取相应信息
        DepartResponse departResponse1 = JSONObject.parseObject(responseJson1, DepartResponse.class);

        // 获取结果集转化Dto实体
        return processDepartDtoList(departResponse1, type);
    }


    /**
     * @author Sun
     * @description 请求及接收反参业务处理：员工
     * @date 2019/11/27 17:23
     * @param requestXml1:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiUserDto>
     **/
    public List<EiUserDto> businessProcessEmployeeRequest(String requestXml1) {
        // 请求，获取反参
        String responseJson1 = departHttpRequestPost(requestXml1);

        // 根据JavaBean获取相应信息
        EmployeeResponse employeeResponse = JSONObject.parseObject(responseJson1, EmployeeResponse.class);

        // 获取结果集转化Dto实体
        return processEmployeeDtoList(employeeResponse);
    }


    /**
     * @author Sun
     * @description 获取结果集转化Dto实体：员工数据
     * @date 2019/11/27 17:55
     * @param employeeResponse:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiUserDto>
     **/
    private List<EiUserDto> processEmployeeDtoList(EmployeeResponse employeeResponse) {
        // 获取结果集转化实体
        List<EmployeeArrayList> employeeArrayList = employeeResponse.getSheadResponse().getArrayList();

        return employeeArrayList.stream().map(ei -> {
            EiUserDto eiUserDto = new EiUserDto();
            eiUserDto.setUserName(ei.getCEmployeeCode());
            eiUserDto.setEmployeeNo(ei.getCEmployeeCode());
            eiUserDto.setId(ei.getCEmployeeId());
            eiUserDto.setName(ei.getCEmployeeName());
            eiUserDto.setValid(true);

            return eiUserDto;
        }).collect(Collectors.toList());
    }

}
