package com.huatonghh.policy.service.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * @author ghy
 * Date: 2021/1/6 9:14
 */
@Data
@ApiModel("基金使用记录DTO")
@NoArgsConstructor
@AllArgsConstructor
public class PolicyFundDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 保单号
     */
    @ApiModelProperty("保单号")
    private String policyNo;

    /**
     * 可计提的防灾防损基金
     */
    @ApiModelProperty("可计提的防灾防损基金")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger totalFund;

    /**
     * 已使用的防灾防损基金
     */
    @ApiModelProperty(value = "已使用的防灾防损基金")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger usedFund;

    /**
     * 剩余的防灾防损基金
     */
    @ApiModelProperty(value = "剩余的防灾防损基金")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger leftFund;

}
