package com.huatonghh.ins_authority.repository;

import com.huatonghh.authority.domain.EiDepart;
import com.huatonghh.ins_authority.domain.EiInsDepartUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Set;


/**
 * @author : Sun
 * @description : 交投集团-公司部门-数据仓库
 * @date : 2019/11/4 19:44
 * @version : 1.0
 */
@Repository
public interface EiInsDepartUserRepository extends JpaRepository<EiInsDepartUser, String> {

    /**
     * 新增部门用户中间表信息
     *
     * @author Sun
     * @date 2019/11/4 19:51
     * @param companyId: 部门id
     * @param userId: 用户id
     **/
    @Modifying
    @Query(nativeQuery = true, value = "INSERT INTO ei_ins_depart_user VALUES (?1, ?2 )")
    void addDepartUser(String companyId, String userId);

}
