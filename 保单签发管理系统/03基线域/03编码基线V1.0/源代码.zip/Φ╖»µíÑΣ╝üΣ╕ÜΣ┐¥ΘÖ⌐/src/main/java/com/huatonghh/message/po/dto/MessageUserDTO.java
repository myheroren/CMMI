package com.huatonghh.message.po.dto;

import com.google.common.base.MoreObjects;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;

/**
 * @author wanggl
 * @date 2020-11-03 16:07
 */
@ApiModel("用户信息")
public class MessageUserDTO implements Serializable {

    private static final long serialVersionUID = 7646844137693991581L;

    @ApiModelProperty(value = "用户编号", required = true)
    @NotEmpty(message = "用户编号不能为空")
    private String userCode;

    @ApiModelProperty(value = "第三方发送信息，可不填")
    private List<ThirdParty> thirdParties;

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public List<ThirdParty> getThirdParties() {
        return thirdParties;
    }

    public void setThirdParties(List<ThirdParty> thirdParties) {
        this.thirdParties = thirdParties;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
            .add("userCode", userCode)
            .add("thirdParties", thirdParties)
            .toString();
    }
}
