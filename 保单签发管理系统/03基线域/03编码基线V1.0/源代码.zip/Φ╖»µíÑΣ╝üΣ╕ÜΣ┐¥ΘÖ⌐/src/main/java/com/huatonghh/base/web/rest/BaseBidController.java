package com.huatonghh.base.web.rest;

import com.huatonghh.base.domain.BaseBid;
import com.huatonghh.base.repository.BaseBidRepository;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.util.system.ApiResponse;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * description: 基础项目
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/22
 */
@RestController
@RequestMapping("/api/base/bid/v1")
@Api(tags = "22、招标人管理", value = "招标人管理")
@Slf4j
@AllArgsConstructor
public class BaseBidController {

    private final BaseBidRepository baseBidRepository;

    @PostMapping("")
    @ApiOperation(value = "1、新增", httpMethod = "POST")
    @Timed
    public ApiResponse save(@RequestBody BaseBid baseProjectDTO) {
        return ApiResponse.ofSuccess(baseBidRepository.save(baseProjectDTO));
    }

    @GetMapping(value = "")
    @ApiOperation(value = "4、根据id", notes = "根据id", httpMethod = "GET")
    @Timed
    public ApiResponse<BaseBid> findById(@RequestParam("id") Integer id) {
        Optional<BaseBid> op = baseBidRepository.findById(id);
        if (!op.isPresent()) {
            throw new BusinessException("数据不存在");
        }
        return ApiResponse.ofSuccess(op.get());
    }

    @GetMapping(value = "all")
    @ApiOperation(value = "3、查询", notes = "查询", httpMethod = "GET")
    @Timed
    public ApiResponse<List<BaseBid>> findAll() {
        return ApiResponse.ofSuccess(baseBidRepository.findAll());
    }

/* @PutMapping("")
    @ApiOperation(value = "2、修改", httpMethod = "PUT")
    @Timed
    public ApiResponse update(@RequestBody @Valid BaseProjectDTO baseProjectDTO) {
        baseBidRepository.save(baseProjectDTO);
        return ApiResponse.ofSuccess(null);
    }*/
}
