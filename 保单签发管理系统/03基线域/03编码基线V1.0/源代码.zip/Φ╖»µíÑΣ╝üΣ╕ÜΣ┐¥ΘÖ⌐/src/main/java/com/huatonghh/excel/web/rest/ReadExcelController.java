package com.huatonghh.excel.web.rest;

import com.alibaba.excel.EasyExcel;
import com.huatonghh.base.config.JtServiceProperties;
import com.huatonghh.base.service.BaseCodeService;
import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.excel.listener.PolicyImportDataListen;
import com.huatonghh.excel.repository.ImportFailDAO;
import com.huatonghh.excel.service.ReadExcelService;
import com.huatonghh.excel.service.dto.DataImportResult;
import com.huatonghh.excel.service.dto.PolicyImportData;
import com.huatonghh.ins_authority.service.EiInsDepartService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

/**
 * @author : Sun
 * @version : 1.0
 * description : excel导入
 * @date : 2019/11/5 21:17
 */
@RestController
@Slf4j
@RequestMapping("/api/poi/v2/read")
@AllArgsConstructor
@Api(tags = "30、读Excel表格", value = "读表格")
public class ReadExcelController {

    private final BaseCodeService baseCodeService;

    private final ReadExcelService readExcelService;

    private final ImportFailDAO importFailDAO;

    private final EiInsDepartService eiInsDepartService;

    private final JtServiceProperties jtServiceProperties;

    @ApiOperation(value = "读取历史保单", notes = "读取历史保单", httpMethod = "POST")
    @PostMapping("policy")
    @ResponseBody
    public ApiResponse readPolicyList(MultipartFile file) throws IOException {
        DataImportResult dataImportResult = DataImportResult.init();
        EasyExcel.read(file.getInputStream(), PolicyImportData.class, new PolicyImportDataListen(readExcelService, importFailDAO, dataImportResult, baseCodeService, eiInsDepartService)).sheet().headRowNumber(1).doRead();
        return this.getImportResponse(dataImportResult);
    }

    private ApiResponse getImportResponse(DataImportResult dataImportResult) {
        Integer failNum = dataImportResult.getFailNum();
        if (0 == failNum) {
            return ApiResponse.ofSuccess("上传成功，批次号：" + dataImportResult.getImportBatchNo());
        } else {
            String failUrl = jtServiceProperties.getServiceUrl() + "/api/poi/v2/write/fail?failId=" + dataImportResult.getFailId();
            String message = "上传完成，批次号：" + dataImportResult.getImportBatchNo() + "," + failNum + "条失败";
            return ApiResponse.ofFail("6001", message, failUrl);
        }
    }
}
