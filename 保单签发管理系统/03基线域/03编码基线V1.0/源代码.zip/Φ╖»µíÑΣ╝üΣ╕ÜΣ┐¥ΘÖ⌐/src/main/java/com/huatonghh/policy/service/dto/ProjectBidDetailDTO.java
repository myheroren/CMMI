package com.huatonghh.policy.service.dto;

import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.file.service.dto.FiAuditFileDto;
import com.huatonghh.policy.service.dto.policy.PolicyListDto;
import com.huatonghh.policy.service.dto.project.ProjectDTO;
import com.huatonghh.policy.service.dto.project.ProjectPreCoinsuranceDTO;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/9/10
 */
@Data
@ApiModel("项目中标管理-项目详情")
public class ProjectBidDetailDTO {
    private ProjectDTO baseInfo;
    private List<FiAuditFileDto> files;
    private PageInfo<PolicyListDto> policyMainList;
    private List<ProjectPreCoinsuranceDTO> coinsuranceInfos;
}
