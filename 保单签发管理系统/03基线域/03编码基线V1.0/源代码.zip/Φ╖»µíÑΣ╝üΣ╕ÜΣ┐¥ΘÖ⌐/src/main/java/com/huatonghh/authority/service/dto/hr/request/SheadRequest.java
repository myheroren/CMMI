package com.huatonghh.authority.service.dto.hr.request;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;


/**
 * @author : Sun
 * @description : 通用查询信息-请求头Json报文
 * @date : 2019/11/4 21:01
 * @version : 1.0
 */
@Data
public class SheadRequest {

    /** 请求方系统编号 */
    @JsonProperty(value = "requestId")
    @JSONField(name ="requestId")
    private String requestId;

    /** 目标系统编号 */
    private String targetId;

    /** 服务编号 */
    private String serviceId;

    /** 消息发送时间戳 */
    private String timestamp;

    /** 交易流水号 */
    private String seqNo;

    /** 全局交易流水号 */
    private String transNo;

}
