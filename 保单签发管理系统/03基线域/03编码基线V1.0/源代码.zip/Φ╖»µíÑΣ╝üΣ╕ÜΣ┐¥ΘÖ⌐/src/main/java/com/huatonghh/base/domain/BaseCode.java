package com.huatonghh.base.domain;

import lombok.Data;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

/**
 * @author : Sun
 * @description : 基础代码
 * @date : 2019/11/5 20:52
 * @version : 1.0
 */
@Entity
@Table(name = "base_code")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Data
public class BaseCode {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "type_id")
    private String typeId;

    @Column(name = "type_name")
    private String typeName;

    @Column(name = "code_id")
    private String codeId;

    @Column(name = "code_name")
    private String codeName;

    @Column(name = "ename")
    private String ename;

    @Column(name = "is_valid")
    private boolean valid;

    @Column(name = "remark")
    private String remark;

}
