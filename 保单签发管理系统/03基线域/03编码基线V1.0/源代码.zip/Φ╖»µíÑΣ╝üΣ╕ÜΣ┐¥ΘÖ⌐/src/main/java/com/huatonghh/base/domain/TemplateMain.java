package com.huatonghh.base.domain;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

/**
 * @author : Sun
 * @description : 套餐模板主表
 * @date : 2019/11/5 20:52
 * @version : 1.0
 */
@Entity
@Table(name = "base_template_main")
@Data
public class TemplateMain implements Serializable {

    private static final long serialVersionUID = -2551942733754618028L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "template_name")
    private String templateName;

    @Column(name = "template_type")
    private Byte templateType;

    @Column(name = "remark")
    private String remark;

}
