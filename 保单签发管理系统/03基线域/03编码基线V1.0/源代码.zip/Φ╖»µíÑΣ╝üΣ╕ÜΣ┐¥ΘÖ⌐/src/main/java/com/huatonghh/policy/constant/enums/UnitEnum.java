package com.huatonghh.policy.constant.enums;

/**
 * @author: hao.wang
 * @date: 2019/9/4
 * @description:
 */

public enum UnitEnum {




    /**
     * d d
     */
    PERSON(Byte.valueOf("1"), "人"),
    //分隔符
    CAR(Byte.valueOf("2"), "辆"),
    KILOMETRE(Byte.valueOf("3"), "公里");

    /**
     * 单位描述
     */
    private String desc;
    /**
     * 单位代码
     */
    private Byte code;

    UnitEnum(Byte code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String desc() {
        return this.desc;
    }

    public Byte code() {
        return this.code;
    }
}
