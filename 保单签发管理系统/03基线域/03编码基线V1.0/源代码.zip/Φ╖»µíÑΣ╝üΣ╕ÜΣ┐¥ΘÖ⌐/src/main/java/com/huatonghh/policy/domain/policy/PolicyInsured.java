package com.huatonghh.policy.domain.policy;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;

/**
 * description: 被保险人
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/25
 */
@Entity
@Table(name = "policy_insured")
@Data
@ApiModel("保单-被保险人")
public class PolicyInsured {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @ApiModelProperty(value = "保单号")
    private String policyNo;

    @ApiModelProperty(value = "被保人名字")
    private String insuredName;

    @ApiModelProperty(value = "被保险人证件类型")
    private Byte insuredCertificateType;

    @ApiModelProperty(value = "被保险人证件号码")
    private String insuredCertificateNumber;

}
