package com.huatonghh.file.domain;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;

/**
 * @author : Sun
 * @description : 文件表
 * @date : 2019/11/5 21:23
 * @version : 1.0
 */
@Entity
@Table(name = "fi_file")
@Data
public class FiFile implements Serializable {

    private static final long serialVersionUID = -2573977709360467752L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "file_id")
    private Integer fileId;

    @Column(name = "file_original_name")
    private String fileOriginalName;

    @Column(name = "file_url")
    private String fileUrl;

    @Column(name = "file_size")
    private BigInteger fileSize;

    public FiFile() {
    }

    public FiFile(String fileOriginalName, String fileUrl, BigInteger fileSize) {
        this.fileOriginalName = fileOriginalName;
        this.fileUrl = fileUrl;
        this.fileSize = fileSize;
    }
}
