package com.huatonghh.authority.repository;

import com.huatonghh.authority.domain.EiUserBase;
import com.huatonghh.common.service.dto.ResponseStringKeyValueDto;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


/**
 * @author : Sun
 * @description : 交投集团-用户-数据仓库
 * @date : 2019/11/4 19:52
 * @version : 1.0
 */
@Repository
public interface EiUserBaseRepository extends JpaRepository<EiUserBase, String> {

    /**
     * 根据用户id，只获取用户信息
     *
     * @author Sun
     * @date 2019/11/4 19:54
     * @param id: 用户id
     * @return java.util.Optional<com.huatonghh.authority.domain.EiUserBase>
     **/
    Optional<EiUserBase> findOneById(String id);


    /**
     * 根据用户名，只获取用户信息
     *
     * @author Sun
     * @date 2019/11/4 19:57
     * @param userName: 用户名称
     * @return java.util.Optional<com.huatonghh.authority.domain.EiUserBase>
     **/
    Optional<EiUserBase> findOneByUserName(String userName);


    /**
     * 根据用户id获取用户信息，懒加载获取角色信息
     *
     * @author Sun
     * @date 2019/11/4 19:57
     * @param id: 用户id
     * @return java.util.Optional<com.huatonghh.authority.domain.EiUserBase>
     **/
    @EntityGraph(attributePaths = "authorities")
    Optional<EiUserBase> findOneWithAuthoritiesById(String id);


    /**
     * 根据用户名获取用户信息，懒加载获取角色信息
     *
     * @author Sun
     * @date 2019/11/4 19:58
     * @param user: 用户名
     * @return java.util.Optional<com.huatonghh.authority.domain.EiUserBase>
     **/
    @EntityGraph(attributePaths = "authorities")
    Optional<EiUserBase> findOneWithAuthoritiesByUserName(String user);


    /**
     * 删除用户对应的部门中间表
     *
     * @author Sun
     * @date 2019/11/4 19:58
     * @param userId: 用户id
     **/
    @Modifying
    @Query(nativeQuery = true, value = "delete from ei_depart_user where user_id = :userId")
    void deleteDepartUserByUserId(@Param("userId") String userId);

    @Modifying
    @Query(nativeQuery = true, value = "delete from ei_depart_user where user_id = :userId and company_id = :companyId")
    void deleteDepartUserByUserIdAndCompany(@Param("userId") String userId, @Param("companyId") String companyId);

    /**
     * 根据部门id获取其下用户列表
     *
     * @author Sun
     * @date 2019/11/4 19:59
     * @param id: 部门id
     * @return java.util.List<com.huatonghh.authority.domain.EiUserBase>
     **/
//    @Query(nativeQuery = true, value = "SELECT DISTINCT u.* FROM ei_user u LEFT JOIN ei_depart_user du ON u.id = du.user_id WHERE IF (?1 != '', du.depart_id = ?1, 0 = 0)")
//    List<EiUserBase> findDepartLowerUserList(String id);

    @Query(nativeQuery = true, value = "SELECT DISTINCT u.* FROM ei_user u ,ei_depart ed,ei_depart_user du WHERE u.id = du.user_id  and ed.id = ?1 and du.company_id = ed.id")
    List<EiUserBase> findDepartLowerUserList(String id);


    @Query(nativeQuery = true, value = "SELECT DISTINCT u.* FROM ei_user u ,ei_depart ed,ei_depart_user du WHERE u.id = du.user_id  and ed.id = ?1 and du.company_id = ed.id order by u.id limit ?2,?3")
    List<EiUserBase> findDepartLowerUserListPage(String id, Integer PageNo, Integer pageSize);


    @Query(nativeQuery = true, value = "SELECT count(1) FROM ei_user u ,ei_depart ed,ei_depart_user du WHERE u.id = du.user_id  and ed.id = ?1 and du.company_id = ed.id")
    Integer findDepartLowerUserListTotle(String id);
    /**
     * 根据公司id获取其下用户列表
     *
     * @author Sun
     * @date 2019/11/4 19:59
     * @param id: 部门id
     * @return java.util.List<com.huatonghh.authority.domain.EiUserBase>
     **/
    @Query(nativeQuery = true, value = "select DISTINCT eu.* from ei_user eu,Ei_Depart d1, Ei_Depart d2,ei_depart_user edu WHERE edu.depart_id = d1.id and edu.user_id = eu.id and d1.ids LIKE CONCAT(d2.ids, '%') and d2.id = ?1")
    List<EiUserBase> findCompanyLowerUserList(String id);

    /**
     * 修改用户所属部门
     *
     * @author Sun
     * @date 2019/11/4 20:00
     * @param companyId: 公司id
     * @param departId: 部门id
     * @param userId: 用户id
     **/
    @Modifying
    @Query(nativeQuery = true, value = "INSERT INTO ei_depart_user VALUES (?1, ?2,?3)")
    void batchInsertBaseCodes(String companyId, String departId, String userId);


    /**
     * 根据公司id查询公司下员工的登录账户及中文名字
     *
     * @author Sun
     * @date 2019/11/4 20:00
     * @param id: 公司id
     * @return java.util.List<com.huatonghh.authority.domain.EiUserBase>
     **/
    @Query(nativeQuery = true, value = "SELECT u.* FROM ei_depart_user d, ei_user u WHERE d.depart_id = ?1 AND d.user_id = u.id")
    List<EiUserBase> findUserListByDepart(String id);


    /**
     * 根据登录账户，获取账户中文名；生成key value数据集
     *
     * @author Sun
     * @date 2019/11/6 16:18
     * @param id:
     * @return java.util.List<com.huatonghh.common.service.dto.ResponseStringKeyValueDto>
     **/
    @Query(value = "SELECT DISTINCT new com.huatonghh.common.service.dto.ResponseStringKeyValueDto( d.id, d.name ) FROM EiUserBase d WHERE d.id = :id")
    List<ResponseStringKeyValueDto> queryNameById(@Param("id") String id);

}
