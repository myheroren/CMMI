package com.huatonghh.policy.service.dto.annual;

import com.huatonghh.file.service.dto.FiAuditFileDto;
import com.huatonghh.policy.service.dto.project.ProjectDTO;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.List;

/**
 * @author : hao.wang
 * @date : 2019/8/27
 * description:
 */
@Data
@ApiModel("新增保险计划")
public class PlanDetailDTO {
    private PlanBasicDTO basicInfo;
    private List<ProjectDTO> projects;
    private List<FiAuditFileDto> files;

}
