package com.huatonghh.base.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

/**
 * description: 项目信息
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/22
 */
@Entity
@Table(name = "base_eng")
@Data
@ApiModel(value = "基础项目信息")
public class BaseEng {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @NotBlank
    @ApiModelProperty(value = "工程名字")
    private String name;
    @ApiModelProperty(value = "项目别称")
    private String alias;
    @ApiModelProperty(value = "联系电话")
    private String tel;
    @ApiModelProperty(value = "联系人")
    private String contact;
    @Column(name = "is_valid")
    private Boolean valid;
}
