package com.huatonghh.policy.service;

import com.huatonghh.policy.domain.project.ProjectPreCoinsurance;
import com.huatonghh.policy.repository.ProjectPreCoinsuranceRepository;
import com.huatonghh.policy.service.dto.project.ProjectPreCoinsuranceDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.List;
import java.util.stream.Collectors;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/9
 */
@Service
@Slf4j
@AllArgsConstructor
public class ProjectPreCoinsuranceService {
    private final ProjectPreCoinsuranceRepository preCoinsuranceRepository;
    private final ModelMapper modelMapper;

    public List<ProjectPreCoinsuranceDTO> findAllByProjectNo(BigInteger projectNo) {
        List<ProjectPreCoinsurance> cs = preCoinsuranceRepository.findAllByProjectNo(projectNo);
        if (null == cs || cs.isEmpty()) {
            return null;
        }
        return cs.stream().map(c -> modelMapper.map(c, ProjectPreCoinsuranceDTO.class)).collect(Collectors.toList());
    }
}
