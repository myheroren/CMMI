package com.huatonghh.base.repository;

import com.huatonghh.base.domain.TemplateMain;
import com.huatonghh.common.service.dto.ResponseIntegerKeyValueDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

/**
 * @author : Sun
 * @description : 通用模板主表，现用于方案配置-数据仓库
 * @date : 2019/11/5 20:56
 * @version : 1.0
 */
public interface TemplateMainRepository extends JpaRepository<TemplateMain, Integer> {

    /**
     * 根据模板名称，获取模板主信息
     *
     * @author Sun
     * @date 2019/11/5 20:57
     * @param templateName: 模板名称
     * @param templateType: 模板类型
     * @return java.util.Optional<com.huatonghh.base.domain.TemplateMain>
     **/
    Optional<TemplateMain> findByTemplateNameAndTemplateType(String templateName, Byte templateType);


    /**
     * 根据模板类型查询模板下拉框列表
     *
     * @author Sun
     * @date 2019/11/5 20:57
     * @param templateType: 模板类型
     * @return java.util.List<com.huatonghh.common.service.dto.ResponseIntegerKeyValueDto>
     **/
    @Query(value = "SELECT DISTINCT new com.huatonghh.common.service.dto.ResponseIntegerKeyValueDto(m.id, m.templateName) " +
        "from TemplateMain m WHERE m.templateType = :templateType")
    List<ResponseIntegerKeyValueDto> queryRiskPlanSelectKeyValue(@Param("templateType") Byte templateType);


    /**
     * 模板分页列表
     *
     * @author Sun
     * @date 2019/11/5 20:58
     * @param typecode: 模板类型
     * @param pageable: 分页
     * @return org.springframework.data.domain.Page<com.huatonghh.base.domain.TemplateMain>
     **/
    Page<TemplateMain> findByTemplateType(Byte typecode, Pageable pageable);


}
