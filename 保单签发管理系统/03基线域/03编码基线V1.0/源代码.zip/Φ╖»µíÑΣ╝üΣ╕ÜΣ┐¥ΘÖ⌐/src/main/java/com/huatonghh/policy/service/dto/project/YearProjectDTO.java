package com.huatonghh.policy.service.dto.project;

import com.huatonghh.file.service.dto.FiAuditFileDto;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.List;

/**
 * @author :  hao.wang
 * @date : 2019/9/4
 * description :
 */
@Data
@ApiModel("汇总项目详情")
public class YearProjectDTO {
    private List<ProjectDTO> projects;
    private List<FiAuditFileDto> files;
}
