package com.huatonghh.policy.service.dto.renew;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import com.huatonghh.file.service.dto.FiAuditFileDto;
import com.huatonghh.policy.service.dto.policy.PolicyVehRiskPlanDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

/**
 * Description :
 * @author : Sun
 * @date : 2019/10/31 19:51
 * @version : 1.0
 */
@Data
@ApiModel("保存车险保单")
public class SaveJointCarPolicyRenewDto implements Serializable {

    private static final long serialVersionUID = -397891734520609311L;

    /** 必要信息 */
    @ApiModelProperty(value = "车或非车标识：1车、0非车，必传")
    @NotNull(message = "车或非车标识不能为空")
    private Byte carUncarFlag;

    @ApiModelProperty(value = "保险类别")
    private String insuranceCategory;


    /** 项目信息 */
    @ApiModelProperty(value = "中标项目编号")
    @JsonSerialize(using = ToStringSerializer.class)
    private BigInteger projectNo;

    @ApiModelProperty(value = "发起公司")
    private String startCompany;

    @ApiModelProperty(value = "保险公司")
    private String belongCompany;

    @ApiModelProperty(value = "保司联系人")
    private String belongCompanyPerson;

    @ApiModelProperty(value = "联系电话")
    private String belongCompanyPhone;

    /** 基本信息 */
    @ApiModelProperty(value = "投保人")
    private String holderName;

    @ApiModelProperty(value = "被保险人")
    private String insuredName;

    @ApiModelProperty(value = "车架号")
    private String frameNo;

    @ApiModelProperty(value = "车牌号")
    private String plateNo;

    @ApiModelProperty(value = "发动机号")
    private String engineNo;

    @ApiModelProperty(value = "使用性质")
    private String usageCode;

    @ApiModelProperty(value = "车辆型号")
    private String vehicleModel;

    @ApiModelProperty(value = "车主")
    private String ownerName;


    /** 险种信息：交强险 */
    @ApiModelProperty(value = "是否勾选交强险")
    private boolean jq;

    @ApiModelProperty(value = "交强险：保单号")
    private String jqPolicyNo;

    @ApiModelProperty(value = "交强险：有效起期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date jqPolicyBgnTime;

    @ApiModelProperty(value = "交强险：有效止期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date jqPolicyEndTime;

    @ApiModelProperty(value = "交强险：保费")
//    @JsonSerialize(using = ToStringSerializer.class)
    @JsonDeserialize(using= AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger jqTotalPremium;

    @ApiModelProperty(value = "交强险：手续费比例")
    private String jqFeeProp;

    @ApiModelProperty(value =  "交强险：车船税")
    private String jqVehicleVesselTax;


    /** 险种信息：商业险 */
    @ApiModelProperty(value = "是否勾选商业险")
    private boolean sy;

    @ApiModelProperty(value = "商业险：保单号")
    private String syPolicyNo;

    @ApiModelProperty(value = "商业险：有效起期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date syPolicyBgnTime;

    @ApiModelProperty(value = "商业险：有效止期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date syPolicyEndTime;

    @ApiModelProperty(value = "商业险：保费")
    @JsonDeserialize(using= AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger syTotalPremium;

    @ApiModelProperty(value = "商业险：手续费比例")
    private String syFeeProp;

    @ApiModelProperty(value = "商业险：NCD系数")
    private String syNcdCoef;

    @ApiModelProperty(value = "商业险：自主核保系数")
    private String syAutoUnderwritingCoef;



    /** 险种信息：货物运输险 */
    @ApiModelProperty(value = "是否勾选货物运输险")
    private boolean hw;

    @ApiModelProperty(value = "货物运输险：保单号")
    private String hwPolicyNo;

    @ApiModelProperty(value = "货物运输险：有效起期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date hwPolicyBgnTime;

    @ApiModelProperty(value = "货物运输险：有效止期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date hwPolicyEndTime;

    @ApiModelProperty(value = "货物运输险：保费")
//    @JsonSerialize(using = ToStringSerializer.class)
    @JsonDeserialize(using= AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger hwTotalPremium;


    @ApiModelProperty(value = "附件列表")
    private List<FiAuditFileDto> fiAuditFileDtos;

    @ApiModelProperty(value = "车辆方案列表")
    private List<PolicyVehRiskPlanDto> policyVehRiskPlanDtoList;

    @ApiModelProperty(value = "续保信息")
    PolicyRenewDTO PolicyRenewDTO;
}
