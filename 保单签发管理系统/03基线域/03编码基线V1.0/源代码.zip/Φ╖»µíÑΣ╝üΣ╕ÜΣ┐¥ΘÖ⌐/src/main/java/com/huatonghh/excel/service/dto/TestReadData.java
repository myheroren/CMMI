package com.huatonghh.excel.service.dto;

import com.alibaba.excel.annotation.format.DateTimeFormat;
import lombok.Data;

/**
 * 基础数据类
 *
 * @author Jiaju Zhuang
 **/
@Data
public class TestReadData {
    private Double doubleData1;
    private String string;
    @DateTimeFormat("yyyy年MM月dd日HH时mm分ss秒")
    private String date;
    private Double doubleData;
}
