package com.huatonghh.policy.service.dto;

import com.huatonghh.policy.domain.plan.PlanEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author ghy
 * Date: 2020/10/20 11:54
 */
@Data
@ApiModel("计划DTO")
public class PlanDTO {

    @ApiModelProperty("当前流程实例ID")
    private String currentProcessId;

    @ApiModelProperty("当前任务ID")
    private String currentTaskId;

    @ApiModelProperty("计划实体")
    private PlanEntity planEntity;

    @ApiModelProperty("是否是待办,1是,0不是")
    private Byte isTodo;
}
