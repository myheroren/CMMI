/**
 * Spring Framework configuration files.
 */
package com.huatonghh.authority.service.dto;
