package com.huatonghh.policy.service;

import com.huatonghh.policy.domain.policy.PolicyInsured;
import com.huatonghh.policy.repository.policy.PolicyInsuredRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/25
 */
@Slf4j
@Service
@AllArgsConstructor
public class PolicyInsuredService {

    private final PolicyInsuredRepository insuredRepository;

    public List<PolicyInsured> findAllByPolicyNo(String policyNo) {
        return insuredRepository.findAllByPolicyNo(policyNo);
    }

    public void saveAll(List<PolicyInsured> insureds) {
        if (null == insureds || insureds.isEmpty()) {
            return;
        }
        insuredRepository.saveAll(insureds);
    }
}
