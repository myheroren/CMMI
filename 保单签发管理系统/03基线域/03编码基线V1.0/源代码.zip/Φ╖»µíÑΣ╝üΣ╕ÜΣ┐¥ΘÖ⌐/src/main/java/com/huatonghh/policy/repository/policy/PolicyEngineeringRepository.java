package com.huatonghh.policy.repository.policy;

import com.huatonghh.policy.domain.policy.PolicyEngineering;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigInteger;
import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/22
 */
public interface PolicyEngineeringRepository extends JpaRepository<PolicyEngineering, BigInteger> {

    /**
     * 根据保单号
     *
     * @param policyNo 保单号
     * @return 工程列表
     */
    List<PolicyEngineering> findAllByPolicyNo(String policyNo);
}
