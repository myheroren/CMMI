package com.huatonghh.authority.service.dto.hr.response.xml;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import lombok.Data;


/**
 * @author : Sun
 * @description : <ns2:selectAllResponse></ns2:selectAllResponse>
 * @date : 2019/11/4 21:08
 * @version : 1.0
 */
@Data
@XStreamAlias("ns2:selectAllResponse")
public class XmlNsSelectAllResponse {

    @XStreamAsAttribute
    @XStreamAlias("xmlns:ns2")
    private String xmlns;

    @XStreamAlias("return")
    private String jsonResponse;

}
