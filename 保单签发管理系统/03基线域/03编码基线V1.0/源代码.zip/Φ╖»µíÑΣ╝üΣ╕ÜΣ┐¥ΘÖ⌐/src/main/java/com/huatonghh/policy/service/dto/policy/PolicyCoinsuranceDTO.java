package com.huatonghh.policy.service.dto.policy;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/9
 */
@Data
public class PolicyCoinsuranceDTO {
    @ApiModelProperty("id")
    private Integer coId;
    @ApiModelProperty("保单号")
    private String policyNo;
    @ApiModelProperty("归属保险公司")
    private String belongCompany;
    @ApiModelProperty("归属保险公司名称")
    private String belongCompanyName;
    @ApiModelProperty("共保比例")
    private String proportion;
}
