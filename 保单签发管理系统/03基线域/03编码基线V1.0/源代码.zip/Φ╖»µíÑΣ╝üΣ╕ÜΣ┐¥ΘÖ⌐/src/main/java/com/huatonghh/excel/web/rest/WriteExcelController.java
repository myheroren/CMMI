package com.huatonghh.excel.web.rest;

import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.write.builder.ExcelWriterBuilder;
import com.alibaba.excel.write.style.column.LongestMatchColumnWidthStyleStrategy;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.google.common.collect.Lists;
import com.huatonghh.base.service.BaseCodeService;
import com.huatonghh.base.service.dto.BaseCodeDto;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.util.BeanCopierUtils;
import com.huatonghh.common.util.hutool.FileStreamUtil;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.common.util.system.PageParam;
import com.huatonghh.empower.service.EmpowerQuery;
import com.huatonghh.empower.service.EmpowerService;
import com.huatonghh.excel.domain.ImportFailEntity;
import com.huatonghh.excel.repository.ImportFailDAO;
import com.huatonghh.excel.service.WriteExcelService;
import com.huatonghh.excel.service.dto.EmpowerExport;
import com.huatonghh.excel.service.dto.FundExport;
import com.huatonghh.excel.service.dto.PolicyImportData;
import com.huatonghh.excel.util.NumberFormatUtils;
import com.huatonghh.fund.domain.EiInsFund;
import com.huatonghh.fund.service.EiInsFundService;
import com.huatonghh.policy.domain.project.ProjectEntity;
import com.huatonghh.policy.service.dto.claim.noncar.ClaimListDTO;
import com.huatonghh.policy.service.dto.claim.noncar.ClaimListExport;
import com.huatonghh.policy.service.dto.claim.noncar.ClaimListQuery;
import com.huatonghh.policy.service.dto.policy.PolicyListCondition;
import com.huatonghh.policy.service.dto.policy.PolicyListDto;
import com.huatonghh.policy.service.dto.policy.PolicyRenewExport;
import com.huatonghh.policy.service.dto.policy.PolicyUncarExport;
import com.huatonghh.policy.web.rest.PolicyController;
import com.huatonghh.policy.web.rest.PolicyRenewV2Controller;
import com.huatonghh.policy.web.rest.claim.UnCarClaimController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.math.BigInteger;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author : Sun
 * @version : 1.0
 * description : excel导出
 * @date : 2019/11/5 21:18
 */
@RestController
@Slf4j
@RequestMapping("/api/poi/v2/write")
@Api(tags = "29、写表格", value = "写表格")
public class WriteExcelController {

    private final WriteExcelService writeExcelService;

    private final PolicyController policyController;

    private final PolicyRenewV2Controller policyRenewV2Controller;

    private final UnCarClaimController unCarClaimController;

    private final EiInsFundService eiInsFundService;

    private final EmpowerService empowerService;

    private final ImportFailDAO importFailDAO;

    private final Map<String, String> STATUS_MAP;

    private final Map<String, String> KIND_MAP;

    private final Map<String, String> CLAIM_STATUS_MAP;

    private final Map<String, String> RENEW_STATUS_MAP;

    public WriteExcelController(BaseCodeService baseCodeService, WriteExcelService writeExcelService, PolicyController policyController, PolicyRenewV2Controller policyRenewV2Controller, UnCarClaimController unCarClaimController, EiInsFundService eiInsFundService, EmpowerService empowerService, ImportFailDAO importFailDAO) {
        this.writeExcelService = writeExcelService;
        this.policyController = policyController;
        this.policyRenewV2Controller = policyRenewV2Controller;
        this.unCarClaimController = unCarClaimController;
        this.eiInsFundService = eiInsFundService;
        this.empowerService = empowerService;
        this.importFailDAO = importFailDAO;


        // 初始化base code
        List<BaseCodeDto> status = baseCodeService.queryBaseCodeByTypeCode("policyStatus");
        List<BaseCodeDto> renewStatus = baseCodeService.queryBaseCodeByTypeCode("renewStatus");
        List<BaseCodeDto> kindCodes = baseCodeService.queryBaseCodeByTypeCode("lq_kind_code");
        List<BaseCodeDto> claimStatus = baseCodeService.queryBaseCodeByTypeCode("claimStatus");
        STATUS_MAP = status.stream().collect(Collectors.toMap(BaseCodeDto::getCodeId, BaseCodeDto::getCodeName));
        KIND_MAP = kindCodes.stream().collect(Collectors.toMap(BaseCodeDto::getCodeId, BaseCodeDto::getCodeName));
        CLAIM_STATUS_MAP = claimStatus.stream().collect(Collectors.toMap(BaseCodeDto::getCodeId, BaseCodeDto::getCodeName));
        RENEW_STATUS_MAP = renewStatus.stream().collect(Collectors.toMap(BaseCodeDto::getCodeId, BaseCodeDto::getCodeName));

    }

    @ApiOperation(value = "下载历史保单模板", notes = "下载历史保单模板", httpMethod = "GET")
    @GetMapping("model/policyMain")
    public void downloadPolicyMain(HttpServletResponse response) {
        FileStreamUtil.downloadModel(response, "excel/policy_main.xlsx", "历史保单-批量导入模板.xlsx");
    }

    @ApiOperation(value = "下载导入失败的数据", notes = "下载导入失败的数据", httpMethod = "GET")
    @GetMapping("fail")
    public void downloadStudent(HttpServletResponse response, @RequestParam("failId") BigInteger failId) throws IOException {
        this.handleCommonResponse(response);
        Optional<ImportFailEntity> op = importFailDAO.findById(failId);
        if (!op.isPresent()) {
            return;
        }
        this.writeFailData(response, op.get());
    }

    private void writeFailData(HttpServletResponse response, ImportFailEntity importFailEntity) throws IOException {
        // 保单
        if ("1".equals(importFailEntity.getType())) {
            List<PolicyImportData> result = Lists.newArrayList();
            JSONArray arr = JSONUtil.parseArray(importFailEntity.getData());
            for (Object o : arr) {
                PolicyImportData dto = JSONUtil.toBean((JSONObject) o, PolicyImportData.class);
                result.add(dto);
            }
            ExcelWriterBuilder writerBuilder = EasyExcel.write(response.getOutputStream(), PolicyImportData.class);
            writerBuilder.sheet("错误数据").doWrite(result);
        }
    }

    @PostMapping(value = "/policy")
    @ApiOperation(value = "1、非车保单导出")
    @ApiOperationSupport(order = 1)
    public void policy(@RequestBody PolicyListCondition policyListCondition,
                       HttpServletResponse response) {
        List<PolicyListDto> policyListDtos = policyController.exportList(policyListCondition);
        if (CollectionUtils.isEmpty(policyListDtos)) {
            throw new BusinessException("无保单");
        }
        try {
            this.handleCommonResponse(response);
            ArrayList<PolicyUncarExport> uncarExports = new ArrayList<>();
            for (PolicyListDto policyListDto : policyListDtos) {
                PolicyUncarExport export = new PolicyUncarExport();
                BeanCopierUtils.copy(policyListDto, export);
                export.setKindCode(KIND_MAP.get(policyListDto.getKindCode()));
                export.setTotalPremium(NumberFormatUtils.centToYuan(policyListDto.getTotalPremium()));
                export.setStatus(STATUS_MAP.get(String.valueOf(policyListDto.getStatus())));
                uncarExports.add(export);
            }
            EasyExcel.write(response.getOutputStream(), PolicyUncarExport.class).sheet("保单")
                .registerWriteHandler(new LongestMatchColumnWidthStyleStrategy())
                .doWrite(uncarExports);
        } catch (IOException e) {
            throw new BusinessException("导出失败");
        }
    }

    @PostMapping(value = "/renewPolicy")
    @ApiOperation(value = "2、续保管理保单导出")
    @ApiOperationSupport(order = 2)
    public void renewPolicy(@RequestBody PolicyListCondition policyListCondition,
                            HttpServletResponse response) {
        List<PolicyListDto> policyListDtos = policyRenewV2Controller.exportList(policyListCondition);
        if (CollectionUtils.isEmpty(policyListDtos)) {
            throw new BusinessException("无保单");
        }
        try {
            this.handleCommonResponse(response);
            ArrayList<PolicyRenewExport> uncarExports = new ArrayList<>();
            for (PolicyListDto policyListDto : policyListDtos) {
                PolicyRenewExport export = new PolicyRenewExport();
                BeanCopierUtils.copy(policyListDto, export);
                export.setKindCode(KIND_MAP.get(policyListDto.getKindCode()));
                uncarExports.add(export);
            }
            EasyExcel.write(response.getOutputStream(), PolicyRenewExport.class).sheet("续保保单")
                .registerWriteHandler(new LongestMatchColumnWidthStyleStrategy())
                .doWrite(uncarExports);
        } catch (IOException e) {
            throw new BusinessException("导出失败");
        }
    }

    @PostMapping(value = "/uncarClaim")
    @ApiOperation(value = "3、理赔导出")
    @ApiOperationSupport(order = 3)
    public void uncarClaim(@RequestBody @Valid ClaimListQuery query,
                           HttpServletResponse response) {
        List<ClaimListDTO> claimList = unCarClaimController.claimList(query);
        if (CollectionUtils.isEmpty(claimList)) {
            throw new BusinessException("无理赔数据");
        }
        try {
            this.handleCommonResponse(response);
            ArrayList<ClaimListExport> claimListExports = new ArrayList<>();
            for (ClaimListDTO claimListDTO : claimList) {
                ClaimListExport export = new ClaimListExport();
                BeanCopierUtils.copy(claimListDTO, export);
                export.setClaimStatus(CLAIM_STATUS_MAP.get(String.valueOf(claimListDTO.getClaimStatus())));
                claimListExports.add(export);
            }
            EasyExcel.write(response.getOutputStream(), ClaimListExport.class).sheet("理赔信息")
                .registerWriteHandler(new LongestMatchColumnWidthStyleStrategy())
                .doWrite(claimListExports);
        } catch (IOException e) {
            throw new BusinessException("导出失败");
        }
    }

    @PostMapping(value = "/fund")
    @ApiOperation(value = "4、基金使用记录导出")
    @ApiOperationSupport(order = 4)
    public void fund(HttpServletResponse response) {
        PageParam<Object> pageParam = new PageParam<>();
        pageParam.setPageNum(1);
        pageParam.setPageSize(Integer.MAX_VALUE);
        PageInfo<EiInsFund> page = eiInsFundService.list(pageParam);
        List<EiInsFund> list = page.getList();
        if (CollectionUtils.isEmpty(list)) {
            throw new BusinessException("没有基金使用记录");
        }
        try {
            this.handleCommonResponse(response);
            ArrayList<FundExport> fundExport = new ArrayList<>();
            for (int i = 1; i <= list.size(); i++) {
                FundExport export = new FundExport();
                BeanCopierUtils.copy(list.get(i - 1), export);
                export.setNumber(i);
                fundExport.add(export);
            }

            EasyExcel.write(response.getOutputStream(), FundExport.class).sheet("基金使用记录")
                .registerWriteHandler(new LongestMatchColumnWidthStyleStrategy())
                .doWrite(fundExport);
        } catch (IOException e) {
            throw new BusinessException("导出失败");
        }
    }

    @PostMapping(value = "/empower")
    @ApiOperation(value = "5、授权列表导出")
    @ApiOperationSupport(order = 5)
    public void empower(@RequestBody PageParam<EmpowerQuery> pageParam, HttpServletResponse response) {
        pageParam.setPageNum(1);
        pageParam.setPageSize(Integer.MAX_VALUE);
        List<ProjectEntity> list = empowerService.getPageList(pageParam);

        if (CollectionUtils.isEmpty(list)) {
            throw new BusinessException("没有查询到授权信息!");
        }
        try {
            this.handleCommonResponse(response);
            ArrayList<EmpowerExport> empowerList = new ArrayList<>();
            for (ProjectEntity projectEntity : list) {
                EmpowerExport export = new EmpowerExport();
                BeanCopierUtils.copy(projectEntity, export);
                export.setRiskKindName(KIND_MAP.get(projectEntity.getRiskKind()));
                export.setEstAmount(NumberFormatUtils.centToYuan(projectEntity.getEstAmount()));
                empowerList.add(export);
            }

            EasyExcel.write(response.getOutputStream(), EmpowerExport.class).sheet("授权信息")
                .registerWriteHandler(new LongestMatchColumnWidthStyleStrategy())
                .doWrite(empowerList);
        } catch (IOException e) {
            throw new BusinessException("导出失败");
        }
    }


    private void handleCommonResponse(HttpServletResponse response) throws IOException {
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding("utf-8");
        String fileName = URLEncoder.encode("文件导出", "UTF-8");
        response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");
    }
}
