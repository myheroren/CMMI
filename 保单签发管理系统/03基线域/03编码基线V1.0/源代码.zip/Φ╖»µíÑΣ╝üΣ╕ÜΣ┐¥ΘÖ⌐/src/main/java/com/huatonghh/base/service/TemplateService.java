package com.huatonghh.base.service;

import com.google.common.collect.Lists;
import com.huatonghh.base.domain.TemplateMain;
import com.huatonghh.base.domain.TemplateVehRiskPlan;
import com.huatonghh.base.repository.TemplateMainRepository;
import com.huatonghh.base.repository.TemplateVehRiskPlanRepository;
import com.huatonghh.common.service.dto.ResponseIntegerKeyValueDto;
import com.huatonghh.base.service.dto.TemplateCondition;
import com.huatonghh.base.service.dto.TemplateMainDto;
import com.huatonghh.base.service.dto.TemplateVehRiskPlanDto;
import com.huatonghh.common.constant.enums.StatusEnum;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.util.system.PageInfo;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFactory;
import org.modelmapper.ModelMapper;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

/**
 * Description : 模板套餐管理-业务层
 * @author : Sun
 * @date : 2019/9/19 14:55
 * @version : 1.0
 */
@Service
@CacheConfig
@Slf4j
@AllArgsConstructor
public class TemplateService {

    private final MapperFactory mapperFactory;

    private final ModelMapper modelMapper;

    private final TemplateMainRepository templateMainRepository;

    private final TemplateVehRiskPlanRepository templateVehRiskPlanRepository;


    /**
     * @author Sun
     * @description 套餐表增删改查、套餐下拉框、根据套餐id获取详情
     * @date 2019/11/5 21:16
     * @param templateMainDto:
     **/
    @Transactional(rollbackFor = RuntimeException.class)
    public void saveTemplateRiskPlan(@RequestBody @Valid TemplateMainDto templateMainDto) {
        Integer id = templateMainDto.getId();
        String templateName = templateMainDto.getTemplateName();
        Byte templateType = templateMainDto.getTemplateType();
        if(id == null) {
            // 新增-校验模板名称是否存在
            Optional<TemplateMain> optional = templateMainRepository.findByTemplateNameAndTemplateType(templateName, templateType);
            if(optional.isPresent()) {
                throw new BusinessException("模板名称:" + templateName + "已经存在");
            }
        }

        // 保单模板主信息
        TemplateMain templateMain = modelMapper.map(templateMainDto, TemplateMain.class);
        templateMain = templateMainRepository.save(templateMain);

        // 根据类型，保存对应模板详细信息
        if(templateType == 1) {
            List<TemplateVehRiskPlanDto> templateList = templateMainDto.getTemplateVehRiskPlanDtos();

            if(templateList == null || templateList.isEmpty()) {
                return;
            }
            // 删除现有的模板方法
            templateVehRiskPlanRepository.deleteByTemplateId(templateMain.getId());

            // Dto转换为entity
            mapperFactory.classMap(TemplateVehRiskPlanDto.class, TemplateVehRiskPlan.class).byDefault().register();
            List<TemplateVehRiskPlan> templateVehRiskPlans = mapperFactory.getMapperFacade().mapAsList(templateList, TemplateVehRiskPlan.class);
            for (TemplateVehRiskPlan templateVehRiskPlan : templateVehRiskPlans) {
                templateVehRiskPlan.setTemplateId(templateMain.getId());
                templateVehRiskPlan.setId(null);
            }

            // 保存
            templateVehRiskPlanRepository.saveAll(templateVehRiskPlans);
        }
    }


    /**
     * @author Sun
     * @description 根据模板类型查询模板下拉框列表
     * @date 2019/11/5 21:17
     * @param templateType: 模板类型
     * @return java.util.List<com.huatonghh.common.service.dto.ResponseIntegerKeyValueDto>
     **/
    public List<ResponseIntegerKeyValueDto> queryRiskPlanSelectKeyValue(Byte templateType) {
        return templateMainRepository.queryRiskPlanSelectKeyValue(templateType);
    }


    /**
     * @author Sun
     * @description 模板分页列表
     * @date 2019/11/5 21:17
     * @param templateC:
     * @return com.huatonghh.common.util.system.PageInfo<com.huatonghh.base.service.dto.TemplateMainDto>
     **/
    public PageInfo<TemplateMainDto> queryTemplatePageList(TemplateCondition templateC) {
        // 获取分页信息
        Integer pageNum = templateC.getPageNum();
        Integer pageSize = templateC.getPageSize();
        // 查询
        Page<TemplateMain> byTemplateType = templateMainRepository.findByTemplateType(templateC.getTemplateType(), PageRequest.of(pageNum - 1, pageSize));

        // 组装反参
        List<TemplateMainDto> result = Lists.newArrayList();
        byTemplateType.getContent().forEach(templateMain -> result.add(modelMapper.map(templateMain, TemplateMainDto.class)));
        return PageInfo.of(pageNum, pageSize, result, byTemplateType.getTotalElements());
    }


    /**
     * @author Sun
     * @description 根据模板id获取模板详情
     * @date 2019/11/5 21:17
     * @param id: 模板id
     * @return com.huatonghh.base.service.dto.TemplateMainDto
     **/
    public TemplateMainDto queryTemplateRiskPlanDetail(Integer id) {
        Optional<TemplateMain> byId = templateMainRepository.findById(id);
        if(!byId.isPresent()){
            throw new BusinessException(StatusEnum.TEMPLATE_NOT_EXIST);
        }
        TemplateMain templateMain = byId.get();
        TemplateMainDto templateMainDto = modelMapper.map(templateMain, TemplateMainDto.class);

        // 获取车辆模板方案列表
        List<TemplateVehRiskPlan> byTemplateId = templateVehRiskPlanRepository.findByTemplateId(templateMain.getId());
        mapperFactory.classMap(TemplateVehRiskPlan.class, TemplateVehRiskPlanDto.class).byDefault().register();
        List<TemplateVehRiskPlanDto> templateVehRiskPlanDtos = mapperFactory.getMapperFacade().mapAsList(byTemplateId, TemplateVehRiskPlanDto.class);
        templateMainDto.setTemplateVehRiskPlanDtos(templateVehRiskPlanDtos);
        return templateMainDto;
    }

}
