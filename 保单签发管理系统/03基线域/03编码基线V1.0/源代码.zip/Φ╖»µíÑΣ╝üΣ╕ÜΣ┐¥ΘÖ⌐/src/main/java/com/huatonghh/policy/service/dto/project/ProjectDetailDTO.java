package com.huatonghh.policy.service.dto.project;

import com.huatonghh.file.service.dto.FiAuditFileDto;
import com.huatonghh.policy.service.dto.task.CheckDTO;
import com.huatonghh.policy.service.dto.task.HandlerDTO;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/9/10
 */
@Data
@ApiModel("计划内项目项目详情")
public class ProjectDetailDTO {
    private ProjectDTO baseInfo;
    private List<ProjectPreCoinsuranceDTO> coinsuranceInfos;
    private List<FiAuditFileDto> files;
    private List<CheckDTO> checks;
    private List<HandlerDTO> handlers;
}
