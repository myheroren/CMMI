package com.huatonghh.policy.service.dto.project;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.huatonghh.common.service.BlocDepartJsonSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Date: 2020/2/12 16:27</p>
 *
 * @author EDZ
 */
@Data
public class ToDoResponse {
    private String taskId;
    @ApiModelProperty("计划编号")
    @JsonSerialize(using = ToStringSerializer.class)
    private String planNo;
    private String planName;
    private Byte planType;
    private String startCompany;
    @JsonSerialize(using = BlocDepartJsonSerializer.class)
    private String startCompanyName;
    @ApiModelProperty("计划开始时间 yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startTime;
    private Byte mainStatus;

    @ApiModelProperty("任务创建时间 yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
}
