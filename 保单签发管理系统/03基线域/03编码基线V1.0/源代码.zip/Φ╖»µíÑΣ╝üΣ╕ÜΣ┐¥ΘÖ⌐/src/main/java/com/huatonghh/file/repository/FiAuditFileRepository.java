package com.huatonghh.file.repository;

import com.huatonghh.file.domain.FiAuditFile;
import com.huatonghh.file.service.dto.FiAuditFileDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * @author : Sun
 * @version : 1.0
 * @description : 审批附件表-数据仓库
 * @date : 2019/11/5 21:24
 */
@Repository
public interface FiAuditFileRepository extends JpaRepository<FiAuditFile, Integer> {

    /**
     * findByFileId
     *
     * @param fileId:
     * @return java.util.Optional<com.huatonghh.file.domain.FiAuditFile>
     * @author Sun
     * @date 2019/11/5 21:26
     **/
    Optional<FiAuditFile> findByFileId(Integer fileId);

    /**
     * 根据所属编号，所属类型，有效状态查询
     *
     * @param belongId:   所属编号
     * @param belongType: 所属类型
     * @param valid:      有效状态
     * @return java.util.List<com.huatonghh.file.domain.FiAuditFile>
     * @author Sun
     * @date 2019/11/5 21:24
     **/
    List<FiAuditFile> findAllByBelongIdAndBelongTypeAndValidOrderByCreateTimeDesc(String belongId, Byte belongType, Boolean valid);


    /**
     * findFiAuditFileDto
     *
     * @param belongId:
     * @param belongType:
     * @param valid:
     * @return java.util.List<com.huatonghh.file.service.dto.FiAuditFileDto>
     * @author Sun
     * @date 2019/11/5 21:25
     **/
    @Query(value = "SELECT new com.huatonghh.file.service.dto.FiAuditFileDto(a.auditId, a.fileId, a.fileName, a.uploadUser,a.uploadUserName, a.uploadLink, a.belongId, a.belongType, a.remark, a.valid, a.preview, a.createTime, u.fileSize) FROM FiFile u, FiAuditFile a WHERE u.fileId = a.fileId AND a.belongId = :belongId AND a.belongType = :belongType AND a.valid = :valid")
    List<FiAuditFileDto> findFiAuditFileDto(@Param("belongId") String belongId, @Param("belongType") Byte belongType, @Param("valid") Boolean valid);


    /**
     * 根据belong_id删除所有方案
     *
     * @param belongId:
     * @param belongType:
     * @author Sun
     * @date 2019/11/5 21:25
     **/
    @Modifying
    @Query("delete from FiAuditFile d where d.belongId = :belongId and d.belongType = :belongType")
    @Transactional(rollbackFor = RuntimeException.class)
    void deleteByBelongIdAndType(@Param("belongId") String belongId, @Param("belongType") Byte belongType);


    /**
     * 根据业务主键和业务类型更新上传环节
     *
     * @param belongId:   业务主键
     * @param belongType: 业务类型
     * @param uploadLink: 上传环节
     * @author Sun
     * @date 2019/11/5 21:25
     **/
    @Modifying
    @Query("update FiAuditFile d set d.uploadLink =:uploadLink where d.belongId = :belongId and d.belongType = :belongType")
    @Transactional(rollbackFor = RuntimeException.class)
    void updateByBelongIdAndType(@Param("belongId") String belongId, @Param("belongType") Byte belongType, @Param("uploadLink") String uploadLink);


    /**
     * 更新主键的上传环节
     *
     * @param belongId:      业务主键
     * @param oldUploadLink: 旧上传环节
     * @param newUploadLink: 新上传环节
     * @author Sun
     * @date 2019/11/5 21:25
     **/
    @Modifying
    @Query("update FiAuditFile d set d.uploadLink =:newUploadLink where d.belongId = :belongId and d.uploadLink = :oldUploadLink")
    @Transactional(rollbackFor = RuntimeException.class)
    void updateByBelongIdAndUploadLink(@Param("belongId") String belongId, @Param("oldUploadLink") String oldUploadLink, @Param("newUploadLink") String newUploadLink);

}
