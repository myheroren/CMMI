package com.huatonghh.excel.service.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import lombok.Data;

/**
 * description: 历史保单导入
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/9
 */
@Data
@ContentRowHeight(20)
@HeadRowHeight(20)
@ColumnWidth(15)
public class PCDImportData {

    @ExcelProperty(value = "c_area_cname", index = 0)
    private String codeName;

    @ExcelProperty(value = "c_area_code", index = 1)
    private String remark;

    @ExcelProperty(value = "c_par_code", index = 2)
    private String ename;

}
