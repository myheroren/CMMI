package com.huatonghh.fund.controller;

import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.common.util.system.PageParam;
import com.huatonghh.fund.domain.EiInsFund;
import com.huatonghh.fund.service.EiInsFundService;
import com.huatonghh.fund.service.dto.FundDTO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

/**
 * @author ghy
 * Date: 2021/1/5 16:48
 */
@RestController
@AllArgsConstructor
@RequestMapping("/api/fund/v1")
@Api(tags = "基金记录接口")
public class EiInsFundController {

    private final EiInsFundService eiInsFundService;

    @ApiOperation(value = "基金使用记录列表")
    @PostMapping("/pageList")
    public ApiResponse<PageInfo<EiInsFund>> pageList(@RequestBody PageParam<Object> pageParam){
        return ApiResponse.ofSuccess(eiInsFundService.list(pageParam));
    }

    @ApiOperation(value = "最后一次使用记录")
    @GetMapping("/lastUsed")
    public ApiResponse<EiInsFund> lastUsed(){
        return ApiResponse.ofSuccess(eiInsFundService.getLastUsed());
    }

    @ApiOperation(value = "录入基金")
    @PostMapping("/save")
    public ApiResponse<EiInsFund> save(@RequestBody FundDTO fundDTO){
        eiInsFundService.save(fundDTO);
        return ApiResponse.ofSuccess(null);
    }
}
