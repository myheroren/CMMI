package com.huatonghh.base.repository;

import com.huatonghh.base.domain.BaseCode;
import com.huatonghh.base.service.dto.BaseCodeDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * @author : Sun
 * @version : 1.0
 * @description : 基础代码-数据仓库
 * @date : 2019/11/5 20:52
 */
public interface BaseCodeRepository extends JpaRepository<BaseCode, Integer> {

    /**
     * 批量删除基础代码
     *
     * @param ids: 基础代码ID
     * @author Sun
     * @date 2019/11/5 20:53
     **/
    @Modifying
    @Query(value = "update BaseCode b set b.valid = '0' where b.id in :ids")
    void batchDeleteBaseCodes(@Param("ids") int[] ids);


    /**
     * 获取所有类型代码
     *
     * @return java.util.List<java.lang.String> 类型代码
     * @author Sun
     * @date 2019/11/5 20:53
     **/
    @Query("select distinct b.typeId from BaseCode b")
    List<String> findDistinctTypeCodes();


    /**
     * 根据类型代码查询基础代码
     *
     * @param typeCode: 类型代码
     * @param valid:    有效标志
     * @return java.util.List<com.huatonghh.base.domain.BaseCode> 基础代码
     * @author Sun
     * @date 2019/11/5 20:53
     **/
    List<BaseCode> findByTypeIdAndValid(String typeCode, boolean valid);

    /**
     * 根据类型代码、名称查询基础代码
     *
     * @param typeCode 类型代码
     * @param codeName 中文名称
     * @param valid    有效标志
     * @return java.util.List<com.huatonghh.base.domain.BaseCode> 基础代码
     */
    List<BaseCode> findByTypeIdAndCodeNameAndValid(String typeCode, String codeName, boolean valid);

    /**
     * 根据类型代码、名称查询基础代码
     *
     * @param typeCode 类型代码
     * @param codeId   中文名称
     * @param valid    有效标志
     * @return java.util.List<com.huatonghh.base.domain.BaseCode> 基础代码
     */
    List<BaseCode> findByTypeIdAndCodeIdAndValid(String typeCode, String codeId, boolean valid);

    /**
     * 根据类型代码查询基础代码 旧版
     *
     * @param b: 有效标志
     * @return java.util.List<com.huatonghh.base.domain.BaseCode>
     * @author Sun
     * @date 2019/11/5 20:55
     **/
    List<BaseCode> findByValid(boolean b);


    /**
     * 根据类型代码查询基础代码
     *
     * @param typecode: 类型代码
     * @param valid:    有效标志
     * @param pageable: 分页
     * @return org.springframework.data.domain.Page<com.huatonghh.base.domain.BaseCode> 基础代码
     * @author Sun
     * @date 2019/11/5 20:54
     **/
    Page<BaseCode> findByTypeIdAndValid(String typecode, boolean valid, Pageable pageable);


    /**
     * 根据类型代码查询基础代码，旧版
     *
     * @param valid:
     * @param pageable:
     * @return org.springframework.data.domain.Page<com.huatonghh.base.domain.BaseCode>
     * @author Sun
     * @date 2019/11/5 20:54
     **/
    Page<BaseCode> findByValid(boolean valid, Pageable pageable);


    /**
     * 查询所有类型信息
     *
     * @return java.util.List<com.huatonghh.base.service.dto.BaseCodeDto>
     * @author Sun
     * @date 2019/11/5 20:54
     **/
    @Query("select distinct new com.huatonghh.base.service.dto.BaseCodeDto(b.typeId,b.typeName) from BaseCode b order by b.id desc")
    List<BaseCodeDto> findDistinctTypeIdInfo();


    /**
     * 查询所有类型信息
     *
     * @param typeId:
     * @return java.util.List<com.huatonghh.base.service.dto.BaseCodeDto>
     * @author Sun
     * @date 2019/11/5 20:54
     **/
    @Query("select distinct new com.huatonghh.base.service.dto.BaseCodeDto(b.codeId,b.codeName) from BaseCode b where b.typeId = :typeId")
    List<BaseCodeDto> findDistinctTypeIdInfoByTypeId(@Param("typeId") String typeId);

    /**
     * 查询地区数据
     *
     * @param typeId 字典类型id（city_code）
     * @return BaseCode类型的数据集合
     */
    List<BaseCode> findByTypeIdOrderByRemark(String typeId);
}
