package com.huatonghh.policy.repository.policy;

import com.huatonghh.policy.domain.policy.PolicyUncarDetail;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigInteger;
import java.util.Optional;

/**
 * @author : Sun
 * @description :
 * @date : 2019/11/5 21:44
 * @version : 1.0
 */
public interface PolicyUncarDetailRepository extends JpaRepository<PolicyUncarDetail, BigInteger> {

    /**
     * findByPolicyNo
     *
     * @author Sun
     * @date 2019/11/5 21:44
     * @param policyNo:
     * @return java.util.Optional<com.huatonghh.plan.domain.policy.PolicyUncarDetail>
     **/
    Optional<PolicyUncarDetail> findByPolicyNo(String policyNo);

}
