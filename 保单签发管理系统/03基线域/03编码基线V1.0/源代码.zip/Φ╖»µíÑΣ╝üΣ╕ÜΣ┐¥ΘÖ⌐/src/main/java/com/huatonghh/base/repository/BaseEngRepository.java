package com.huatonghh.base.repository;

import com.huatonghh.base.domain.BaseEng;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/7
 */
public interface BaseEngRepository extends JpaRepository<BaseEng, Integer> {
    /**
     * 根据name和有效查
     *
     * @param name  项目名称
     * @param valid 是否有效
     * @return 基本项目
     */
    List<BaseEng> findAllByNameAndValid(String name, Boolean valid);

    /**
     * 查所有
     *
     * @return 基本项目
     */
    @Query(value = "select * from base_eng b where b.is_valid =1  order by b.current_timestamp desc", nativeQuery = true)
    List<BaseEng> allOrderByTime();
}
