package com.huatonghh.policy.service.claim.noncar;


import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.huatonghh.authority.repository.EiUserRepository;
import com.huatonghh.base.service.BaseCodeService;
import com.huatonghh.base.service.dto.BaseCodeDto;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.repository.DynamicQuery;
import com.huatonghh.common.util.BOIdUtils;
import com.huatonghh.common.util.BeanCopierUtils;
import com.huatonghh.common.util.DateFormatUtil;
import com.huatonghh.common.util.hutool.ClassUtils;
import com.huatonghh.common.util.hutool.LineToHumpTool;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.common.util.system.PageParam;
import com.huatonghh.file.service.AuditFileService;
import com.huatonghh.file.service.dto.FiAuditFileDto;
import com.huatonghh.message.constant.MessageConstant;
import com.huatonghh.message.po.dto.*;
import com.huatonghh.message.po.entity.Message;
import com.huatonghh.message.repository.MessageRepository;
import com.huatonghh.message.service.MessageService;
import com.huatonghh.policy.constant.ClaimConstant;
import com.huatonghh.policy.constant.PlanConstant;
import com.huatonghh.policy.constant.PolicyConstant;
import com.huatonghh.policy.domain.claim.noncar.ClaimHistory;
import com.huatonghh.policy.domain.claim.noncar.ClaimInfo;
import com.huatonghh.policy.domain.policy.PolicyCarDetail;
import com.huatonghh.policy.domain.policy.PolicyMain;
import com.huatonghh.policy.repository.PolicyUncarClaimPayRepository;
import com.huatonghh.policy.repository.claim.ClaimHistoryRepository;
import com.huatonghh.policy.repository.claim.noncar.UnCarClaimRepository;
import com.huatonghh.policy.repository.policy.PolicyMainRepository;
import com.huatonghh.policy.service.PolicyService;
import com.huatonghh.policy.service.client.CurrentCompanyDTO;
import com.huatonghh.policy.service.client.UserClient;
import com.huatonghh.policy.service.dto.claim.form.ClaimHighwayDetailDTO;
import com.huatonghh.policy.service.dto.claim.form.ClaimMessageDTO;
import com.huatonghh.policy.service.dto.claim.form.EngClaimQuery;
import com.huatonghh.policy.service.dto.claim.noncar.*;
import com.huatonghh.policy.service.dto.policy.SavePolicyCarDto;
import com.huatonghh.policy.service.dto.policy.SavePolicyDto;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author : hao.wang
 * @date : 2019/8/23
 * description : 理赔Service
 */
@Service
@Slf4j
@AllArgsConstructor
public class UnCarClaimService {

    private final PolicyService policyService;

    private final PolicyMainRepository policyMainRepository;

    private final UnCarClaimRepository claimRepository;

    private final ClaimHistoryRepository historyRepository;

    private final UserClient userClient;

    private final AuditFileService fileService;

    private final DynamicQuery dynamicQuery;

    private final PolicyUncarClaimPayRepository policyUncarClaimPayRepository;

    private final MessageService messageService;

    private final MessageRepository messageRepository;

    private final AuditFileService auditFileService;

    private final ClaimHistoryRepository claimHistoryRepository;

    private final BaseCodeService baseCodeService;

    private final EiUserRepository eiUserRepository;

    public String save(ClaimBasicDTO basicDTO) {
        PolicyMain policyMain = this.getPolicy(basicDTO.getPolicyNo());

        ClaimInfo claimInfo = new ClaimInfo();

        BeanCopierUtils.copy(basicDTO, claimInfo);

        claimInfo.setReportId(BOIdUtils.getId("LP"));
        claimInfo.setInsuranceCategory(policyMain.getInsuranceCategory());
        claimInfo.setKindCode(policyMain.getKindCode());
        //理赔状态
        claimInfo.setClaimStatus(ClaimConstant.CLAIM_STATUS_REPORT);
        claimInfo.setCreateTime(DateUtil.date());
        String userName = userClient.getCurrentUserName();
        String user = userClient.getGroupUserInfo(userName).getName();
        claimInfo.setOperatorCode(userName);
        claimInfo.setOperator(user);
        String reportId = claimRepository.save(claimInfo).getReportId();

        //保存理赔节点信息
        ClaimHistory history = new ClaimHistory();
        history.setClaimStatus(ClaimConstant.CLAIM_STATUS_REPORT);
        history.setCreateTime(DateUtil.date());
        history.setReportId(reportId);
        history.setOperator(user);
        historyRepository.save(history);

        //todo 给保险公司发消息

        // 保存附件
        List<FiAuditFileDto> files = basicDTO.getFiles();
        if (CollectionUtils.isNotEmpty(files)) {
            for (FiAuditFileDto file : files) {
                file.setBelongId(String.valueOf(basicDTO.getReportId()));
                auditFileService.saveAuditFile(file);
            }
        }
        return reportId;
    }


    public void update(ClaimBasicDTO basicDTO) {
        ClaimInfo claimInfo = this.checkExist(basicDTO.getReportId());

        BeanCopierUtils.copy(basicDTO, claimInfo);
        String user = userClient.getGroupUserInfo(userClient.getCurrentUserName()).getName();
        int status;
        if (!ClaimConstant.CLAIM_STATUS_DOWN.equals(claimInfo.getClaimStatus())) {
            status = claimInfo.getClaimStatus();
            status += 1;
        } else {
            status = (int) ClaimConstant.CLAIM_STATUS_DOWN;
        }
        // 立案
        if (ClaimConstant.CLAIM_STATUS_REGISTER.equals((byte) status)) {
            claimInfo.setClaimBeginDate(DateUtil.date());
        }
        if (ClaimConstant.CLAIM_STATUS_DOWN.equals((byte) status)) {
            claimInfo.setClaimEndDate(DateUtil.date());
        }
        claimInfo.setClaimStatus((byte) (status));
        claimInfo.setUpdateTime(DateUtil.date());
        claimInfo.setOperator(user);
        claimRepository.save(claimInfo);

        //保存理赔信息
        ClaimHistory history = new ClaimHistory();
        history.setClaimStatus((byte) (status));
        history.setCreateTime(DateUtil.date());
        history.setReportId(basicDTO.getReportId());
        history.setOperator(user);
        historyRepository.save(history);

        //todo 发送消息

    }

    public ClaimDetailDTO detail(String reportId) {
        ClaimInfo claimInfo = checkExist(reportId);
        ClaimDetailDTO claimDetailDTO = new ClaimDetailDTO();
        ClaimBasicDTO basicInfo = new ClaimBasicDTO();

        BeanCopierUtils.copy(claimInfo, basicInfo);
        //报案信息及出险信息
        claimDetailDTO.setBasicInfo(basicInfo);

        List<FiAuditFileDto> claimFilesByClaim = fileService.listFiAuditFileDto(reportId.toString(), PlanConstant.BELONG_TYPE_CLAIM, true);
        List<FiAuditFileDto> claimFilesByReport = fileService.listFiAuditFileDto(reportId.toString(), PlanConstant.BELONG_TYPE_REPORT, true);

        claimFilesByClaim.addAll(claimFilesByReport);
        //附件信息
        basicInfo.setFiles(claimFilesByClaim);
        //理赔节点信息
        claimDetailDTO.setClaimHistories(historyRepository.findAllByReportIdOrderByClaimStatusAsc(reportId));
        //保单信息
        claimDetailDTO.setPolicyInfo(this.getPolicyInfoByPolicyNo(claimInfo.getPolicyNo()));
        //支付信息
        claimDetailDTO.setPayInfo(policyUncarClaimPayRepository.findAllByReportNo(claimInfo.getReportNo()));
        return claimDetailDTO;
    }


    private PolicyDTO getPolicyInfoByPolicyNo(String policyNo) {
        PolicyDTO policyInfo = new PolicyDTO();
        SavePolicyDto policy = policyService.queryPolicyDetail(policyNo);

        BeanCopierUtils.copy(policy, policyInfo);
        if (PolicyConstant.POLICY_CAR.equals(policy.getCarUncarFlag())) {
            SavePolicyCarDto car = policy.getSavePolicyCarDto();
            policyInfo.setFrameNo(car.getFrameNo());
            policyInfo.setPlateNo(car.getPlateNo());
            policyInfo.setVehicleModel(car.getVehicleModel());
        } else {

            policyInfo.setProName(policyInfo.getProName());
        }
        return policyInfo;
    }

    public PageInfo<ClaimListDTO> list(ClaimListQuery query) {
        // 施工方特殊处理
        // 获取分页信息
        int pageNum = query.getPageNo();
        int pageSize = query.getPageSize();
        // 得到查询sql
        StringBuilder sqlBuild = this.getQuerySql(query);

        // 得到总数
        Long total = this.getTotal(sqlBuild.toString());

        // 查数据
        List<ClaimListDTO> plans = this.listClaimByQuery(sqlBuild, pageNum, pageSize);
        if (plans == null) {
            return PageInfo.of(pageNum, pageSize, null, 0L);
        }

        return PageInfo.of(pageNum, pageSize, plans, total);
    }


    private List<ClaimListDTO> listClaimByQuery(StringBuilder sqlBuild, int pageNum, int pageSize) {
        sqlBuild.append(" limit ?1, ?2 ");
        log.info("根据条件查计划列表:{}", sqlBuild);
        return dynamicQuery.nativeQueryListModel(ClaimListDTO.class, sqlBuild.toString(), (pageNum - 1) * pageSize, pageSize);
    }

    private Long getTotal(String sqlBuild) {
        return dynamicQuery.nativeQueryCount("SELECT count(*) FROM ( " + sqlBuild + ") a");
    }

    private StringBuilder getQuerySql(ClaimListQuery query) {
        // 字段
        StringBuilder sqlBuild = this.getClaimListBaseSql();
        this.formSql(sqlBuild, query);
        // 条件
        this.getConditionSql(query, sqlBuild);
        return sqlBuild;
    }

    private void formSql(StringBuilder sqlBuild, ClaimListQuery query) {
        // 当前公司
        String companyId;
        CurrentCompanyDTO currentCompanyDTO = userClient.getCurrentCompanyInfo();
        boolean isCurrentGroup = userClient.isCurrentGroup();
        if (isCurrentGroup) {
            companyId = currentCompanyDTO.getEiDepartDto().getId();
        } else {
            companyId = currentCompanyDTO.getEiInsDepartDto().getId().toString();
        }

        sqlBuild.append(" ,d1.name as  startCompanyName ");
        sqlBuild.append(" ,d2.name as  belongCompanyName ");
        sqlBuild.append(" from policy_uncar_claim c , policy_main m ,ei_depart d1 ,ei_ins_depart d2 ,ei_depart d3");

        sqlBuild.append(" where 1=1 ");
        sqlBuild.append(" and c.policy_no =  m.policy_no  ");
        sqlBuild.append(" and d1.id=m.start_company ");
        sqlBuild.append(" and d2.id=m.belong_company ");

        // 是否是需求公司
        if (isCurrentGroup) {
            // 需求公司看自己发起的,自己下级
            sqlBuild.append(" AND d3.id = '")
                .append(companyId).append("'")
                .append(" AND d1.ids LIKE CONCAT(d3.ids,'%')");
        } else {
            // 保险公司看属于自己的
            sqlBuild.append(" and m.belong_company = ").append(companyId);
        }
    }

    private void getConditionSql(ClaimListQuery query, StringBuilder sqlBuild) {
        //排序的列名称
        String column = LineToHumpTool.humpToLines(query.getColumn());

        if (CollectionUtils.isNotEmpty(query.getIds())) {
            sqlBuild.append(" and c.report_id in (");
            sqlBuild.append(StringUtils.join(query.getIds(), ","));
            sqlBuild.append(")");
        } else {
            if (StringUtils.isNotBlank(query.getPolicyNo())) {
                sqlBuild.append(" and m.policy_no like '").append("%").append(query.getPolicyNo()).append("%").append("'");
            }
            // 需求公司
            if (StringUtils.isNotBlank(query.getStartCompany())) {
                sqlBuild.append(" and m.start_company =").append(query.getBelongCompany());
            }
            // 险种
            if (StringUtils.isNotBlank(query.getInsuranceCategory())) {
                sqlBuild.append(" and m.kind_code =").append(query.getKindCode());
            }
            // 理赔状态
            if (null != query.getStatus()) {
                if (query.getStatus().contains(",")) {
                    sqlBuild.append(" and c.claim_status in (").append(query.getStatus()).append(")");
                } else {
                    sqlBuild.append(" and c.claim_status =").append(query.getStatus());
                }
            }
            // 车，非车标志
            if (null != query.getCarUncarFlag()) {
                sqlBuild.append(" and m.car_uncar_flag =").append(query.getCarUncarFlag());
            }
            // 投保人
            if (StringUtils.isNotBlank(query.getHolderName())) {
                sqlBuild.append(" and m.holder_name like '").append("%" + query.getHolderName() + "%").append("'");
            }
            // 被保人
            if (StringUtils.isNotBlank(query.getInsuredName())) {
                sqlBuild.append(" and m.insured_name = '").append(query.getInsuredName()).append("'");
            }
            // 保险公司
            if (StringUtils.isNotBlank(query.getBelongCompany())) {
                sqlBuild.append(" and d2.id = '").append(query.getBelongCompany()).append("'");
            }
            // 出险时间
            if (null != query.getAccidentStartTime()) {
                sqlBuild.append(StrUtil.format(" AND c.accident_time >= '{}' ", DateFormatUtil.dateToStr(query.getAccidentStartTime(), "yyyy-MM-dd HH:mm:ss")));
            }
            if (null != query.getAccidentEndTime()) {
                sqlBuild.append(StrUtil.format(" AND c.accident_time <= '{}' ", DateFormatUtil.dateToStr(query.getAccidentEndTime(), "yyyy-MM-dd HH:mm:ss")));
            }
            // 报案时间
            if (null != query.getReportStartTime()) {
                sqlBuild.append(StrUtil.format(" AND c.report_time >= '{}' ", DateFormatUtil.dateToStr(query.getReportStartTime(), "yyyy-MM-dd HH:mm:ss")));
            }
            if (null != query.getReportEndTime()) {
                sqlBuild.append(StrUtil.format(" AND c.report_time <=  '{}' ", DateFormatUtil.dateToStr(query.getReportEndTime(), "yyyy-MM-dd HH:mm:ss")));
            }
        }
        // 默认逆序
        String descType = "desc";
        if (query.getRange().equals(1)) {
            descType = "asc";
        }

        // 获取车、非车特有列表字段 UnCarClaimInfoEntity
        // 默认根据时间戳
        if (PlanConstant.COLUMN_CURRENT.equals(column)) {
            sqlBuild.append(" order by c." + column + " ").append(descType);
        } else if (ClassUtils.containsField(new ClaimInfo(), query.getColumn())) {
            sqlBuild.append(" order by c." + column + " ").append(descType);
        } else if (ClassUtils.containsField(new PolicyMain(), query.getColumn())) {
            sqlBuild.append(" order by m." + column + " ").append(descType);
        } else if (ClassUtils.containsField(new PolicyCarDetail(), query.getColumn())) {
            sqlBuild.append(" order by cd." + column + " ").append(descType);
        }

    }

    private StringBuilder getClaimListBaseSql() {
        StringBuilder sql = new StringBuilder("");
        sql.append(" SELECT DISTINCT");
        sql.append(" c.report_id as reportId ");
        sql.append(" ,c.report_no as reportNo ");
        sql.append(" ,c.claim_status as claimStatus ");
        sql.append(" ,c.create_time as createTime ");
        sql.append(" ,c.update_time as updateTime ");
        sql.append(" ,c.accident_time as accidentTime ");
        sql.append(" ,c.report_time as reportTime ");
        sql.append(" ,m.policy_no as policyNo ");
        sql.append(" ,m.insurance_category as insuranceCategory ");
        sql.append(" ,m.kind_code as kindCode ");
        sql.append(" ,m.project_name as projectName ");
        sql.append(" ,m.holder_name as holderName ");
        sql.append(" ,m.insured_name as insuredName ");
        sql.append(" ,m.insured_name as insuredNameCn ");
        sql.append(" ,m.start_company as startCompany ");
        sql.append(" ,m.belong_company as belongCompany ");
        sql.append(" ,m.policy_bgn_time as policyBgnTime ");
        sql.append(" ,m.policy_end_time as policyEndTime ");
        sql.append(" ,m.car_uncar_flag as carUncarFlag ");
        return sql;
    }


    public List<PolicyClaimDTO> listByPolicy(String policyNo) {
        List<ClaimInfo> list = claimRepository.findAllByPolicyNoOrderByCreateTimeDesc(policyNo);
        if (null == list || list.size() <= 0) {
            return null;
        }
        return list.stream().map(ele -> {
                PolicyClaimDTO policyClaimDTO = new PolicyClaimDTO();
                BeanCopierUtils.copy(ele, policyClaimDTO);
                return policyClaimDTO;
            }
        ).collect(Collectors.toList());
    }

    public Long getCountClaim(EngClaimQuery query, String claimStatus) {
        String policyNos = query.getPolicyNos();
        if (StringUtils.isBlank(policyNos)) {
            return null;
        }
        StringBuilder sql = new StringBuilder("\n" +
            "select count(1) from policy_uncar_claim c\n" +
            "where 1=1\n" +
            "and c.insurance_category = 5 ");
        if (null == claimStatus) {
            sql.append(" and c.claim_status <> '0'");
        } else {
            sql.append(" and c.claim_status = '").append(claimStatus + "'");
        }

        policyNos = this.getSqlStr(policyNos);
        sql.append(" and c.policy_no in (" + policyNos + ")");

        if (null != query.getBeginTime() && null != query.getEndTime()) {
            sql.append(StrUtil.format(" AND c.create_time BETWEEN '{}' AND '{}' ", DateFormatUtil.dateToStr(query.getBeginTime(), "yyyy-MM-dd"), DateFormatUtil.dateToStr(query.getEndTime(), "yyyy-MM-dd")));
        }
        return dynamicQuery.nativeQueryCount(sql.toString());
    }

    public List<ClaimHighwayDetailDTO> allEngClaim(EngClaimQuery query) {
        String policyNos = query.getPolicyNos();
        if (StringUtils.isBlank(policyNos)) {
            return null;
        }
        // 1,2,3->'1','2','3'
        policyNos = this.getSqlStr(policyNos);
        StringBuilder sql = new StringBuilder("select \n" +
            "count(c.report_id) countApply\n" +
            ",sum(c.pre_loss_amount) preLossAmount\n" +
            ",sum(c.ask_for_amount) askForAmount\n" +
            ",sum(c.pay_amount)  payAmount\n" +
            "from policy_uncar_claim c\n" +
            "where 1=1\n" +
            "and c.insurance_category = 5\n" +
            "and c.policy_no in (" + policyNos + ")");
        if (null != query.getBeginTime() && null != query.getEndTime()) {
            sql.append(StrUtil.format(" AND c.create_time BETWEEN '{}' AND '{}' ", DateFormatUtil.dateToStr(query.getBeginTime(), "yyyy-MM-dd"), DateFormatUtil.dateToStr(query.getEndTime(), "yyyy-MM-dd")));
        }
        return dynamicQuery.nativeQueryListModel(ClaimHighwayDetailDTO.class, sql.toString());
    }

    public String getSqlStr(String s) {
        if (!s.contains(",")) {
            return "'" + s + "'";
        }
        String[] split = s.split(",");
        StringBuilder r = new StringBuilder();
        for (int i = 0; i < split.length; i++) {
            r.append("'" + split[i] + "',");
        }
        return r.toString().substring(0, r.length() - 1);
    }

    private ClaimInfo checkExist(String id) {
        Optional<ClaimInfo> op = claimRepository.findById(id);
        if (op.isPresent()) {
            return op.get();
        }
        throw new BusinessException("理赔不存在");
    }

    private PolicyMain getPolicy(String policyNo) {
        Optional<PolicyMain> op = policyMainRepository.findByPolicyNo(policyNo);
        if (!op.isPresent()) {
            throw new BusinessException("该理赔的保单号不存在");
        }
        return op.get();
    }

    /**
     * 理赔详情发送消息
     *
     * @param claimMessageDTO 消息参数
     */
    @Transactional(rollbackFor = RuntimeException.class, propagation = Propagation.REQUIRED)
    public void sendMsg(ClaimMessageDTO claimMessageDTO) {
        // 通过理赔报案id拿到关联的保单
        String reportId = claimMessageDTO.getReportId();
        Optional<ClaimInfo> claimInfoEntityOpt = claimRepository.findById(reportId);
        ClaimInfo claimInfoEntity = claimInfoEntityOpt.orElseThrow(() -> new BusinessException("未找到理赔信息"));
        Optional<PolicyMain> policyMainOpt = policyMainRepository.findByPolicyNo(claimInfoEntity.getPolicyNo());
        PolicyMain policyMain = policyMainOpt.orElseThrow(() -> new BusinessException("未找到保单信息"));

        MessageDTO messageDTO = new MessageDTO();
        ArrayList<MessageUserDTO> userList = new ArrayList<>();
        MessageUserDTO messageUserDTO = new MessageUserDTO();

        CurrentCompanyDTO currentCompanyDTO = userClient.getCurrentCompanyInfo();
        // 如果当前为企业端用户
        if (PlanConstant.ENTERPRISE_GROUP.equals(currentCompanyDTO.getType())) {
            messageDTO.setTitle(currentCompanyDTO.getEiDepartDto().getName() + "业务员");
            messageDTO.setSender(currentCompanyDTO.getEiDepartDto().getId());
            messageUserDTO.setUserCode(policyMain.getBelongCompany());
        } else {
            messageDTO.setTitle(currentCompanyDTO.getEiInsDepartDto().getName());
            messageDTO.setSender(currentCompanyDTO.getEiInsDepartDto().getId().toString());
            messageUserDTO.setUserCode(policyMain.getStartCompany());

            //推送待办消息到云之家平台
            CloudUpcomingDTO cloudUpcomingDTO = CloudUpcomingDTO.of();
            List<String> list = eiUserRepository.findOpenIdsByCompanyId(policyMain.getStartCompany());
            if (!list.isEmpty()) {
                List<OpenId> openIds = CloudUpcomingDTO.setOpenIds(list);
                cloudUpcomingDTO.setTitle("理赔进度").setContent("保险公司回复:" + claimMessageDTO.getContent()).setSourceId(UUID.randomUUID().toString()).setParams(openIds);
                messageService.sendMessage2CloudHome(cloudUpcomingDTO);
            }
        }
        userList.add(messageUserDTO);
        messageDTO.setUsers(userList);
        messageDTO.setSource(String.valueOf(claimMessageDTO.getReportId()));
        messageDTO.setType(MessageConstant.CLAIM_CHAT_MSG);
        messageDTO.setContent(claimMessageDTO.getContent());
        messageDTO.setPath("insuranceManage/claims/claimReportDetail?reportId=" + claimMessageDTO.getReportId());
        messageService.sendMessage(messageDTO);
    }

    /**
     * 根据理赔报案id查询沟通消息列表
     *
     * @param reportId 理赔报案id
     * @return list
     */
    public List<MessageVO> queryMsg(String reportId) {
        PageParam<MessageQuery> pageParam = new PageParam<>();
        MessageQuery messageQuery = new MessageQuery();

        messageQuery.setType(MessageConstant.CLAIM_CHAT_MSG);
        messageQuery.setSource(reportId);
        pageParam.setPageNum(1);
        pageParam.setPageSize(Integer.MAX_VALUE);
        pageParam.setParams(messageQuery);

        PageInfo<MessageVO> pageInfo = messageService.messageList(pageParam);
        return pageInfo.getList();
    }

    public List<ClaimListDTO> claimList(ClaimListQuery query) {
        // 得到查询sql
        StringBuilder sqlBuild = this.getQuerySql(query);
        // 查数据
        return this.listClaimByQuery(sqlBuild, 1, Integer.MAX_VALUE);
    }

    public List<ReportAssociationDTO> reportInfoAssociationList(String policyNo, String reportId) {
        List<ClaimInfo> claimInfoList = claimRepository.findAllByPolicyNoAndReportNoIsNotNullAndRelated(policyNo, (byte) 0);
        List<ReportAssociationDTO> result = new ArrayList<>();
        for (ClaimInfo claimInfo : claimInfoList) {
            if (claimInfo.getReportId().equals(reportId)) {
                continue;
            }
            ReportAssociationDTO reportAssociationDTO = new ReportAssociationDTO();
            BeanCopierUtils.copy(claimInfo, reportAssociationDTO);
            result.add(reportAssociationDTO);
        }
        return result;
    }

    @Transactional(rollbackFor = RuntimeException.class, propagation = Propagation.REQUIRED)
    public void associate(String reportId, String reportNo) {
        ClaimInfo byReportNo = claimRepository.findByReportNo(reportNo);
        claimRepository.delete(byReportNo);
        Optional<ClaimInfo> byReportId = claimRepository.findById(reportId);
        byReportId.ifPresent(claimInfo -> {
            if (claimInfo.getIsOnlineClaims() == 1) {
                byReportNo.setIsOnlineClaims((byte) 1);
            } else {
                byReportNo.setIsOnlineClaims((byte) 0);
            }
            BeanCopierUtils.copy(byReportNo, claimInfo);
            claimInfo.setReportId(reportId);
            claimInfo.setRelated((byte) 1);

            claimHistoryRepository.deleteByReportId(claimInfo.getReportId());
            List<ClaimHistory> claimHistoriyList = claimHistoryRepository.findAllByReportIdOrderByClaimStatusAsc(byReportNo.getReportId());
            for (ClaimHistory claimHistory : claimHistoriyList) {
                claimHistory.setReportId(claimInfo.getReportId());
                claimHistoryRepository.saveAndFlush(claimHistory);
            }
        });
        //消息的关联id更改为新的id
        List<Message> messageList = messageRepository.findBySource(byReportNo.getReportId());
        messageList.forEach(message -> {
            message.setSource(reportId);
            String substring = message.getContent().substring(14);
            message.setContent(reportId + substring);
            messageRepository.save(message);
        });
        // 发送消息给企业端
        sendMessage2Company(reportId, byReportNo);
    }

    public void sendMessage2Company(String reportId, ClaimInfo byReportNo) {
        List<BaseCodeDto> claimStatus = baseCodeService.queryBaseCodeByTypeCode("claimStatus");
        Map<String, String> claimStatusMap = claimStatus.stream().collect(Collectors.toMap(BaseCodeDto::getCodeId, BaseCodeDto::getCodeName));
        Optional<PolicyMain> byPolicyNo = policyMainRepository.findByPolicyNo(byReportNo.getPolicyNo());
        byPolicyNo.ifPresent(policyMain -> {
            MessageDTO messageDTO = new MessageDTO();
            List<MessageUserDTO> users = new ArrayList<>();
            MessageUserDTO messageUserDTO = new MessageUserDTO();
            messageUserDTO.setUserCode(policyMain.getStartCompany());
            users.add(messageUserDTO);

            messageDTO.setUsers(users);
            messageDTO.setSender(policyMain.getBelongCompany());
            messageDTO.setTitle(policyMain.getBelongCompanyName());
            messageDTO.setContent(reportId + "报案的理赔进度更新至" + claimStatusMap.get(byReportNo.getClaimStatus().toString()) + "状态");
            messageDTO.setSource(String.valueOf(reportId));
            messageDTO.setType(MessageConstant.CLAIM_MSG);
            messageDTO.setPath("api/noncar-claim/v1/" + reportId);
            messageService.sendMessage(messageDTO);

            //推送待办消息到云之家平台
            CloudUpcomingDTO cloudUpcomingDTO = CloudUpcomingDTO.of();
            List<String> list = eiUserRepository.findOpenIdsByCompanyId(policyMain.getStartCompany());
            if (!list.isEmpty()) {
                List<OpenId> openIds = CloudUpcomingDTO.setOpenIds(list);
                cloudUpcomingDTO.setTitle("理赔进度").setContent(reportId + "报案的理赔进度更新至" + claimStatusMap.get(byReportNo.getClaimStatus().toString()) + "状态").setSourceId(UUID.randomUUID().toString()).setParams(openIds);
                messageService.sendMessage2CloudHome(cloudUpcomingDTO);
            }
        });
    }
}
