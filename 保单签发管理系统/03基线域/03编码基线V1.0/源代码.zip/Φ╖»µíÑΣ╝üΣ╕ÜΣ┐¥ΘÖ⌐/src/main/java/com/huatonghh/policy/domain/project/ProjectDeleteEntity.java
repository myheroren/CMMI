package com.huatonghh.policy.domain.project;

import lombok.Data;

import javax.persistence.*;
import java.math.BigInteger;
import java.util.Date;

/**
 * @author :  hao.wang
 * @date :  2019/8/27
 * description :
 */
@Entity
@Table(name = "ins_project_delete")
@Data
public class ProjectDeleteEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private BigInteger projNo;
    private String projName;
    private String startCompany;
    private String startUser;
    private String riskKind;
    private Integer insureNumber;
    private Byte unit;
    @Column(name = "proj_type")
    private Byte projType;
    /**
     * 预估保险金额
     */
    private BigInteger estAmount;
    /**
     * 预估预估总保费
     */
    private BigInteger estPremium;
    private Date startTime;
    private Date endTime;
    private String remark;
    private String belongCompany;
    private Byte status;
    private BigInteger planNo;
    @Column(name = "is_valid")
    private Boolean valid;
    private Date createTime;
    private Date updateTime;
}
