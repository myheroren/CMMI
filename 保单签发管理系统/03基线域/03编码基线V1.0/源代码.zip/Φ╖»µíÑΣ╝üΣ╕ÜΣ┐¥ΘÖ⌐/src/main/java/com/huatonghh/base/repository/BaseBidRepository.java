package com.huatonghh.base.repository;

import com.huatonghh.base.domain.BaseBid;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/7
 */
public interface BaseBidRepository extends JpaRepository<BaseBid, Integer> {

    /**
     * 根据人查询
     *
     * @param contact 联系人
     * @return
     */
    List<BaseBid> findAllByContact(String contact);
}
