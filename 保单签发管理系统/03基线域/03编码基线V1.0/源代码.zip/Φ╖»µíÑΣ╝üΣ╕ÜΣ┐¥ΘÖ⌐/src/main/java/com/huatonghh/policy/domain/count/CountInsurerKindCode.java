package com.huatonghh.policy.domain.count;

import lombok.Data;

import javax.persistence.*;
import java.math.BigInteger;
import java.util.Date;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/11
 */
@Entity
@Table(name = "count_insurer_kind")
@Data
public class CountInsurerKindCode {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String startCompany;
    private String kindCode;
    private BigInteger totalPremium;
    private Date createTime;
    private Byte type;
}
