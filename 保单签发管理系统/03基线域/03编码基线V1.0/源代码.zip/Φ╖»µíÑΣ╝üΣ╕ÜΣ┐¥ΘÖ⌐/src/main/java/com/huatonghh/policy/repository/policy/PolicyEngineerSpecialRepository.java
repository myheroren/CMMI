package com.huatonghh.policy.repository.policy;

import com.huatonghh.policy.domain.policy.PolicyEngineerSpecial;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigInteger;

/**
 * (PolicyEngineerSpecial)表数据库访问层
 *
 * @author makejava
 * @since 2020-11-11 15:04:34
 */
public interface PolicyEngineerSpecialRepository  extends JpaRepository<PolicyEngineerSpecial, BigInteger> {

    /**
     * 通过ID查询单条数据
     *
     * @param policyNo 保单号
     * @return 实例对象
     */
    PolicyEngineerSpecial findByPolicyNo(String policyNo);


}
