package com.huatonghh.excel.service.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.huatonghh.excel.util.BigIntegerConverter;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigInteger;
import java.util.Date;

/**
 * 复杂头数据.这里最终效果是第一行就一个主标题，第二行分类
 *
 * @author Jiaju Zhuang
 **/
@Data
@ContentRowHeight(20)
@HeadRowHeight(20)
@ColumnWidth(15)
public class PolicyTestData {

    @ExcelProperty(value = "序号", converter = BigIntegerConverter.class, index = 0)
    private BigInteger id;

    @ExcelProperty(value = "保单号", index = 1)
    @ColumnWidth(25)
    private String policyNo;

    @ExcelProperty(value = "车或非车标识", index = 2)
    private Byte carUncarFlag;

    @ExcelProperty(value = "保险类别", index = 3)
    private String insuranceCategory;

    @ExcelProperty(value = "险种代码", index = 4)
    private String kindCode;

    @ExcelProperty(value = "投保人", index = 5)
    private String holderName;

    @ExcelProperty(value = "被保险人", index = 6)
    private String insuredName;

    @ExcelProperty(value = "中标项目编号", converter = BigIntegerConverter.class, index = 7)
    private BigInteger projectNo;

    @ExcelProperty(value = "发起公司", index = 8)
    private String startCompany;

    @ExcelProperty(value = "保险公司", index = 9)
    private String belongCompany;

    @ExcelProperty(value = "保费", converter = BigIntegerConverter.class, index = 10)
    private BigInteger totalPremium;

    @ExcelProperty(value = "保单起期", index = 11)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyBgnTime;

    @ExcelProperty(value = "保单止期", index = 12)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyEndTime;

    @ExcelProperty(value = "保司联系人", index = 13)
    private String belongCompanyPerson;

    @ExcelProperty(value = "联系电话", index = 14)
    private String belongCompanyPhone;

    @ExcelProperty(value = "状态", index = 15)
    private Byte status;



    @ExcelProperty(value = {"车", "车架号"}, index = 16)
    private String frameNo;

    @ExcelProperty(value = {"车", "车牌号"}, index = 17)
    private String plateNo;

    @ExcelProperty(value = {"车", "发动机号"}, index = 18)
    private String engineNo;

    @ExcelProperty(value = {"车", "使用性质"}, index = 19)
    private String usageCode;

    @ExcelProperty(value = {"车", "车辆型号"}, index = 20)
    private String vehicleModel;

    @ExcelProperty(value = {"车", "车船税"}, index = 21)
    private String vehicleVesselTax;

    @ExcelProperty(value = {"车", "NCD系数"}, index = 22)
    private String ncdCoef;

    @ExcelProperty(value = {"车", "自主核保系数"}, index = 23)
    private String autoUnderwritingCoef;



    @ExcelProperty(value = {"非车", "投保产品"}, index = 24)
    private String mainRiskDuty;

    @ExcelProperty(value = {"非车", "总保额"}, converter = BigIntegerConverter.class, index = 25)
    private BigInteger totalAmount;

    @ExcelProperty(value = {"非车", "手续费比例"}, index = 26)
    private String feeProp;

    @ExcelProperty(value = {"非车", "签单日期"}, index = 27)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date issueDate;

    @ExcelProperty(value = {"非车", "共保信息"}, index = 28)
    private String coinsuranceDetail;

    @ExcelProperty(value = {"非车", "实收日期"}, index = 29)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date paidInDate;

    @ExcelProperty(value = {"非车", "支付类型：见费出单/分期"}, index = 30)
    private Byte paymentType;

    @ExcelProperty(value = {"非车", "所属标段"}, index = 31)
    private String subordinateBid;

    @ExcelProperty(value = {"非车", "工程名称"}, index = 32)
    private String engineeringName;

    @ExcelProperty(value = {"非车", "保证期间"}, index = 33)
    private String guarantyPeriod;

}
