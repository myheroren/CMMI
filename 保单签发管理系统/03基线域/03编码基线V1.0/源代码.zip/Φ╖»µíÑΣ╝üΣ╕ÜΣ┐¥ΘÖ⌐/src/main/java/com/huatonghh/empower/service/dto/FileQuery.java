package com.huatonghh.empower.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author ghy
 * Date: 2021/1/6 9:14
 */
@Data
@ApiModel("文件展示查询参数")
@NoArgsConstructor
@AllArgsConstructor
public class FileQuery implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 授权文件id
     */
    @ApiModelProperty("授权文件id")
    private Integer fileId;

    /**
     * 保单号
     */
    @ApiModelProperty("保单号")
    private String policyNo;

}
