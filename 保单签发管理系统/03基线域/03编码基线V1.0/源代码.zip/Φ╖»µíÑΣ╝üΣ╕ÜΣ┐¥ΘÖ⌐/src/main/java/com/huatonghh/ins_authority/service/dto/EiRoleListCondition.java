package com.huatonghh.ins_authority.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author : Sun
 * @description : 角色
 * @date : 2019/11/4 21:11
 * @version : 1.0
 */
@Data
@ApiModel(value = "角色查询")
public class EiRoleListCondition implements Serializable {

    private static final long serialVersionUID = 5644670566104743521L;

    @ApiModelProperty(value = "公司ID")
    private String companyId;

    @ApiModelProperty(value = "角色ID")
    private Integer roleId;

    @ApiModelProperty(value = "角色名称")
    private String roleName;

    @ApiModelProperty(value = "描述")
    private String remark;

    @ApiModelProperty(value = "是否生效")
    private Boolean valid;

    /**
     * 页码
     */
    @ApiModelProperty(value = "页码", example = "1")
    @NotNull(message = "分页页码不能为空")
    private Integer pageNum;

    /**
     * 条目数
     */
    @ApiModelProperty(value = "条目数", example = "10")
    @NotNull(message = "分页条目数不能为空")
    private Integer pageSize;


}
