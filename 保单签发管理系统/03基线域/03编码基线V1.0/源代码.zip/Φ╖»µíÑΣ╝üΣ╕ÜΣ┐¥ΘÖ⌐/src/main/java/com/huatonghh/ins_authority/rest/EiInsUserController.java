package com.huatonghh.ins_authority.rest;

import com.huatonghh.authority.security.SecurityUtils;
import com.huatonghh.authority.service.EiAuthorityService;
import com.huatonghh.authority.service.dto.EiAuthorityDto;
import com.huatonghh.authority.service.dto.EiAuthorityTreeDto;
import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.ei.service.dto.PasswordChangeDTO;
import com.huatonghh.ei.web.rest.errors.InvalidPasswordException;
import com.huatonghh.ei.web.rest.vm.LoginVM;
import com.huatonghh.ei.web.rest.vm.LoginVerifyVM;
import com.huatonghh.ei.web.rest.vm.ManagedUserVM;
import com.huatonghh.ins_authority.service.EiInsUserService;
import com.huatonghh.ins_authority.service.dto.EiInsUserCondition;
import com.huatonghh.ins_authority.service.dto.EiInsUserDto;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * @author : Sun
 * @description : 用户、查询菜单权限等接口
 * @date : 2019/11/5 21:35
 * @version : 1.0
 */
@RestController
@RequestMapping("/api/ins_user/v1")
@Api(tags="11、ins.保险公司用户管理", value = "用户、查询菜单权限等接口")
@Slf4j
@AllArgsConstructor
public class EiInsUserController {

    private final EiInsUserService eiUserService;

    private final EiAuthorityService eiAuthorityService;


    @PostMapping("/login")
    @ApiOperation(value = "0、登录", notes = "JWT登录接口，原有登录依旧保留", httpMethod = "POST")
    public ResponseEntity authorize(LoginVM loginVM) {
        return eiUserService.authorize(loginVM);
    }


    @PostMapping("/loginv")
    @ApiOperation(value = "0、登录", notes = "含验证码登录接口，原有登录依旧保留，进行swagger测试用", httpMethod = "POST")
    public ResponseEntity authorizeVerify(LoginVerifyVM loginVM) {
        return eiUserService.authorizeVerify(loginVM);
    }


    @PostMapping("/page_list")
    @ApiOperation(value = "1、获取员工分页列表", notes = "目前不区分部门员工，后续OA对接后再修改", httpMethod = "POST")
    @Timed
    public ApiResponse<PageInfo<EiInsUserDto>> queryUserListByPage(@RequestBody @Valid EiInsUserCondition eiUserCondition) {
        return ApiResponse.ofSuccess(eiUserService.queryUserListByPage(eiUserCondition));
    }


    @GetMapping("/info")
    @ApiOperation(value = "2、根据登录账户获取员工详细信息", notes = "此接口也可以获取员工所属角色信息，不传参则查当前登录用户", httpMethod = "GET")
    @Timed
    public ApiResponse<EiInsUserDto> queryEiUserInfo(@RequestParam(name = "userName", required = false) String userName) {
        // 根据token获取登录账号
        String user = SecurityUtils.loginUser();

        // 传用户账号名称，就用账号名称查
        if(StringUtils.isNotBlank(userName)) {
            user = userName;
        }

        // 获取员工详细信息
        return ApiResponse.ofSuccess(eiUserService.queryEiUserInfo(user));
    }


    @PostMapping("/save")
    @ApiOperation(value = "3、保存员工信息", notes = "此接口也可以保存员工所属部门角色信息", httpMethod = "POST")
    @Timed
    public ApiResponse<EiInsUserDto> saveEiUser(@RequestBody @Valid EiInsUserDto eiUserDto) {
        return ApiResponse.ofSuccess(eiUserService.saveEiUser(eiUserDto));
    }


    @GetMapping("/authoarity_token")
    @ApiOperation(value = "4、获取token中该员工菜单权限二叉树列表", notes = "登录后从token获取部门，查询菜单权限、按钮权限等", httpMethod = "GET")
    @Timed
    public ApiResponse<List<EiAuthorityTreeDto>> queryAuthorityByToken() {
        // 根据token获取登录账号
        String user = SecurityUtils.loginUser();

        // 获取token中该员工菜单权限二叉树列表
        List<EiAuthorityDto> eiAuthorityDtos = eiUserService.queryAuthorityByUser(user);
        return ApiResponse.ofSuccess(eiAuthorityService.processTreeList(eiAuthorityDtos, null));
    }


    @PostMapping("/change_password")
    @ApiOperation(value = "5、修改密码", notes = "重写了JWT修改密码，只为保持模块统一，接口地址头相同而已", httpMethod = "POST")
    @Timed
    public void changePassword(@RequestBody PasswordChangeDTO passwordChangeDto) {
        if (!checkPasswordLength(passwordChangeDto.getNewPassword())) {
            throw new InvalidPasswordException();
        }
        eiUserService.changePassword(passwordChangeDto.getCurrentPassword(), passwordChangeDto.getNewPassword());
    }


    @GetMapping("/clear_cache")
    @ApiOperation(value = "6、清除缓存", httpMethod = "GET")
    @Timed
    public void clearCache() {
        eiUserService.clearCache();
    }


    @DeleteMapping("/delete/{userId}")
    @ApiOperation(value = "7、删除用户", httpMethod = "DELETE")
    @Timed
    public void delete(@PathVariable(value = "userId") Integer userId) {
        eiUserService.delete(userId);
    }


    @GetMapping("/depart_lower/user_list")
    @ApiOperation(value = "8、根据部门id获取其下用户列表",  httpMethod = "GET")
    @Timed
    public ApiResponse<List<EiInsUserDto>> queryDepartLowerUserList(@RequestParam(name = "id", required = false) Integer id) {
        return ApiResponse.ofSuccess(eiUserService.queryDepartLowerUserList(id));
    }

    @GetMapping("/depart_lower/user_page")
    @ApiOperation(value = "8、根据部门id获取其下用户列表,有分页", httpMethod = "GET")
    @Timed
    public ApiResponse<PageInfo<EiInsUserDto>> queryDepartLowerUserListPage(@RequestParam(name = "id", required = false) String id, @RequestParam(name = "pageNo", required = true) Integer pageNo, @RequestParam(name = "pageSize", required = true) Integer pageSize) {
        return ApiResponse.ofSuccess(eiUserService.queryDepartLowerUserListPage(id,pageNo,pageSize));
    }

    /**
     * @author Sun
     * @description 修改密码、长度
     * @date 2019/11/5 21:35
     * @param password: 密码
     * @return boolean
     **/
    private static boolean checkPasswordLength(String password) {
        return !StringUtils.isEmpty(password) &&
            password.length() >= ManagedUserVM.PASSWORD_MIN_LENGTH &&
            password.length() <= ManagedUserVM.PASSWORD_MAX_LENGTH;
    }

}
