package com.huatonghh.policy.service.dto.policy;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import com.huatonghh.file.service.dto.FiAuditFileDto;
import com.huatonghh.policy.domain.policy.PolicyEngineerSpecial;
import com.huatonghh.policy.domain.policy.PolicyInsured;
import com.huatonghh.policy.domain.policy.modify.PolicyModify;
import com.huatonghh.policy.domain.policy.renew.PolicyRenewEntity;
import com.huatonghh.policy.service.dto.claim.noncar.PolicyClaimDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Column;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

/**
 * Description : 保单信息保存实体
 *
 * @author : Sun
 * @version : 1.0
 * @date : 2019/9/21 11:41
 */
@Data
@ApiModel("保单信息保存实体")
public class SavePolicyDto implements Serializable {

    private static final long serialVersionUID = 2904020514091639176L;

    @ApiModelProperty(value = "自增id：新增不传、修改必传")
    @JsonSerialize(using = ToStringSerializer.class)
    private BigInteger id;

    @ApiModelProperty(value = "保单号")
    @NotNull(message = "保单号不能为空")
    private String policyNo;

    @ApiModelProperty(value = "车或非车标识：1车、0非车，必传")
    @NotNull(message = "车或非车标识不能为空")
    private Byte carUncarFlag;

    @ApiModelProperty(value = "保险类别")
    private String insuranceCategory;

    @ApiModelProperty(value = "险种代码；例:车（交强、商业）,非车待定")
    private String kindCode;


    /**
     * 投保人，中文
     */
    @ApiModelProperty(name = "投保人，中文")
    private String holderName;

    /**
     * 投保人证件类型:统一社会信用代码，组织机构代码
     */
    @ApiModelProperty(name = "投保人证件类型:1统一社会信用代码，2组织机构代码")
    private String holderCertificateType;
    /**
     * 投保人证件号码
     */
    @ApiModelProperty(name = "投保人证件号码")
    private String holderCertificateNumber;


    /**
     * 被保险人，中文
     */
    @ApiModelProperty(name = "被保险人，中文")
    private String insuredName;

    /**
     * 被保人证件类型：:统一社会信用代码，组织机构代码
     */
    @ApiModelProperty(name = " 被保人证件类型：:1统一社会信用代码，2组织机构代码")
    private String insuredCertificateType;

    /**
     * 被保人证件号码
     */
    @ApiModelProperty(name = "被保人证件号码")
    private String insuredCertificateNumber;

    @ApiModelProperty(value = "中标项目编号")
    @JsonSerialize(using = ToStringSerializer.class)
    private BigInteger projectNo;

    @ApiModelProperty(value = "发起公司")
    private String startCompany;

    @ApiModelProperty(value = "保险公司")
    private String belongCompany;

    @ApiModelProperty(value = "保费")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger totalPremium;

    @ApiModelProperty(value = "项目合同金额")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger projectContractAmount;

    @ApiModelProperty(value = "费率")
    private BigDecimal rate;

    @ApiModelProperty(value = "可计提的防灾防损基金")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger totalFund;

    @ApiModelProperty(value = "已使用的防灾防损基金")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger usedFund;

    @ApiModelProperty(value = "剩余的防灾防损基金")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger leftFund;

    @ApiModelProperty(value = "总保额")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger totalAmount;

    @ApiModelProperty(value = "不含税保费")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger freeTaxPremium;

    @ApiModelProperty(value = "签单日期（投保日期）")
    private Date policyApplyTime;

    @ApiModelProperty(value = "有效起期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyBgnTime;

    @ApiModelProperty(value = "有效止期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyEndTime;

    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    @ApiModelProperty(value = "更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    @ApiModelProperty(value = "保司联系人")
    private String belongCompanyPerson;

    @ApiModelProperty(value = "联系电话")
    private String belongCompanyPhone;

    @ApiModelProperty(value = "状态")
    private Byte status;

    @ApiModelProperty(value = "基本项目id")
    private String proId;
    @ApiModelProperty(value = "基本项目名称")
    private String proName;
    @ApiModelProperty(value = "基本项目简称")
    private String proAlias;
    @ApiModelProperty(value = "基本项目电话")
    private String proTel;
    @ApiModelProperty(value = "基本项目联系人")
    private String proContact;

    @ApiModelProperty(value = "投标日期,yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date bidDate;

    @ApiModelProperty(value = "招标人、询价人电话")
    private String bidTel;
    @ApiModelProperty(value = "招标人、询价人")
    private String bidContact;
    @ApiModelProperty(value = "手续费")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger handlingFee;

    private SavePolicyCarDto savePolicyCarDto;

    private SavePolicyUncarDto savePolicyUncarDto;

    private List<FiAuditFileDto> fiAuditFileDtos;

    private List<PolicyClaimDTO> claimInfos;

    private List<PolicyModify> modifyInfos;

    private List<PolicyRenewEntity> renewInfos;

    private PolicyEngineeringDTO engineeringInfo;

    private List<PolicyPayPeriodDTO> payPeriodInfos;

    private List<PolicyInsured> insuredInfos;

    private List<PolicyCoinsuranceDTO> coinsuranceInfos;

    @ApiModelProperty(value = "险种特殊字段信息")
    private PolicyEngineerSpecial policyEngineerSpecial;
}
