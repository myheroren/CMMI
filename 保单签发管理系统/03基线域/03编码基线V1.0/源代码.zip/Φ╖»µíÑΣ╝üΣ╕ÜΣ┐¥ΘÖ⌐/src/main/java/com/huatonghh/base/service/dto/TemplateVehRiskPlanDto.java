package com.huatonghh.base.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * Description : 车辆管理-方案套餐
 * @author : Sun
 * @date : 2019/8/31 14:01
 * @version : 1.0
 */
@Data
@ApiModel("模板管理-方案套餐")
public class TemplateVehRiskPlanDto implements Serializable {

    private static final long serialVersionUID = -4891939841839458213L;

    @ApiModelProperty(value = "自增id：新增不传、修改传")
    private Integer id;

    @ApiModelProperty(value = "套餐模板id")
    @NotNull
    private Integer templateId;

    @ApiModelProperty(value = "险种代码")
    private String kindCode;

    @ApiModelProperty(value = "险别代码")
    private String riskCode;

    @ApiModelProperty(value = "险别名称")
    private String riskName;

    @ApiModelProperty(value = "保额")
    private String amount;

    @ApiModelProperty(value = "主险附加险标志（1：主险，0：附加险）")
    private Boolean mainAdditionalFlag;

}
