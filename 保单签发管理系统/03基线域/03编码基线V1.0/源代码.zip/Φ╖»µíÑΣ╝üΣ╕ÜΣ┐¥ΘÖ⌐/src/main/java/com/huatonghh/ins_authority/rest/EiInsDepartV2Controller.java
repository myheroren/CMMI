package com.huatonghh.ins_authority.rest;

import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.ins_authority.service.EiInsDepartV2Service;
import com.huatonghh.ins_authority.service.dto.EiInsDepartVO;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author : Sun
 * @version : 1.0
 * @description : 部门管理相关接口，部门列表二叉树、增删改查等
 * @date : 2019/11/5 21:34
 */
@AllArgsConstructor
@RestController
@RequestMapping("/api/ins_depart/v2")
@Api(tags = "10、ins.保险公司部门管理", value = "部门相关接口")
@Slf4j
public class EiInsDepartV2Controller {

    private final EiInsDepartV2Service eiDepartService;

    @GetMapping("/lower_list/{id}")
    @ApiOperation(value = "2、根据部门id，查询所有子部门列表", httpMethod = "GET")
    @Timed
    public ApiResponse<List<EiInsDepartVO>> queryDepartListById(@PathVariable(value = "id") Integer id) {
        return ApiResponse.ofSuccess(eiDepartService.queryDepartListById(id));
    }


}
