package com.huatonghh.ins_authority.rest;

import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.ins_authority.domain.EiInsDepart;
import com.huatonghh.ins_authority.service.EiInsDepartService;
import com.huatonghh.ins_authority.service.dto.EiInsDepartDto;
import com.huatonghh.ins_authority.service.dto.EiInsDepartTreeDto;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * @author : Sun
 * @description : 部门管理相关接口，部门列表二叉树、增删改查等
 * @date : 2019/11/5 21:34
 * @version : 1.0
 */
@RestController
@RequestMapping("/api/ins_depart/v1")
@Api(tags="10、ins.保险公司部门管理", value = "部门相关接口")
@Slf4j
public class EiInsDepartController {

    private final EiInsDepartService eiDepartService;

    public EiInsDepartController(EiInsDepartService eiDepartService) {
        this.eiDepartService = eiDepartService;
    }


    @GetMapping("/tree_list")
    @ApiOperation(value = "1、获取部门二叉树列表", notes = "此方法使用了缓存，但尚未添加清除缓存接口，亲注意", httpMethod = "GET")
    @Timed
    public ApiResponse<List<EiInsDepartTreeDto>> queryDepartTreeList(@RequestParam(name = "id", required = false) Integer id) {
        return ApiResponse.ofSuccess(eiDepartService.queryDepartTreeList(id));
    }


    @GetMapping("/lower_list/{id}")
    @ApiOperation(value = "2、根据部门id，查询所有子部门列表", httpMethod = "GET")
    @Timed
    public ApiResponse<List<EiInsDepartDto>> queryDepartListById(@PathVariable(value = "id") Integer id) {
        return ApiResponse.ofSuccess(eiDepartService.queryDepartListById(id));
    }

    @DeleteMapping("/delete/{departId}")
    @ApiOperation(value = "4、删除部门", httpMethod = "DELETE")
    @Timed
    public void delete(@PathVariable(value = "departId") Integer departId) {
        eiDepartService.delete(departId);
    }


    @PostMapping("/save")
    @ApiOperation(value = "5、部门信息保存", httpMethod = "POST")
    @Timed
    public ApiResponse<EiInsDepartDto> saveDepart(@RequestBody @Valid EiInsDepartDto eiDepartDto) {
        return ApiResponse.ofSuccess(eiDepartService.saveDepart(eiDepartDto));
    }

    @GetMapping("/insList")
    @ApiOperation(value = "获取所有保险公司列表", notes = "获取所有保险公司列表", httpMethod = "GET")
    @Timed
    public ApiResponse<List<EiInsDepart>> queryInsDepart() {
        return ApiResponse.ofSuccess(eiDepartService.queryInsDepart());
    }

}
