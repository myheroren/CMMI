package com.huatonghh.policy.repository;

import com.huatonghh.policy.domain.project.ProjectPreCoinsurance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigInteger;
import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/6
 */
public interface ProjectPreCoinsuranceRepository extends JpaRepository<ProjectPreCoinsurance, Integer> {
    /**
     * 根据项目编号查询
     *
     * @param projectNo 项目编号
     * @return 共保列表
     */
    List<ProjectPreCoinsurance> findAllByProjectNo(BigInteger projectNo);


    /**
     * 根据项目编号删除共保信息
     *
     * @param projectNo 项目编号
     */
    @Modifying
    @Query(value = "delete  from  ProjectPreCoinsurance p where p.projectNo =:projectNo")
    void deleteByProjectNo(@Param("projectNo") BigInteger projectNo);
}

