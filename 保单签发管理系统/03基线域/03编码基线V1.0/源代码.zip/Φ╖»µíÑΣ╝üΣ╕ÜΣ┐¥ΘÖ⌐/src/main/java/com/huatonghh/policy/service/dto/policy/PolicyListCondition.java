package com.huatonghh.policy.service.dto.policy;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

/**
 * Description :
 *
 * @author : Sun
 * @version : 1.0
 * @date : 2019/8/30 11:24
 */
@Data
@ApiModel(value = "保单分页列表实体")
public class PolicyListCondition implements Serializable {

    private static final long serialVersionUID = -4369727546160179684L;

    /**
     * 基本条件
     */
    @ApiModelProperty(value = "保单号")
    private String policyNo;

    @ApiModelProperty(value = "车或非车标识：1车、0非车，必传", required = true)
    @NotNull
    private Byte carUncarFlag;

    @ApiModelProperty(value = "保险类别：车1、企业工程23456")
    private String insuranceCategory;

    @ApiModelProperty(value = "险种代码；例:车（交强、商业）,非车待定")
    private String kindCode;


    /**
     * 公司id
     */
    @ApiModelProperty(value = "所属分公司")
    private String startCompany;

    @ApiModelProperty(value = "保险公司")
    private String belongCompany;


    /**
     * 其他条件
     */
    @ApiModelProperty(value = "中标项目编号")
    @JsonSerialize(using = ToStringSerializer.class)
    private BigInteger projectNo;

    @ApiModelProperty(value = "投保人")
    private String holderName;

    @ApiModelProperty(value = "创建、投保查询起始日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startCreateTime;

    @ApiModelProperty(value = "创建、投保查询终止日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endCreateTime;

    @ApiModelProperty(value = "保险起始日期-起")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startBgnTime;

    @ApiModelProperty(value = "保险起始日期-止")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endBgnTime;

    @ApiModelProperty(value = "状态")
    private Byte status;

    /**
     * 页码
     */
    @ApiModelProperty(value = "页码", example = "1")
    @NotNull(message = "分页页码不能为空")
    private Integer pageNum;

    /**
     * 条目数
     */
    @ApiModelProperty(value = "条目数", example = "10")
    @NotNull(message = "分页条目数不能为空")
    private Integer pageSize;

    @ApiModelProperty(value = "排序方式，0，代表逆序，1表示正序")
    @NotNull(message = "排序方式，不能为空")
    private Integer range;

    @ApiModelProperty(value = "排序字段名称，必须是驼峰标志")
    @NotNull(message = "排序字段名称，不能为空")
    private String column;

    @ApiModelProperty(value = "勾选")
    private List<Integer> ids;

    @ApiModelProperty(value = "距离到期时间（天）")
    private Integer expirationDays;

    @ApiModelProperty(value = "续保状态：0未续保，1已续保")
    private Byte renewStatus;
}
