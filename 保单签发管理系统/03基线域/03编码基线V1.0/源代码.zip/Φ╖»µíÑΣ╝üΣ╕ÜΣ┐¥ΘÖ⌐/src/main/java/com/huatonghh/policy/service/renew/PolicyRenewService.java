package com.huatonghh.policy.service.renew;//package com.huatonghh.plan.service.renew;
//
//
//import cn.hutool.core.date.DateUtil;
//import com.huatonghh.authority.service.EiUserService;
//import com.huatonghh.authority.service.dto.EiUserDto;
//import com.huatonghh.base.constant.BaseConstant;
//import com.huatonghh.base.service.BaseRemindService;
//import com.huatonghh.common.constant.enums.StatusEnum;
//import com.huatonghh.common.exception.BusinessException;
//import com.huatonghh.common.repository.DynamicQuery;
//import com.huatonghh.common.util.hutool.ClassUtils;
//import com.huatonghh.common.util.hutool.LineToHumpTool;
//import com.huatonghh.common.util.system.PageInfo;
//import com.huatonghh.file.domain.FiAuditFile;
//import com.huatonghh.file.repository.FiAuditFileRepository;
//import com.huatonghh.file.service.AuditFileService;
//import com.huatonghh.file.service.dto.FiAuditFileDto;
//import com.huatonghh.ins_authority.service.EiInsUserService;
//import com.huatonghh.ins_authority.service.dto.EiInsUserDto;
//import com.huatonghh.plan.constant.PlanConstant;
//import com.huatonghh.plan.constant.PolicyConstant;
//import com.huatonghh.plan.domain.policy.PolicyCarDetail;
//import com.huatonghh.plan.domain.policy.PolicyMain;
//import com.huatonghh.plan.domain.policy.PolicyUncarDetail;
//import com.huatonghh.plan.domain.policy.PolicyVehRiskPlan;
//import com.huatonghh.plan.domain.policy.modify.PolicyCarDetailModify;
//import com.huatonghh.plan.domain.policy.modify.PolicyMainModify;
//import com.huatonghh.plan.domain.policy.modify.PolicyUncarDetailModify;
//import com.huatonghh.plan.domain.policy.renew.PolicyRenew;
//import com.huatonghh.plan.repository.modify.PolicyMainModifyRepository;
//import com.huatonghh.plan.repository.modify.PolicyModifyRepository;
//import com.huatonghh.plan.repository.modify.car.PolicyCarDetailModifyRepository;
//import com.huatonghh.plan.repository.modify.nocar.PolicyUncarDetailModifyRepository;
//import com.huatonghh.plan.repository.policy.PolicyCarDetailRepository;
//import com.huatonghh.plan.repository.policy.PolicyMainRepository;
//import com.huatonghh.plan.repository.policy.PolicyUncarDetailRepository;
//import com.huatonghh.plan.repository.policy.PolicyVehRiskPlanRepository;
//import com.huatonghh.plan.repository.renew.PolicyRenewRepository;
//import com.huatonghh.plan.service.dto.policy.*;
//import com.huatonghh.plan.service.dto.renew.PolicyRenewDTO;
//import com.huatonghh.plan.service.dto.renew.SaveJointCarPolicyRenewDto;
//import com.huatonghh.plan.service.dto.renew.SavePolicyRenewDto;
//import lombok.AllArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//import ma.glasnost.orika.MapperFactory;
//import org.apache.commons.lang3.StringUtils;
//import org.modelmapper.ModelMapper;
//import org.springframework.cache.annotation.CacheConfig;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//import org.springframework.web.bind.annotation.RequestBody;
//
//import javax.validation.Valid;
//import java.math.BigInteger;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//import java.util.Optional;
//import java.util.stream.Collectors;
//
///**
// * Description : 保单管理-业务层
// *
// * @author : juyanming
// * @version : 1.0
// * @date : 2019/10/14 17:18
// */
//@Service
//@CacheConfig
//@Slf4j
//@AllArgsConstructor
//public class PolicyRenewService {
//
//    private final PolicyCarDetailModifyRepository policyCarDetailModifyRepository;
//
//    private final PolicyMainModifyRepository policyMainModifyRepository;
//
//    private final PolicyUncarDetailModifyRepository policyUncarDetailModifyRepository;
//
//    private final PolicyCarDetailRepository policyCarDetailRepository;
//
//    private final PolicyMainRepository policyMainRepository;
//
//    private final PolicyUncarDetailRepository policyUncarDetailRepository;
//
//    private final ModelMapper modelMapper;
//
//    private final DynamicQuery dynamicQuery;
//
//    private final MapperFactory mapperFactory;
//
//    private final FiAuditFileRepository fiAuditFileRepository;
//
//    private final AuditFileService fileService;
//
//    private final PolicyVehRiskPlanRepository policyVehRiskPlanRepository;
//
//    private final PolicyModifyRepository policyModifyRepository;
//
//    private final PolicyRenewRepository policyRenewRepository;
//
//    private final BaseRemindService remindService;
//
//    private final EiUserService eiUserService;
//
//    private final EiInsUserService insUserService;
//
//    /**
//     * Description : 保存保单信息：基本信息、非车/车信息
//     *
//     * @author : juyanming
//     * @date : 2019/10/21 12:20
//     */
//    @Transactional(rollbackFor = RuntimeException.class)
//    public void saveHidePolicy(String policyNo) {
//        policyMainRepository.findByPolicyNo(policyNo).ifPresent(p -> {
//            p.setRemindDisplay(false);
//            p.setUpdateTime(DateUtil.date());
//            policyMainRepository.save(p);
//        });
//    }
//
//    /**
//     * Description : 保存保单信息：基本信息、非车/车信息
//     *
//     * @author : juyanming
//     * @date : 2019/10/21 12:20
//     */
//    @Transactional(rollbackFor = RuntimeException.class)
//    public void savePolicy(SavePolicyRenewDto savePolicyDto, int flag) {
//
//        // 创建domain实体
//        PolicyCarDetail policyCarDetail;
//        PolicyUncarDetail policyUncarDetail;
//        PolicyMain policyMain = modelMapper.map(savePolicyDto, PolicyMain.class);
//        policyMain.setPolicyNo(savePolicyDto.getPolicyNoNew());
//        // 获取保单号：新增时校验是否存在此保单、保存车 非车信息时，使用基本信息保单号
//        String policyNo = savePolicyDto.getPolicyNoNew();
//        if (flag == 1) {
//            policyMain.setId(null);
//
//            // 校验是否存在该保单信息
//            Optional<PolicyMain> byPolicyNo = policyMainRepository.findByPolicyNo(policyNo);
//            if (byPolicyNo.isPresent()) {
//                throw new BusinessException(StatusEnum.POLICY_EXIST_DETAIL, policyNo);
//            }
//
//        } else {
//            if (policyMain.getId() == null) {
//                throw new BusinessException(StatusEnum.POLICY_MAIN_NEED_ID);
//            }
//        }
//
//        // 保存保单基本信息
//        policyMain.setCreateTime(DateUtil.date());
//        if (policyMain.getRemindDisplay() == null) {
//            policyMain.setRemindDisplay(true);
//        }
//        PolicyMain policyMainNew = policyMainRepository.saveAndFlush(policyMain);
//        Optional<PolicyRenew> policyRenew = policyRenewRepository.findPolicyRenewByPolicyNo(savePolicyDto.getPolicyNo());
//        if (!policyRenew.isPresent()) {
//            throw new BusinessException(StatusEnum.RENEW_DETAIL_NOT_EXIST, policyNo);
//        }
//        PolicyRenew PolicyRenewResult = policyRenew.get();
//        PolicyRenewResult.setPolicyNoNew(savePolicyDto.getPolicyNoNew());
//        PolicyRenewResult.setStatus((byte) 1);
//        PolicyRenewResult.setPolicyIdNew(policyMainNew.getId());
//        PolicyRenewResult.setEndTime(DateUtil.date());
//        //更新 续保信息
//        policyRenewRepository.saveAndFlush(PolicyRenewResult);
//
//        // 车或非车标识：1车、0非车
//        if (savePolicyDto.getCarUncarFlag() == 1 && savePolicyDto.getSavePolicyCarDto() != null) {
//            SavePolicyCarDto savePolicyCarDto = savePolicyDto.getSavePolicyCarDto();
//            policyCarDetail = modelMapper.map(savePolicyCarDto, PolicyCarDetail.class);
//            // 保单号：使用基本信息中的保单号
//            policyCarDetail.setPolicyNo(policyNo);
//            if (flag == 1) {
//                policyCarDetail.setId(null);
//            } else {
//                if (policyCarDetail.getId() == null) {
//                    throw new BusinessException(StatusEnum.POLICY_CAR_NEED_ID);
//                }
//            }
//            policyCarDetailRepository.save(policyCarDetail);
//
//            // 获取方案列表
//            List<PolicyVehRiskPlanDto> policyVehRiskPlanDtoList = savePolicyCarDto.getPolicyVehRiskPlanDtoList();
//            if (policyVehRiskPlanDtoList != null && !policyVehRiskPlanDtoList.isEmpty()) {
//                // 删除现有的方案
//                policyVehRiskPlanRepository.deleteByPolicyNo(policyNo);
//
//                // Dto转换为entity
//                mapperFactory.classMap(PolicyVehRiskPlanDto.class, PolicyVehRiskPlan.class).byDefault().register();
//                List<PolicyVehRiskPlan> policyVehRiskPlans = mapperFactory.getMapperFacade().mapAsList(policyVehRiskPlanDtoList, PolicyVehRiskPlan.class);
//                // 使用主保单号，省着传错的进来
//                for (PolicyVehRiskPlan policyVehRiskPlan : policyVehRiskPlans) {
//                    policyVehRiskPlan.setPolicyNo(policyNo);
//                }
//                // 保存
//                policyVehRiskPlanRepository.saveAll(policyVehRiskPlans);
//            }
//        }
//        if (savePolicyDto.getCarUncarFlag() == 0 && savePolicyDto.getSavePolicyUncarDto() != null) {
//            policyUncarDetail = modelMapper.map(savePolicyDto.getSavePolicyUncarDto(), PolicyUncarDetail.class);
//            // 保单号：使用基本信息中的保单号
//            policyUncarDetail.setPolicyNo(policyNo);
//            if (flag == 1) {
//                policyUncarDetail.setId(null);
//            } else {
//                if (policyUncarDetail.getId() == null) {
//                    throw new BusinessException(StatusEnum.POLICY_UNCAR_NEED_ID);
//                }
//            }
//            policyUncarDetailRepository.save(policyUncarDetail);
//        }
//
//        // 保存保单附件列表信息
//        savePolicyFileAuditDetail(savePolicyDto);
//    }
//
//    /**
//     * Description : 保存保单信息：基本信息、非车/车信息
//     *
//     * @author : Sun
//     * @date : 2019/9/21 12:20
//     */
//    @Transactional(rollbackFor = RuntimeException.class)
//    public void savePolicyRenew(PolicyRenewDTO policyRenewDTO) {
////        if (policyRenew.getId() == null) {
////                throw new BusinessException(StatusEnum.MODIFY_MAIN_NEED_ID);
////        }
//        PolicyRenew policyRenew = modelMapper.map(policyRenewDTO, PolicyRenew.class);
//        policyRenewRepository.saveAndFlush(policyRenew);
//
//    }
//
//
//    /**
//     * Description : 保存保单附件列表信息
//     *
//     * @author : Sun
//     * @date : 2019/9/27 10:35
//     */
//    private void savePolicyFileAuditDetail(SavePolicyRenewDto savePolicyDto) {
//        List<FiAuditFileDto> fiAuditFileDtos = savePolicyDto.getFiAuditFileDtos();
//        String belongId;
//        Byte belongType;
//        if (fiAuditFileDtos == null || fiAuditFileDtos.isEmpty()) {
//            return;
//        } else {
//            belongId = fiAuditFileDtos.get(0).getBelongId();
//            belongType = fiAuditFileDtos.get(0).getBelongType();
//        }
//
//        // 判断所有
//        for (FiAuditFileDto fiAuditFileDto : fiAuditFileDtos) {
//            if (!belongId.equals(fiAuditFileDto.getBelongId())) {
//                throw new BusinessException(StatusEnum.POLICY_BELONG_ID_DIFFERENT);
//            }
//            if (!PlanConstant.BELONG_TYPE_POLICY.equals(fiAuditFileDto.getBelongType())) {
//                throw new BusinessException(StatusEnum.POLICY_BELONG_ID_NOT_CORRECT);
//            }
//        }
//
//        // 删除现有关联附件信息
//        fiAuditFileRepository.deleteByBelongIdAndType(belongId, belongType);
//
//        // Dto转换为entity
//        mapperFactory.classMap(FiAuditFileDto.class, FiAuditFile.class).byDefault().register();
//        List<FiAuditFile> fiAuditFiles = mapperFactory.getMapperFacade().mapAsList(fiAuditFileDtos, FiAuditFile.class);
//        fiAuditFileRepository.saveAll(fiAuditFiles);
//        log.info("保存保单附件列表信息success!!!");
//    }
//
//    /**
//     * Description : 保存保单附件列表信息
//     *
//     * @author : Sun
//     * @date : 2019/9/27 10:35
//     */
//    private void savePolicyRenewFileAuditDetail(SavePolicyRenewDto savePolicyDto) {
//        List<FiAuditFileDto> fiAuditFileDtos = savePolicyDto.getFiAuditFileDtos();
//        String belongId;
//        Byte belongType;
//        if (fiAuditFileDtos == null || fiAuditFileDtos.isEmpty()) {
//            return;
//        } else {
//            belongId = fiAuditFileDtos.get(0).getBelongId();
//            belongType = fiAuditFileDtos.get(0).getBelongType();
//        }
//
//        // 判断所有
//        for (FiAuditFileDto fiAuditFileDto : fiAuditFileDtos) {
//            if (!belongId.equals(fiAuditFileDto.getBelongId())) {
//                throw new BusinessException(StatusEnum.POLICY_BELONG_ID_DIFFERENT);
//            }
//            if (!PlanConstant.BELONG_TYPE_POLICY.equals(fiAuditFileDto.getBelongType())) {
//                throw new BusinessException(StatusEnum.POLICY_BELONG_ID_NOT_CORRECT);
//            }
//            fiAuditFileDto.setBelongId(savePolicyDto.getPolicyNoNew());
//
//        }
//        belongId = savePolicyDto.getPolicyNoNew();
//
//        // 删除现有关联附件信息
//        fiAuditFileRepository.deleteByBelongIdAndType(belongId, belongType);
//
//        // Dto转换为entity
//        mapperFactory.classMap(FiAuditFileDto.class, FiAuditFile.class).byDefault().register();
//        List<FiAuditFile> fiAuditFiles = mapperFactory.getMapperFacade().mapAsList(fiAuditFileDtos, FiAuditFile.class);
//        fiAuditFileRepository.saveAll(fiAuditFiles);
//        log.info("保存保单附件列表信息success!!!");
//    }
//
//
//    /**
//     * Description : 根据保单号获取保单详情
//     *
//     * @author : Sun
//     * @date : 2019/9/21 12:52
//     */
//    public SavePolicyRenewDto queryPolicyDetail(String policyNo) {
//        // 定义反参
//        SavePolicyRenewDto savePolicyDto;
//        SavePolicyCarDto savePolicyCarDto;
//        SavePolicyUncarDto savePolicyUncarDto;
//
//        // 获取保单基本信息
//        Optional<PolicyMain> policyMainOptional = policyMainRepository.findByPolicyNo(policyNo);
//        if (!policyMainOptional.isPresent()) {
//            throw new BusinessException(StatusEnum.POLICY_NO_DETAIL + policyNo);
//        }
//
//        Optional<PolicyRenew> policyRenew = policyRenewRepository.findPolicyRenewByPolicyNo(policyNo);
//        if (!policyRenew.isPresent()) {
//            throw new BusinessException(StatusEnum.RENEW_DETAIL_NOT_EXIST, policyNo);
//        }
//        // 组装前端基本信息实体
//        PolicyMain policyMain = policyMainOptional.get();
//        savePolicyDto = modelMapper.map(policyMain, SavePolicyRenewDto.class);
//        PolicyRenew PolicyRenewResult = policyRenew.get();
//        savePolicyDto.setProjectNo(PolicyRenewResult.getProjectNo());
//        savePolicyDto.setBelongCompany(PolicyRenewResult.getBelongCompany());
//
//        // 车或非车标识：1车、0非车
//        if (policyMain.getCarUncarFlag() == 1) {
//            Optional<PolicyCarDetail> byPolicyNo = policyCarDetailRepository.findByPolicyNo(policyNo);
//            if (byPolicyNo.isPresent()) {
//                PolicyCarDetail policyCarDetail = byPolicyNo.get();
//                savePolicyCarDto = modelMapper.map(policyCarDetail, SavePolicyCarDto.class);
//                // 获取方案信息
//                List<PolicyVehRiskPlan> policyVehRiskPlans = policyVehRiskPlanRepository.findByPolicyNo(policyNo);
//                mapperFactory.classMap(PolicyVehRiskPlan.class, PolicyVehRiskPlanDto.class).byDefault().register();
//                List<PolicyVehRiskPlanDto> policyVehRiskPlanDtos = mapperFactory.getMapperFacade().mapAsList(policyVehRiskPlans, PolicyVehRiskPlanDto.class);
//                savePolicyCarDto.setPolicyVehRiskPlanDtoList(policyVehRiskPlanDtos);
//                // end
//                savePolicyDto.setSavePolicyCarDto(savePolicyCarDto);
//            }
//        } else {
//            Optional<PolicyUncarDetail> byPolicyNo = policyUncarDetailRepository.findByPolicyNo(policyNo);
//            if (byPolicyNo.isPresent()) {
//                PolicyUncarDetail policyUncarDetail = byPolicyNo.get();
//                savePolicyUncarDto = modelMapper.map(policyUncarDetail, SavePolicyUncarDto.class);
//                savePolicyDto.setSavePolicyUncarDto(savePolicyUncarDto);
//            }
//        }
//
//        // 获取附件信息列表
//        savePolicyDto.setFiAuditFileDtos(fileService.listFiAuditFileDto(policyNo, PlanConstant.BELONG_TYPE_POLICY, true));
//
//        return savePolicyDto;
//    }
//
//    /**
//     * Description : 根据保单号获取保单详情
//     *
//     * @author : Sun
//     * @date : 2019/9/21 12:52
//     */
//    public SavePolicyModifyDto queryPolicyDetailById(BigInteger policyId) {
//        // 定义反参
//        SavePolicyModifyDto savePolicyDto;
//        SavePolicyCarDto savePolicyCarDto;
//        SavePolicyUncarDto savePolicyUncarDto;
//
//        // 获取保单基本信息
//        Optional<PolicyMainModify> policyMainOptional = policyMainModifyRepository.findById(policyId);
//        if (!policyMainOptional.isPresent()) {
//            throw new BusinessException(StatusEnum.POLICY_NO_DETAIL + "" + policyId);
//        }
//
//
//        // 组装前端基本信息实体
//        PolicyMainModify policyMain = policyMainOptional.get();
//        savePolicyDto = modelMapper.map(policyMain, SavePolicyModifyDto.class);
//
//        // 车或非车标识：1车、0非车
//        if (policyMain.getCarUncarFlag() == 1) {
//            Optional<PolicyCarDetailModify> byPolicyNo = policyCarDetailModifyRepository.findByPolicyId(policyId);
//            if (byPolicyNo.isPresent()) {
//                PolicyCarDetailModify policyCarDetail = byPolicyNo.get();
//                savePolicyCarDto = modelMapper.map(policyCarDetail, SavePolicyCarDto.class);
//                // 获取方案信息
//                List<PolicyVehRiskPlan> policyVehRiskPlans = policyVehRiskPlanRepository.findByPolicyNo(policyCarDetail.getPolicyNo());
//                mapperFactory.classMap(PolicyVehRiskPlan.class, PolicyVehRiskPlanDto.class).byDefault().register();
//                List<PolicyVehRiskPlanDto> policyVehRiskPlanDtos = mapperFactory.getMapperFacade().mapAsList(policyVehRiskPlans, PolicyVehRiskPlanDto.class);
//                savePolicyCarDto.setPolicyVehRiskPlanDtoList(policyVehRiskPlanDtos);
//                // end
//                savePolicyDto.setSavePolicyCarDto(savePolicyCarDto);
//            }
//        } else {
//            Optional<PolicyUncarDetailModify> byPolicyNo = policyUncarDetailModifyRepository.findByPolicyId(policyId);
//            if (byPolicyNo.isPresent()) {
//                PolicyUncarDetailModify policyUncarDetail = byPolicyNo.get();
//                savePolicyUncarDto = modelMapper.map(policyUncarDetail, SavePolicyUncarDto.class);
//                savePolicyDto.setSavePolicyUncarDto(savePolicyUncarDto);
//            }
//        }
//
//        // 获取附件信息列表
//        savePolicyDto.setFiAuditFileDtos(fileService.listFiAuditFileDto(policyMain.getPolicyNo(), PlanConstant.BELONG_TYPE_POLICY, true));
//
//        savePolicyDto.setPolicyModifys(policyModifyRepository.findPolicyModifyByPolicyId(policyId));
//
//        return savePolicyDto;
//    }
//
//
//    /**
//     * Description : 保单分页列表
//     * SELECT * FROM policy_main m LEFT JOIN policy_car_detail cd ON m.policy_no = cd.policy_no WHERE m.policy_no = 'string1';
//     * SELECT * FROM policy_main m LEFT JOIN policy_uncar_detail ud ON m.policy_no = ud.policy_no WHERE m.policy_no = 'string2';
//     *
//     * @author : Sun
//     * @date : 2019/9/21 14:01
//     */
//    public PageInfo<PolicyListDto> queryPageList(PolicyListCondition policy) {
//        // 获取分页信息
//        Integer pageNum = policy.getPageNum();
//        Integer pageSize = policy.getPageSize();
//
//        // 保单号
//        String policyNo = policy.getPolicyNo();
//        // 车或非车标识：1车、0非车，必传
//        Byte carUncarFlag = policy.getCarUncarFlag();
//        // 保险类别：车1、企业工程23456
//        String insuranceCategory = policy.getInsuranceCategory();
//        // 险种代码；例:车（交强、商业）,非车待定
//        String kindCode = policy.getKindCode();
//        // 所属分公司
//        String startCompany = policy.getStartCompany();
//        // 保险公司
//        String belongCompany = policy.getBelongCompany();
//        // 中标项目编号
//        BigInteger projectNo = policy.getProjectNo();
//        // 投保人
//        String holderName = policy.getHolderName();
//        // 创建、投保查询起始日期
//        Date startCreateTime = policy.getStartCreateTime();
//        // 创建、投保查询终止日期
//        Date endCreateTime = policy.getEndCreateTime();
//        // 状态
//        Byte status = policy.getStatus();
//
//        // 组装通用sql
//        StringBuilder sql = new StringBuilder();
//        processQuerySql(carUncarFlag, startCompany, startCreateTime, endCreateTime, sql);
//
//        // 查询结果
//        long total;
//        List<PolicyListDto> policyCarListDtos;
//        if (StringUtils.isNotBlank(startCompany)) {
//            total = dynamicQuery.nativeQueryCount("select count(1) from (" + sql + ") a",
//                carUncarFlag, policyNo, insuranceCategory, kindCode, belongCompany,
//                projectNo, holderName, status, startCreateTime, endCreateTime,
//                startCompany);
//            sql.append("order by m.create_time desc limit ?12, ?13 ");
//
//            policyCarListDtos = dynamicQuery.nativeQueryListModel(PolicyListDto.class, sql.toString(),
//                carUncarFlag, policyNo, insuranceCategory, kindCode, belongCompany,
//                projectNo, holderName, status, startCreateTime, endCreateTime,
//                startCompany, (pageNum - 1) * pageSize, pageSize);
//        } else {
//            total = dynamicQuery.nativeQueryCount("select count(1) from (" + sql + ") a",
//                carUncarFlag, policyNo, insuranceCategory, kindCode, belongCompany,
//                projectNo, holderName, status, startCreateTime, endCreateTime);
//            sql.append("order by m.create_time desc limit ?11, ?12 ");
//
//            policyCarListDtos = dynamicQuery.nativeQueryListModel(PolicyListDto.class, sql.toString(),
//                carUncarFlag, policyNo, insuranceCategory, kindCode, belongCompany,
//                projectNo, holderName, status, startCreateTime, endCreateTime,
//                (pageNum - 1) * pageSize, pageSize);
//        }
//        return PageInfo.of(pageNum, pageSize, policyCarListDtos, total);
//    }
//
//    /**
//     * Description : 保单分页列表
//     * SELECT * FROM policy_main m LEFT JOIN policy_car_detail cd ON m.policy_no = cd.policy_no WHERE m.policy_no = 'string1';
//     * SELECT * FROM policy_main m LEFT JOIN policy_uncar_detail ud ON m.policy_no = ud.policy_no WHERE m.policy_no = 'string2';
//     *
//     * @author : Sun
//     * @date : 2019/9/21 14:01
//     */
//    public PageInfo<PolicyListDto> queryPageTodos(PolicyListCondition policy) {
//        // 获取分页信息
//        Integer pageNum = policy.getPageNum();
//        Integer pageSize = policy.getPageSize();
//
//        // 保单号
//        String policyNo = policy.getPolicyNo();
//        // 车或非车标识：1车、0非车，必传
//        Byte carUncarFlag = policy.getCarUncarFlag();
//        // 保险类别：车1、企业工程23456
//        String insuranceCategory = policy.getInsuranceCategory();
//        // 险种代码；例:车（交强、商业）,非车待定
//        String kindCode = policy.getKindCode();
//        // 所属分公司
//        String startCompany = policy.getStartCompany();
//        // 保险公司
//        String belongCompany = policy.getBelongCompany();
//        // 中标项目编号
//        BigInteger projectNo = policy.getProjectNo();
//        // 投保人
//        String holderName = policy.getHolderName();
//        // 创建、投保查询起始日期
//        Date startCreateTime = policy.getStartCreateTime();
//        // 创建、投保查询终止日期
//        Date endCreateTime = policy.getEndCreateTime();
//        // 状态
//        Byte status = policy.getStatus();
//
//        Integer hasEndDays = policy.getHasEndDays();
//
//        // 组装通用sql
//        StringBuilder sql = new StringBuilder();
//        processQuerySqlTodos(policy, carUncarFlag, startCompany, startCreateTime, endCreateTime, hasEndDays, sql);
//
//        // 查询结果
//        long total;
//        List<PolicyListDto> policyCarListDtos;
//        if (StringUtils.isNotBlank(startCompany)) {
//            total = dynamicQuery.nativeQueryCount("select count(1) from (" + sql + ") a",
//                carUncarFlag, policyNo, insuranceCategory, kindCode, belongCompany,
//                projectNo, holderName, status, startCreateTime, endCreateTime,
//                startCompany);
//
//            sql.append(" limit ?12, ?13 ");
//
//            policyCarListDtos = dynamicQuery.nativeQueryListModel(PolicyListDto.class, sql.toString(),
//                carUncarFlag, policyNo, insuranceCategory, kindCode, belongCompany,
//                projectNo, holderName, status, startCreateTime, endCreateTime,
//                startCompany, (pageNum - 1) * pageSize, pageSize);
//        } else {
//            total = dynamicQuery.nativeQueryCount("select count(1) from (" + sql + ") a",
//                carUncarFlag, policyNo, insuranceCategory, kindCode, belongCompany,
//                projectNo, holderName, status, startCreateTime, endCreateTime);
//
//            sql.append("  limit ?11, ?12 ");
//
//
//            policyCarListDtos = dynamicQuery.nativeQueryListModel(PolicyListDto.class, sql.toString(),
//                carUncarFlag, policyNo, insuranceCategory, kindCode, belongCompany,
//                projectNo, holderName, status, startCreateTime, endCreateTime,
//                (pageNum - 1) * pageSize, pageSize);
//        }
//        return PageInfo.of(pageNum, pageSize, policyCarListDtos, total);
//    }
//
//
//    /**
//     * @param jointCar:
//     * @author Sun
//     * @description 车险新增保单
//     * @date 2019/11/5 21:47
//     **/
//    public PolicyMain saveJointCarPolicyDto(SaveJointCarPolicyRenewDto jointCar) {
//        PolicyMain policyMain = new PolicyMain();
//        PolicyRenewDTO policyRenewDTO = jointCar.getPolicyRenewDTO();
//        // 交强险种信息
//        if (jointCar.isJq()) {
//            SavePolicyRenewDto jqPolicy = new SavePolicyRenewDto();
//            SavePolicyCarDto jqPolicyCar = new SavePolicyCarDto();
//            processCommonCarPolicy(jointCar, jqPolicy, jqPolicyCar);
//            jqPolicy.setPolicyNoNew(policyRenewDTO.getPolicyNoNew());
//            // 依次同步附件中的保单号
//            List<FiAuditFileDto> fiAuditFileDtos = jqPolicy.getFiAuditFileDtos();
//            fiAuditFileDtos = fiAuditFileDtos.stream().peek(fiAuditFileDto -> fiAuditFileDto.setBelongId(jointCar.getJqPolicyNo())).collect(Collectors.toList());
//            jqPolicy.setFiAuditFileDtos(fiAuditFileDtos);
//
//            // 加工交强特有信息
//            jqPolicy.setKindCode("1");
//            jqPolicy.setPolicyNo(jointCar.getJqPolicyNo());
//            jqPolicyCar.setPolicyNo(jointCar.getJqPolicyNo());
//            jqPolicy.setPolicyBgnTime(jointCar.getJqPolicyBgnTime());
//            jqPolicy.setPolicyEndTime(jointCar.getJqPolicyEndTime());
//            jqPolicy.setTotalPremium(jointCar.getJqTotalPremium());
//            jqPolicyCar.setFeeProp(jointCar.getJqFeeProp());
//            jqPolicyCar.setVehicleVesselTax(jointCar.getJqVehicleVesselTax());
//            jqPolicy.setSavePolicyCarDto(jqPolicyCar);
//            policyMain = savePolicyRenew(jqPolicy, 1);
//        }
//
//        // 商业险种信息
//        if (jointCar.isSy()) {
//            SavePolicyRenewDto syPolicy = new SavePolicyRenewDto();
//            SavePolicyCarDto syPolicyCar = new SavePolicyCarDto();
//            processCommonCarPolicy(jointCar, syPolicy, syPolicyCar);
//            syPolicy.setPolicyNoNew(policyRenewDTO.getPolicyNoNew());
//            // 依次同步附件中的保单号
//            List<FiAuditFileDto> fiAuditFileDtos = syPolicy.getFiAuditFileDtos();
//            fiAuditFileDtos = fiAuditFileDtos.stream().peek(fiAuditFileDto -> fiAuditFileDto.setBelongId(jointCar.getSyPolicyNo())).collect(Collectors.toList());
//            syPolicy.setFiAuditFileDtos(fiAuditFileDtos);
//
//            // 加工商业特有信息
//            syPolicy.setKindCode("2");
//            syPolicy.setPolicyNo(jointCar.getSyPolicyNo());
//            syPolicyCar.setPolicyNo(jointCar.getSyPolicyNo());
//            syPolicy.setPolicyBgnTime(jointCar.getSyPolicyBgnTime());
//            syPolicy.setPolicyEndTime(jointCar.getSyPolicyEndTime());
//            syPolicy.setTotalPremium(jointCar.getSyTotalPremium());
//            syPolicyCar.setFeeProp(jointCar.getSyFeeProp());
//            syPolicyCar.setNcdCoef(jointCar.getSyNcdCoef());
//            syPolicyCar.setAutoUnderwritingCoef(jointCar.getSyAutoUnderwritingCoef());
//            syPolicy.setSavePolicyCarDto(syPolicyCar);
//            syPolicyCar.setPolicyVehRiskPlanDtoList(jointCar.getPolicyVehRiskPlanDtoList());
//            policyMain = savePolicyRenew(syPolicy, 1);
//        }
//
//
//        // 货运险险种信息
//        if (jointCar.isHw()) {
//            SavePolicyRenewDto hwPolicy = new SavePolicyRenewDto();
//            SavePolicyCarDto hwPolicyCar = new SavePolicyCarDto();
//            processCommonCarPolicy(jointCar, hwPolicy, hwPolicyCar);
//            hwPolicy.setPolicyNoNew(policyRenewDTO.getPolicyNoNew());
//            // 依次同步附件中的保单号
//            List<FiAuditFileDto> fiAuditFileDtos = hwPolicy.getFiAuditFileDtos();
//            fiAuditFileDtos = fiAuditFileDtos.stream().peek(fiAuditFileDto -> fiAuditFileDto.setBelongId(jointCar.getHwPolicyNo())).collect(Collectors.toList());
//            hwPolicy.setFiAuditFileDtos(fiAuditFileDtos);
//
//            // 加工商业特有信息
//            hwPolicy.setKindCode("3");
//            hwPolicy.setPolicyNo(jointCar.getHwPolicyNo());
//            hwPolicyCar.setPolicyNo(jointCar.getHwPolicyNo());
//            hwPolicy.setPolicyBgnTime(jointCar.getHwPolicyBgnTime());
//            hwPolicy.setPolicyEndTime(jointCar.getHwPolicyEndTime());
//            hwPolicy.setTotalPremium(jointCar.getHwTotalPremium());
//            hwPolicy.setSavePolicyCarDto(hwPolicyCar);
//            policyMain = savePolicyRenew(hwPolicy, 1);
//        }
//
//        return policyMain;
//    }
//
//    public void renewReport(SaveJointCarPolicyRenewDto jointCar, PolicyMain policyMain) {
//        PolicyRenewDTO policyRenewDTO = jointCar.getPolicyRenewDTO();
//        String oldPolicyNo = policyRenewDTO.getPolicyNo();
//        String newPolicyNo = policyRenewDTO.getPolicyNoNew();
//        // 人
//        List<EiUserDto> userDtos = eiUserService.queryDepartLowerUserList(policyMain.getStartCompany());
//        if (null == userDtos || userDtos.isEmpty()) {
//            return;
//        }
//        List<String> users = userDtos.stream().map(EiUserDto::getUserName).collect(Collectors.toList());
//        remindService.renewReport(newPolicyNo, oldPolicyNo, users, BaseConstant.REMIND_EI_RENEW_DOWN_CAR, null, true);
//    }
//
//    /**
//     * @param jointCar:
//     * @param policy:
//     * @param policyCar:
//     * @author Sun
//     * @description 组装通用信息
//     * @date 2019/11/5 21:47
//     **/
//    private void processCommonCarPolicy(@RequestBody @Valid SaveJointCarPolicyRenewDto jointCar, SavePolicyRenewDto policy, SavePolicyCarDto policyCar) {
//        // 组装必要信息
//        policy.setCarUncarFlag(jointCar.getCarUncarFlag());
//        policy.setInsuranceCategory(jointCar.getInsuranceCategory());
//
//        // 组装项目信息
//        policy.setProjectNo(jointCar.getProjectNo());
//        policy.setStartCompany(jointCar.getStartCompany());
//        policy.setBelongCompany(jointCar.getBelongCompany());
//        policy.setBelongCompanyPerson(jointCar.getBelongCompanyPerson());
//        policy.setBelongCompanyPhone(jointCar.getBelongCompanyPhone());
//
//        // 组装基本信息
//        policy.setHolderName(jointCar.getHolderName());
//        policy.setInsuredName(jointCar.getInsuredName());
//        policyCar.setFrameNo(jointCar.getFrameNo());
//        policyCar.setPlateNo(jointCar.getPlateNo());
//        policyCar.setEngineNo(jointCar.getEngineNo());
//        policyCar.setUsageCode(jointCar.getUsageCode());
//        policyCar.setVehicleModel(jointCar.getVehicleModel());
//        policyCar.setOwnerName(jointCar.getOwnerName());
//
//        // 附件信息
//        List<FiAuditFileDto> fiAuditFileDtos = jointCar.getFiAuditFileDtos();
//        policy.setFiAuditFileDtos(fiAuditFileDtos);
//    }
//
//    /**
//     * @param savePolicyDto:
//     * @param flag:
//     * @author Sun
//     * @description 保存保单信息：基本信息、非车/车信息
//     * @date 2019/11/5 21:46
//     **/
//    @Transactional(rollbackFor = RuntimeException.class)
//    public PolicyMain savePolicyRenew(SavePolicyRenewDto savePolicyDto, int flag) {
//        // 获取保单号：新增时校验是否存在此保单、保存车 非车信息时，使用基本信息保单号
////        String policyNo = savePolicyDto.getPolicyNo();
//        String policyNo = savePolicyDto.getPolicyNoNew();
//        // 创建domain实体
//        PolicyCarDetail policyCarDetail;
//        PolicyUncarDetail policyUncarDetail;
//        PolicyMain policyMain = modelMapper.map(savePolicyDto, PolicyMain.class);
//        policyMain.setPolicyNo(savePolicyDto.getPolicyNoNew());
//        if (policyMain.getRemindDisplay() == null) {
//            policyMain.setRemindDisplay(true);
//        }
//        if (flag == 1) {
//            policyMain.setId(null);
//
//            // 校验是否存在该保单信息
//            Optional<PolicyMain> byPolicyNo = policyMainRepository.findByPolicyNo(policyMain.getPolicyNo());
//            if (byPolicyNo.isPresent()) {
//                throw new BusinessException(StatusEnum.POLICY_EXIST_DETAIL, policyNo);
//            }
//
//        } else {
//            if (policyMain.getId() == null) {
//                throw new BusinessException(StatusEnum.POLICY_MAIN_NEED_ID);
//            }
//        }
//
//        // 保存保单基本信息
//        policyMain.setCreateTime(DateUtil.date());
////        policyMainRepository.save(policyMain);
//        PolicyMain policyMainNew = policyMainRepository.saveAndFlush(policyMain);
//
//
//        // 车或非车标识：1车、0非车
//        if (savePolicyDto.getCarUncarFlag() == 1 && savePolicyDto.getSavePolicyCarDto() != null) {
//            SavePolicyCarDto savePolicyCarDto = savePolicyDto.getSavePolicyCarDto();
//            policyCarDetail = modelMapper.map(savePolicyCarDto, PolicyCarDetail.class);
//            // 保单号：使用基本信息中的保单号
//            policyCarDetail.setPolicyNo(policyNo);
//            if (flag == 1) {
//                policyCarDetail.setId(null);
//            } else {
//                if (policyCarDetail.getId() == null) {
//                    throw new BusinessException(StatusEnum.POLICY_CAR_NEED_ID);
//                }
//            }
//            policyCarDetailRepository.save(policyCarDetail);
//
//            // 获取方案列表
//            List<PolicyVehRiskPlanDto> policyVehRiskPlanDtoList = savePolicyCarDto.getPolicyVehRiskPlanDtoList();
//            if (policyVehRiskPlanDtoList != null && !policyVehRiskPlanDtoList.isEmpty()) {
//                // 删除现有的方案
//                policyVehRiskPlanRepository.deleteByPolicyNo(policyNo);
//
//                // Dto转换为entity
//                mapperFactory.classMap(PolicyVehRiskPlanDto.class, PolicyVehRiskPlan.class).byDefault().register();
//                List<PolicyVehRiskPlan> policyVehRiskPlans = mapperFactory.getMapperFacade().mapAsList(policyVehRiskPlanDtoList, PolicyVehRiskPlan.class);
//                // 使用主保单号，省着传错的进来
//                for (PolicyVehRiskPlan policyVehRiskPlan : policyVehRiskPlans) {
//                    policyVehRiskPlan.setPolicyNo(policyNo);
//                }
//                // 保存
//                policyVehRiskPlanRepository.saveAll(policyVehRiskPlans);
//            }
//        }
//        if (savePolicyDto.getCarUncarFlag() == 0 && savePolicyDto.getSavePolicyUncarDto() != null) {
//            policyUncarDetail = modelMapper.map(savePolicyDto.getSavePolicyUncarDto(), PolicyUncarDetail.class);
//            // 保单号：使用基本信息中的保单号
//            policyUncarDetail.setPolicyNo(policyNo);
//            if (flag == 1) {
//                policyUncarDetail.setId(null);
//            } else {
//                if (policyUncarDetail.getId() == null) {
//                    throw new BusinessException(StatusEnum.POLICY_UNCAR_NEED_ID);
//                }
//            }
//            policyUncarDetailRepository.save(policyUncarDetail);
//        }
//
//        // 保存保单附件列表信息
//        try {
//            savePolicyRenewFileAuditDetail(savePolicyDto);
//        } catch (Exception e) {
//            throw new BusinessException("保存附件列表信息异常");
//        }
//
//        return policyMainNew;
//    }
//
//    /**
//     * Description : 组装查询sql
//     *
//     * @author : Sun
//     * @date : 2019/9/26 11:30
//     */
//    private void processQuerySql(Byte carUncarFlag, String startCompany, Date startCreateTime, Date endCreateTime, StringBuilder sql) {
//        sql.append(" SELECT distinct ");
//        sql.append(" m.id as id, ");
//        sql.append(" m.policy_no as policyNo, ");
//        sql.append(" m.car_uncar_flag as carUncarFlag, ");
//        sql.append(" m.insurance_category as insuranceCategory, ");
//        sql.append(" m.kind_code as kindCode, ");
//        sql.append(" m.holder_name as holderName, ");
//        sql.append(" m.insured_name as insuredName, ");
//        sql.append(" m.project_no as projectNo, ");
//        sql.append(" m.start_company as startCompany, ");
//        sql.append(" m.belong_company as belongCompany, ");
//        sql.append(" m.total_premium as totalPremium, ");
//        sql.append(" m.policy_bgn_time as policyBgnTime, ");
//        sql.append(" m.policy_end_time as policyEndTime, ");
//        sql.append(" m.create_time as createTime, ");
//        sql.append(" m.belong_company_person as belongCompanyPerson, ");
//        sql.append(" m.belong_company_phone as belongCompanyPhone, ");
//        sql.append(" m.status as status, ");
//
//        if (PolicyConstant.POLICY_CAR.equals(carUncarFlag)) {
//            sql.append(" cd.frame_no as frameNo, ");
//            sql.append(" cd.plate_no as plateNo, ");
//            sql.append(" cd.engine_no as engineNo, ");
//            sql.append(" cd.usage_code as usageCode, ");
//            sql.append(" cd.vehicle_model as vehicleModel, ");
//            sql.append(" cd.vehicle_vessel_tax as vehicleVesselTax, ");
//            sql.append(" cd.ncd_coef as ncdCoef, ");
//            sql.append(" cd.auto_underwriting_coef as autoUnderwritingCoef ");
//            sql.append(" FROM policy_main m LEFT JOIN policy_car_detail cd ");
//            sql.append(" ON m.policy_no = cd.policy_no ");
//        } else {
//            sql.append(" ud.main_risk_duty as mainRiskDuty, ");
//            sql.append(" ud.total_amount as totalAmount, ");
//            sql.append(" ud.fee_prop as feeProp, ");
//            sql.append(" ud.issue_date as issueDate, ");
//            sql.append(" ud.coinsurance_detail as coinsuranceDetail, ");
//            sql.append(" ud.paid_in_date as paidInDate, ");
//            sql.append(" ud.payment_type as paymentType, ");
//            sql.append(" ud.subordinate_bid as subordinateBid, ");
//            sql.append(" ud.engineering_name as engineeringName, ");
//            sql.append(" ud.guaranty_period as guarantyPeriod ");
//            sql.append(" FROM policy_main m LEFT JOIN policy_uncar_detail ud ");
//            sql.append(" ON m.policy_no = ud.policy_no ");
//        }
//
//        if (StringUtils.isNotBlank(startCompany)) {
//            sql.append(" , ei_depart d1 ");
//        }
//
//        sql.append(" , policy_renew pr ");
//
//        sql.append(" WHERE ");
//        sql.append(" 1 = 1 ");
//        sql.append(" AND IF (?1 is not NULL, m.car_uncar_flag = ?1, 0 = 0) ");
//        sql.append(" AND IF (?2 != '', m.policy_no = ?2, 0 = 0) ");
//        sql.append(" AND IF (?3 != '', m.insurance_category = ?3, 0 = 0) ");
//        sql.append(" AND IF (?4 != '', m.kind_code = ?4, 0 = 0) ");
//        sql.append(" AND IF (?5 != '', m.belong_company = ?5, 0 = 0) ");
//        sql.append(" AND IF (?6 != '', m.project_no = ?6, 0 = 0) ");
//        sql.append(" AND IF (?7 != '', m.holder_name = ?7, 0 = 0) ");
//        sql.append(" AND IF (?8 is not NULL, m.status = ?8, 0 = 0) ");
//        if (startCreateTime != null && endCreateTime != null) {
//            sql.append(" AND m.create_time BETWEEN ?9 AND ?10 ");
//        } else {
//            sql.append(" AND IF (?9 != '', m.create_time >= ?9, 0 = 0) ");
//            sql.append(" AND IF (?10 != '', m.create_time < ?10, 0 = 0) ");
//        }
//
//        if (StringUtils.isNotBlank(startCompany)) {
//            sql.append(" AND d1.id = m.start_company ");
//            sql.append(" AND d1.id = ?11 ");
////            sql.append(" AND d1.ids LIKE CONCAT(d2.ids,'%') ");
//        }
//
//        sql.append(" and pr.policy_no = m.policy_no ");
//
////        sql.append(" pr.policy_end_time >= CURDATE() and pr.policy_end_time <= DATE_ADD(CURDATE(), INTERVAL ?12 DAY)");
//    }
//
//    /**
//     * Description : 组装查询sql
//     *
//     * @author : Sun
//     * @date : 2019/9/26 11:30
//     */
//    private void processQuerySqlTodos(PolicyListCondition policy, Byte carUncarFlag, String startCompany, Date startCreateTime, Date endCreateTime, Integer hasEndDays, StringBuilder sql) {
//
//        //排序的列名称
//        String column = LineToHumpTool.humpToLines(policy.getColumn());
//        sql.append(" SELECT distinct ");
//        sql.append(" m.id as id, ");
//        sql.append(" DATEDIFF(m.policy_end_time,CURDATE( )) AS remainingDueDays, ");
//        sql.append(" m.policy_no as policyNo, ");
//        sql.append(" m.remind_status as remindStatus, ");
//        sql.append(" m.car_uncar_flag as carUncarFlag, ");
//        sql.append(" m.insurance_category as insuranceCategory, ");
//        sql.append(" m.kind_code as kindCode, ");
//        sql.append(" m.holder_name as holderName, ");
//        sql.append(" m.insured_name as insuredName, ");
//        sql.append(" m.project_no as projectNo, ");
//        sql.append(" m.start_company as startCompany, ");
//        sql.append(" m.belong_company as belongCompany, ");
//        sql.append(" m.total_premium as totalPremium, ");
//        sql.append(" m.policy_bgn_time as policyBgnTime, ");
//        sql.append(" m.policy_end_time as policyEndTime, ");
//        sql.append(" m.create_time as createTime, ");
//        sql.append(" m.belong_company_person as belongCompanyPerson, ");
//        sql.append(" m.belong_company_phone as belongCompanyPhone, ");
//        sql.append(" m.status as status, ");
//
//        if (PolicyConstant.POLICY_CAR.equals(carUncarFlag)) {
//            sql.append(" cd.frame_no as frameNo, ");
//            sql.append(" cd.plate_no as plateNo, ");
//            sql.append(" cd.engine_no as engineNo, ");
//            sql.append(" cd.usage_code as usageCode, ");
//            sql.append(" cd.vehicle_model as vehicleModel, ");
//            sql.append(" cd.vehicle_vessel_tax as vehicleVesselTax, ");
//            sql.append(" cd.ncd_coef as ncdCoef, ");
//            sql.append(" cd.auto_underwriting_coef as autoUnderwritingCoef ");
//            sql.append(" FROM policy_main m LEFT JOIN policy_car_detail cd ");
//            sql.append(" ON m.policy_no = cd.policy_no ");
//        } else {
//            sql.append(" ud.main_risk_duty as mainRiskDuty, ");
//            sql.append(" ud.total_amount as totalAmount, ");
//            sql.append(" ud.fee_prop as feeProp, ");
//            sql.append(" ud.issue_date as issueDate, ");
//            sql.append(" ud.coinsurance_detail as coinsuranceDetail, ");
//            sql.append(" ud.paid_in_date as paidInDate, ");
//            sql.append(" ud.payment_type as paymentType, ");
//            sql.append(" ud.subordinate_bid as subordinateBid, ");
//            sql.append(" ud.engineering_name as engineeringName, ");
//            sql.append(" ud.guaranty_period as guarantyPeriod ");
//            sql.append(" FROM policy_main m LEFT JOIN policy_uncar_detail ud ");
//            sql.append(" ON m.policy_no = ud.policy_no ");
//        }
//
//        if (StringUtils.isNotBlank(startCompany)) {
//            sql.append(" , ei_depart d1 ");
//        }
//
//        sql.append(" , policy_renew pr ");
//
//        sql.append(" WHERE ");
//        sql.append(" 1 = 1 ");
//        sql.append(" AND IF (?1 is not NULL, m.car_uncar_flag = ?1, 0 = 0) ");
//        sql.append(" AND IF (?2 != '', m.policy_no = ?2, 0 = 0) ");
//        sql.append(" AND IF (?3 != '', m.insurance_category = ?3, 0 = 0) ");
//        sql.append(" AND IF (?4 != '', m.kind_code = ?4, 0 = 0) ");
//        sql.append(" AND IF (?5 != '', m.belong_company = ?5, 0 = 0) ");
//        sql.append(" AND IF (?6 != '', m.project_no = ?6, 0 = 0) ");
//        sql.append(" AND IF (?7 != '', m.insured_name like ?7, 0 = 0) ");
//        sql.append(" AND IF (?8 is not NULL, m.status = ?8, 0 = 0) ");
//        if (startCreateTime != null && endCreateTime != null) {
//            sql.append(" AND m.create_time BETWEEN ?9 AND ?10 ");
//        } else {
//            sql.append(" AND IF (?9 != '', m.create_time >= ?9, 0 = 0) ");
//            sql.append(" AND IF (?10 != '', m.create_time < ?10, 0 = 0) ");
//        }
//
//        if (StringUtils.isNotBlank(startCompany)) {
//            sql.append(" AND d1.id = m.start_company ");
//            sql.append(" AND d1.id = ?11 ");
////            sql.append(" AND d1.ids LIKE CONCAT(d2.ids,'%') ");
//        }
//        sql.append(" and m.remind_display <> 0 ");
//        sql.append(" and m.car_uncar_flag = " + carUncarFlag);
//        sql.append(" and not EXISTS (select pr.policy_no from policy_renew pr where pr.policy_no = m.policy_no )");
//        sql.append(" and  m.policy_end_time >= CURDATE() and m.policy_end_time <= DATE_ADD(CURDATE(), INTERVAL " + hasEndDays + " DAY)");
//
//        // 默认逆序
//        String descType = "desc";
//        if (policy.getRange().equals(1)) {
//            descType = "asc";
//        }
//        // 获取车、非车特有列表字段
//        if (PolicyConstant.POLICY_CAR.equals(policy.getCarUncarFlag())) {
//            if (PlanConstant.COLUMN_CURRENT.equals(column)) {
//                sql.append(" order by m." + column + " " + descType);
//            } else if (ClassUtils.containsField(new PolicyMain(), policy.getColumn())) {
//                sql.append(" order by m." + column + " " + descType);
//            } else if (ClassUtils.containsField(new PolicyCarDetail(), policy.getColumn())) {
//                sql.append(" order by cd." + column + " " + descType);
//            }
//        } else if (PolicyConstant.POLICY_CAR_UN.equals(policy.getCarUncarFlag())) {
//            if (PlanConstant.COLUMN_CURRENT.equals(column)) {
//                sql.append(" order by m." + column + " " + descType);
//            } else if (ClassUtils.containsField(new PolicyMain(), policy.getColumn())) {
//                sql.append(" order by m." + column + " " + descType);
//            } else if (ClassUtils.containsField(new PolicyUncarDetail(), policy.getColumn())) {
//                sql.append(" order by ud." + column + " " + descType);
//            }
//        } else {
//            if (PlanConstant.COLUMN_CURRENT.equals(column)) {
//                sql.append(" order by m." + column + " " + descType);
//            } else if (ClassUtils.containsField(new PolicyMain(), policy.getColumn())) {
//                sql.append(" order by m." + column + " " + descType);
//            } else if (ClassUtils.containsField(new PolicyUncarDetail(), policy.getColumn())) {
//                sql.append(" order by ud." + column + " " + descType);
//            } else if (ClassUtils.containsField(new PolicyCarDetail(), policy.getColumn())) {
//                sql.append(" order by cd." + column + " " + descType);
//            }
//        }
//    }
//
//
//    public void renewRemind() {
//        PolicyListCondition policyListCondition = new PolicyListCondition();
//        policyListCondition.setPageNum(1);
//        policyListCondition.setCarUncarFlag(PolicyConstant.POLICY_CAR);
//        policyListCondition.setPageSize(100000);
//        policyListCondition.setHasEndDays(30);
//        PageInfo<PolicyListDto> page = this.queryPageTodos(policyListCondition);
//        if (null == page) {
//            return;
//        }
//        List<PolicyListDto> list = page.getList();
//        if (null == list || list.isEmpty()) {
//            return;
//        }
//        list = list.stream().filter(d -> null == d.getRemindStatus()).collect(Collectors.toList());
//        if (list.isEmpty()) {
//            return;
//        }
//        list.forEach(policy -> {
//            // 车
//            if (PolicyConstant.POLICY_CAR.equals(policy.getCarUncarFlag())) {
//                String date = DateUtil.format(policy.getPolicyEndTime(), "YYYY-MM-dd");
//                this.reportEi(policy, date);
//                this.reportIns(policy, date);
//                policyMainRepository.updatePolicyRenewStatus(policy.getPolicyNo(), true);
//            }
//        });
//
//    }
//
//    private void reportEi(PolicyListDto policy, String date) {
//        String startCompany = policy.getStartCompany();
//        if (StringUtils.isBlank(startCompany)) {
//            return;
//        }
//        List<EiUserDto> userDtos = eiUserService.queryDepartLowerUserList(startCompany);
//        if (null == userDtos || userDtos.isEmpty()) {
//            return;
//        }
//        List<String> users = userDtos.stream().map(EiUserDto::getUserName).collect(Collectors.toList());
//        remindService.renewReport(null, policy.getPolicyNo(), users, BaseConstant.REMIND_EI_RENEW_CAR, date, false);
//
//    }
//
//    private void reportIns(PolicyListDto policy, String date) {
//        String belong = policy.getBelongCompany();
//        if (StringUtils.isBlank(belong)) {
//            return;
//        }
//        List<EiInsUserDto> userDtos = insUserService.queryDepartLowerUserList(Integer.valueOf(belong));
//        if (null == userDtos || userDtos.isEmpty()) {
//            return;
//        }
//        List<String> users = userDtos.stream().map(EiInsUserDto::getUserName).collect(Collectors.toList());
//        remindService.renewReport(null, policy.getPolicyNo(), users, BaseConstant.REMIND_INS_RENEW_CAR, date, true);
//
//    }
//}
