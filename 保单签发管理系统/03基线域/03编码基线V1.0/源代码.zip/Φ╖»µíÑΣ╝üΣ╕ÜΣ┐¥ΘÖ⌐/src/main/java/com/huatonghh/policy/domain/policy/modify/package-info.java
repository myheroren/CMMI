/**
 * 存储 批改 相关信息.
 */
package com.huatonghh.policy.domain.policy.modify;
