package com.huatonghh.message.po.dto;

import com.google.common.base.MoreObjects;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

/**
 * @author wanggl
 * @date 2020-11-03 15:55
 */
@ApiModel("第三方消息发送信息")
public class ThirdParty implements Serializable {

    private static final long serialVersionUID = -2998877898885359800L;

    @ApiModelProperty(value = "发送方式", required = true)
    @NotEmpty(message = "发送方式不能为空")
    private String type;

    @ApiModelProperty(value = "用户信息", required = true)
    @NotEmpty(message = "用户信息不能为空")
    private String userInfo;

    @ApiModelProperty(value = "url", required = true)
    @NotEmpty(message = "url不能为空")
    private String url;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(String userInfo) {
        this.userInfo = userInfo;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
            .add("type", type)
            .add("userInfo", userInfo)
            .add("url", url)
            .toString();
    }
}
