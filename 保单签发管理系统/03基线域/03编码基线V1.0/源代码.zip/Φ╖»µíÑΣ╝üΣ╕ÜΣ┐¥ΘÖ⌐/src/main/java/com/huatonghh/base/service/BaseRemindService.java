package com.huatonghh.base.service;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.template.Template;
import cn.hutool.extra.template.TemplateConfig;
import cn.hutool.extra.template.TemplateEngine;
import cn.hutool.extra.template.TemplateUtil;
import com.google.common.collect.Lists;
import com.huatonghh.authority.constant.AuthorityConstant;
import com.huatonghh.authority.domain.EiUser;
import com.huatonghh.authority.repository.EiUserRepository;
import com.huatonghh.authority.security.SecurityUtils;
import com.huatonghh.base.constant.BaseConstant;
import com.huatonghh.base.domain.BaseRemind;
import com.huatonghh.base.repository.BaseCodeRepository;
import com.huatonghh.base.repository.BaseRemindRepository;
import com.huatonghh.base.service.dto.BaseCodeDto;
import com.huatonghh.base.service.dto.BaseRemindDto;
import com.huatonghh.common.constant.enums.StatusEnum;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.repository.DynamicQuery;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.ins_authority.domain.EiInsUser;
import com.huatonghh.ins_authority.repository.EiInsUserRepository;
import com.huatonghh.policy.domain.policy.PolicyMain;
import com.huatonghh.policy.repository.policy.PolicyMainRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author : Sun
 * @version : 1.0
 * @description : 通知中心-业务层
 * @date : 2019/11/5 21:06
 */
@Service
@Slf4j
@AllArgsConstructor
public class BaseRemindService {

    private final ModelMapper modelMapper;

    private final BaseRemindRepository baseRemindRepository;

    private final PolicyMainRepository policyMainRepository;

    private final EiInsUserRepository eiInsUserRepository;

    private final EiUserRepository eiUserRepository;

    private final DynamicQuery dynamicQuery;

    private final BaseCodeRepository baseCodeRepository;


    /**
     * @param baseRemindDtoList:
     * @author Sun
     * @description 新增通知
     * @date 2019/11/5 21:07
     **/
    public void saveRemind(List<BaseRemindDto> baseRemindDtoList) {
        List<BaseRemind> baseReminds = baseRemindDtoList.stream().map(baseRemindDto ->
            modelMapper.map(baseRemindDto, BaseRemind.class)).collect(Collectors.toList());
        baseRemindRepository.saveAll(baseReminds);
    }


    /**
     * @param planNo:      方案号
     * @param projectNo:   项目编号
     * @param policyNo:    保单号
     * @param claimNo:     赔案号
     * @param claimStatus: 理赔状态
     * @author Sun
     * @description 非车理赔报案
     * @date 2019/11/5 21:08
     **/
    public void uncarClaimReport(String planNo, String projectNo, String policyNo, String claimNo, Byte claimStatus, String remindContent) {
        // 获取基础代码
        List<BaseCodeDto> codeList = baseCodeRepository.findDistinctTypeIdInfoByTypeId(BaseConstant.CLAIM_STATUS);

        // 保险计划编号、项目编号、保单号、赔案号
        String belongCompany = getBelongCompanyByPolicyNo(policyNo).getBelongCompany();
        List<EiInsUser> eiInsUsers = eiInsUserRepository.findUserListByDepart(Integer.valueOf(belongCompany));

        // 通知主要内容，本例：通过id码查出：已报案、已立案、已定损、已核损、已理算、已结案

        // 发起人存 当前登录账号的人就行了
        String sendUserId = getUser();
        String sendUserName = getSendUserNameByUserId(sendUserId);

        // 通知类型：保单（保单后面的赔案、批改、续保都归于保单下，只用于页面面包屑切换使用）
        List<BaseRemindDto> list = Lists.newArrayList();
        for (EiInsUser eiInsUser : eiInsUsers) {
            BaseRemindDto remind = new BaseRemindDto();
            remind.setSendUserId(sendUserId);
            remind.setSendUserName(sendUserName);
            remind.setReceiveUserId(eiInsUser.getUserName());
            remind.setReceiveUserName(eiInsUser.getName());
            remind.setPlanNo(planNo);
            remind.setProjectNo(projectNo);
            remind.setPolicyNo(policyNo);
            remind.setClaimNo(claimNo);

            // 类型码，匹配中文名字
            remind.setRemindOutline(processRemindOutLineCN(claimStatus.toString(), codeList));
            remind.setRemindContent(remindContent);
            remind.setRemindType(BaseConstant.REMIND_TYPE_POLICY);
            remind.setReadStatus(Convert.toByte("0"));
            remind.setBacklogStatus(Convert.toByte("0"));
            remind.setCreateTime(DateUtil.date());
            list.add(remind);
        }
        saveRemind(list);
    }


    /**
     * @param planNo:      方案号
     * @param projectNo:   项目编号
     * @param policyNo:    保单号
     * @param claimNo:     赔案号
     * @param claimStatus: 理赔状态
     * @author Sun
     * @description 非车理赔-保险公司更新理赔进度
     * @date 2019/11/5 21:09
     **/
    public void uncarClaimUpdateProgress(String planNo, String projectNo, String policyNo, String claimNo, Byte claimStatus, String remindContent) {
        // 获取基础代码
        List<BaseCodeDto> codeList = baseCodeRepository.findDistinctTypeIdInfoByTypeId(BaseConstant.CLAIM_STATUS);

        String belongCompany = getBelongCompanyByPolicyNo(policyNo).getStartCompany();
        List<EiUser> eiUsers = eiUserRepository.findUserListByDepart(belongCompany);

        String sendUserId = getUser();
        String sendUserName = getSendUserNameByUserId(sendUserId);

        List<BaseRemindDto> list = Lists.newArrayList();
        for (EiUser eiUser : eiUsers) {
            BaseRemindDto remind = new BaseRemindDto();
            remind.setSendUserId(sendUserId);
            remind.setSendUserName(sendUserName);
            remind.setReceiveUserId(eiUser.getUserName());
            remind.setReceiveUserName(eiUser.getName());
            remind.setPlanNo(planNo);
            remind.setProjectNo(projectNo);
            remind.setPolicyNo(policyNo);
            remind.setClaimNo(claimNo);

            remind.setRemindOutline(processRemindOutLineCN(claimStatus.toString(), codeList));
            remind.setRemindContent(remindContent);
            remind.setRemindType(Convert.toByte(3));
            remind.setReadStatus(Convert.toByte("0"));
            remind.setBacklogStatus(Convert.toByte("0"));
            remind.setCreateTime(DateUtil.date());
            list.add(remind);
        }
        saveRemind(list);
    }

    public void returnPolicy(String policyNo, String option, List<String> toUsers, String remindContent, Byte remindType) {
        if (null == toUsers || toUsers.isEmpty()) {
            return;
        }
        List<BaseRemindDto> baseRemindDtoList = Lists.newArrayList();
        for (String to : toUsers) {
            BaseRemindDto remind = this.initBaseRemindDto();
            remind.setReceiveUserId(to);
            remind.setReceiveUserName(getSendUserNameByUserId(to));
            remind.setRemindType(remindType);
            remind.setPolicyNo(policyNo);
            // 操作
            remind.setRemindOutline(option);
            // 消息模板
            remind.setRemindContent(remindContent);
            baseRemindDtoList.add(remind);
        }
        this.saveRemind(baseRemindDtoList);
    }

    public void carTransfer(String frameNo, String plateNo, Boolean isAgree, List<String> toUsers, String remindContent, Byte remindType) {
        List<BaseRemindDto> baseRemindDtoList = Lists.newArrayList();
        for (String to : toUsers) {
            BaseRemindDto remind = this.initBaseRemindDto();
            remind.setReceiveUserId(to);
            remind.setReceiveUserName(getSendUserNameByUserId(to));
            remind.setRemindType(remindType);
            remind.setPolicyNo(frameNo);
            remind.setPlanNo(plateNo);
            if (isAgree != null) {
                if (isAgree) {
                    remind.setRemindOutline("同意");
                } else {
                    remind.setRemindOutline("拒绝");
                }
            }
            // 消息模板
            remind.setRemindContent(remindContent);
            baseRemindDtoList.add(remind);
        }
        this.saveRemind(baseRemindDtoList);
    }

    // 催办通知
    public void urgeRemind(String receiveAccount, String businessId, String remindContent, Byte remindType, String taskId) {
        // 发起人存 当前登录账号的人就行了
        BaseRemindDto remind = this.initBaseRemindDto();
        remind.setReceiveUserId(receiveAccount);
        remind.setReceiveUserName(getSendUserNameByUserId(receiveAccount));
        remind.setRemindType(remindType);
        // 年度计划，汇总计划
        if (BaseConstant.REMIND_TYPE_PLAN.equals(remindType) || BaseConstant.REMIND_TYPE_PLAN_GATHER.equals(remindType)) {
            remind.setPlanNo(businessId);
        }
        // 计划外项目
        if (BaseConstant.REMIND_TYPE_PROJECT.equals(remindType)) {
            remind.setProjectNo(businessId);
        }
        // taskId
        remind.setRemindOutline(taskId);
        // 消息模板
        remind.setRemindContent(remindContent);
        List<BaseRemindDto> baseRemindDtoList = Lists.newArrayList();
        baseRemindDtoList.add(remind);
        this.saveRemind(baseRemindDtoList);
    }

    /**
     * 批改通知，发起，完成
     *
     * @param endoId        批单id
     * @param policyNo      保单号
     * @param toUsers       用户
     * @param remindContent 模板
     * @param remindType    类型
     */
    public void endoReport(String endoId, String policyNo, List<String> toUsers, String remindContent, Byte remindType) {
        if (null == toUsers || toUsers.isEmpty()) {
            return;
        }
        List<BaseRemindDto> baseRemindDtoList = Lists.newArrayList();
        for (String to : toUsers) {
            BaseRemindDto remind = this.initBaseRemindDto();
            remind.setReceiveUserId(to);
            remind.setReceiveUserName(getSendUserNameByUserId(to));
            remind.setRemindType(remindType);
            remind.setPolicyNo(policyNo);
            // 批单号
            remind.setRemindOutline(endoId);
            // 消息模板
            remind.setRemindContent(remindContent);
            baseRemindDtoList.add(remind);
        }
        this.saveRemind(baseRemindDtoList);
    }

    private BaseRemindDto initBaseRemindDto() {
        BaseRemindDto remind = new BaseRemindDto();
        String sendUserName = getUser();
        String sendRealName = getSendUserNameByUserId(sendUserName);
        remind.setSendUserId(sendUserName);
        remind.setSendUserName(sendRealName);
        remind.setReadStatus((byte) 0);
        remind.setBacklogStatus((byte) 0);
        remind.setCreateTime(DateUtil.date());
        return remind;
    }

    /**
     * 续保完成通知
     */
    public void renewReport(String policyNoNew, String policyNo, List<String> toUsers, String remindContent, String date, Boolean isToIns) {
        if (null == toUsers || toUsers.isEmpty()) {
            return;
        }
        List<BaseRemindDto> baseRemindDtoList = Lists.newArrayList();
        for (String to : toUsers) {
            BaseRemindDto remind = new BaseRemindDto();
            remind.setReadStatus((byte) 0);
            remind.setBacklogStatus((byte) 0);
            remind.setCreateTime(DateUtil.date());
            remind.setReceiveUserId(to);
            if (isToIns) {
                Optional<EiInsUser> op = eiInsUserRepository.findOneByUserName(to);
                op.ifPresent(u -> {
                    remind.setReceiveUserName(u.getName());
                });
            } else {
                Optional<EiUser> op = eiUserRepository.findOneByUserName(to);
                op.ifPresent(u -> {
                    remind.setReceiveUserName(u.getName());
                });
            }
            remind.setRemindType(BaseConstant.REMIND_TYPE_RENEW);
            remind.setPolicyNo(policyNo);
            remind.setRemindContent(remindContent);
            if (StringUtils.isNotBlank(policyNoNew)) {
                // 新保单号
                remind.setRemindOutline(policyNoNew);
                String sendUserName = getUser();
                String sendRealName = getSendUserNameByUserId(sendUserName);
                remind.setSendUserId(sendUserName);
                remind.setSendUserName(sendRealName);
            } else {
                remind.setRemindOutline(date);
            }

            baseRemindDtoList.add(remind);
        }
        this.saveRemind(baseRemindDtoList);
    }

    /**
     * @param codeType: 码类型
     * @param codeList: 基础代码list
     * @return java.lang.String
     * @author Sun
     * @description 类型码，匹配中文名字
     * @date 2019/11/5 21:09
     **/
    private String processRemindOutLineCN(String codeType, List<BaseCodeDto> codeList) {
        for (BaseCodeDto baseCodeDto : codeList) {
            if (baseCodeDto.getTypeId().equals(codeType)) {
                return baseCodeDto.getTypeName();
            }
        }
        return null;
    }


    /**
     * @param sendUserId: 发消息人id
     * @return java.lang.String
     * @author Sun
     * @description 根据当前登录账号，获取用户中文名
     * @date 2019/11/5 21:09
     **/
    private String getSendUserNameByUserId(String sendUserId) {
        String sendUserName = null;
        String loginRole = SecurityUtils.getLoginRole().get(0);
        if (AuthorityConstant.JTJT.equals(loginRole)) {
            Optional<EiUser> userName = eiUserRepository.findOneByUserName(sendUserId);
            if (userName.isPresent()) {
                sendUserName = userName.get().getName();
            }
        } else if (AuthorityConstant.BXGS.equals(loginRole)) {
            Optional<EiInsUser> insUserName = eiInsUserRepository.findOneByUserName(sendUserId);
            if (insUserName.isPresent()) {
                sendUserName = insUserName.get().getName();
            }
        } else {
            sendUserName = "未登录账户";
        }
        return sendUserName;
    }


    /**
     * @param policyNo: 保单号
     * @return com.huatonghh.plan.domain.policy.PolicyMain
     * @author Sun
     * @description 发起公司、归属保险公司
     * 1.本方法，根据保单号 查询出 归属保险公司下的所有账号 作为通知接收人；
     * 2.schedule更新理赔进度， 根据保单号查询出 需求公司下的所有账号，作为 通知接收人
     * @date 2019/11/5 21:10
     **/
    private PolicyMain getBelongCompanyByPolicyNo(String policyNo) {
        Optional<PolicyMain> op = policyMainRepository.findByPolicyNo(policyNo);
        if (!op.isPresent()) {
            throw new BusinessException("保单" + policyNo + "不存在");
        }
        return op.get();
    }


    /**
     * @return java.lang.String
     * @author Sun
     * @description 根据登录账号获取用户信息
     * @date 2019/11/5 21:11
     **/
    public String getUser() {
        Optional<String> currentUserLogin = SecurityUtils.getCurrentUserLogin();
        if (currentUserLogin.isPresent()) {
            return currentUserLogin.get();
        } else {
            throw new BusinessException(StatusEnum.USER_NOT_LOGIN);
        }
    }


    /**
     * @param pageNum:    页码
     * @param pageSize:   条目数
     * @param read:       是否已读
     * @param backlog:    是否加入备忘
     * @param remindType: 通知类型
     * @return com.huatonghh.common.util.system.PageInfo<com.huatonghh.base.service.dto.BaseRemindDto>
     * @author Sun
     * @description 分页列表
     * @date 2019/11/5 21:11
     **/
    public PageInfo<BaseRemindDto> pageList(Integer pageNum, Integer pageSize, Byte read, Byte backlog, Byte remindType) {
        String user = getUser();
        StringBuilder sql = new StringBuilder("SELECT ");
        sql.append(" r.id as id, ");
        sql.append(" r.send_user_id as sendUserId, ");
        sql.append(" r.send_user_name as sendUserName, ");
        sql.append(" r.receive_user_id as receiveUserId, ");
        sql.append(" r.receive_user_name as receiveUserName, ");
        sql.append(" r.plan_no as planNo, ");
        sql.append(" r.project_no as projectNo, ");
        sql.append(" r.policy_no as policyNo, ");
        sql.append(" r.claim_no as claimNo, ");
        sql.append(" r.remind_outline as remindOutline, ");
        sql.append(" r.remind_content as remindContent, ");
        sql.append(" r.remind_level as remindLevel, ");
        sql.append(" r.remind_type as remindType, ");
        sql.append(" r.is_read as readStatus, ");
        sql.append(" r.is_backlog as backlogStatus, ");
        sql.append(" r.create_time as createTime ");
        sql.append(" FROM base_remind r WHERE");
        sql.append(" r.receive_user_id = ?1 ");
        if (read != null) {
            sql.append(StrUtil.format(" and r.is_read = '{}' ", read));
        }
        if (backlog != null) {
            sql.append(StrUtil.format(" and r.is_backlog = '{}' ", backlog));
        }
        if (remindType != null) {
            sql.append(StrUtil.format(" and r.remind_type = '{}' ", remindType));
        }

        long total = dynamicQuery.nativeQueryCount("select count(1) from (" + sql + ") a",
            user);
        sql.append("order by r.create_time desc limit ?2, ?3");

        List<BaseRemindDto> baseRemindDtoList = dynamicQuery.nativeQueryListModel(BaseRemindDto.class, sql.toString(),
            user, (pageNum - 1) * pageSize, pageSize);

        // 拼接模板消息详细内容
        processRemindMsg(baseRemindDtoList);

        return PageInfo.of(pageNum, pageSize, baseRemindDtoList, total);
    }


    /**
     * @param baseRemindDtoList:
     * @author Sun
     * @description 拼接模板消息详细内容
     * @date 2019/11/5 21:11
     **/
    private void processRemindMsg(List<BaseRemindDto> baseRemindDtoList) {
        List<BaseCodeDto> codeList = baseCodeRepository.findDistinctTypeIdInfoByTypeId(BaseConstant.REMIND_HTTP);

        TemplateEngine engine = TemplateUtil.createEngine(new TemplateConfig());
        for (BaseRemindDto baseRemindDto : baseRemindDtoList) {
            // 从基础代码获取通知模板
            List<BaseCodeDto> contentList = baseCodeRepository.findDistinctTypeIdInfoByTypeId(BaseConstant.REMIND_CONTENT);
            String remindContent = processRemindOutLineCN(baseRemindDto.getRemindContent(), contentList);
            if (StringUtils.isNotBlank(remindContent)) {
                Template template = engine.getTemplate(remindContent);

                Map<String, Object> map = new HashMap<>(16);
                map.put("user", baseRemindDto.getSendUserName());
                map.put("userHttp", processRemindOutLineCN("userHttp", codeList) + baseRemindDto.getSendUserName());

                map.put("policyNo", baseRemindDto.getPolicyNo());
                map.put("outline", baseRemindDto.getRemindOutline());
                // 非车保单
                map.put(BaseConstant.REMIND_HTTP_EI_UN_CAR_POLICY, processRemindOutLineCN(BaseConstant.REMIND_HTTP_EI_UN_CAR_POLICY, codeList) + baseRemindDto.getPolicyNo());
                map.put(BaseConstant.REMIND_HTTP_INS_UN_CAR_POLICY, processRemindOutLineCN(BaseConstant.REMIND_HTTP_INS_UN_CAR_POLICY, codeList) + baseRemindDto.getPolicyNo());
                // 车保单
                map.put(BaseConstant.REMIND_HTTP_EI_CAR_POLICY, processRemindOutLineCN(BaseConstant.REMIND_HTTP_EI_CAR_POLICY, codeList) + baseRemindDto.getPolicyNo());
                map.put(BaseConstant.REMIND_HTTP_INS_CAR_POLICY, processRemindOutLineCN(BaseConstant.REMIND_HTTP_INS_CAR_POLICY, codeList) + baseRemindDto.getPolicyNo());
                // 非车理赔
                map.put(BaseConstant.REMIND_HTTP_EI_UN_CAR_CLAIM, processRemindOutLineCN(BaseConstant.REMIND_HTTP_EI_UN_CAR_CLAIM, codeList) + baseRemindDto.getClaimNo());
                map.put(BaseConstant.REMIND_HTTP_INS_UN_CAR_CLAIM, processRemindOutLineCN(BaseConstant.REMIND_HTTP_INS_UN_CAR_CLAIM, codeList) + baseRemindDto.getClaimNo());
                // 车理赔
                map.put(BaseConstant.REMIND_HTTP_EI_CAR_CLAIM, processRemindOutLineCN(BaseConstant.REMIND_HTTP_EI_CAR_CLAIM, codeList) + baseRemindDto.getClaimNo());
                map.put(BaseConstant.REMIND_HTTP_INS_CAR_CLAIM, processRemindOutLineCN(BaseConstant.REMIND_HTTP_INS_CAR_CLAIM, codeList) + baseRemindDto.getClaimNo());

                // 年度计划
                if (BaseConstant.REMIND_TYPE_PLAN.equals(baseRemindDto.getRemindType())) {
                    map.put("businessId", baseRemindDto.getPlanNo());
                    map.put("taskId", baseRemindDto.getRemindOutline());
                    map.put("outline", null);
                    map.put(BaseConstant.REMIND_HTTP_ANNUAL_PLAN, processRemindOutLineCN(BaseConstant.REMIND_HTTP_ANNUAL_PLAN, codeList));
                }
                // 汇总计划
                if (BaseConstant.REMIND_TYPE_PLAN_GATHER.equals(baseRemindDto.getRemindType())) {
                    map.put("businessId", baseRemindDto.getPlanNo());
                    map.put("taskId", baseRemindDto.getRemindOutline());
                    map.put("outline", null);
                    map.put(BaseConstant.REMIND_HTTP_GATHER_PLAN, processRemindOutLineCN(BaseConstant.REMIND_HTTP_GATHER_PLAN, codeList));
                }
                // 计划外项目
                if (BaseConstant.REMIND_TYPE_PROJECT.equals(baseRemindDto.getRemindType())) {
                    map.put("businessId", baseRemindDto.getProjectNo());
                    map.put("taskId", baseRemindDto.getRemindOutline());
                    map.put("outline", null);
                    map.put(BaseConstant.REMIND_HTTP_UN_PLAN_PROJECT, processRemindOutLineCN(BaseConstant.REMIND_HTTP_UN_PLAN_PROJECT, codeList));
                }

                // 保险公司车批改
                if (BaseConstant.REMIND_INS_ENDORSEMENT_CAR.equals(baseRemindDto.getRemindContent())) {
                    map.put("endoNo", baseRemindDto.getRemindOutline());
                    map.put(BaseConstant.REMIND_HTTP_INS_ENDO_CAR, processRemindOutLineCN(BaseConstant.REMIND_HTTP_INS_ENDO_CAR, codeList));
                }
                // 保险公司非车批改
                if (BaseConstant.REMIND_INS_ENDORSEMENT_UN_CAR.equals(baseRemindDto.getRemindContent())) {
                    map.put("endoNo", baseRemindDto.getRemindOutline());
                    map.put(BaseConstant.REMIND_HTTP_INS_ENDO_UN_CAR, processRemindOutLineCN(BaseConstant.REMIND_HTTP_INS_ENDO_UN_CAR, codeList));
                }
                // 企业车批改
                if (BaseConstant.REMIND_EI_ENDORSEMENT_CAR.equals(baseRemindDto.getRemindContent())) {
                    map.put("endoNo", baseRemindDto.getRemindOutline());
                    map.put(BaseConstant.REMIND_HTTP_EI_ENDO_CAR, processRemindOutLineCN(BaseConstant.REMIND_HTTP_EI_ENDO_CAR, codeList));
                }
                // 企业非车批改
                if (BaseConstant.REMIND_EI_ENDORSEMENT_UN_CAR.equals(baseRemindDto.getRemindContent())) {
                    map.put("endoNo", baseRemindDto.getRemindOutline());
                    map.put(BaseConstant.REMIND_HTTP_EI_ENDO_UN_CAR, processRemindOutLineCN(BaseConstant.REMIND_HTTP_EI_ENDO_UN_CAR, codeList));
                }
                // 车续保完成
                if (BaseConstant.REMIND_EI_RENEW_DOWN_CAR.equals(baseRemindDto.getRemindContent())) {
                    map.put("policyNoNew", baseRemindDto.getRemindOutline());
                    map.put(BaseConstant.REMIND_EI_RENEW_DOWN_CAR, processRemindOutLineCN(BaseConstant.REMIND_EI_RENEW_DOWN_CAR, codeList));
                }
                // 续保提醒
                if (BaseConstant.REMIND_EI_RENEW_CAR.equals(baseRemindDto.getRemindContent())) {
                    map.put("date", baseRemindDto.getRemindOutline());
                    map.put(BaseConstant.REMIND_EI_RENEW_CAR, processRemindOutLineCN(BaseConstant.REMIND_EI_RENEW_CAR, codeList));
                }
                if (BaseConstant.REMIND_INS_RENEW_CAR.equals(baseRemindDto.getRemindContent())) {
                    map.put("date", baseRemindDto.getRemindOutline());
                    map.put(BaseConstant.REMIND_INS_RENEW_CAR, processRemindOutLineCN(BaseConstant.REMIND_INS_RENEW_CAR, codeList));
                }

                // 车、非车，退保，注销
                // 车，保险公司确认车退保
                if (BaseConstant.REMIND_EI_RETURN_CAR.equals(baseRemindDto.getRemindContent())) {
                    map.put("option", baseRemindDto.getRemindOutline());
                    map.put(BaseConstant.REMIND_EI_RETURN_CAR, processRemindOutLineCN(BaseConstant.REMIND_EI_RETURN_CAR, codeList));
                }
                if (BaseConstant.REMIND_EI_RETURN_UN_CAR.equals(baseRemindDto.getRemindContent())) {
                    map.put("option", baseRemindDto.getRemindOutline());
                    map.put(BaseConstant.REMIND_EI_RETURN_UN_CAR, processRemindOutLineCN(BaseConstant.REMIND_EI_RETURN_UN_CAR, codeList));
                }
                if (BaseConstant.REMIND_INS_RETURN_CAR.equals(baseRemindDto.getRemindContent())) {
                    map.put("option", baseRemindDto.getRemindOutline());
                    map.put(BaseConstant.REMIND_INS_RETURN_CAR, processRemindOutLineCN(BaseConstant.REMIND_INS_RETURN_CAR, codeList));
                }
                if (BaseConstant.REMIND_INS_RETURN_UN_CAR.equals(baseRemindDto.getRemindContent())) {
                    map.put("option", baseRemindDto.getRemindOutline());
                    map.put(BaseConstant.REMIND_INS_RETURN_UN_CAR, processRemindOutLineCN(BaseConstant.REMIND_INS_RETURN_UN_CAR, codeList));
                }
                // 企业取消退保，注销，通知保险公司
                if (BaseConstant.REMIND_INS_RETURN_CANCEL_CAR.equals(baseRemindDto.getRemindContent())) {
                    map.put("option", baseRemindDto.getRemindOutline());
                    map.put(BaseConstant.REMIND_INS_RETURN_CANCEL_CAR, processRemindOutLineCN(BaseConstant.REMIND_INS_RETURN_CANCEL_CAR, codeList));
                }
                if (BaseConstant.REMIND_INS_RETURN_CANCEL_UN_CAR.equals(baseRemindDto.getRemindContent())) {
                    map.put("option", baseRemindDto.getRemindOutline());
                    map.put(BaseConstant.REMIND_INS_RETURN_CANCEL_UN_CAR, processRemindOutLineCN(BaseConstant.REMIND_INS_RETURN_CANCEL_UN_CAR, codeList));
                }
                // 车转移
                if (BaseConstant.REMIND_CAR_TRANSFER_APPLY.equals(baseRemindDto.getRemindContent())) {
                    map.put("platNo", baseRemindDto.getPlanNo());
                    map.put("frameNo", baseRemindDto.getPolicyNo());
                    map.put(BaseConstant.REMIND_HTTP_CAR_DETAIL, processRemindOutLineCN(BaseConstant.REMIND_HTTP_CAR_DETAIL, codeList) + baseRemindDto.getPolicyNo());
                }
                if (BaseConstant.REMIND_CAR_TRANSFER_CONFIRM.equals(baseRemindDto.getRemindContent())) {
                    map.put("platNo", baseRemindDto.getPlanNo());
                    map.put("frameNo", baseRemindDto.getPolicyNo());
                    map.put("agree", baseRemindDto.getRemindOutline());
                    map.put(BaseConstant.REMIND_HTTP_CAR_DETAIL, processRemindOutLineCN(BaseConstant.REMIND_HTTP_CAR_DETAIL, codeList) + baseRemindDto.getPolicyNo());
                }
                if (BaseConstant.REMIND_CAR_TRANSFER_APPLY_CANCEL.equals(baseRemindDto.getRemindContent())) {
                    map.put("platNo", baseRemindDto.getPlanNo());
                    map.put("frameNo", baseRemindDto.getPolicyNo());
                    map.put(BaseConstant.REMIND_HTTP_CAR_DETAIL, processRemindOutLineCN(BaseConstant.REMIND_HTTP_CAR_DETAIL, codeList) + baseRemindDto.getPolicyNo());
                }

                baseRemindDto.setRemindMsg(template.render(map));
                //map.put(BaseConstant.REMIND_CAR_TRANSFER_CONFIRM, processRemindOutLineCN(BaseConstant.REMIND_CAR_TRANSFER_CONFIRM, codeList));
                //map.put(BaseConstant.REMIND_CAR_TRANSFER_APPLY_CANCEL, processRemindOutLineCN(BaseConstant.REMIND_CAR_TRANSFER_APPLY_CANCEL, codeList));
                //map.put(BaseConstant.REMIND_CAR_TRANSFER_APPLY, processRemindOutLineCN(BaseConstant.REMIND_CAR_TRANSFER_APPLY, codeList)+baseRemindDto.getPolicyNo());

            }
        }
    }


}
