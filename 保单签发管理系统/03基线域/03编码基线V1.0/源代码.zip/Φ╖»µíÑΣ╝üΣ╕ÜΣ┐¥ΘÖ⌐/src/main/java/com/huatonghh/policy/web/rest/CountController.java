package com.huatonghh.policy.web.rest;

import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.policy.service.CountService;
import com.huatonghh.policy.service.dto.count.*;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * description:统计
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/11
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/api/count/v1")
@Api(tags = "31、统计", value = "统计")
public class CountController {

    private final CountService countService;

    @PostMapping(value = "kind")
    @ApiOperation(value = "险种保费占比", httpMethod = "POST")
    @Timed
    public ApiResponse<List<CountKindCodeDTO>> countKind(@Valid @RequestBody CountKindCodeRequest request) {
        return ApiResponse.ofSuccess(countService.findKindCode(request));
    }

    @PostMapping(value = "insurer")
    @ApiOperation(value = "保险公司保费统计", httpMethod = "POST")
    @Timed
    public ApiResponse countInsurer(@Valid @RequestBody CountKindCodeRequest request) {
        return ApiResponse.ofSuccess(countService.findBelong(request));
    }

    @PostMapping(value = "eng")
    @ApiOperation(value = "工程险项目保费统计", httpMethod = "POST")
    @Timed
    public ApiResponse<List<CountEngDTO>> countEng(@Valid @RequestBody CountKindCodeRequest request) {
        return ApiResponse.ofSuccess(countService.findEng(request));
    }

    @PostMapping(value = "insurer_kind")
    @ApiOperation(value = "保险公司险种保费统计", httpMethod = "POST")
    @Timed
    public ApiResponse findCountInsurer(@Valid @RequestBody CountKindCodeRequest request) {
//        List<Map<String, String>> countInsurerVO = countService.findInsurerKind(request);
//        for (Map<String, String> map:countInsurerVO) {
//            Set<Map.Entry<String, String>> entrys = map.entrySet();  //此行可省略，直接将map.entrySet()写在for-each循环的条件中
//            for(Map.Entry<String, String> entry:entrys){
//                if((!(entry.getKey().equals("belongCompany")))&&entry.getValue().equals("0")){
//                    log.info("key值："+entry.getKey()+" value值："+entry.getValue());
//                }
//            }
//
//        }

        return ApiResponse.ofSuccess(countService.findInsurerKind(request));
    }
}
