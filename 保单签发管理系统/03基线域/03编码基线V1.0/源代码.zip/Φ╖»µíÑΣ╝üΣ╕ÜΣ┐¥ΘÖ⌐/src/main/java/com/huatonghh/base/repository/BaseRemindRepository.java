package com.huatonghh.base.repository;

import com.huatonghh.base.domain.BaseRemind;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author : Sun
 * @description : 通知中心-数据仓库
 * @date : 2019/11/5 20:56
 * @version : 1.0
 */
public interface BaseRemindRepository extends JpaRepository<BaseRemind, Integer> {

}
