package com.huatonghh.empower.service;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author ghy
 * Date: 2021/1/6 17:36
 */
@Data
@ApiModel("授权列表查询条件")
public class EmpowerQuery {

    @ApiModelProperty("项目编号")
    private String projNo;

    @ApiModelProperty("发起公司id")
    private String startCompany;

    @ApiModelProperty("险种代码")
    private String riskKind;

    @ApiModelProperty("合同工期")
    private Integer duration;
}
