package com.huatonghh.ins_authority.domain;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;


/**
 * @author : Sun
 * @description : 交投集团-用户角色中间表-数据库映射实体
 * @date : 2019/11/4 19:42
 * @version : 1.0
 */
@Entity
@Table(name = "ei_ins_user_role")
@Data
public class InsRoleUser
    implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "user_id")
    private String userId;


    @Column(name = "role_id")
    private Integer roleId;

}
