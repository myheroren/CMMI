package com.huatonghh.policy.constant;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/22
 */
public class PolicyConstant {
    /**
     * 分期类型
     * 1分期 2见费出单
     */
    public static final Byte PAYMENT_TYPE_STAGES = 1;
    public static final Byte PAYMENT_TYPE_FEE = 2;
    /**
     * 1车、0非车
     */
    public static final Byte POLICY_CAR = 1;
    public static final Byte POLICY_CAR_UN = 0;
    /**
     * 1交强，2商业，3货运
     */
    public static final String KIND_JQ = "1";
    public static final String KIND_SY = "2";
    public static final String KIND_HW = "3";

    /**
     * 1退保，2注销
     */
    public static final Byte POLICY_RETURN = 1;
    public static final Byte POLICY_CANCEL = 2;

    /**
     * 保单状态
     * 0未生效，1生效,2过期
     * -2注销，-22注销申请
     * -1退保，-11退保申请
     */
    public static final Byte POLICY_STATUS_CANCEL_BEFORE = -22;
    public static final Byte POLICY_STATUS_CANCEL = -2;
    public static final Byte POLICY_STATUS_RETURN_BEFORE = -11;
    public static final Byte POLICY_STATUS_RETURN = -1;
    public static final Byte POLICY_STATUS_VALID_BEFORE = 0;
    public static final Byte POLICY_STATUS_VALID = 1;
    public static final Byte POLICY_STATUS_OVERDUE = 2;


    /**
     * 续保状态
     */
    public static final Byte POLICY_RENEW_STATUS_RENEWED = 1;
    public static final Byte POLICY_RENEW_STATUS_NOT_RENEWED = 0;
}
