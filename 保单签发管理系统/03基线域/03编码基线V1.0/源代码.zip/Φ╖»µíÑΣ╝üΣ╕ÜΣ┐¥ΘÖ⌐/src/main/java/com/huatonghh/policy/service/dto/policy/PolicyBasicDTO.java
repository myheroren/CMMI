package com.huatonghh.policy.service.dto.policy;


import lombok.Data;

import java.math.BigInteger;
import java.util.Date;

/**
 * @author : wh
 * description : 保单基础信息
 * @version : 1.0
 * @date : 2020/5/18 16:00
 */
@Data
public class PolicyBasicDTO {

    private BigInteger id;

    private String policyNo;

    /**
     * 1车，0非车
     */
    private Byte carUncarFlag;

    /**
     * 保险类别
     */
    private String insuranceCategory;

    /**
     * 险种代码；例:车（交强、商业）,非车待定
     */
    private String kindCode;
    /**
     * 投保人
     */
    private String holderName;

    /**
     * 被保险人
     */
    private String insuredName;
    /**
     * 中标项目
     */
    private BigInteger projectNo;
    /**
     * 发起公司
     */
    private String startCompany;
    /**
     * 归属保险公司
     */
    private String belongCompany;
    /**
     * 归属保险公司
     */
    private String belongCompanyName;
    /**
     * 含税保费
     */
    private BigInteger totalPremium;
    /**
     * 不含税保费
     */
    private BigInteger freeTaxPremium;
    /**
     * 保费到账日期
     */
    private Date premiumArrivalTime;
    /**
     * 保费应收日期
     */
    private Date premiumReceivableTime;
    /**
     * 投保日期
     */
    private Date policyApplyTime;
    private Date policyBgnTime;
    private Date policyEndTime;
    private Date createTime;
    private Date updateTime;
    /**
     * 保险公司联系人
     */
    private String belongCompanyPerson;
    /**
     * 保险公司联系电话
     */
    private String belongCompanyPhone;

    private Byte status;

    /**
     * 是否提醒
     */
    private Boolean remindDisplay;

    private Boolean remindStatus;

    /**
     * 投标日期，精确到天
     */
    private Date bidDate;

    /**
     * 基本项目id，所有项目都会有
     */
    private Integer proId;
    /**
     * 基本项目名称
     */
    private String proName;
    /**
     * 基本项目简称
     */
    private String proAlias;
    /**
     * 基本项目联系人
     */
    private String proContact;
    private String proTel;
    private String bidTel;
    private String bidContact;
    /**
     * 手续费
     */
    private BigInteger handlingFee;
    /**
     * 收入手续费
     */
    private BigInteger handlingFeeIncome;
    /**
     * 入账手续费
     */
    private BigInteger handlingFeeEntryAccount;
    /**
     * 手续费比例
     */
    private String feeProp;
    /**
     * 手续费应收日期
     */
    private Date handlingFeeReceivableTime;
    /**
     * 手续费转账日期
     */
    private Date handlingFeeArrivalTime;
}
