package com.huatonghh.policy.constant;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/11
 */
public class ClaimConstant {
    /**
     * 理赔状态，0报案,1立案，2定损，3核损，4理算，5结案，6支付,7销案
     */
//    public static final Byte CLAIM_STATUS_REPORT = 0;
//    public static final Byte CLAIM_STATUS_REGISTER = 1;
//    public static final Byte CLAIM_STATUS_FIXED_LOSS = 2;
//    public static final Byte CLAIM_STATUS_CHECK_LOSS = 3;
//    public static final Byte CLAIM_STATUS_CLAIM = 4;
//    public static final Byte CLAIM_STATUS_DOWN = 5;
//    public static final Byte CLAIM_STATUS_PAY = 6;
//    public static final Byte CLAIM_STATUS_DESTORY = 7;

    /**
     * 取值为数字：
     * 已报案       1
     * 已查勘       2
     * 已提交资料    3
     * 已审核       4
     * 已确认赔款    5
     * 已结案       6
     * 已支付       7
     * 已销案       8
     */
    public static final Byte CLAIM_STATUS_REPORT = 1;
    public static final Byte CLAIM_STATUS_FIXED_LOSS = 2;
    public static final Byte CLAIM_STATUS_REGISTER = 3;
    public static final Byte CLAIM_STATUS_CLAIM = 4;
    public static final Byte CLAIM_STATUS_CHECK_LOSS = 5;
    public static final Byte CLAIM_STATUS_DOWN = 6;
    public static final Byte CLAIM_STATUS_PAY = 7;
    public static final Byte CLAIM_STATUS_DESTORY = 8;

    //结案、支付信息查询接口默认传：CGXCIG01
    public static final String CLAIM_PROC_UNIT = "CGXCIG01";
}
