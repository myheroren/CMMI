package com.huatonghh.policy.service.dto.task;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/14
 */
@Data
@ApiModel("处理人")
public class HandlerDTO {
    @ApiModelProperty("操作人id")
    private String operator;
    @ApiModelProperty("操作人账号")
    private String operatorAccount;
    @ApiModelProperty("操作人中文名称")
    private String operatorName;
}
