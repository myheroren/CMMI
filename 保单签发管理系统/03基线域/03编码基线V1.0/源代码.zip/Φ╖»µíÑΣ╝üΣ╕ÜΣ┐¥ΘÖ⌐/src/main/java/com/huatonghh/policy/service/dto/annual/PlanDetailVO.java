package com.huatonghh.policy.service.dto.annual;

import com.huatonghh.file.service.dto.FiAuditFileDto;
import com.huatonghh.policy.service.dto.project.ProjectDTO;
import com.huatonghh.policy.service.dto.task.CheckDTO;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.List;

/**
 * @author : hao.wang
 * @date : 2019/8/27
 * description:
 */
@Data
@ApiModel("保险计划详情")
public class PlanDetailVO {
    private PlanBasicDTO basicInfo;
    private List<ProjectDTO> projects;
    private List<FiAuditFileDto> files;
    private List<CheckDTO> checks;

}
