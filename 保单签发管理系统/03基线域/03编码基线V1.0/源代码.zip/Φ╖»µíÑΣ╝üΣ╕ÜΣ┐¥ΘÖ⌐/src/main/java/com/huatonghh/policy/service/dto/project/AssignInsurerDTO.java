package com.huatonghh.policy.service.dto.project;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/9
 */
@Data
@ApiModel("分配")
public class AssignInsurerDTO {
    @ApiModelProperty("项目编号")
    @NotNull(message = "项目编号不能为空")
    private List<String> projNos;
    @ApiModelProperty("归属保险公司")
    @NotBlank(message = "归属保险公司不能为空")
    private String belongCompany;

    private ProjectPreDTO projectPreInfo;
}
