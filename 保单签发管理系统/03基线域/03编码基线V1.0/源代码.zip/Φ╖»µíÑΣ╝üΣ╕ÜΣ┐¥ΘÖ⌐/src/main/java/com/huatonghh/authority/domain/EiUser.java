package com.huatonghh.authority.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.huatonghh.authority.domain.EiRole;
import lombok.Data;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.*;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * @author : Sun
 * @description : 交投集团-用户-数据库映射实体
 * @date : 2019/11/4 19:42
 * @version : 1.0
 */
@Entity
@Table(name = "ei_user")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Data
@DynamicInsert
@DynamicUpdate
public class EiUser implements Serializable {

    private static final long serialVersionUID = -597649964085048405L;

    @Id
    private String id;

    @Column(name = "account_id")
    private String userName;

    @Column(name = "account_password")
    private String userPassword;

    @Column(name = "employee_no")
    private String employeeNo;

    @Column(name = "employee_name")
    private String name;

    @Column(name = "post")
    private Byte post;

    @Column(name = "position")
    private Byte position;

    @Column(name = "gender")
    private Boolean gender;

    @Column(name = "id_card")
    private String idCard;

    @Column(name = "phone_no")
    private String phoneNo;

    @Column(name = "email")
    private String email;

    @Column(name = "remark")
    private String remark;

    @Column(name = "is_valid")
    private Boolean valid;

    @Column(name = "is_auth")
    private Boolean auth;

    @Column(name = "open_id")
    private String openId;

    @JsonIgnore
    @ManyToMany(fetch =FetchType.EAGER)
    @JoinTable(
        name = "ei_user_role",
        joinColumns = {@JoinColumn(name = "user_id", referencedColumnName = "id")},
        inverseJoinColumns = {@JoinColumn(name = "role_id", referencedColumnName = "role_id")})
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @BatchSize(size = 40)
    private Set<EiRole> authorities = new HashSet<>();

}
