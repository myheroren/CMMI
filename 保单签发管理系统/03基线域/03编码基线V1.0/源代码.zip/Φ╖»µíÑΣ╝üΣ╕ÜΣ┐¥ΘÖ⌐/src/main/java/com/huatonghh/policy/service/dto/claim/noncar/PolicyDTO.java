package com.huatonghh.policy.service.dto.claim.noncar;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * description:保单信息
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/11
 */
@Data
@ApiModel("保单信息")
public class PolicyDTO {
    @ApiModelProperty(value = "保单号")
    private String policyNo;
    @ApiModelProperty(value = "车或非车标识：1车、0非车，必传")
    private Byte carUncarFlag;
    @ApiModelProperty(value = "保险类别")
    private String insuranceCategory;
    @ApiModelProperty(value = "险种代码；例:车（交强、商业）,非车待定")
    private String kindCode;
    @ApiModelProperty(value = "投保人")
    private String holderName;
    @ApiModelProperty(value = "被保险人")
    private String insuredName;
    @ApiModelProperty(value = "有效起期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyBgnTime;
    @ApiModelProperty(value = "有效止期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyEndTime;

    @ApiModelProperty(value = "车牌")
    private String plateNo;
    @ApiModelProperty(value = "车架")
    private String frameNo;
    @ApiModelProperty(value = "厂牌类型")
    private String vehicleModel;
    @ApiModelProperty(value = "投保产品")
    private String mainRiskDuty;
    @ApiModelProperty(value = "项目名称")
    private String proName;
    @ApiModelProperty("被保人证件类型")
    @JsonProperty("c_cert_type_code")
    private String insuredCertificateType;
    //    @NotNull
    @JsonProperty("c_certf_cde")
    @ApiModelProperty("被保人证件号码")
    private String insuredCertificateNumber;

}
