package com.huatonghh.file.web.rest;

import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.file.service.AuditFileService;
import com.huatonghh.file.service.FastDFSUpAndDowService;
import com.huatonghh.file.service.dto.FiAuditFileDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;

/**
 * @author : Sun
 * @version : 1.0
 * @description : 文件上传
 * @date : 2019/11/5 21:30
 */
@RestController
@RequestMapping("/api/file/v1")
@AllArgsConstructor
@Api(tags = "22、文件上传", value = "文件上传")
public class FileController {

    private final AuditFileService auditFileService;

    private final FastDFSUpAndDowService fastDFSUpAndDowService;

    @Transactional(rollbackFor = RuntimeException.class)
    @PostMapping(value = "/upload")
    @ApiOperation(value = "上传文件信息", notes = "上传文件信息", httpMethod = "POST")
    public ApiResponse uploadAngel(@RequestBody @Valid FiAuditFileDto fiAuditFileDto) {
        return ApiResponse.ofSuccess(auditFileService.saveAuditFile(fiAuditFileDto));
    }


    /**
     * @param fiAuditFileDtos:
     * @return com.huatonghh.common.util.system.ApiResponse
     * @author Sun
     * @description 批量文件信息，未完成TODO
     * @date 2019/11/5 21:30
     **/
    @Transactional(rollbackFor = RuntimeException.class)
    @PostMapping(value = "/batch_upload")
    @ApiOperation(value = "批量上传文件信息，会更新原有文件信息", notes = "上传文件信息", httpMethod = "POST")
    public ApiResponse batchUploadFileDetail(@RequestBody @Valid List<FiAuditFileDto> fiAuditFileDtos) {
        return ApiResponse.ofSuccess(auditFileService.batchUploadFileDetail(fiAuditFileDtos));
    }


    /**
     * @param file:
     * @return com.huatonghh.common.util.system.ApiResponse
     * @author Sun
     * @description 上传文件
     * @date 2019/11/5 21:30
     **/
    @PostMapping("/upload_file")
    @ApiOperation(value = "上传文件", notes = "上传文件", httpMethod = "POST")
    public ApiResponse uploadAngel(@RequestParam("file") MultipartFile file) {
        // dfsClient.uploadFile()这种方法也可以
        return ApiResponse.ofSuccess(fastDFSUpAndDowService.uploadFile(file));
    }


    @GetMapping("/download/{fileId}")
    @ApiOperation(value = "下载", notes = "下载", httpMethod = "GET")
    public void download(@PathVariable Integer fileId, HttpServletResponse response) {
        fastDFSUpAndDowService.downloadFile(fileId, response);
    }

    @GetMapping("/mobile/download/{fileId}")
    @ApiOperation(value = "下载", notes = "下载", httpMethod = "GET")
    public void mobileDownload(@PathVariable Integer fileId, HttpServletResponse response) {
        fastDFSUpAndDowService.downloadFile(fileId, response);
    }

    @Transactional(rollbackFor = RuntimeException.class)
    @DeleteMapping(value = "/delete/{fileId}")
    @ApiOperation(value = "删除文件", notes = "删除文件", httpMethod = "DELETE")
    public ApiResponse delete(@PathVariable Integer fileId) {
        auditFileService.deleteFile(fileId);
        return ApiResponse.ofSuccess(null);
    }


    @GetMapping("/preview/{preview}/{fileId}")
    @ApiOperation(value = "预览文件", notes = "预览文件", httpMethod = "GET")
    public ApiResponse previewFile(@PathVariable Byte preview, @PathVariable Integer fileId) {
        return ApiResponse.ofSuccess(auditFileService.previewFile(preview, fileId));
    }

}
