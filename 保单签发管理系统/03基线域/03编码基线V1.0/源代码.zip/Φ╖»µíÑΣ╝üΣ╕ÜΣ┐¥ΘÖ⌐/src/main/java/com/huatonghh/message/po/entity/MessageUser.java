package com.huatonghh.message.po.entity;


import com.google.common.base.MoreObjects;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 消息用户表(MessageUser)实体类
 *
 * @author wanggl
 * @since 2020-11-02 20:09:22
 */
@ApiModel("消息用户表实体类")
@Entity
@Table(name = "message_user")
public class MessageUser implements Serializable {

    private static final long serialVersionUID = -63450867059498348L;

    @ApiModelProperty(value = "自增id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ApiModelProperty(value = "消息id")
    private Long messageId;

    @ApiModelProperty(value = "用户编号")
    private String userCode;

    @ApiModelProperty(value = "已读（0==未读，1==已读）")
    @Column(name = "is_read")
    private Byte read;

    @ApiModelProperty(value = "已读时间")
    private LocalDateTime readTime;

    public MessageUser() {
    }

    public MessageUser(Long id, Long messageId, String userCode, Byte read, LocalDateTime readTime) {
        this.id = id;
        this.messageId = messageId;
        this.userCode = userCode;
        this.read = read;
        this.readTime = readTime;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMessageId() {
        return messageId;
    }

    public void setMessageId(Long messageId) {
        this.messageId = messageId;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public Byte getRead() {
        return read;
    }

    public void setRead(Byte read) {
        this.read = read;
    }

    public LocalDateTime getReadTime() {
        return readTime;
    }

    public void setReadTime(LocalDateTime readTime) {
        this.readTime = readTime;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
            .add("id", id)
            .add("messageId", messageId)
            .add("userCode", userCode)
            .add("read", read)
            .add("readTime", readTime)
            .toString();
    }
}
