package com.huatonghh.ins_authority.repository;

import com.huatonghh.common.service.dto.ResponseIntegerKeyValueDto;
import com.huatonghh.ins_authority.domain.EiInsDepart;
import com.huatonghh.ins_authority.domain.EiInsDepartBase;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * @author : Sun
 * @description : 保险公司部门-数据仓库
 * @date : 2019/11/5 21:31
 * @version : 1.0
 */
@Repository
public interface EiInsDepartBaseRepository extends JpaRepository<EiInsDepartBase, Integer> {

    /**
     * 根据部门名称，查询部门详细信息
     *
     * @author Sun
     * @date 2019/11/5 21:31
     * @param name:
     * @return java.util.Optional<com.huatonghh.ins_authority.domain.EiInsDepart>
     **/
    Optional<EiInsDepart> findOneByName(String name);


    /**
     * 查询二叉树列表时，无需查部门下员工数据
     *
     * @author Sun
     * @date 2019/11/5 21:32
     * @return java.util.List<com.huatonghh.ins_authority.domain.EiInsDepart>
     **/
    @Override
    List<EiInsDepartBase> findAll();


    /**
     * 根据部门id，查询所有子部门列表
     *
     * @author Sun
     * @date 2019/11/5 21:32
     * @param id:
     * @return java.util.List<com.huatonghh.ins_authority.domain.EiInsDepart>
     **/
    @EntityGraph(attributePaths = "authorities")
    @Query(value = "select d1 from EiInsDepart d1, EiInsDepart d2 WHERE d1.ids LIKE CONCAT(d2.ids, '%') and d2.id = :id")
    List<EiInsDepartBase> findParentDepartById(@Param("id") Integer id);


    /**
     * 查询某个用户所属部门信息
     *
     * @author Sun
     * @date 2019/11/5 21:32
     * @param id:
     * @return java.util.Set<com.huatonghh.ins_authority.domain.EiInsDepart>
     **/
    @Query(nativeQuery = true, value = "SELECT d.* FROM ei_ins_depart_user du, ei_ins_depart d WHERE du.depart_id = d.id AND du.user_id = ?1")
    Set<EiInsDepartBase> findDepartByUserId(Integer id);


    /**
     * 根据部门id，查询所有子部门列表
     *
     * @author Sun
     * @date 2019/11/5 21:32
     * @param id:
     * @return java.util.Set<com.huatonghh.ins_authority.domain.EiInsDepart>
     **/
    @Query(nativeQuery = true, value = "select e.* from ei_ins_depart e where parent_id = ?1")
    Set<EiInsDepartBase> findSubDepartById(Integer id);


    /**
     * 删除当前部门，及其所有子部门
     *
     * @author Sun
     * @date 2019/11/5 21:32
     * @param id:
     **/
    @Modifying
    @Query(nativeQuery = true, value = "DELETE FROM ei_ins_depart WHERE ids LIKE CONCAT(:id ,'%')")
    void deleteDepart(@Param("id") String id);


    /**
     * 先删除部门员工中间表，才可以删除部门表
     *
     * @author Sun
     * @date 2019/11/5 21:32
     * @param id:
     **/
    @Modifying
    @Query(nativeQuery = true, value = "DELETE du FROM ei_ins_depart d, ei_ins_depart_user du WHERE d.ids LIKE CONCAT(:id ,'%') and d.id = du.depart_id")
    void deleteDepartUser(@Param("id") String id);


    /**
     * 根据保险公司部门id，获取部门id、名称key value数据集
     *
     * @author Sun
     * @date 2019/11/6 15:51
     * @param id: 部门id
     * @return java.util.List<com.huatonghh.common.service.dto.ResponseIntegerKeyValueDto>
     **/
    @Query(value = "SELECT DISTINCT new com.huatonghh.common.service.dto.ResponseIntegerKeyValueDto( d.id, d.name ) FROM EiInsDepart d WHERE d.id = :id")
    List<ResponseIntegerKeyValueDto> queryNameById(@Param("id") Integer id);

}
