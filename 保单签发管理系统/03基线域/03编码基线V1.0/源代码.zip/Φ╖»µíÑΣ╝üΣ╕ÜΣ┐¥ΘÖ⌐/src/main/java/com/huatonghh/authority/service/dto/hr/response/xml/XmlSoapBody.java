package com.huatonghh.authority.service.dto.hr.response.xml;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import lombok.Data;


/**
 * @author : Sun
 * @description : <soap:Body></soap:Body>
 * @date : 2019/11/4 21:08
 * @version : 1.0
 */
@Data
@XStreamAlias("soap:Body")
public class XmlSoapBody {

    @XStreamAlias("ns2:selectAllResponse")
    private XmlNsSelectAllResponse xmlNsSelectAllResponse;

}
