package com.huatonghh.policy.service.dto.count;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJson2Serializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * description:保险公司维度统计结果
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/11
 */
@Data
@ApiModel("保险公司维度统计结果")
public class CountInsurerDTO {
    @ApiModelProperty("保险公司")
    private String belongCompany;
    @ApiModelProperty("保费")
    @JsonSerialize(using = AmountJson2Serializer.class)
    private BigDecimal totalPremium;
    @ApiModelProperty("日期 yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date createTime;
}
