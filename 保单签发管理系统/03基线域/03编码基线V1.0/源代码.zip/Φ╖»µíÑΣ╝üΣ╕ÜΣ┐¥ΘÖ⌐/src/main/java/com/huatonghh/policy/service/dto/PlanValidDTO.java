package com.huatonghh.policy.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author ghy
 * Date: 2020/11/6 14:13
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel("计划详情操作权限DTO")
public class PlanValidDTO {

    @ApiModelProperty("是否待办")
    private Byte isToDo;

    @ApiModelProperty("计划状态")
    private Byte status;

    @ApiModelProperty("计划的发起公司")
    private String startCompany;

    @ApiModelProperty("当前登录人所属公司")
    private String curCompany;

    @ApiModelProperty("流程图中的节点操作人")
    private String operator;
}
