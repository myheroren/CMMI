package com.huatonghh.authority.domain;

import java.io.Serializable;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/30
 */
public class EiRoleUserKey implements Serializable {
    private String userId;
    private Integer roleId;
    private String companyId;
}
