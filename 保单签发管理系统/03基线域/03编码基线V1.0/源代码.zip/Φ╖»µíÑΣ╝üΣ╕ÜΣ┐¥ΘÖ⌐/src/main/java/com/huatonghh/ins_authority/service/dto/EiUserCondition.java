package com.huatonghh.ins_authority.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author : Sun
 * @description : 用户分页查询条件
 * @date : 2019/11/4 21:11
 * @version : 1.0
 */
@Data
@ApiModel(value = "用户分页查询条件")
public class EiUserCondition implements Serializable {

    private static final long serialVersionUID = 3363453658737979524L;

    @ApiModelProperty(value = "用户ID")
    private String id;

    @ApiModelProperty(value = "账户")
    private String userName;

    @ApiModelProperty(value = "密码")
    private String userPassword;

    /**
     * 页码
     */
    @ApiModelProperty(value = "页码", example = "1")
    @NotNull(message = "分页页码不能为空")
    private Integer pageNum;

    /**
     * 条目数
     */
    @ApiModelProperty(value = "条目数", example = "10")
    @NotNull(message = "分页条目数不能为空")
    private Integer pageSize;


}
