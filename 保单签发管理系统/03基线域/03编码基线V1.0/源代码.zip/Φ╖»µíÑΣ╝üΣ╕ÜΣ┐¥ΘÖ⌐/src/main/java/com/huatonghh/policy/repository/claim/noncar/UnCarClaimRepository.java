package com.huatonghh.policy.repository.claim.noncar;


import com.huatonghh.policy.domain.claim.noncar.ClaimInfo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigInteger;
import java.util.List;

/**
 * @author :  hao.wang
 * @date : 2019/8/23
 * description :
 */
public interface UnCarClaimRepository extends JpaRepository<ClaimInfo, String> {


    /**
     * 根据保单号查询
     *
     * @param policyNo
     * @return
     */
    List<ClaimInfo> findAllByPolicyNoOrderByCreateTimeDesc(String policyNo);


    /**
     * 根据保单号和赔付次数查询
     * @param policyNo 保单号
     * @param caseTimes 赔案次数
     * @return 理赔列表
     */
    ClaimInfo findByReportNoAndPolicyNoAndCaseTimes(String reportNo, String policyNo, String caseTimes);


    /**
     * 根据保单号和赔付次数查询
     * @param policyNo 保单号
     * @param reportNo 报案号
     * @return 理赔列表
     */
    ClaimInfo findByReportNoAndPolicyNo(String reportNo, String policyNo);

    /**
     * 根据保单号查询报案信息
     * @param policyNo
     * @return
     */
    List<ClaimInfo> findAllByPolicyNoAndReportNoIsNotNullAndRelated(String policyNo, Byte related);

    /**
     * 根据报案号查询
     * @return
     */
    ClaimInfo findByReportNo(String reportNo);
}
