package com.huatonghh.policy.service;

import com.huatonghh.policy.domain.policy.PolicyPayPeriod;
import com.huatonghh.policy.repository.policy.PolicyPayPeriodRepository;
import com.huatonghh.policy.service.dto.policy.PolicyPayPeriodDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/22
 */
@Slf4j
@Service
@AllArgsConstructor
public class PolicyPayPeriodService {
    private final PolicyPayPeriodRepository payPeriodRepository;
    private final ModelMapper modelMapper;

    public void save(List<PolicyPayPeriodDTO> payPeriodInfos) {
        if (null == payPeriodInfos || payPeriodInfos.isEmpty()) {
            return;
        }
        List<PolicyPayPeriod> list = payPeriodInfos.stream().map(dto -> modelMapper.map(dto, PolicyPayPeriod.class)).collect(Collectors.toList());
        payPeriodRepository.saveAll(list);
    }

    public List<PolicyPayPeriodDTO> findAllByPolicyNo(String policyNo) {
        List<PolicyPayPeriod> list = payPeriodRepository.findAllByPolicyNo(policyNo);
        if (null == list || list.isEmpty()) {
            return null;
        }
        return list.stream().map(entity -> modelMapper.map(entity, PolicyPayPeriodDTO.class)).collect(Collectors.toList());
    }

}
