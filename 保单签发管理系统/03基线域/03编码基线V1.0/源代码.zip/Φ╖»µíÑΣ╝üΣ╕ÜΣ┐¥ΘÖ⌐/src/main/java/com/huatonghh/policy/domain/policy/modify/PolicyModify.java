package com.huatonghh.policy.domain.policy.modify;

import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Data;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import java.math.BigInteger;

/**
 * 保单-批改(PolicyModify)表实体类
 *
 * @author 居炎明
 * @since 2019-10-16 19:49:08
 */
@Entity
@Table(name = "policy_modify")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Api(description = "保单-批改")
public class PolicyModify implements Serializable {

        private static final long serialVersionUID=422829963954393044L;
        @ApiModelProperty(value = "主键")
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "modify_id",nullable = false,unique = true)
        private BigInteger modifyId;


        @ApiModelProperty(value = "保单号")
        @Column(name = "policy_No")
        private String policyNo;

        @ApiModelProperty(value = "批单号")
        @Column(name = "modify_no")
        private String modifyNo;

        @ApiModelProperty(value = "保单Id")
        @Column(name = "policy_id")
        private BigInteger policyId;

        @ApiModelProperty(value = "发起时间")
        @Column(name = "create_time")
        private Date createTime;

        @ApiModelProperty(value = "批改说明")
        @Column(name = "remark")
        private String remark;

        @ApiModelProperty(value = "备注")
        @Column(name = "remark1")
        private String remark1;

        @ApiModelProperty(value = "批改救过状态：0。 驳回 1.通过")
        @Column(name = "modify_status")
        private Byte modifyStatus;

        @ApiModelProperty(value = "操作人")
        @Column(name = "operator")
        private String operator;

        @ApiModelProperty(value = "操作人")
        @Column(name = "start_reason")
        private String startReason;

        @ApiModelProperty(value = "批改时间")
        @Column(name = "end_time")
        private Date endTime;

        @ApiModelProperty(value = "批改项目编号")
        @Column(name = "modify_project_no")
        private String modifyProjectNo;

}
