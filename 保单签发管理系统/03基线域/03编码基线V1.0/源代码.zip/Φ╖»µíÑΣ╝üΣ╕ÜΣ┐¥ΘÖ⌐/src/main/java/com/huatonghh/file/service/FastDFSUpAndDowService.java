package com.huatonghh.file.service;

import com.huatonghh.common.constant.enums.StatusEnum;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.file.config.FastDFSClientWrapper;
import com.huatonghh.file.domain.FiFile;
import com.huatonghh.file.repository.FiFileRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.URLEncoder;
import java.util.Optional;

/**
 * @author : Sun
 * @version : 1.0
 * @description : 上传文件业务层
 * @date : 2019/11/5 21:29
 */
@Service
@Slf4j
public class FastDFSUpAndDowService {

    private final FastDFSClientWrapper fastDFSClientWrapper;

    private final FiFileRepository fiFileRepository;

    public FastDFSUpAndDowService(FastDFSClientWrapper fastDFSClientWrapper, FiFileRepository fiFileRepository) {
        this.fastDFSClientWrapper = fastDFSClientWrapper;
        this.fiFileRepository = fiFileRepository;
    }

    /**
     * @param file: 页面提交时文件
     * @return java.lang.Integer
     * @author Sun
     * @description 文件上传，最后返回fastDFS中的文件名称;group1/M00/01/04/CgMKrVvS0geAQ0pzAACAAJxmBeM793.doc
     * @date 2019/11/5 21:29
     **/
    public Integer uploadFile(MultipartFile file) {
        byte[] bytes = new byte[0];
        try {
            bytes = file.getBytes();
        } catch (IOException e) {
            log.error("获取文件错误");
            e.printStackTrace();
        }
        // 获取源文件名称
        String originalFileName = file.getOriginalFilename();
        // 获取文件后缀--.doc
        String extension = FilenameUtils.getExtension(originalFileName);
        // 获取文件名字
        String fileName = file.getName();
        // 获取文件大小
        long fileSize = file.getSize();

        log.info(originalFileName + "=" + fileName + "=" + fileSize + "=" + extension + "=" + bytes.length);
        // 上传、并返回文件存储的位置
        String fileUrl = fastDFSClientWrapper.uploadFile(bytes, fileSize, extension);

        // 将url对应Integer Id，为了下载便捷和信息不泄露
        FiFile fiFile = new FiFile();
        fiFile.setFileOriginalName(originalFileName);
        fiFile.setFileUrl(fileUrl);
        fiFile.setFileSize(BigInteger.valueOf(fileSize));
        fiFile = fiFileRepository.save(fiFile);
        return fiFile.getFileId();
    }


    /**
     * @param fileId:   当前对象文件存储路径名称，例："group1/M00/00/00/rBUACl1o85-AERjWAADqHVBL0vQ48.xlsx";
     * @param response: HttpServletResponse 内置对象
     * @author Sun
     * @description 文件下载
     * @date 2019/11/5 21:29
     **/
    public void downloadFile(Integer fileId, HttpServletResponse response) {
        Optional<FiFile> fiFileOptional = fiFileRepository.findById(fileId);
        // 获取文件名、下载url
        if (!fiFileOptional.isPresent()) {
            throw new BusinessException(StatusEnum.FILE_SERIALIZABLE_ERROR);
        }
        FiFile fiFile = fiFileOptional.get();
        String fileName = fiFile.getFileOriginalName();
        String fileUrl = fiFile.getFileUrl();

        // 获取下载流
        byte[] bytes = fastDFSClientWrapper.downloadFile(fileUrl);
        // 这里只是为了整合fastdfs，所以写死了文件格式。需要在上传的时候保存文件名。下载的时候使用对应的格式
        try {
            //String  fileEncName=URLEncoder.encode(fileName, "UTF-8");
            String fileEncName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
            response.setHeader("Content-disposition", "attachment;filename=" + fileEncName);
        } catch (UnsupportedEncodingException e) {
            throw new BusinessException("UnsupportedEncodingException：" + e.getMessage());
        }
        response.setCharacterEncoding("UTF-8");
        ServletOutputStream outputStream = null;
        try {
            outputStream = response.getOutputStream();
            outputStream.write(bytes);
        } catch (IOException e) {
            throw new BusinessException("IOException：" + e.getMessage());
        } finally {
            try {
                if (outputStream != null) {
                    outputStream.flush();
                }
                if (outputStream != null) {
                    outputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    void deleteFile(Integer fileId) {
        Optional<FiFile> fiFileOptional = fiFileRepository.findById(fileId);
        // 获取文件名、下载url
        if (!fiFileOptional.isPresent()) {
            throw new BusinessException(StatusEnum.FILE_SERIALIZABLE_ERROR);
        }

        // 删除FastDFS
        fastDFSClientWrapper.deleteFile(fiFileOptional.get().getFileUrl());
        // 删除文件表
        fiFileRepository.deleteById(fileId);

    }

}
