package com.huatonghh.policy.service.dto.policy;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.math.BigInteger;
import java.util.Date;

/**
 * Description : 保单信息保存实体
 * @author : Sun
 * @date : 2019/9/21 11:41
 * @version : 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PolicyListDto {

    @ApiModelProperty(value = "自增id：新增不传、修改必传")
    @JsonSerialize(using = ToStringSerializer.class)
    private BigInteger id;

    @ApiModelProperty(value = "保单号")
    @NotNull(message = "保单号不能为空")
    private String policyNo;

    @ApiModelProperty(value = "车或非车标识：1车、0非车，必传")
    @NotNull(message = "车或非车标识不能为空")
    private Byte carUncarFlag;

    @ApiModelProperty(value = "项目组织")
    private String projectName;

    @ApiModelProperty(value = "保险类别")
    private String insuranceCategory;

    @ApiModelProperty(value = "险种代码；例:车（交强、商业）,非车待定")
    private String kindCode;

    @ApiModelProperty(value = "投保人")
    private String holderName;

    @ApiModelProperty(value = "被保险人")
    private String insuredName;

    @ApiModelProperty(value = "中标项目编号")
    @JsonSerialize(using = ToStringSerializer.class)
    private BigInteger projectNo;

    @ApiModelProperty(value = "发起公司")
    private String startCompany;

    @ApiModelProperty(value = "保险公司")
    private String belongCompany;

    @ApiModelProperty(value = "保险公司名称")
    private String belongCompanyName;

    @ApiModelProperty(value = "保费")
    @JsonDeserialize(using= AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger totalPremium;

    @ApiModelProperty(value = "有效起期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyBgnTime;

    @ApiModelProperty(value = "有效止期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyEndTime;

    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    @ApiModelProperty(value = "更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    @ApiModelProperty(value = "保司联系人")
    private String belongCompanyPerson;

    @ApiModelProperty(value = "联系电话")
    private String belongCompanyPhone;

    @ApiModelProperty(value = "状态")
    private Byte status;

    @ApiModelProperty(value = "车：车架号")
    private String frameNo;

    @ApiModelProperty(value = "车：车牌号")
    private String plateNo;

    @ApiModelProperty(value = "车：发动机号")
    private String engineNo;

    @ApiModelProperty(value = "车：使用性质")
    private String usageCode;

    @ApiModelProperty(value = "车：车主")
    private String ownerName;

    @ApiModelProperty(value = "车：车辆型号")
    private String vehicleModel;

    @ApiModelProperty(value = "车：车船税")
    private String vehicleVesselTax;

    @ApiModelProperty(value = "车：NCD系数")
    private String ncdCoef;

    @ApiModelProperty(value = "车：自主核保系数")
    private String autoUnderwritingCoef;

    @ApiModelProperty(value = "非车：投保产品")
    private String mainRiskDuty;

    @ApiModelProperty(value = "非车：总保额")
    @JsonDeserialize(using= AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger totalAmount;

    @ApiModelProperty(value = "非车：手续费比例")
    private String feeProp;

    @ApiModelProperty(value = "非车：签单日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date issueDate;

    @ApiModelProperty(value = "非车：共保信息")
    private String coinsuranceDetail;

    @ApiModelProperty(value = "非车：实收日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date paidInDate;

    @ApiModelProperty(value = "非车：支付类型：见费出单/分期")
    private Byte paymentType;

    @ApiModelProperty(value = "非车：所属标段")
    private String subordinateBid;

    @ApiModelProperty(value = "非车：工程名称")
    private String engineeringName;

    @ApiModelProperty(value = "非车：保证期间")
    private String guarantyPeriod;

    @ApiModelProperty(value = "批单号")
    private String modifyNo;

    @ApiModelProperty(value = "批改项目编号")
    private BigInteger modifyId;

    @ApiModelProperty(value = "批改项目编号")
    private String modifyProjectNo;

    @ApiModelProperty(value = "提醒状态")
    private Boolean remindStatus;

    @ApiModelProperty(value = "距离到期时间（天）")
    private Integer expirationDays;

    @ApiModelProperty(value = "续保状态：0未续保，1已续保")
    private Byte renewStatus;
}
