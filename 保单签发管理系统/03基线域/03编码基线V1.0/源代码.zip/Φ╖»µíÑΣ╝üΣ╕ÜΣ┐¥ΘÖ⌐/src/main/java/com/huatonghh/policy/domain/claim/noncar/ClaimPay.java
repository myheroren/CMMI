package com.huatonghh.policy.domain.claim.noncar;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

/**
 * (PolicyUncarClaimPay)实体类
 *
 * @author wanggl
 * @since 2020-11-12 15:58:06
 */
@ApiModel("非车理赔支付信息")
@Entity
@Table(name = "policy_uncar_claim_pay")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClaimPay implements Serializable {

    private static final long serialVersionUID = -23855289039685920L;

    @ApiModelProperty(value = "支付信息编号")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    private Long id;

    @ApiModelProperty(value = "赔付编号")
    private String claimNo;

    @ApiModelProperty(value = "报案号")
    @JsonIgnore
    private String reportNo;

    @ApiModelProperty(value = "领款人名称")
    private String receiveName;

    @ApiModelProperty(value = "领款人银行")
    private String receiveBank;

    @ApiModelProperty(value = "开户行")
    private String receiveBankDetail;

    @ApiModelProperty(value = "领款人账户")
    private String receiveAccount;

    @ApiModelProperty(value = "流水号")
    private String serialNumber;

    @ApiModelProperty(value = "金额")
    private BigInteger payAmount;

    @ApiModelProperty(value = "支付时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date payDate;

}
