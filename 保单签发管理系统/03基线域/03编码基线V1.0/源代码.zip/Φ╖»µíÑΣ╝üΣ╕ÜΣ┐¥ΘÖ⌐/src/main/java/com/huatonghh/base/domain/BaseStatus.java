package com.huatonghh.base.domain;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/7
 */
@Entity
@Table(name = "base_status")
@Data
public class BaseStatus {
    @Id
    private String status;
    private String remark;
}
