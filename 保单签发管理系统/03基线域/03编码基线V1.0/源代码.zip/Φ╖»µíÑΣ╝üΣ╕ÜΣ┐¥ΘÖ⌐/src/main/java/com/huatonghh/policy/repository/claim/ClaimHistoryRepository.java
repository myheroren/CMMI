package com.huatonghh.policy.repository.claim;

import com.huatonghh.policy.domain.claim.noncar.ClaimHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/9/16
 */
public interface ClaimHistoryRepository extends JpaRepository<ClaimHistory, Integer> {
    /**
     *
     * @param reportId 报案id
     * @return 历史
     */
    List<ClaimHistory> findAllByReportIdOrderByClaimStatusAsc(String reportId);


    /**
     *
     * @param reportId 报案id 和 claimStatus 案件状态
     * @return 历史
     */
    ClaimHistory findAllByReportIdAndClaimStatus(BigInteger reportId, Byte claimStatus);

    /**
     * 根据ReportId删除
     * @param reportId
     */
    @Modifying
    @Transactional
    @Query(value = "DELETE FROM policy_claim_history WHERE report_id = :reportId", nativeQuery = true)
    void deleteByReportId(@Param("reportId") String reportId);
}
