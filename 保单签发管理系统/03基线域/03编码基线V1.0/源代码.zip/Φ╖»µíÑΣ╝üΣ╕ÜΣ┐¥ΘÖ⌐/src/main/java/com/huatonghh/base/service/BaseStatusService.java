package com.huatonghh.base.service;

import com.huatonghh.base.domain.BaseStatus;
import com.huatonghh.base.repository.BaseStatusRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/7
 */
@Service
@AllArgsConstructor
public class BaseStatusService {
    private final BaseStatusRepository repository;

    public List<BaseStatus> listStatus() {
        return repository.findAll();
    }
}
