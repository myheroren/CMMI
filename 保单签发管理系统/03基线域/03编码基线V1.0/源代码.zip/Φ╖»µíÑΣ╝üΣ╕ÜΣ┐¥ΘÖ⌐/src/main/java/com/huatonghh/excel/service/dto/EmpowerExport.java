package com.huatonghh.excel.service.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import lombok.Data;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

/**
 * @author ghy
 * Date: 2021/1/6 15:42
 */
@ContentRowHeight(16)
@HeadRowHeight(18)
@HeadFontStyle(fontHeightInPoints = 12)
@Data
public class EmpowerExport {

    @ExcelProperty(value = "授权项目编号")
    private String projNo;

    @ExcelProperty(value = "险种名称")
    private String riskKindName;

    @ExcelProperty(value = "发起公司")
    private String startCompanyName;

    @ExcelProperty(value = "授权文件")
    private String fileName;

    @ExcelProperty(value = "预计保额（万元）")
    private String estAmount;

}
