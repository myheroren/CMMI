package com.huatonghh.policy.repository;

import com.huatonghh.policy.domain.project.ProjectEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author hao.wang
 */
@Transactional(rollbackFor = RuntimeException.class)
public interface ProjectRepository extends JpaRepository<ProjectEntity, String> {

    /**
     * 根据计划编号和有效状态查询
     *
     * @param planNo 计划编号
     * @param isValid  有效状态
     * @return 项目列表
     */
    List<ProjectEntity> findAllByPlanNoAndIsValid(String planNo, Byte isValid);

    /**
     * 根据人查询
     *
     * @param startUser 发起公司
     * @param isValid     有效状态
     * @return 项目列表
     */
    List<ProjectEntity> findAllByStartUserAndIsValidOrderByCreateTime(String startUser,  Byte isValid);

    /**
     * 根据所属保险公司查询
     *
     * @param belongCompany 保险公司
     * @return 项目
     */
    Page<ProjectEntity> findAllByBelongCompany(Pageable page, String belongCompany);
}
