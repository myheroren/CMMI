package com.huatonghh.excel.service.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import lombok.Data;

/**
 * description:理赔明细表
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/9
 */
@Data
@ContentRowHeight(20)
@HeadRowHeight(20)
@ColumnWidth(15)
public class ClaimDetailFormData {

    @ExcelProperty(value = "被保险人", index = 0)
    private String insuredName;

    @ExcelProperty(value = "项目类别", index = 1)
    private String engTypeName;

    @ExcelProperty(value = "出险时间", index = 2)
    private String accidentTime;

    @ExcelProperty(value = "出险地点", index = 3)
    private String address;

    @ExcelProperty(value = "案件简况", index = 4)
    private String accidentReason;

    @ExcelProperty(value = "估损金额", index = 5)
    private String preLossAmount;

    @ExcelProperty(value = "保险类别", index = 6)
    private String insureType;

    @ExcelProperty(value = "受理时间", index = 7)
    private String claimBeginDate;

    @ExcelProperty(value = "申请人", index = 8)
    private String reportName;

    @ExcelProperty(value = "索赔金额", index = 9)
    private String askForAmount;

    @ExcelProperty(value = "是否获赔", index = 10)
    private String compensateEnd;

    @ExcelProperty(value = "获赔人", index = 11)
    private String receiveName;

    @ExcelProperty(value = "获赔时间", index = 12)
    private String receiveTime;

    @ExcelProperty(value = "获赔金额", index = 13)
    private String payAmount;
}
