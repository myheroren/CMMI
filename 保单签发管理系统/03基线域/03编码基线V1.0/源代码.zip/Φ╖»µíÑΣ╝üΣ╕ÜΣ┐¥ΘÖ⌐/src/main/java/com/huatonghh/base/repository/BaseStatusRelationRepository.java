package com.huatonghh.base.repository;

import com.huatonghh.base.domain.BaseStatusRelation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/7
 */
public interface BaseStatusRelationRepository extends JpaRepository<BaseStatusRelation, Integer> {
    /**
     * 根据当前状态和操作查关系
     *
     * @param currentStatus 当前状态
     * @param operation     操作
     * @return 关系配置
     */
    Optional<BaseStatusRelation> findByCurrentStatusAndOperation(String currentStatus, String operation);
}
