package com.huatonghh.authority.domain;

import lombok.Data;

import javax.persistence.*;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/30
 */
@Entity
@Table(name = "ei_work_flow_user")
@Data
public class EiWorkFlowUser {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String userId;
    private String departId;
    private Integer level;
    private Integer parentLevel;
    private Integer roleId;
}
