package com.huatonghh.excel.service.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.huatonghh.excel.util.BigIntegerConverter;
import com.huatonghh.excel.util.DateConverter;
import lombok.Data;

import java.math.BigInteger;
import java.util.Date;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/26
 */
@Data
@ContentRowHeight(20)
@HeadRowHeight(20)
@ColumnWidth(15)
public class VehPolicyData {
    @ExcelProperty(value = {"机动车辆保险情况统计表", "车牌号"}, index = 0)
    private String plateNo;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "承保保险公司（全称）"}, index = 1)
    private String belongCompany;

    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆交强保险情况", "保险单号"}, index = 2)
    private String jqPolicyNo;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆交强保险情况", "保险期间（YY/MM/DD)", "保险起始日"}, index = 3, converter = DateConverter.class)
    private Date jqPolicyBgnTime;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆交强保险情况", "保险期间（YY/MM/DD)", "保险到期日"}, index = 4, converter = DateConverter.class)
    private Date jqPolicyEndTime;


    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "保险单号"}, index = 5)
    private String syPolicyNo;

    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "保险期间（YY/MM/DD)", "保险起始日"}, index = 6, converter = DateConverter.class)
    private Date syPolicyBgnTime;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "保险期间（YY/MM/DD)", "保险到期日"}, index = 7, converter = DateConverter.class)
    private Date syPolicyEndTime;

    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "车辆损失险", "保险金额（元）"}, index = 8, converter = BigIntegerConverter.class)
    private BigInteger insuredAmountLoss;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "车辆损失险", "保险费（元）"}, index = 9, converter = BigIntegerConverter.class)
    private BigInteger premiumLoss;

    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "第三者责任保险", "保险金额（元）"}, index = 10, converter = BigIntegerConverter.class)
    private BigInteger insuredAmountThird;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "第三者责任保险", "保险费（元）"}, index = 11, converter = BigIntegerConverter.class)
    private BigInteger premiumThird;

    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "车上人员责任险", "驾驶人", "保险金额（元）"}, index = 12, converter = BigIntegerConverter.class)
    private BigInteger insuredAmountDriver;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "车上人员责任险", "驾驶人", "保险费（元）"}, index = 13, converter = BigIntegerConverter.class)
    private BigInteger premiumDriver;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "车上人员责任险", "乘客", "保险金额（元）"}, index = 14, converter = BigIntegerConverter.class)
    private BigInteger insuredAmountPassenger;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "车上人员责任险", "乘客", "保险费（元）"}, index = 15, converter = BigIntegerConverter.class)
    private BigInteger premiumPassenger;

    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "盗抢险", "保险金额（元）"}, index = 16, converter = BigIntegerConverter.class)
    private BigInteger insuredAmountRobbery;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "盗抢险", "保险费（元）"}, index = 17, converter = BigIntegerConverter.class)
    private BigInteger premiumRobbery;

    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "车身划痕险", "保险金额（元）"}, index = 18, converter = BigIntegerConverter.class)
    private BigInteger insuredAmountScratch;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "车身划痕险", "保险费（元）"}, index = 19, converter = BigIntegerConverter.class)
    private BigInteger premiumScratch;

    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "玻璃单独破碎险", "保险费（元）"}, index = 20, converter = BigIntegerConverter.class)
    private BigInteger premiumGlass;

    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "不计免赔", "保险费（元）"}, index = 21, converter = BigIntegerConverter.class)
    private BigInteger premiumExcluding;

    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "发动机涉水险", "保险金额（元）"}, index = 22, converter = BigIntegerConverter.class)
    private BigInteger insuredAmountEngine;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "发动机涉水险", "保险费（元）"}, index = 23, converter = BigIntegerConverter.class)
    private BigInteger premiumEngine;

    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "自燃损失险", "保险金额（元）"}, index = 24, converter = BigIntegerConverter.class)
    private BigInteger insuredAmountSelfFire;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "机动车辆商业险保险情况", "自燃损失险", "保险费（元）"}, index = 25, converter = BigIntegerConverter.class)
    private BigInteger premiumSelfFire;

    @ExcelProperty(value = {"机动车辆保险情况统计表", "货物运输险保险情况", "保险单号"}, index = 26)
    private String hwPolicyNo;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "货物运输险保险情况", "保险期间（YY/MM/DD)", "保险起始日"}, index = 27, converter = DateConverter.class)
    private Date hwPolicyBgnTime;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "货物运输险保险情况", "保险期间（YY/MM/DD)", "保险到期日"}, index = 28, converter = DateConverter.class)
    private Date hwPolicyEndTime;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "货物运输险保险情况", "保单总保额（元）"}, index = 29, converter = BigIntegerConverter.class)
    private BigInteger insuredAmount;

    @ExcelProperty(value = {"机动车辆保险情况统计表", "保险费统计", "商业险保险费小计（元）"}, index = 30, converter = BigIntegerConverter.class)
    private BigInteger syTotalPremium;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "保险费统计", "交强险保险费（元）"}, index = 31, converter = BigIntegerConverter.class)
    private BigInteger jqPremium;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "保险费统计", "车船税（元）"}, index = 32, converter = BigIntegerConverter.class)
    private BigInteger premiumV;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "保险费统计", "货运险保费（元）"}, index = 33, converter = BigIntegerConverter.class)
    private BigInteger hwPremium;


    @ExcelProperty(value = {"机动车辆保险情况统计表", " 财务信息", "交强险手续费比例（%）"}, index = 34)
    private String jqFeeProp;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "财务信息", "商业险手续费比例（%）"}, index = 35)
    private String syFeeProp;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "财务信息", "货运险手续费比例（%）"}, index = 36)
    private String hwFeeProp;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "财务信息", "NCD系数"}, index = 37)
    private String syNcdCoef;
    @ExcelProperty(value = {"机动车辆保险情况统计表", "财务信息", "自主核保系数"}, index = 38, converter = BigIntegerConverter.class)
    private BigInteger syAutoUnderwritingCoef;
}
