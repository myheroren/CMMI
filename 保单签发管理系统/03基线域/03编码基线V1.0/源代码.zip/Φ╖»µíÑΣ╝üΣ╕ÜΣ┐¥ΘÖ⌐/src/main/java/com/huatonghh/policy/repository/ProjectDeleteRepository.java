package com.huatonghh.policy.repository;

import com.huatonghh.policy.domain.project.ProjectDeleteEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigInteger;

/**
 * @author hao.wang
 */
public interface ProjectDeleteRepository extends JpaRepository<ProjectDeleteEntity, BigInteger> {

}
