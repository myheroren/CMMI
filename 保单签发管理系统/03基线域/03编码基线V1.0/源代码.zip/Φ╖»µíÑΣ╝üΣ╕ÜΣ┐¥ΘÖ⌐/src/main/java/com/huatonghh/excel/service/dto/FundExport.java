package com.huatonghh.excel.service.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author ghy
 * Date: 2021/1/6 15:42
 */
@ContentRowHeight(16)
@HeadRowHeight(18)
@HeadFontStyle(fontHeightInPoints = 12)
@Data
public class FundExport {

    @ExcelProperty(value = "序号")
    private Integer number;

    @ExcelProperty(value = "基金总额")
    private BigDecimal total;

    @ExcelProperty(value = "使用基金数")
    @DateTimeFormat(value = "yyyy-MM-dd")
    private BigDecimal used;

    @ExcelProperty(value = "剩余基金数")
    private BigDecimal left;

    @ExcelProperty(value = "记录时间")
    @DateTimeFormat(value = "yyyy-MM-dd")
    private Date createTime;

}
