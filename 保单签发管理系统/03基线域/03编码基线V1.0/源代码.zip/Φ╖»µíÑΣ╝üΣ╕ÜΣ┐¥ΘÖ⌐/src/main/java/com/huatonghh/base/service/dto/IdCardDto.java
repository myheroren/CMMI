package com.huatonghh.base.service.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * Description : 身份证工具-IdcardUtil
 * @author : Sun
 * @date : 2019/10/22 15:02
 * @version : 1.0
 */
@Data
public class IdCardDto {

    @ApiModelProperty(value = "验证身份证是否合法")
    private Boolean isValidCard;

    @ApiModelProperty(value = "身份证15位转18位")
    private String convert15To18;

    @ApiModelProperty(value = "获取生日月")
    private String getBirthByIdCard;

    @ApiModelProperty(value = "获取年龄")
    private Integer getAgeByIdCard;

    @ApiModelProperty(value = "获取生日年")
    private Short getYearByIdCard;

    @ApiModelProperty(value = "获取生日月")
    private Short getMonthByIdCard;

    @ApiModelProperty(value = "获取生日天")
    private Short getDayByIdCard;

    @ApiModelProperty(value = "获取性别")
    private Integer getGenderByIdCard;

    @ApiModelProperty(value = "获取省份")
    private String getProvinceByIdCard;

}
