package com.huatonghh.policy.service.dto.project;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Date: 2020/2/12 16:11</p>
 *
 * @author EDZ
 */
@Data
@ApiModel("待办查询")
public class TodoDTO {
    @ApiModelProperty("当前页数")
    @NotNull(message = "当前页数不能为空！")
    public Integer pageNo;
    @ApiModelProperty("每页显示数据条数")
    @NotNull(message = "分页大小不能为空！")
    public Integer pageSize;
    @ApiModelProperty("待办类型:0全部，1汇总计划，2年度计划，3单项，4预算汇总，5预算年度，6预算全部")
    public String type;
}
