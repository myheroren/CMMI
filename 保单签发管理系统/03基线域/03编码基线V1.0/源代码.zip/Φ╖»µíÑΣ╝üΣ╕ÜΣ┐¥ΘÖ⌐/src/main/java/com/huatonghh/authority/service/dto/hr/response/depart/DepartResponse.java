package com.huatonghh.authority.service.dto.hr.response.depart;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;


/**
 * @author : Sun
 * @description : 查询公司信息-返回Json报文
 * @date : 2019/11/4 21:05
 * @version : 1.0
 */
@Data
public class DepartResponse {

    @JsonProperty(value = "SHEAD")
    @JSONField(name ="SHEAD")
    private DepartSheadResponse sheadResponse;

}
