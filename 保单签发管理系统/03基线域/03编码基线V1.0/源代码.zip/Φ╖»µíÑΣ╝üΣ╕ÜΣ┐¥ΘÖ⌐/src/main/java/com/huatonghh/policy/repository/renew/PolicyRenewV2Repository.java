package com.huatonghh.policy.repository.renew;

import com.huatonghh.policy.domain.policy.renew.PolicyRenewEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.util.List;


/**
 * description:续保dao
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2020/1/9
 */
@Repository
public interface PolicyRenewV2Repository extends JpaRepository<PolicyRenewEntity, BigInteger> {
    /**
     * 根据原保单号查续保保单
     *
     * @param policyNoOld 原保单号
     * @return 续保列表
     */
    List<PolicyRenewEntity> findAllByPolicyNoOldOrderByIdDesc(String policyNoOld);

    /**
     * 根据原保单号查续保保单
     *
     * @param policyNoNew 新保单号
     * @return 续保列表
     */
    List<PolicyRenewEntity> findAllByPolicyNoNewOrderByIdDesc(String policyNoNew);

    /**
     * 批量插入需要续保的保单信息
     */
    @Transactional(rollbackFor = RuntimeException.class)
    @Modifying
    @Query(value = "insert into policy_renew_info (policy_no_old,belong_company_old,project_no_old,start_company,remind_display,status,insurance_category,frame_no,plate_no) " +
        " select m.policy_no ,m.belong_company,m.project_no,m.start_company,1,0,1,d.frame_no,d.plate_no" +
        " from policy_main m ,policy_car_detail d where 1=1" +
        " and  m.policy_no = d.policy_no " +
        " and  m.policy_end_time >= CURDATE() " +
        " and m.policy_end_time <= DATE_ADD(CURDATE(), INTERVAL  30 DAY)" +
        " and m.policy_no not in (select policy_no_old from  policy_renew_info)", nativeQuery = true)
    void batchInsertCarRenew();
}
