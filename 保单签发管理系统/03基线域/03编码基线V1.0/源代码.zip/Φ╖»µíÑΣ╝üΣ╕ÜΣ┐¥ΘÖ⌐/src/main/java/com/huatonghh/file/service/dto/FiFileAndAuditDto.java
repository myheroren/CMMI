package com.huatonghh.file.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

/**
 * @author : Sun
 * @description : 文件全字段-Dto
 * @date : 2019/11/5 21:26
 * @version : 1.0
 */
@Data
@ApiModel(value = "文件全字段Dto")
public class FiFileAndAuditDto implements Serializable {

    private static final long serialVersionUID = 2316561937129916434L;

    @ApiModelProperty(value = "信息表id，自增")
    private Integer auditId;

    @ApiModelProperty(value = "FastDfs文件表id")
    private Integer fileId;

    @ApiModelProperty(value = "文件大小 long类型")
    private BigInteger fileSize;

    @ApiModelProperty(value = "附件名称，可录入，不录入时默认文件名")
    private String fileName;

    @ApiModelProperty(value = "上传人")
    private String uploadUser;

    @ApiModelProperty(value = "上传环节")
    private String uploadLink;

    @ApiModelProperty(value = "关联编号，计划编号/项目编号")
    @NotNull(message = "关联编号必填")
    private String belongId;

    @ApiModelProperty(value = "关联类型,1计划，2项目，3保单")
    @NotNull(message = "关联类型必填")
    private Byte belongType;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "是否失效；1有效, 0无效")
    private Boolean valid;

    @ApiModelProperty(value = "是否可预览；0不可预览, 1浏览器可直接预览，2微软OFFICE预览")
    private Byte preview;

    @ApiModelProperty(value = "上传时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;

    public FiFileAndAuditDto() {
    }

    public FiFileAndAuditDto(Integer auditId, Integer fileId, BigInteger fileSize, String fileName, String uploadUser, String uploadLink, @NotNull(message = "关联编号必填") String belongId, @NotNull(message = "关联类型必填") Byte belongType, String remark, Boolean valid, Byte preview, Date createTime) {
        this.auditId = auditId;
        this.fileId = fileId;
        this.fileSize = fileSize;
        this.fileName = fileName;
        this.uploadUser = uploadUser;
        this.uploadLink = uploadLink;
        this.belongId = belongId;
        this.belongType = belongType;
        this.remark = remark;
        this.valid = valid;
        this.preview = preview;
        this.createTime = createTime;
    }

}
