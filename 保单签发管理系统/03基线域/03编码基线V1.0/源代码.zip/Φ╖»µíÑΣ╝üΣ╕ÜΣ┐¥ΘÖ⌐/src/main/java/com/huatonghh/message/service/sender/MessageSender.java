package com.huatonghh.message.service.sender;

import com.huatonghh.message.po.dto.MessageThirdPartyDTO;

/**
 * 发送第三方消息
 *
 * @author wanggl
 * @date 2020-11-02 15:48
 */
public interface MessageSender {

    /**
     * 发送第三方消息
     *
     * @param message 第三方消息信息
     * @return 发送成功返回true
     */
    boolean sendMessage(MessageThirdPartyDTO message);
}
