package com.huatonghh.policy.domain.policy;


import lombok.Data;

import javax.persistence.*;
import java.math.BigInteger;
import java.util.Date;

/**
 * description: 保单缴费期次信息
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/22
 */
@Entity
@Table(name = "policy_pay_period")
@Data
public class PolicyPayPeriod {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private BigInteger id;

    @Column(name = "policy_no")
    private String policyNo;

    @Column(name = "period_no")
    private Integer periodNo;

    @Column(name = "belong_company")
    private String belongCompany;

    @Column(name = "belong_company_name")
    private String belongCompanyName;

    @Column(name = "portion_premium")
    private BigInteger portionPremium;

    @Column(name = "portion_fee")
    private BigInteger portionFee;

    @Column(name = "premium_due_date")
    private Date premiumDueDate;

    @Column(name = "fee_due_date")
    private Date feeDueDate;

    @Column(name = "premium_pay_date")
    private Date premiumPayDate;

    @Column(name = "fee_pay_date")
    private Date feePayDate;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_time")
    private Date updateTime;
}
