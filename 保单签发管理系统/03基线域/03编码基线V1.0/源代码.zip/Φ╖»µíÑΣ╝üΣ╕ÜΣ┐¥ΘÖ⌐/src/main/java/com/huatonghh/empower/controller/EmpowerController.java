package com.huatonghh.empower.controller;

import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.common.util.system.PageParam;
import com.huatonghh.empower.service.EmpowerQuery;
import com.huatonghh.empower.service.EmpowerService;
import com.huatonghh.empower.service.dto.FileQuery;
import com.huatonghh.empower.service.dto.PolicySaveDTO;
import com.huatonghh.file.domain.FiAuditFile;
import com.huatonghh.file.service.AuditFileService;
import com.huatonghh.file.service.dto.FiAuditFileDto;
import com.huatonghh.policy.service.dto.project.ProjectDTO;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author ghy
 * Date: 2021/1/6 17:12
 */
@AllArgsConstructor
@RequestMapping("/api/empower/v1")
@RestController
@Api(tags = "授权管理接口")
public class EmpowerController {

    private final EmpowerService empowerService;
    private final AuditFileService auditFileService;

    @ApiOperation(value = "1、授权管理列表")
    @PostMapping("/pageList")
    public ApiResponse<PageInfo<ProjectDTO>> pageList(@RequestBody PageParam<EmpowerQuery> pageParam){
        return ApiResponse.ofSuccess(empowerService.list(pageParam));
    }

    @ApiOperation(value = "2、保单详情文件展示")
    @PostMapping("/fileList")
    public ApiResponse<List<FiAuditFileDto>> fileList(@RequestBody FileQuery fileQuery){
        return ApiResponse.ofSuccess(empowerService.fileList(fileQuery));
    }

    @ApiOperation(value = "3、保单录入")
    @PostMapping("/savePolicy")
    public ApiResponse savePolicy(@RequestBody PolicySaveDTO policySaveDTO){
        empowerService.savePolicy(policySaveDTO);
        return ApiResponse.ofSuccess(null);
    }

    @GetMapping(value = "/file/{fileId}")
    @ApiOperation(value = "4、查询附件信息", notes = "附件信息回显", httpMethod = "GET")
    @Timed
    public ApiResponse<FiAuditFile> getFileInfo(@PathVariable("fileId") Integer fileId) {
        return ApiResponse.ofSuccess(auditFileService.selectFileInfo(fileId));
    }

}
