package com.huatonghh.policy.service.dto.policy;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

/**
 * Description : 保存保单详细信息-车
 * @author : Sun
 * @date : 2019/8/31 14:01
 * @version : 1.0
 */
@Data
@ApiModel("保存保单详细信息-车")
public class SavePolicyCarDto implements Serializable {

    private static final long serialVersionUID = -2265071786760842808L;

    @ApiModelProperty(value = "自增id：新增不传、修改必传")
    @JsonSerialize(using = ToStringSerializer.class)
    private BigInteger id;

    @ApiModelProperty(value = "保单号，与基本信息保单号相同，关联基本信息")
    private String policyNo;

    @ApiModelProperty(value = "车架号")
    private String frameNo;

    @ApiModelProperty(value = "车牌号")
    private String plateNo;

    @ApiModelProperty(value = "发动机号")
    private String engineNo;

    @ApiModelProperty(value = "使用性质")
    private String usageCode;

    @ApiModelProperty(value = "车辆型号")
    private String vehicleModel;

    @ApiModelProperty(value = "车主")
    private String ownerName;

    /** 险种信息 */

    @ApiModelProperty(value = "手续费比例")
    private String feeProp;

    @ApiModelProperty(value =  "车船税")
    private String vehicleVesselTax;

    @ApiModelProperty(value = "NCD系数")
    private String ncdCoef;

    @ApiModelProperty(value = "自主核保系数")
    private String autoUnderwritingCoef;

    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    @ApiModelProperty(value = "更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    @ApiModelProperty(value = "车辆方案列表")
    private List<PolicyVehRiskPlanDto> policyVehRiskPlanDtoList;

}
