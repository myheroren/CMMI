package com.huatonghh.base.web.rest;


import com.huatonghh.base.constant.BaseConstant;
import com.huatonghh.base.service.BaseRemindService;
import com.huatonghh.base.service.dto.BaseRemindDto;
import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.common.util.system.PageInfo;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * @author : Sun
 * @description : 通知中心
 * @date : 2019/11/5 21:06
 * @version : 1.0
 */
@RestController
@RequestMapping("/api/remind/v1")
@Api(tags="21、通知中心", value = "通知中心相关接口")
@Slf4j
@AllArgsConstructor
public class BaseRemindController {

    private final BaseRemindService baseRemindService;

    @PostMapping("/save")
    @ApiOperation(value = "1、新增通知", httpMethod = "POST")
    @Timed
    public ApiResponse saveRemind(@RequestBody @Valid List<BaseRemindDto> baseRemindDtoList) {
        baseRemindService.saveRemind(baseRemindDtoList);
        return ApiResponse.ofSuccess(null);
    }


    @GetMapping(value = "test")
    @Timed
    public void uncarClaimReport(String planNo, String projectNo, String policyNo, String claimNo, Byte claimStatus) {
        baseRemindService.uncarClaimReport(planNo, projectNo, policyNo, claimNo, claimStatus, BaseConstant.REMIND_UN_CAR_CLAIM_REPORT);
    }


    @GetMapping(value = "test1")
    @Timed
    public void uncarClaimUpdateProgress(String planNo, String projectNo, String policyNo, String claimNo, Byte claimStatus) {
        baseRemindService.uncarClaimUpdateProgress(planNo, projectNo, policyNo, claimNo, claimStatus,BaseConstant.REMIND_UNCAR_CLAIM_UPDATE);
    }


    @GetMapping(value = "page_list")
    @Timed
    public ApiResponse<PageInfo<BaseRemindDto>> pageList(Integer pageNum, Integer pageSize,
                                                         @RequestParam(name = "read", required = false) Byte read,
                                                         @RequestParam(name = "backlog", required = false) Byte backlog,
                                                         @RequestParam(name = "remindType", required = false) Byte remindType) {
        return ApiResponse.ofSuccess(baseRemindService.pageList(pageNum, pageSize, read, backlog, remindType));
    }

}
