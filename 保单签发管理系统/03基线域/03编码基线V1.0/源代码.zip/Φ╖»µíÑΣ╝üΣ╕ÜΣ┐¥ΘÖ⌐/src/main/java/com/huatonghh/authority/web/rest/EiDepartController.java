package com.huatonghh.authority.web.rest;

import com.huatonghh.authority.service.EiDepartService;
import com.huatonghh.authority.service.dto.EiDepartDto;
import com.huatonghh.authority.service.dto.EiDepartTreeDto;
import com.huatonghh.common.util.system.ApiResponse;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;


/**
 * @author : Sun
 * @description : 部门管理相关接口，部门列表二叉树、增删改查等
 * @date : 2019/11/5 20:10
 * @version : 1.0
 */
@RestController
@RequestMapping("/api/depart/v1")
@Api(tags="10、V1.部门管理", value = "部门相关接口")
@Slf4j
public class EiDepartController {

    private final EiDepartService eiDepartService;

    public EiDepartController(EiDepartService eiDepartService) {
        this.eiDepartService = eiDepartService;
    }

    @GetMapping("/tree_list")
    @ApiOperation(value = "1、获取部门二叉树列表", notes = "此方法使用了缓存，但尚未添加清除缓存接口，亲注意", httpMethod = "GET")
    @Timed
    public ApiResponse<List<EiDepartTreeDto>> queryDepartTreeList(@RequestParam(name = "id", required = false) String id) {
        return ApiResponse.ofSuccess(eiDepartService.queryDepartTreeList(id));
    }


    @GetMapping("/lower_list/{id}")
    @ApiOperation(value = "2、根据部门id，查询所有子部门列表", httpMethod = "GET")
    @Timed
    public ApiResponse<List<EiDepartDto>> queryDepartListById(@PathVariable(value = "id") String id) {
        return ApiResponse.ofSuccess(eiDepartService.queryCompanyListByParentId(id,"Company"));
    }


    @GetMapping("/parent_lower_list/{id}")
    @ApiOperation(value = "2、根据父部门id，查询所有子部门列表", httpMethod = "GET")
    @Timed
    public ApiResponse<List<EiDepartDto>> queryDepartListByParentId(@PathVariable(value = "id") String id) {
        return ApiResponse.ofSuccess(eiDepartService.queryDepartListByParentId(id));
    }

    @GetMapping("/company_list/{type}/{id}")
    @ApiOperation(value = "2、根据父部门id，查询所有子部门列表", httpMethod = "GET")
    @Timed
    public ApiResponse<List<EiDepartDto>> queryCompanyListByParentId(@PathVariable(value = "type") String type, @PathVariable(value = "id") String id) {
        return ApiResponse.ofSuccess(eiDepartService.queryCompanyListByParentId(id,type));
    }


    @GetMapping("/clear_cache")
    @ApiOperation(value = "3、清除缓存", httpMethod = "GET")
    @Timed
    public void clearCache() {
        eiDepartService.clearCache();
    }


    @DeleteMapping("/delete/{departId}")
    @ApiOperation(value = "4、删除部门", httpMethod = "DELETE")
    @Timed
    public void delete(@PathVariable(value = "departId") String departId) {
        eiDepartService.delete(departId);
    }


    @PostMapping("/save")
    @ApiOperation(value = "5、部门信息保存", httpMethod = "POST")
    @Timed
    public ApiResponse<EiDepartDto> saveDepart(@RequestBody @Valid EiDepartDto eiDepartDto) {
        return ApiResponse.ofSuccess(eiDepartService.saveDepart(eiDepartDto));
    }

    @GetMapping("/getAllCompany")
    @ApiOperation(value = "获取企业端所有的公司id和name", httpMethod = "GET")
    @ResponseBody
    public ApiResponse<List<EiDepartTreeDto>> getAllCompany() {
        // 只查id和name
        List<EiDepartTreeDto> list = eiDepartService.findAllDepartNameAndId();
        return ApiResponse.ofSuccess(list);
    }
}
