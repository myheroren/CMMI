package com.huatonghh.policy.web.rest;

import com.huatonghh.authority.constant.AuthorityConstant;
import com.huatonghh.authority.security.SecurityUtils;
import com.huatonghh.base.service.timing.PolicyStatusService;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.policy.domain.policy.PolicyEngineerSpecial;
import com.huatonghh.policy.repository.policy.PolicyEngineerSpecialRepository;
import com.huatonghh.policy.service.PolicyService;
import com.huatonghh.policy.service.claim.noncar.UnCarClaimService;
import com.huatonghh.policy.service.dto.PolicyFundDTO;
import com.huatonghh.policy.service.dto.policy.*;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * Description : 保单管理-接口
 *
 * @author : Sun
 * @version : 1.0
 * @date : 2019/9/20 17:18
 */
@RestController
@RequestMapping("/api/policy/v1")
@Api(tags = "14、V1.保单管理", value = "保单管理相关接口")
@Slf4j
@AllArgsConstructor
public class PolicyController {

    private final PolicyService policyService;

    private final UnCarClaimService claimService;

    private final PolicyStatusService policyStatusService;

    private final PolicyEngineerSpecialRepository policyEngineerSpecialRepository;

    @GetMapping("/detail/{policyNo}")
    @ApiOperation(value = "3、获取保单详情", httpMethod = "GET")
    @Timed
    public ApiResponse<SavePolicyDto> queryPolicyDetail(@PathVariable(value = "policyNo") String policyNo) {
        SavePolicyDto savePolicyDto = policyService.queryPolicyDetail(policyNo);//附件信息+详情
        savePolicyDto.setClaimInfos(claimService.listByPolicy(policyNo));//理赔信息
        PolicyEngineerSpecial engineerSpecial = policyEngineerSpecialRepository.findByPolicyNo(policyNo);
        if(engineerSpecial == null){
            log.error("当前保单号:{}",policyNo);
            throw new BusinessException("保单信息不完整，工程险内容为空，请检查同步数据!");
        }
        savePolicyDto.setPolicyEngineerSpecial(engineerSpecial);//险种特殊字段信息
        return ApiResponse.ofSuccess(savePolicyDto);
    }

    @PostMapping("/updateFund")
    @ApiOperation(value = "更新基金", httpMethod = "POST")
    @Timed
    public ApiResponse updateFund(@RequestBody PolicyFundDTO policyFundDTO) {
        policyService.updateFund(policyFundDTO);
        return ApiResponse.ofSuccess(null);
    }

    @PostMapping("/page_list")
    @ApiOperation(value = "9、保单中心列表查询", httpMethod = "POST")
    @Timed
    public ApiResponse<PageInfo<PolicyListDto>> queryPageList(@RequestBody @Valid PolicyListCondition policyListCondition) {
        this.check(policyListCondition);
        // 3.组装查询sql
        StringBuilder sql = policyService.processQuerySql(policyListCondition);
        // 4.查询分页列表数据集
        return ApiResponse.ofSuccess(policyService.queryPageList(sql, policyListCondition.getPageNum(), policyListCondition.getPageSize()));
    }

    /**
     * 导出Excel时用到的
     * @param policyListCondition
     * @return
     */
    public List<PolicyListDto> exportList(@RequestBody @Valid PolicyListCondition policyListCondition) {
        this.check(policyListCondition);
        // 3.组装查询sql
        StringBuilder sql = policyService.processQuerySqlWithCompany(policyListCondition);
        // 4.查询分页列表数据集
        return policyService.queryAllPolicy(sql);
    }

    @PostMapping("/policy_list")
    @ApiOperation(value = "10、所有保单分页列表", httpMethod = "POST")
    @Timed
    public ApiResponse<PageInfo<PolicyBaseListDTO>> queryPolicyList(@RequestBody @Valid PolicyListCondition policyListCondition) {
        this.check(policyListCondition);
        return ApiResponse.ofSuccess(policyService.queryPolicyList(policyListCondition));
    }

    @GetMapping(value = "updatePolicyStatus")
    @ApiOperation(value = "手动调用保单状态更新接口", notes = "手动调用保单状态更新接口", httpMethod = "GET")
    public ApiResponse<Long> updatePolicyStatus() {
        policyStatusService.updatePolicyStatus();
        return ApiResponse.ofSuccess(null);
    }

    private void check(PolicyListCondition policyListCondition) {
        // 1.获取登录角色
        String loginRole = SecurityUtils.loginRole();

        // 2.根据登录角色，获取不同的查询sql
        if (AuthorityConstant.JTJT.equals(loginRole)) {
            // 交投集团登录，如果查询条件中不含集团公司id，不查询
            if (StringUtils.isBlank(policyListCondition.getStartCompany())) {
                throw new BusinessException("请传入集团公司编号");
            }
        } else if (AuthorityConstant.BXGS.equals(loginRole)) {
            // 保险公司登录，如果查询条件中不含保险公司id，不查询
            if (StringUtils.isBlank(policyListCondition.getBelongCompany())) {
                throw new BusinessException("请传入保险公司编号");
            }
        }
    }
}
