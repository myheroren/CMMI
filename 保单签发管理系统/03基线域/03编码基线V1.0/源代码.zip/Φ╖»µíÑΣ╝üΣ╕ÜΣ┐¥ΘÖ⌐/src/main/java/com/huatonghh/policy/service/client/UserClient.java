package com.huatonghh.policy.service.client;

import com.huatonghh.authority.constant.AuthorityConstant;
import com.huatonghh.authority.domain.EiDepart;
import com.huatonghh.authority.domain.EiUser;
import com.huatonghh.authority.repository.EiDepartRepository;
import com.huatonghh.authority.repository.EiUserRepository;
import com.huatonghh.authority.security.SecurityUtils;
import com.huatonghh.authority.service.EiDepartService;
import com.huatonghh.authority.service.EiRoleService;
import com.huatonghh.authority.service.EiUserService;
import com.huatonghh.authority.service.dto.EiDepartDto;
import com.huatonghh.authority.service.dto.EiUserDto;
import com.huatonghh.common.constant.enums.StatusEnum;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.service.RedisService;
import com.huatonghh.policy.constant.PlanConstant;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.Lists;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/9/18
 */
@Service
@Slf4j
@AllArgsConstructor
public class UserClient {

    private final EiUserService eiUserService;

    private final EiDepartService eiDepartService;

    private final InsurerClient insurerClient;
    private final RedisService redisService;
    private final EiDepartRepository eiDepartRepository;
    private final EiRoleService eiRoleService;
    private final EiUserRepository eiUserRepository;

    public String getCurrentUserName() {
        Optional<String> currentUserLogin = SecurityUtils.getCurrentUserLogin();
        if (!currentUserLogin.isPresent()) {
            throw new BusinessException("当前登录人信息丢失，请检查");
        }
        return currentUserLogin.get();
    }

    public boolean isCurrentGroup() {
        List<String> role = SecurityUtils.getLoginRole();
        // 交投集团
        return PlanConstant.ROLE_GROUP.equals(role.get(0));
    }

    public List<Integer> getCurrentRoleIds() {
        return SecurityUtils.getLoginRole_().stream().map(Integer::valueOf).collect(Collectors.toList());
    }

    /**
     * 当前登录的企业公司
     *
     * @return 企业
     */
    public EiDepartDto getCurrentGroupCompany() {
        // 取当前登录人的公司
        EiUserDto user = this.getCurrentUser();
        String companyId = (String) redisService.get(user.getUserName() + "_" + AuthorityConstant.USER_COMPANY);
        if (companyId == null || "".equals(companyId)) {
            throw new BusinessException(StatusEnum.USER_TOKEN_INVALID);
        }
        Optional<EiDepart> eiDepart = eiDepartRepository.findById(companyId);
        if (!eiDepart.isPresent()) {
            throw new BusinessException("公司不存在");
        }

        EiDepart eiDepartm = eiDepart.get();
        EiDepartDto eiDepartDto = new EiDepartDto();
        eiDepartDto.setId(eiDepartm.getId());
        eiDepartDto.setHtLevel(eiDepartm.getHtLevel());
        eiDepartDto.setName(eiDepartm.getName());
        eiDepartDto.setType(eiDepartm.getType());
        eiDepartDto.setParentId(eiDepartm.getParentId());
        eiDepartDto.setLevel(eiDepartm.getLevel());
        eiDepartDto.setIds(eiDepartm.getIds());

        return eiDepartDto;
    }

    /**
     * 获取当前登录公司的id
     *
     * @return 当前登录公司信息
     */
    public CurrentCompanyDTO getCurrentCompanyInfo() {
        CurrentCompanyDTO currentCompanyDTO = new CurrentCompanyDTO();
        // 集团
        if (isCurrentGroup()) {
            currentCompanyDTO.setType(PlanConstant.ROLE_GROUP);
            currentCompanyDTO.setEiDepartDto(this.getCurrentGroupCompany());
        } else {
            // 保险公司
            currentCompanyDTO.setType(PlanConstant.ROLE_INSURER);
            currentCompanyDTO.setEiInsDepartDto(insurerClient.getCurrentInsurerCompany());
        }
        return currentCompanyDTO;
    }

    public EiUserDto getGroupUserInfo(String account) {
        return eiUserService.queryEiUserInfo(account);
    }

    public EiUser getGroupUserById(String userId) {
        return eiUserService.findOneById(userId);
    }

    public CurrentUserDTO getCurrentUserInfo() {
        CurrentUserDTO currentUserDTO = new CurrentUserDTO();
        if (isCurrentGroup()) {
            currentUserDTO.setType(PlanConstant.ROLE_GROUP);
            currentUserDTO.setEiUserDto(this.getCurrentUser());
        } else {
            currentUserDTO.setType(PlanConstant.ROLE_INSURER);
            currentUserDTO.setEiInsUserDto(insurerClient.getCurrentUser());
        }
        return currentUserDTO;
    }


    public String getDepartNameById(String id) {
        Optional<EiDepart> op = eiDepartService.findById(id);
        if (!op.isPresent()) {
            throw new BusinessException("部门不存在");
        }
        return op.get().getName();
    }

    public List<EiDepartDto> queryDepartListById(String id) {
        return eiDepartService.queryDepartListById(id);
    }

    private EiUserDto getCurrentUser() {
        String userName = this.getCurrentUserName();
        List<String> role = SecurityUtils.getLoginRole();
        // 交投集团
        if (PlanConstant.ROLE_GROUP.equals(role.get(0))) {
            return eiUserService.queryEiUserInfo(userName);
        }
        throw new BusinessException(StatusEnum.USER_TOKEN_INVALID);
    }

}
