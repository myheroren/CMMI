package com.huatonghh.base.domain;

import lombok.Data;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.util.Date;

/**
 * @author : Sun
 * @description : 通知中心
 * @date : 2019/11/5 20:52
 * @version : 1.0
 */
@Entity
@Table(name = "base_remind")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Data
public class BaseRemind {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "send_user_id")
    private String sendUserId;

    @Column(name = "send_user_name")
    private String sendUserName;

    @Column(name = "receive_user_id")
    private String receiveUserId;

    @Column(name = "receive_user_name")
    private String receiveUserName;

    @Column(name = "plan_no")
    private String planNo;

    @Column(name = "project_no")
    private String projectNo;

    @Column(name = "policy_no")
    private String policyNo;

    @Column(name = "claim_no")
    private String claimNo;

    @Column(name = "remind_outline")
    private String remindOutline;

    @Column(name = "remind_content")
    private String remindContent;

    @Column(name = "remind_level")
    private Byte remindLevel;

    @Column(name = "remind_type")
    private Byte remindType;

    @Column(name = "is_read")
    private Byte readStatus;

    @Column(name = "is_backlog")
    private Byte backlogStatus;

    @Column(name = "create_time")
    private Date createTime;

}
