package com.huatonghh.policy.service.dto.policy;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigInteger;

/**
 * Description : 车辆管理-方案信息
 *
 * @author : Sun
 * @version : 1.0
 * @date : 2019/8/31 14:01
 */
@Data
@ApiModel("保单管理-车辆方案信息")
public class PolicyVehRiskPlanDto implements Serializable {

    private static final long serialVersionUID = 4076218841513494126L;

    @ApiModelProperty(value = "自增id：新增不传、修改传")
    private Integer id;

    @ApiModelProperty(value = "保单号:必传")
    @NotNull
    private String policyNo;

    @ApiModelProperty(value = "险种代码")
    private String kindCode;

    @ApiModelProperty(value = "险别代码")
    private String riskCode;

    @ApiModelProperty(value = "险别名称")
    private String riskName;

    @ApiModelProperty(value = "保额")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger amount;
    @ApiModelProperty(value = "保费")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger premium;

    @ApiModelProperty(value = "主险附加险标志（1：主险，0：附加险）")
    private Boolean mainAdditionalFlag;

    @ApiModelProperty(value = "不计免赔标志（1：勾选，0：未勾选）")
    private Boolean deductible;

    @ApiModelProperty(value = "排序编号：先为空即可")
    private Integer sortNo;
}
