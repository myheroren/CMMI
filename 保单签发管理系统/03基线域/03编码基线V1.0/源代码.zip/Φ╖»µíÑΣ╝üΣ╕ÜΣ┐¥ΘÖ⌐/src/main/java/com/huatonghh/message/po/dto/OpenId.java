package com.huatonghh.message.po.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author ghy
 * Date: 2021/3/11 15:58
 */
@Data
@ApiModel("openId")
@AllArgsConstructor
@NoArgsConstructor
public class OpenId {

    @ApiModelProperty("openId")
    private String openId;
}
