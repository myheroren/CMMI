package com.huatonghh.file.domain;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * @author : Sun
 * @description : 审批附件表
 * @date : 2019/11/5 21:23
 * @version : 1.0
 */
@Entity
@Table(name = "fi_audit_file")
@Data
public class FiAuditFile implements Serializable {

    private static final long serialVersionUID = 8004645536162283986L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "audit_id")
    private Integer auditId;

    @Column(name = "file_id")
    private Integer fileId;

    @Column(name = "belong_id")
    private String belongId;

    @Column(name = "belong_type")
    private Byte belongType;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "upload_user")
    private String uploadUser;

    @Column(name = "upload_user_name")
    private String uploadUserName;

    @Column(name = "upload_link")
    private String uploadLink;

    @Column(name = "remark")
    private String remark;

    @Column(name = "is_valid")
    private Boolean valid;

    @Column(name = "is_preview")
    private Byte preview;

    @Column(name = "create_time")
    private Date createTime;


    public FiAuditFile() {
    }

    public FiAuditFile(Integer fileId, String belongId, Byte belongType, String fileName, String uploadUser, String uploadLink, String remark, Boolean valid, Byte preview, Date createTime) {
        this.fileId = fileId;
        this.belongId = belongId;
        this.belongType = belongType;
        this.fileName = fileName;
        this.uploadUser = uploadUser;
        this.uploadLink = uploadLink;
        this.remark = remark;
        this.valid = valid;
        this.preview = preview;
        this.createTime = createTime;
    }
}
