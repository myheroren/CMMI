package com.huatonghh.message.po.dto;

import com.google.common.base.MoreObjects;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author wanggl
 * @date 2020-11-02 20:29
 */
public class MessageThirdPartyDTO implements Serializable {

    private static final long serialVersionUID = -2513765581616492789L;

    @ApiModelProperty(value = "消息业务编号，调用方指定")
    private String serviceCode;

    @ApiModelProperty(value = "消息来源")
    private String source;

    @ApiModelProperty(value = "消息类型")
    private String type;

    @ApiModelProperty(value = "标题")
    private String title;

    @ApiModelProperty(value = "内容")
    private String content;

    @ApiModelProperty(value = "用户信息")
    private String userInfo;

    @ApiModelProperty(value = "url")
    private String url;

    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createTime;

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(String userInfo) {
        this.userInfo = userInfo;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
            .add("serviceCode", serviceCode)
            .add("source", source)
            .add("type", type)
            .add("title", title)
            .add("content", content)
            .add("userInfo", userInfo)
            .add("url", url)
            .add("createTime", createTime)
            .toString();
    }
}
