package com.huatonghh.empower.service.dto;

import com.huatonghh.file.service.dto.FiAuditFileDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author ghy
 * Date: 2021/1/8 9:01
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel("保单录入")
public class PolicySaveDTO {

    @ApiModelProperty("保单基本信息")
    private PolicyBaseInfoDTO policyBaseInfoDTO;

    @ApiModelProperty("保单工程险特殊字段信息")
    private PolicyEngineeringDTO policyEngineeringDTO;

    @ApiModelProperty("项目编号")
    private String projNo;

    @ApiModelProperty("发起公司")
    private String startCompany;

    @ApiModelProperty("文件id")
    private List<FiAuditFileDto> files;
}
