package com.huatonghh.policy.service.dto.policy;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigInteger;
import java.util.Date;

/**
 * description: 保单缴费期次
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/22
 */
@Data
@ApiModel("保单缴费期次")
public class PolicyPayPeriodDTO {
    @ApiModelProperty(value = "id")
    private BigInteger id;
    @ApiModelProperty(value = "保单号")
    private String policyNo;
    @ApiModelProperty(name = "期次")
    private Integer periodNo;
    @ApiModelProperty(name = "保险公司")
    private BigInteger belongCompany;
    @ApiModelProperty(name = "保险公司名字")
    private String belongCompanyName;
    @ApiModelProperty(name = "份额保费")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger portionPremium;
    @ApiModelProperty(value = "份额手续费")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger portionFee;
    @ApiModelProperty(value = "份额保费应收日期")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date premiumDueDate;
    @ApiModelProperty(value = "份额手续费应收日期")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date feeDueDate;
    @ApiModelProperty(value = "份额保费到账日期")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date premiumPayDate;
    @ApiModelProperty(value = "份额手续费到账日期")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date feePayDate;
    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    @ApiModelProperty(value = "更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;
}
