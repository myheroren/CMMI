package com.huatonghh.policy.service.dto.task;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/9/16
 */
@Data
@ApiModel("审核信息")
public class CheckDTO {

    @ApiModelProperty("操作类型、环节")
    private String operationType;
    @ApiModelProperty("操作人id")
    private String operator;
    @ApiModelProperty("操作人账号")
    private String operatorAccount;
    @ApiModelProperty("操作人中文名称")
    private String operatorName;
    @ApiModelProperty("任务id")
    private String taskId;
    @ApiModelProperty("审核结果")
    private String result;
    @ApiModelProperty("备注")
    private String remark;
    @ApiModelProperty("审批意见")
    private String idea;
    @ApiModelProperty("公司名称")
    private String company;
    @ApiModelProperty("操作时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date time;
}
