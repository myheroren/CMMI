package com.huatonghh.file.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

/**
 * @author : Sun
 * @version : 1.0
 * @description : 附件表-dto
 * @date : 2019/11/5 21:26
 */
@Data
@ApiModel(value = "附件信息表")
public class FiAuditFileDto implements Serializable {

    private static final long serialVersionUID = -6330437694671549490L;

    @ApiModelProperty(value = "信息表id，自增")
    private Integer auditId;

    @ApiModelProperty(value = "FastDfs文件表id")
    private Integer fileId;

    @ApiModelProperty(value = "附件名称，可录入，不录入时默认文件名")
    private String fileName;

    @ApiModelProperty(value = "附件名称，可录入，不录入时默认文件名")
    private String fileUrl;

    @ApiModelProperty(value = "上传人")
    private String uploadUser;

    @ApiModelProperty(value = "上传人中文名称")
    private String uploadUserName;

    @ApiModelProperty(value = "上传环节")
    private String uploadLink;

    @ApiModelProperty(value = "关联编号，计划编号/项目编号/保单号")
    @NotNull(message = "关联编号必填")
    private String belongId;

    @ApiModelProperty(value = "关联类型,1计划，2项目，3保单")
    @NotNull(message = "关联类型必填")
    private Byte belongType;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "是否失效；1有效, 0无效")
    private Boolean valid;

    @ApiModelProperty(value = "是否可预览；0不可预览, 1浏览器可直接预览，2微软OFFICE预览")
    private Byte preview;

    @ApiModelProperty(value = "上传时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;


    @ApiModelProperty(value = "FiFileDto：文件大小 long类型")
    @JsonSerialize(using = ToStringSerializer.class)
    private BigInteger fileSize;

    @ApiModelProperty(value = "FiFileDto：格式化fileSize")
    private String readableFileSize;

    public FiAuditFileDto() {
    }

    public FiAuditFileDto(Integer auditId, Integer fileId, String fileName, String uploadUser, String uploadUserName, String uploadLink, String belongId, Byte belongType, String remark, Boolean valid, Byte preview, Date createTime, BigInteger fileSize) {
        this.auditId = auditId;
        this.fileId = fileId;
        this.fileName = fileName;
        this.uploadUser = uploadUser;
        this.uploadUserName = uploadUserName;
        this.uploadLink = uploadLink;
        this.belongId = belongId;
        this.belongType = belongType;
        this.remark = remark;
        this.valid = valid;
        this.preview = preview;
        this.createTime = createTime;
        this.fileSize = fileSize;
    }
}
