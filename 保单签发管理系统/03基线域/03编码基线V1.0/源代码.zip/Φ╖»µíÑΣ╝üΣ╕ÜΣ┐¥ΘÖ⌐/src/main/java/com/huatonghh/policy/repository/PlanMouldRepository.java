package com.huatonghh.policy.repository;

import com.huatonghh.policy.domain.plan.PlanMouldEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigInteger;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/9/30
 */
public interface PlanMouldRepository extends JpaRepository<PlanMouldEntity, BigInteger> {

}
