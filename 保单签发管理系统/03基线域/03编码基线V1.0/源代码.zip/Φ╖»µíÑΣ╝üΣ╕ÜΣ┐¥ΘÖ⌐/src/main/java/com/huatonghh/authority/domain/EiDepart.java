package com.huatonghh.authority.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * @author : Sun
 * @description : 交投集团-部门公司-数据库映射实体
 * @date : 2019/11/4 19:41
 * @version : 1.0
 */
@Entity
@Table(name = "ei_depart")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Data
public class EiDepart implements Serializable {

    private static final long serialVersionUID = 2382896980380725919L;

    @Id
    @Column(name = "id")
    private String id;

    @Column(name = "name")
    private String name;

    @Column(name = "level")
    private String level;

    @Column(name = "parent_id")
    private String parentId;

    @Column(name = "ids")
    private String ids;

    @Column(name = "type")
    private String type;

    @Column(name = "ht_level")
    private String htLevel;


    @JsonIgnore
    @ManyToMany
    @JoinTable(
        name = "ei_depart_user",
        joinColumns = {@JoinColumn(name = "depart_id", referencedColumnName = "id")},
        inverseJoinColumns = {@JoinColumn(name = "user_id", referencedColumnName = "id")})
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @BatchSize(size = 30)
    private Set<EiUser> authorities = new HashSet<>();


    @Override
    public String toString() {
        return "EiDepart{" +
            "id=" + id +
            ", name='" + name + '\'' +
            ", parentId=" + parentId +
            '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof EiDepart)) {
            return false;
        }
        EiDepart eiDepart = (EiDepart) o;
        return Objects.equals(id, eiDepart.id) &&
            Objects.equals(name, eiDepart.name) &&
            Objects.equals(parentId, eiDepart.parentId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, parentId);
    }
}
