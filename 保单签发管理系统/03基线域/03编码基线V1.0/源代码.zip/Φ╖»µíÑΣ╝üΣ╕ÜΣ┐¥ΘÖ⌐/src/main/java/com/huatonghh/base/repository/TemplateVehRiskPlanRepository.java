package com.huatonghh.base.repository;

import com.huatonghh.base.domain.TemplateVehRiskPlan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author : Sun
 * @description : 方案配置表-数据仓库
 * @date : 2019/11/5 21:07
 * @version : 1.0
 */
public interface TemplateVehRiskPlanRepository extends JpaRepository<TemplateVehRiskPlan, Integer> {

    /**
     * 根据模板id查找方案列表
     *
     * @author Sun
     * @date 2019/11/5 20:59
     * @param templateId:
     * @return java.util.List<com.huatonghh.base.domain.TemplateVehRiskPlan>
     **/
    List<TemplateVehRiskPlan> findByTemplateId(Integer templateId);


    /**
     * 删除模板
     *
     * @author Sun
     * @date 2019/11/5 20:58
     * @param templateId: 模板id
     **/
    @Modifying
    @Query("delete from TemplateVehRiskPlan d where d.templateId = :templateId")
    @Transactional(rollbackFor = RuntimeException.class)
    void deleteByTemplateId(@Param("templateId") Integer templateId);
}
