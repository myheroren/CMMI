package com.huatonghh.message.repository;

import com.huatonghh.message.po.entity.MessageThirdParty;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * 第三方消息发送表(MessageThirdParty)数据库访问层
 *
 * @author wanggl
 * @since 2020-11-02 20:09:22
 */
public interface MessageThirdPartyRepository extends JpaRepository<MessageThirdParty, Long> {

}
