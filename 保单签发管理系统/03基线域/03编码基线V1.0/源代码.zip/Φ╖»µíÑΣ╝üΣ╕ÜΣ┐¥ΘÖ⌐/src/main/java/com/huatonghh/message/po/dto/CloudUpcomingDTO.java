package com.huatonghh.message.po.dto;

import com.huatonghh.message.constant.MessageConstant;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.LinkedList;
import java.util.List;

/**
 * 云之家待办消息DTO
 *
 * @author ghy
 * Date: 2021/3/11 9:39
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@ApiModel("云之家待办消息DTO")
public class CloudUpcomingDTO {

    @ApiModelProperty("点击待办跳转的URL")
    private String url;

    @ApiModelProperty("业务id")
    private String sourceId;

    @ApiModelProperty("待办内容")
    private String content;

    @ApiModelProperty("标题")
    private String title;

    @ApiModelProperty("待办内容")
    private String headImg;

    @ApiModelProperty("第三方应用id")
    private String appId;

    @ApiModelProperty("待办处理人id")
    private List<OpenId> params;

    @ApiModelProperty("请求方式:trur同步;false异步")
    private Boolean sync;

    public static CloudUpcomingDTO of() {
        return new CloudUpcomingDTO()
            .setSync(true)
            .setHeadImg(MessageConstant.headImg)
            .setAppId(MessageConstant.appId)
            .setUrl(MessageConstant.destUrl);
    }

    public static List<OpenId> setOpenIds(List<String> list) {
        List<OpenId> params = new LinkedList<>();
        list.forEach(str -> {
            params.add(new OpenId(str));
        });
        return params;
    }
}
