package com.huatonghh.authority.service;

import cn.hutool.core.util.IdUtil;
import com.google.common.collect.Lists;
import com.huatonghh.authority.constant.AuthorityConstant;
import com.huatonghh.authority.domain.EiDepart;
import com.huatonghh.authority.domain.EiHrDepart;
import com.huatonghh.authority.repository.EiDepartRepository;
import com.huatonghh.authority.repository.EiHrDepartRepository;
import com.huatonghh.authority.service.dto.EiDepartDto;
import com.huatonghh.authority.service.dto.EiDepartTreeDto;
import com.huatonghh.common.constant.enums.StatusEnum;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.service.dto.ResponseStringKeyValueDto;
import com.huatonghh.common.util.process.ProcessDtoToEntityUtil;
import com.huatonghh.common.util.process.ProcessEntityToDtoUtil;
import com.huatonghh.common.util.tree.BuildTree;
import com.huatonghh.common.util.tree.Tree;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;


/**
 * @author : Sun
 * @version : 1.0
 * @description : 部门管理业务层
 * @date : 2019/11/5 20:11
 */
@Service
@CacheConfig
@Slf4j
public class EiDepartService {

    private final EiDepartRepository eiDepartRepository;
    private final EiHrDepartRepository eiHrDepartRepository;

    private final ProcessDtoToEntityUtil processDtoToEntity;

    private final ProcessEntityToDtoUtil processEntityToDto;

    private final ModelMapper modelMapper;

    public EiDepartService(EiDepartRepository eiDepartRepository, EiHrDepartRepository eiHrDepartRepository, ProcessDtoToEntityUtil processDtoToEntity, ProcessEntityToDtoUtil processEntityToDto, ModelMapper modelMapper) {
        this.eiDepartRepository = eiDepartRepository;
        this.eiHrDepartRepository = eiHrDepartRepository;
        this.processDtoToEntity = processDtoToEntity;
        this.processEntityToDto = processEntityToDto;
        this.modelMapper = modelMapper;
    }


    /**
     * @param id:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiDepartTreeDto>
     * @author Sun
     * @description 获取部门二叉树列表
     * @date 2019/11/5 20:09
     **/
    @Cacheable(cacheNames = AuthorityConstant.EI_DEPARTS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null || #result.size() == 0")
    public List<EiDepartTreeDto> queryDepartTreeList(String id) {
        // 不指定即为查所有部门
        if (id == null) {
            id = AuthorityConstant.DEPART_TREE_HEAD_QYBX;
        }
        // 查询所有部门列表
        List<EiDepart> eiDepartList = eiDepartRepository.findParentDepartById(id);

        // 组装二叉树
        List<EiDepartTreeDto> eiDepartTreeDtoList = Lists.newArrayList();
        for (EiDepart eiDepart : eiDepartList) {
            // 获取最高层级部门
            if (id.equals(eiDepart.getId())) {
                EiDepartTreeDto eiDepartTreeDto = new EiDepartTreeDto();
                eiDepartTreeDto.setId(eiDepart.getId());
                eiDepartTreeDto.setName(eiDepart.getName());
                eiDepartTreeDto.setParentId(eiDepart.getParentId());
                // 放入新treeDto集合，并返回
                eiDepartTreeDto.setChildren(getChild(eiDepartTreeDto.getId(), eiDepartList));
                eiDepartTreeDtoList.add(eiDepartTreeDto);
            }
        }
        return eiDepartTreeDtoList;
    }


    /**
     * @param id:
     * @param eiDepartList:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiDepartTreeDto>
     * @author Sun
     * @description ei_depart 递归方法
     * @date 2019/11/5 20:09
     **/
    private List<EiDepartTreeDto> getChild(String id, List<EiDepart> eiDepartList) {
        List<EiDepartTreeDto> childList = Lists.newArrayList();
        for (EiDepart eiDepart : eiDepartList) {
            if (id.equals(eiDepart.getParentId())) {
                EiDepartTreeDto treeDepartDto = new EiDepartTreeDto();
                treeDepartDto.setId(eiDepart.getId());
                treeDepartDto.setName(eiDepart.getName());
                treeDepartDto.setParentId(eiDepart.getParentId());
                childList.add(treeDepartDto);
            }
        }
        // 递归，把子菜单的子菜单再循环一遍
        for (EiDepartTreeDto treeDepartDto : childList) {
            treeDepartDto.setChildren(getChild(treeDepartDto.getId(), eiDepartList));
        }
        // 递归退出条件
        if (childList.size() == 0) {
            return null;
        }
        return childList;
    }


    /**
     * @param id:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiDepartDto>
     * @author Sun
     * @description 根据部门id，查询所有子部门列表
     * @date 2019/11/5 20:08
     **/
    @Cacheable(cacheNames = AuthorityConstant.EI_DEPARTS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null || #result.size() == 0")
    public List<EiDepartDto> queryDepartListById(String id) {
        // 查询所有子部门列表
        List<EiDepart> eiDepartList = eiDepartRepository.findParentDepartById(id);
        return eiDepartList.stream().map(eiDepart -> processEntityToDto.depart(eiDepart, 1)).collect(Collectors.toList());
    }


    /**
     * @param id:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiDepartDto>
     * @author Sun
     * @description 根据父部门id，查询所有子部门列表
     * @date 2019/11/5 20:09
     **/
    public List<EiDepartDto> queryCompanyListByParentId(String id, String type) {
        List<EiDepart> eiDepartList = Lists.newArrayList();
        if("-1".equals(id)){
            // 查询所有子部门列表
            List<EiDepart> eiDepartList2 = eiDepartRepository.findCompanyByParentId(id, type);
            if (null != eiDepartList2) {
                eiDepartList.addAll(eiDepartList2);
            }
        }else {
            // 查自己
            Optional<EiDepart> op = eiDepartRepository.findById(id);
            if (!op.isPresent()) {
                return null;
            }

            eiDepartList.add(op.get());

            // 查询所有子部门列表
            List<EiDepart> eiDepartList2 = eiDepartRepository.findCompanyByDepartIdAndType(id, type);
            if (null != eiDepartList2) {
                eiDepartList.addAll(eiDepartList2);
            }
        }
        return eiDepartList.stream().map(eiDepart -> processEntityToDto.depart(eiDepart, 0)).collect(Collectors.toList());
    }

    /**
     * @param id:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiDepartDto>
     * @author Sun
     * @description 根据父部门id，查询所有子部门列表
     * @date 2019/11/5 20:09
     **/
    @Cacheable(cacheNames = AuthorityConstant.EI_DEPARTS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null || #result.size() == 0")
    public List<EiDepartDto> queryDepartListByParentId(String id) {
        // 查询所有子部门列表
        List<EiDepart> eiDepartList = eiDepartRepository.findParentDepartByDepartId(id);
        return eiDepartList.stream().map(eiDepart -> processEntityToDto.depart(eiDepart, 0)).collect(Collectors.toList());
    }


    /**
     * @author Sun
     * @description 清除缓存
     * @date 2019/11/5 20:08
     **/
    @CacheEvict(cacheNames = AuthorityConstant.EI_DEPARTS_BY_LOGIN_CACHE, allEntries = true)
    public void clearCache() {
        log.info("清除缓存成功！！！");
    }


    /**
     * @param departId: 部门id
     * @author Sun
     * @description 删除部门
     * @date 2019/11/5 20:08
     **/
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(cacheNames = AuthorityConstant.EI_DEPARTS_BY_LOGIN_CACHE, allEntries = true)
    public void delete(String departId) {
        try {
            Optional<EiDepart> byId = eiDepartRepository.findById(departId);
            if (byId.isPresent()) {
                String ids = byId.get().getIds();
                // 先删除中间表
                eiDepartRepository.deleteDepartUser(ids);
                eiDepartRepository.deleteDepart(ids);
            }
        } catch (Exception e) {
            log.error(StatusEnum.AUTHORITY_DELETE_DEPART_ERROR.getMessage() + ": {}", e.getMessage());
            throw new BusinessException(StatusEnum.AUTHORITY_DELETE_DEPART_ERROR);
        }
    }


    /**
     * @param departId: 公司id
     * @return java.util.List<com.huatonghh.common.util.tree.Tree < com.huatonghh.authority.service.dto.EiDepartDto>>
     * @author Sun
     * @description 根据当前公司id组装 当前公司及所有子公司树形图
     * @date 2019/11/5 20:01
     **/
    public List<Tree<EiDepartDto>> getTree(String departId, List<EiDepartDto> eiDepartDtoList) {
        // 组装数据
        List<Tree<EiDepartDto>> trees = new ArrayList<>();
        for (EiDepartDto ei : eiDepartDtoList) {
            Tree<EiDepartDto> tree = new Tree<>();
            tree.setId(ei.getId());
            tree.setParentId(ei.getParentId());
            tree.setText(ei.getName());
            Map<String, Object> state = new HashMap<>(16);
            state.put("opened", true);
            tree.setState(state);
            trees.add(tree);
        }

        // 不指定即为查所有部门
        if (StringUtils.isBlank(departId)) {
            departId = AuthorityConstant.DEPART_TREE_HEAD_QYBX_GENERAL;
        }

        // 根据父id查二叉树
        return BuildTree.build(trees, departId, 0);
    }

    /**
     * @param departId: 公司id
     * @return java.util.List<com.huatonghh.common.util.tree.Tree < com.huatonghh.authority.service.dto.EiDepartDto>>
     * @author Sun
     * @description 根据当前公司id组装 当前公司及所有子公司树形图
     * @date 2019/11/5 20:01
     **/
    public List<Tree<EiDepartDto>> getTree(String departId, List<EiDepartDto> eiDepartDtoList, int type) {
        // 组装数据
        List<Tree<EiDepartDto>> trees = new ArrayList<>();
        for (EiDepartDto ei : eiDepartDtoList) {
            Tree<EiDepartDto> tree = new Tree<>();
            tree.setId(ei.getId());
            tree.setParentId(ei.getParentId());
            tree.setText(ei.getName());
            Map<String, Object> state = new HashMap<>(16);
            state.put("opened", true);
            tree.setState(state);
            trees.add(tree);
        }

        // 不指定即为查所有部门
        if (StringUtils.isBlank(departId)) {
            departId = AuthorityConstant.DEPART_TREE_HEAD_QYBX_GENERAL;
        }

        // 根据父id查二叉树
        return BuildTree.build(trees, departId, type);
    }

    /**
     * @param eiDepartDto:
     * @return com.huatonghh.authority.service.dto.EiDepartDto
     * @author Sun
     * @description 部门信息保存
     * @date 2019/11/5 20:08
     **/
    @CacheEvict(cacheNames = AuthorityConstant.EI_DEPARTS_BY_LOGIN_CACHE, allEntries = true)
    @Transactional(rollbackFor = RuntimeException.class)
    public EiDepartDto saveDepart(EiDepartDto eiDepartDto) {
        if (StringUtils.isBlank(eiDepartDto.getId())) {
            eiDepartDto.setId(IdUtil.simpleUUID());
        }
        EiDepart eiDepart = processDtoToEntity.depart(eiDepartDto, 0);
        // 校验父部门是否存在
        String parentId = eiDepart.getParentId();
        if (StringUtils.isBlank(parentId) || "-1".equals(parentId)) {
            eiDepart.setParentId("-1");
            eiDepart = eiDepartRepository.save(eiDepart);
            eiDepart.setIds(eiDepart.getId() + ";");
            eiDepart = eiDepartRepository.save(eiDepart);
            return processEntityToDto.depart(eiDepart, 0);
        } else {
            Optional<EiDepart> byId = eiDepartRepository.findById(parentId);
            if (!byId.isPresent()) {
                throw new BusinessException("父部门不存在");
            }
            eiDepart = eiDepartRepository.save(eiDepart);
            eiDepart.setIds(byId.get().getIds() + eiDepart.getId() + ";");
            eiDepart = eiDepartRepository.save(eiDepart);
            return processEntityToDto.depart(eiDepart, 0);
        }
    }


    /**
     * @param eiDepartDtos:
     * @return java.util.List<com.huatonghh.authority.domain.EiDepart>
     * @author Sun
     * @description 部门信息批量保存
     * @date 2019/11/5 20:08
     **/
    @CacheEvict(cacheNames = AuthorityConstant.EI_DEPARTS_BY_LOGIN_CACHE, allEntries = true)
    @Transactional(rollbackFor = RuntimeException.class)
    public List<EiDepart> saveBatchDepart(List<EiDepartDto> eiDepartDtos) {
        List<EiDepart> eiDeparts = eiDepartDtos.stream().map(eiDepartDto -> processDtoToEntity.depart(eiDepartDto, 1)).collect(Collectors.toList());
        return eiDepartRepository.saveAll(eiDeparts);
    }


    public Optional<EiDepart> findById(String id) {
        return eiDepartRepository.findById(id);
    }

    public List<EiDepart> findAllByParentId(String id) {
        return eiDepartRepository.findAllByParentId(id);
    }

    public List<EiDepart> findAllByHtLevelAndType(String htLevel, String type) {
        return eiDepartRepository.findAllByHtLevelAndType(htLevel, type);
    }

    /**
     * @return java.util.List<com.huatonghh.authority.service.dto.EiDepartDto>
     * @author Sun
     * @description 获取所有部门列表，并转为Dto
     * @date 2019/11/5 20:05
     **/
    public List<EiDepartDto> findAllDepartList() {
        // 查询所有部门列表
        List<EiDepart> eiDepartList = eiDepartRepository.findAll();

        // 转为DTO
        return eiDepartList.stream().map(eiDepart -> processEntityToDto.depart(eiDepart, 0)).collect(Collectors.toList());
    }

    /**
     * @return java.util.List<com.huatonghh.authority.service.dto.EiDepartDto>
     * @author Sun
     * @description 获取所有部门列表，并转为Dto
     * @date 2019/11/5 20:05
     **/
    public List<EiDepartDto> findAllDepartListByDepartId(String id) {
        // 查询指定公司部门列表
        List<EiDepart> eiDepartList = eiDepartRepository.findParentDepartById(id);

        // 转为DTO
        return eiDepartList.stream().map(eiDepart -> processEntityToDto.depart(eiDepart, 0)).collect(Collectors.toList());
    }


    /**
     * @param departId: 部门id
     * @return com.huatonghh.authority.domain.EiDepart
     * @author Sun
     * @description 获取部门信息，并校验是否存在
     * @date 2019/11/6 14:14
     **/
    @Cacheable(cacheNames = AuthorityConstant.EI_DEPARTS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null")
    public EiDepart findByIdCheckOptional(String departId) {
        Optional<EiDepart> eiDepartOptional = eiDepartRepository.findById(departId);
        if (!eiDepartOptional.isPresent()) {
            throw new BusinessException("集团未检索到该部门：", departId);
        }
        return eiDepartOptional.get();
    }


    /**
     * @param departId: 部门id
     * @return java.lang.String
     * @author Sun
     * @description 根据部门id，获取部门id、名称key value数据集， 并返回部门名称
     * @date 2019/11/6 15:56
     **/
    @Cacheable(cacheNames = AuthorityConstant.EI_DEPARTS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null")
    public String queryNameById(String departId) {
        List<ResponseStringKeyValueDto> responseStringKeyValueDtoList = eiDepartRepository.queryNameById(departId);
        if (responseStringKeyValueDtoList != null && responseStringKeyValueDtoList.size() > 0) {
            return responseStringKeyValueDtoList.get(0).getValue();
        }
        return null;
    }

    @Cacheable(cacheNames = AuthorityConstant.EI_DEPARTS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null")
    public String queryIdByName(String name) {
        List<ResponseStringKeyValueDto> responseStringKeyValueDtoList = eiDepartRepository.queryIdByName(name);
        if (responseStringKeyValueDtoList != null && responseStringKeyValueDtoList.size() > 0) {
            return responseStringKeyValueDtoList.get(0).getValue();
        }
        return null;
    }


    /**
     * @param eiDepartDtos:
     * @return java.util.List<com.huatonghh.authority.domain.EiDepart>
     * @author Sun
     * @description 部门信息批量保存，用于人力资源同步，不会涉及关联表
     * @date 2019/11/5 20:08
     **/
    @CacheEvict(cacheNames = AuthorityConstant.EI_DEPARTS_BY_LOGIN_CACHE, allEntries = true)
    @Transactional(rollbackFor = RuntimeException.class)
    public List<EiHrDepart> saveBatchHrDepart(List<EiDepartDto> eiDepartDtos) {
        List<EiHrDepart> eiHrDeparts = processDtoToEntity.hrDepart(eiDepartDtos);
        return eiHrDepartRepository.saveAll(eiHrDeparts);
    }


    /**
     * @author Sun
     * @description 更新全表ids
     * @date 2019/11/28 14:56
     **/
    public List<EiDepartDto> updateAllIds(List<EiDepartDto> eiDepartDtoList) {
        List<EiDepartDto> collect = eiDepartDtoList.stream().filter(eiDepartDto -> "-1".equals(eiDepartDto.getParentId())).collect(Collectors.toList());

        for (EiDepartDto eiDepartDto : collect) {
            String id = eiDepartDto.getId();
            String ids = "";
            for (EiDepartDto child : eiDepartDtoList) {
                if (id.equals(child.getId())) {
                    child.setIds(id + ";");
                    ids = child.getIds();
                }
            }
            // 递归赋值
            eiDepartDtoList = recursiveProcess(new EiDepartDto(id, null, "-1", ids), eiDepartDtoList);
        }

        return eiDepartDtoList;
    }


    /**
     * @param e:
     * @param list:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiDepartDto>
     * @author Sun
     * @description 递归组装ids
     * @date 2019/11/28 15:00
     **/
    public List<EiDepartDto> recursiveProcess(EiDepartDto e, List<EiDepartDto> list) {
        for (EiDepartDto child : list) {
            if (e.getId().equals(child.getParentId())) {
                child.setIds(e.getIds() + child.getId() + ";");
                list = recursiveProcess(child, list);
            }
        }
        return list;
    }

    /**
     * 需求报送列表页面下拉列表
     * @return
     */
    public List<EiDepartTreeDto> findAllDepartNameAndId() {
        return eiDepartRepository.findNameAndId();
    }

}
