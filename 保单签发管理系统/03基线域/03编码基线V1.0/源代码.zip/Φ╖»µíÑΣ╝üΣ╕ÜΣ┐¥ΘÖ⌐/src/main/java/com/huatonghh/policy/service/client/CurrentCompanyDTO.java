package com.huatonghh.policy.service.client;

import com.huatonghh.authority.service.dto.EiDepartDto;
import com.huatonghh.ins_authority.service.dto.EiInsDepartDto;
import lombok.Data;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/16
 */
@Data
public class CurrentCompanyDTO {
    /**
     * 1集团,2保险公司
     */
    private String type;
    private EiInsDepartDto eiInsDepartDto;
    private EiDepartDto eiDepartDto;
}
