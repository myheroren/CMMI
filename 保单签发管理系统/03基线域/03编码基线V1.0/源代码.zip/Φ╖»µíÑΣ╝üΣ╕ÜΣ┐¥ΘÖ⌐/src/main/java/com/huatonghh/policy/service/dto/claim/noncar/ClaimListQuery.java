package com.huatonghh.policy.service.dto.claim.noncar;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/11
 */
@Data
@ApiModel("非车理赔列表查询条件")
public class ClaimListQuery {
    @ApiModelProperty("当前页数")
    @NotNull(message = "当前页数不能为空！")
    public Integer pageNo;

    @ApiModelProperty("每页显示数据条数")
    @NotNull(message = "分页大小不能为空！")
    public Integer pageSize;

    @ApiModelProperty(value = "保单号")
    private String policyNo;

    @ApiModelProperty(value = "投保人")
    private String holderName;

    @ApiModelProperty(value = "被保人")
    private String insuredName;


    @ApiModelProperty(value = "所属分公司")
    private String startCompany;

    @ApiModelProperty(value = "保险公司")
    private String belongCompany;

    @ApiModelProperty(value = "出险查询起期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date accidentStartTime;

    @ApiModelProperty(value = "出险查询止期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date accidentEndTime;

    @ApiModelProperty(value = "出险查询起期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date reportStartTime;

    @ApiModelProperty(value = "出险查询止期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date reportEndTime;

    @ApiModelProperty(value = "状态")
    private String status;

    @ApiModelProperty(value = "车或非车标识：1车、0非车，必传")
    private Byte carUncarFlag;

    @ApiModelProperty(value = "保险类别")
    private String insuranceCategory;

    @ApiModelProperty(value = "险种代码: 0工程险；1团意险；2安责险；3雇主责任险")
    private String kindCode;

    @ApiModelProperty(value = "理赔编号")
    private String reportId;

    @ApiModelProperty(value = "排序方式，0，代表逆序，1表示正序")
    @NotNull(message = "排序方式，不能为空")
    private Integer range;

    @ApiModelProperty(value = "排序字段名称，必须是驼峰标志")
    @NotNull(message = "排序字段名称，不能为空")
    private String column;

    @ApiModelProperty(value = "理赔报案id数组")
    private List<Long> ids;
}
