package com.huatonghh.ins_authority.service.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.huatonghh.authority.service.dto.EiRoleDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * @author : Sun
 * @description : 
 * @date : 2019/11/5 21:39
 * @version : 1.0
 */
@Data
@ApiModel(value = "保险公司用户")
public class EiInsUserDto implements Serializable {

    private static final long serialVersionUID = -8549990517170989494L;

    @ApiModelProperty(value = "用户ID")
    private Integer id;

    @ApiModelProperty(value = "登录账户")
    @NotNull
    private String userName;

    @JsonIgnore
    @ApiModelProperty(value = "用户密码")
    private String userPassword;

    @ApiModelProperty(value = "员工编号")
    private String employeeNo;

    @ApiModelProperty(value = "职位：1、领导；2、员工")
    private Byte position;

    @ApiModelProperty(value = "中文名字")
    private String name;

    @ApiModelProperty(value = "性别")
    private Boolean gender;

    @ApiModelProperty(value = "身份证号")
    private String idCard;

    @ApiModelProperty(value = "手机号")
    private String phoneNo;

    @ApiModelProperty(value = "邮箱")
    private String email;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "是否生效")
    private Boolean valid;

    @ApiModelProperty(value = "用户所属角色")
    private Set<EiRoleDto> authorities = new HashSet<>();

    @ApiModelProperty(value = "用户所属部门")
    private Set<EiInsDepartDto> authoritiesDepart = new HashSet<>();

}
