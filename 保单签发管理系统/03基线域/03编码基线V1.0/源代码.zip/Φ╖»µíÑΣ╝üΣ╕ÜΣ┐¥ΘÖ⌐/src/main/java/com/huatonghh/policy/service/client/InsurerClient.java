package com.huatonghh.policy.service.client;

import com.huatonghh.authority.security.SecurityUtils;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.ins_authority.domain.EiInsDepart;
import com.huatonghh.ins_authority.service.EiInsDepartService;
import com.huatonghh.ins_authority.service.EiInsUserService;
import com.huatonghh.ins_authority.service.dto.EiInsDepartDto;
import com.huatonghh.ins_authority.service.dto.EiInsUserDto;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/15
 */
@Service
@AllArgsConstructor
public class InsurerClient {
    private final EiInsDepartService eiInsDepartService;
    private final EiInsUserService eiInsUserService;

    public String getBelongCompanyNameById(Integer id) {
        Optional<EiInsDepart> op = eiInsDepartService.findById(id);
        if (!op.isPresent()) {
           return null;
        }
        return op.get().getName();
    }

    public EiInsDepartDto getCurrentInsurerCompany() {
        // 取当前登录人的公司
        EiInsUserDto user = this.queryEiUserInfo(this.getCurrentUserName());
        Set<EiInsDepartDto> departSet = user.getAuthoritiesDepart();
        if (null == departSet || departSet.size() <= 0) {
            throw new BusinessException("当前登录账户所属公司有误");
        }
        List<EiInsDepartDto> departList = new ArrayList<>(departSet);
        return departList.get(0);
    }

    public String getCurrentUserName() {
        Optional<String> currentUserLogin = SecurityUtils.getCurrentUserLogin();
        if (!currentUserLogin.isPresent()) {
            throw new BusinessException("当前登录人信息丢失，请检查");
        }
        return currentUserLogin.get();
    }

    public EiInsUserDto getCurrentUser() {
        return this.queryEiUserInfo(this.getCurrentUserName());
    }

    public EiInsUserDto queryEiUserInfo(String userName) {
        return eiInsUserService.queryEiUserInfo(userName);
    }
}
