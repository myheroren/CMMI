package com.huatonghh.authority.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Column;
import java.io.Serializable;

/**
 * @author : Sun
 * @description : 菜单权限对象
 * @date : 2019/11/4 21:10
 * @version : 1.0
 */
@Data
@ApiModel(value = "菜单权限对象")
public class EiAuthorityDto implements Serializable {

    private static final long serialVersionUID = -5122917180293894124L;

    @ApiModelProperty(value = "菜单权限id")
    private Integer id;

    @ApiModelProperty(value = "前端路由组件")
    private String component;

    @ApiModelProperty(value = "路由名称")
    private String name;

    @ApiModelProperty(value = "状态")
    private String status;

    @ApiModelProperty(value = "标题")
    private String title;

    @ApiModelProperty(value = "图标")
    private String icon;

    @ApiModelProperty(value = "是否生效")
    private Boolean visible;

    @ApiModelProperty(value = "上级菜单id")
    private Integer parentId;

}
