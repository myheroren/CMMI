package com.huatonghh.authority.service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.security.core.GrantedAuthority;

import java.util.List;

/**
 * @author : Sun
 * @description : token实体
 * @date : 2019/11/4 21:11
 * @version : 1.0
 */
public class JWTToken {

    private String idToken;

    private List<String> loginRoles;

    public JWTToken(String idToken, List<String> loginRoles) {
        this.idToken = idToken;
        this.loginRoles = loginRoles;
    }

    @JsonProperty("id_token")
    String getIdToken() {
        return idToken;
    }

    void setIdToken(String idToken) {
        this.idToken = idToken;
    }

    @JsonProperty("login_role")
    List<String> getLoginRoles() {
        return loginRoles;
    }

    void setLoginRoles(List<String> loginRoles) {
        this.loginRoles = loginRoles;
    }
}
