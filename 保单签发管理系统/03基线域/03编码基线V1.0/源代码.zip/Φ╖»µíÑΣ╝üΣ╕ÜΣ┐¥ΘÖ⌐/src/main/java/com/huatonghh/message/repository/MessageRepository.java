package com.huatonghh.message.repository;

import com.huatonghh.message.po.entity.Message;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;

import java.util.List;

/**
 * 消息主体表(Message)数据库访问层
 *
 * @author wanggl
 * @since 2020-11-02 20:09:22
 */
public interface MessageRepository extends JpaRepository<Message, Long>, QuerydslPredicateExecutor<Message> {

    List<Message> findBySource(String source);

}
