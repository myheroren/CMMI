package com.huatonghh.empower.service.impl;

import cn.hutool.core.util.NumberUtil;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.util.BeanCopierUtils;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.common.util.system.PageParam;
import com.huatonghh.empower.service.EmpowerQuery;
import com.huatonghh.empower.service.EmpowerService;
import com.huatonghh.empower.service.dto.FileQuery;
import com.huatonghh.empower.service.dto.PolicyBaseInfoDTO;
import com.huatonghh.empower.service.dto.PolicyEngineeringDTO;
import com.huatonghh.empower.service.dto.PolicySaveDTO;
import com.huatonghh.file.constant.FileConstant;
import com.huatonghh.file.domain.FiAuditFile;
import com.huatonghh.file.repository.FiAuditFileRepository;
import com.huatonghh.file.service.dto.FiAuditFileDto;
import com.huatonghh.policy.constant.PlanConstant;
import com.huatonghh.policy.constant.PolicyConstant;
import com.huatonghh.policy.domain.policy.PolicyEngineerSpecial;
import com.huatonghh.policy.domain.policy.PolicyMain;
import com.huatonghh.policy.domain.project.ProjectEntity;
import com.huatonghh.policy.repository.ProjectRepository;
import com.huatonghh.policy.repository.policy.PolicyEngineerSpecialRepository;
import com.huatonghh.policy.repository.policy.PolicyMainRepository;
import com.huatonghh.policy.service.client.UserClient;
import com.huatonghh.policy.service.dto.project.ProjectDTO;
import com.huatonghh.policy.util.ProxyUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFactory;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static cn.hutool.core.date.DateUtil.parseDateTime;

/**
 * @author ghy
 * Date: 2021/1/6 17:15
 */
@Service
@Slf4j
@AllArgsConstructor
@Transactional(rollbackFor = RuntimeException.class, propagation = Propagation.REQUIRED)
public class EmpowerServiceImpl implements EmpowerService {

    private final ProjectRepository projectRepository;
    private final UserClient userClient;
    private final FiAuditFileRepository fiAuditFileRepository;
    private final PolicyMainRepository policyMainRepository;
    private final PolicyEngineerSpecialRepository policyEngineerSpecialRepository;
    private final MapperFactory mapperFactory;

    /**
     * 授权列表-组装DTO列表
     *
     * @return
     */
    @Override
    public PageInfo<ProjectDTO> list(PageParam<EmpowerQuery> pageParam) {
        List<ProjectEntity> pageList = this.getPageList(pageParam);

        List<ProjectDTO> list = new ArrayList<>();
        pageList.forEach(project -> {
            ProjectDTO projectDTO = new ProjectDTO();
            BeanCopierUtils.copy(project, projectDTO);
            list.add(projectDTO);
        });
        return PageInfo.of(pageParam.getPageNum(), pageParam.getPageSize(), list, (long) list.size());
    }

    /**
     * 授权列表-分页条件查询
     *
     * @return
     */
    @Override
    public List<ProjectEntity> getPageList(PageParam<EmpowerQuery> pageParam) {
        Integer id = userClient.getCurrentCompanyInfo().getEiInsDepartDto().getId();
        EmpowerQuery empowerQuery = pageParam.getParams();

        ProjectEntity projectEntity = new ProjectEntity();
        BeanCopierUtils.copy(empowerQuery, projectEntity);
        projectEntity.setBelongCompany(String.valueOf(id));

        Pageable pageable = PageRequest.of(pageParam.getPageNum() - 1, pageParam.getPageSize(), Sort.Direction.DESC, "createTime");
        ExampleMatcher matcher = ExampleMatcher.matching()
            //项目编号全模糊，其余的全部精准匹配
            .withMatcher("projNo", ExampleMatcher.GenericPropertyMatchers.contains());
        Example<ProjectEntity> example = Example.of(projectEntity, matcher);
        Page<ProjectEntity> page = projectRepository.findAll(example, pageable);
        return page.getContent();
    }

    @Override
    public List<FiAuditFileDto> fileList(FileQuery fileQuery) {
        List<FiAuditFile> fileList = fiAuditFileRepository.findAllByBelongIdAndBelongTypeAndValidOrderByCreateTimeDesc(fileQuery.getPolicyNo(), PlanConstant.BELONG_TYPE_POLICY, true);
        Optional<FiAuditFile> empowerFileOpt = fiAuditFileRepository.findByFileId(fileQuery.getFileId());
        FiAuditFileDto empowerFile = new FiAuditFileDto();
        empowerFileOpt.ifPresent(fiAuditFile -> BeanCopierUtils.copy(fiAuditFile, empowerFile));

        ArrayList<FiAuditFileDto> files = new ArrayList<>();
        fileList.forEach(file -> {
            FiAuditFileDto fiAuditFileDto = new FiAuditFileDto();
            BeanCopierUtils.copy(file, fiAuditFileDto);
            files.add(fiAuditFileDto);
        });
        files.add(empowerFile);
        return files;
    }

    /**
     * 页面录入保单
     *
     * @return
     */
    @Override
    public Object savePolicy(PolicySaveDTO policySaveDTO) {
        PolicyBaseInfoDTO policyBaseInfoDTO = policySaveDTO.getPolicyBaseInfoDTO();
        if (policyBaseInfoDTO.getPolicyNo() == null) {
            throw new BusinessException("保单号不能为空!");
        }
        log.info("保单同步接口-保单基本信息数据:{}", policyBaseInfoDTO);

        PolicyEngineeringDTO policyEngineeringDTO = policySaveDTO.getPolicyEngineeringDTO();
        log.info("保单同步接口-工程险特殊字段信息数据:{}", policyEngineeringDTO);

        savePolicyAndEngineering(policyBaseInfoDTO, policyEngineeringDTO, policySaveDTO.getStartCompany());

        //保单号关联项目编号
        String projNo = policySaveDTO.getProjNo();
        Optional<ProjectEntity> byId = projectRepository.findById(projNo);
        byId.ifPresent(projectEntity -> projectEntity.setPolicyNo(policyBaseInfoDTO.getPolicyNo()));

        //关联附件
        savePlanFileAuditDetail(policySaveDTO.getFiles(), policyBaseInfoDTO.getPolicyNo());
        return null;
    }

    /**
     * Description : 保存附件列表信息
     *
     * @author : Sun
     * @date : 2019/9/27 10:35
     */
    public void savePlanFileAuditDetail(List<FiAuditFileDto> fiAuditFileDtos, String belongId) {

        Byte belongType;
        if (fiAuditFileDtos == null || fiAuditFileDtos.isEmpty()) {
            return;
        } else {
//            belongId = fiAuditFileDtos.get(0).getBelongId();
            belongType = fiAuditFileDtos.get(0).getBelongType();
        }

        // 判断所有
        for (FiAuditFileDto fiAuditFileDto : fiAuditFileDtos) {
            if (!belongId.equals(fiAuditFileDto.getBelongId())) {
                fiAuditFileDto.setBelongId(belongId);
//                throw new BusinessException(StatusEnum.POLICY_BELONG_ID_DIFFERENT);
            }
            if (!PlanConstant.BELONG_TYPE_POLICY.equals(fiAuditFileDto.getBelongType())) {
                throw new BusinessException("附件类型不是保单类型!");
            }
        }

        // 删除现有关联附件信息
        fiAuditFileRepository.deleteByBelongIdAndType(belongId, belongType);

        // Dto转换为entity
        mapperFactory.classMap(FiAuditFileDto.class, FiAuditFile.class).byDefault().register();
        List<FiAuditFile> fiAuditFiles = mapperFactory.getMapperFacade().mapAsList(fiAuditFileDtos, FiAuditFile.class);
        fiAuditFileRepository.saveAll(fiAuditFiles);
        log.info("保存计划附件列表信息success!!!");
    }

    /**
     * 保存保单基本信息跟工程险特殊字段信息
     */
    @Override
    public void savePolicyAndEngineering(PolicyBaseInfoDTO policyBaseInfoDTO, PolicyEngineeringDTO policyEngineeringDTO, String startCompany) {
        PolicyMain policyMain = new PolicyMain();

        Optional<PolicyMain> policyMainOptional = policyMainRepository.findByPolicyNo(policyBaseInfoDTO.getPolicyNo());
        if (policyMainOptional.isPresent()) {
            throw new BusinessException("保单号已存在");
        }

        policyMain.setPolicyNo(policyBaseInfoDTO.getPolicyNo());
        policyMain.setCarUncarFlag((byte) 0);
        policyMain.setInsuranceCategory((policyBaseInfoDTO.getInsuranceCategory()));
        policyMain.setKindCode(policyBaseInfoDTO.getKindCode());

        if (policyMain.getCreateTime() == null) {
            policyMain.setCreateTime(new Date());
        }
        policyMain.setUpdateTime(new Date());

        policyMain.setHolderName(policyBaseInfoDTO.getHolderName());
        policyMain.setHolderCertificateType(policyBaseInfoDTO.getHolderCertificateType());
        policyMain.setHolderCertificateNumber(policyBaseInfoDTO.getHolderCertificateNumber());

        policyMain.setInsuredName(policyBaseInfoDTO.getInsuredName());
        policyMain.setInsuredCertificateType(policyBaseInfoDTO.getInsuredCertificateType());
        policyMain.setInsuredCertificateNumber(policyBaseInfoDTO.getInsuredCertificateNumber());

        policyMain.setStartCompany(startCompany);
        policyMain.setBelongCompany(policyBaseInfoDTO.getBelongCompany());
        policyMain.setBelongCompanyName(policyBaseInfoDTO.getBelongCompanyName());

        policyMain.setTotalPremium(BigInteger.valueOf(new Double(NumberUtil.mul(policyBaseInfoDTO.getTotalPremium(), new Double(100))).longValue()));
        policyMain.setTotalAmount(BigInteger.valueOf(new Double(NumberUtil.mul(policyBaseInfoDTO.getTotalAmount(), new Double(100))).longValue()));

        policyMain.setProjectContractAmount(BigInteger.valueOf(new Double(NumberUtil.mul(policyBaseInfoDTO.getProjectContractAmount(), new Double(100))).longValue()));
        policyMain.setRate(BigDecimal.valueOf(policyBaseInfoDTO.getRate() == null ? 0.00 : policyBaseInfoDTO.getRate()));
        policyMain.setTotalFund(BigInteger.valueOf(new Double(NumberUtil.mul(policyBaseInfoDTO.getTotalFund(), new Double(100))).longValue()));
        policyMain.setUsedFund(BigInteger.valueOf(new Double(NumberUtil.mul(policyBaseInfoDTO.getUsedFund(), new Double(100))).longValue()));
        policyMain.setLeftFund(BigInteger.valueOf(new Double(NumberUtil.mul(policyBaseInfoDTO.getLeftFund(), new Double(100))).longValue()));

        policyMain.setPolicyApplyTime(policyBaseInfoDTO.getPolicyApplyTime());
        policyMain.setPolicyBgnTime(policyBaseInfoDTO.getPolicyBgnTime());
        policyMain.setPolicyEndTime(policyBaseInfoDTO.getPolicyEndTime());
        policyMain.setStatus(PolicyConstant.POLICY_STATUS_VALID);

        //当前时间戳作为导入批次号
//        policyMain.setImportBatchNo(new BigInteger(String.valueOf(System.currentTimeMillis())));

        PolicyEngineerSpecial policyEngineerSpecial = new PolicyEngineerSpecial();

        PolicyEngineerSpecial dbPolicyEngineerSpecial = policyEngineerSpecialRepository.findByPolicyNo(policyEngineeringDTO.getPolicyNo());
        if (dbPolicyEngineerSpecial != null) {
            policyEngineerSpecial = dbPolicyEngineerSpecial;
        }
        policyEngineerSpecial.setAccumulativeCompensationLimit(BigInteger.valueOf(new Double(NumberUtil.mul(policyEngineeringDTO.getAccumulativeCompensationLimit(), new Double(100))).longValue()));
        policyEngineerSpecial.setSingleCompensationLimit(BigInteger.valueOf(new Double(NumberUtil.mul(policyEngineeringDTO.getSingleCompensationLimit(), new Double(100))).longValue()));
        policyEngineerSpecial.setPerPersonSingleCompensationLimit(BigInteger.valueOf(new Double(NumberUtil.mul(policyEngineeringDTO.getPerPersonSingleCompensationLimit(), new Double(100))).longValue()));
        policyEngineerSpecial.setAccidentalDeathDisabilityCoverage(BigInteger.valueOf(new Double(NumberUtil.mul(policyEngineeringDTO.getAccidentalDeathDisabilityCoverage(), new Double(100))).longValue()));
        policyEngineerSpecial.setAccidentalMedicalCoverage(BigInteger.valueOf(new Double(NumberUtil.mul(policyEngineeringDTO.getAccidentalMedicalCoverage(), new Double(100))).longValue()));
        policyEngineerSpecial.setDiseaseDeathInsurance(BigInteger.valueOf(new Double(NumberUtil.mul(policyEngineeringDTO.getDiseaseDeathInsurance(), new Double(100))).longValue()));

        policyEngineerSpecial.setPolicyNo(policyBaseInfoDTO.getPolicyNo());

        policyEngineerSpecial.setProjectName(policyEngineeringDTO.getProjectName());

        //项目名称 保单基础部分存一份，方便查询
        policyMain.setProjectName(policyEngineeringDTO.getProjectName());

        policyEngineerSpecial.setProjectAddress(policyEngineeringDTO.getProjectAddress());
        policyEngineerSpecial.setDetailAddress(policyEngineeringDTO.getDetailAddress());
        policyEngineerSpecial.setInsurancePeriod(policyEngineeringDTO.getInsurancePeriod());
        policyEngineerSpecial.setType(Byte.valueOf(policyBaseInfoDTO.getKindCode()));

        if (policyEngineerSpecial.getCreateTime() == null) {
            policyEngineerSpecial.setCreateTime(new Date());
        }
        policyEngineerSpecial.setUpdateTime(new Date());

        policyMainRepository.save(policyMain);
        policyEngineerSpecialRepository.save(policyEngineerSpecial);
    }
}
