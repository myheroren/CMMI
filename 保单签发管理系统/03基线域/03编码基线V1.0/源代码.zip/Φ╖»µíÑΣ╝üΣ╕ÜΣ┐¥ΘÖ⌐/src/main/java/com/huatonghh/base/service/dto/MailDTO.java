package com.huatonghh.base.service.dto;

import lombok.Data;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/18
 */
@Data
public class MailDTO {
    private String from;
    private String to;
    /**
     * 邮件主题
     */
    private String subject;
    /**
     * 邮件内容
     */
    private String content;
}
