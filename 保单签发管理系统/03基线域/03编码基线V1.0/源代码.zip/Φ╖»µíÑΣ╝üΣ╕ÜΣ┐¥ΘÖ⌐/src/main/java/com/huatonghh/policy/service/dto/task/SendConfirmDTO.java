package com.huatonghh.policy.service.dto.task;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/17
 */
@Data
@ApiModel("提交方案")
public class SendConfirmDTO {
    @ApiModelProperty("任务")
    @NotBlank(message = "当前任务不能为空！")
    private String taskId;
    @ApiModelProperty("业务主键")
    @NotNull(message = "业务主键不能为空！")
    @JsonSerialize(using = ToStringSerializer.class)
    private BigInteger businessId;
    @ApiModelProperty("备注")
    private String msg;
}
