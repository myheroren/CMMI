package com.huatonghh.policy.service.dto.policy;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/28
 */
@Data
@ApiModel("保单退保申请")
public class PolicyReturnDTO {
    @ApiModelProperty(value = "保单号")
    @NotBlank
    private String policyNo;
    @ApiModelProperty(value = "1退保，2注销")
    @NotNull
    private Byte option;
}
