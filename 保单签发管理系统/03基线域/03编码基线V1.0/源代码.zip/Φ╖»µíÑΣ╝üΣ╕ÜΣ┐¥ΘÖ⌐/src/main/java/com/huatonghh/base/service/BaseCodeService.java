package com.huatonghh.base.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.collect.Lists;
import com.huatonghh.base.constant.BaseConstant;
import com.huatonghh.base.domain.BaseCode;
import com.huatonghh.base.repository.BaseCodeRepository;
import com.huatonghh.base.service.dto.BaseCodeCondition;
import com.huatonghh.base.service.dto.BaseCodeDto;
import com.huatonghh.base.service.dto.InsAccdntDataDTO;
import com.huatonghh.base.service.dto.RegionDataDTO;
import com.huatonghh.common.constant.enums.StatusEnum;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.util.system.PageInfo;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;


/**
 * @author : Sun
 * @version : 1.0
 * @description : 基础代码字典管理业务层
 * @date : 2019/11/5 21:04
 */
@Service
@CacheConfig
@Slf4j
@AllArgsConstructor
public class BaseCodeService {

    private final BaseCodeRepository baseCodeRepository;

    private final ObjectMapper objectMapper;

    private final ModelMapper modelMapper;

    /**
     * @return java.lang.String
     * @author Sun
     * @description 查询所有的基础代码，返回前端，用于日常业务匹配
     * @date 2019/11/5 21:04
     **/
    @Cacheable(cacheNames = BaseConstant.BASE_CODE_CACHE, key = "methodName", unless = "#result == null")
    public String allBaseCode() {
        List<String> typeCodes = baseCodeRepository.findDistinctTypeCodes();
        ObjectNode objectNode = objectMapper.createObjectNode();
        typeCodes.forEach(typeCode -> {
            List<BaseCodeDto> codes = queryBaseCodeByTypeCode(typeCode);
            JsonNode jsonNode = objectMapper.valueToTree(codes);
            objectNode.replace(typeCode, jsonNode);
        });
        return objectNode.toString();
    }

    /**
     * 清空缓存
     */
    @CacheEvict(value = BaseConstant.BASE_CODE_CACHE, key = "methodName", allEntries = true)
    public String clearAllBaseCodeCache() {
        log.info("清空BaseCode缓存");
        return null;
    }

    /**
     * @param baseC:
     * @return com.huatonghh.common.util.system.PageInfo<com.huatonghh.base.service.dto.BaseCodeDto>
     * @author Sun
     * @description 获取各类型基础代码列表
     * @date 2019/11/5 21:05
     **/
    public PageInfo<BaseCodeDto> queryBaseCode(BaseCodeCondition baseC) {
        String typeCode = baseC.getTypeCode();
        // 获取分页信息
        Integer pageNum = baseC.getPageNum();
        Integer pageSize = baseC.getPageSize();
        // 查询
        List<BaseCodeDto> result = Lists.newArrayList();
        Page<BaseCode> codes;
        Sort sort = new Sort(Sort.Direction.DESC, "id");
        if (StringUtils.isNotBlank(typeCode)) {
            codes = baseCodeRepository.findByTypeIdAndValid(typeCode, true, PageRequest.of(pageNum - 1, pageSize, sort));
        } else {
            codes = baseCodeRepository.findByValid(true, PageRequest.of(pageNum - 1, pageSize, sort));
        }
        codes.getContent().forEach(code -> result.add(modelMapper.map(code, BaseCodeDto.class)));

        return PageInfo.of(pageNum, pageSize, result, codes.getTotalElements());
    }

    public BaseCode queryBaseCode(String typeCode, String codeId) {
        List<BaseCode> codes = baseCodeRepository.findByTypeIdAndCodeIdAndValid(typeCode, codeId, true);
        if (null == codes || codes.isEmpty()) {
            return null;
        }
        return codes.get(0);
    }
    /**
     * @param typeCode:
     * @return java.util.List<com.huatonghh.base.service.dto.BaseCodeDto>
     * @author Sun
     * @description 根据类型代码查询所有有效的基础代码
     * @date 2019/11/5 21:05
     **/
    public List<BaseCodeDto> queryBaseCodeByTypeCode(String typeCode) {
        List<BaseCodeDto> result = Lists.newArrayList();
        List<BaseCode> codes = baseCodeRepository.findByTypeIdAndValid(typeCode, true);
        codes.forEach(code -> result.add(modelMapper.map(code, BaseCodeDto.class)));
        return result;
    }

    public String queryCodeId(String typeCode, String codeName) {
        List<BaseCode> codes = baseCodeRepository.findByTypeIdAndCodeNameAndValid(typeCode, codeName, true);
        if (null == codes || codes.isEmpty()) {
            return null;
        }
        return codes.get(0).getCodeId();
    }

    public String queryCodeName(String typeCode, String codeId) {
        List<BaseCode> codes = baseCodeRepository.findByTypeIdAndCodeIdAndValid(typeCode, codeId, true);
        if (null == codes || codes.isEmpty()) {
            return null;
        }
        return codes.get(0).getCodeName();
    }

    /**
     * @param baseCodeDto:
     * @author Sun
     * @description 保存基础代码
     * @date 2019/11/5 21:05
     **/
    @CacheEvict(cacheNames = BaseConstant.BASE_CODE_CACHE, allEntries = true)
    @Transactional(rollbackFor = RuntimeException.class)
    public void saveOrUpdateBaseCode(BaseCodeDto baseCodeDto) {
        List<BaseCode> baseCodes = baseCodeRepository.findByTypeIdAndValid(baseCodeDto.getTypeId(), true);
        baseCodes.forEach(baseCode -> {
            if (!baseCode.getTypeName().equals(baseCodeDto.getTypeName())) {
                if (!baseCode.getCodeId().equals(baseCodeDto.getCodeId())) {
                    throw new BusinessException(StatusEnum.BASE_CODE_TYPE_ID_AND_NAME_ERROR);
                }
            }
        });
        BaseCode baseCode = modelMapper.map(baseCodeDto, BaseCode.class);
        baseCodeRepository.save(baseCode);
    }

    /**
     * @param ids:
     * @author Sun
     * @description 删除基础代码
     * @date 2019/11/5 21:06
     **/
    @CacheEvict(cacheNames = BaseConstant.BASE_CODE_CACHE, allEntries = true)
    @Transactional(rollbackFor = RuntimeException.class)
    public void batchDeleteBaseCode(int[] ids) {
        // 单个删、批量删方法不同
        if (ids == null || ids.length == 0) {
            throw new BusinessException(StatusEnum.BASE_CODE_BATCH_DELETE_ERROR);
        } else if (ids.length == 1) {
            baseCodeRepository.findById(ids[0]).ifPresent(baseCode -> baseCode.setValid(false));
        } else {
            baseCodeRepository.batchDeleteBaseCodes(ids);
        }
    }


    /**
     * @return java.util.List<com.huatonghh.base.service.dto.BaseCodeDto>
     * @author Sun
     * @description 基础代码类型下拉框列表
     * @date 2019/11/5 21:06
     **/
    public List<BaseCodeDto> typeList() {
        return baseCodeRepository.findDistinctTypeIdInfo();
    }

    /**
     * 获取省市区区域数据数据
     *
     * @return 封装好的List集合
     */
    public List<RegionDataDTO> regionDataList() {
        ArrayList<RegionDataDTO> data = new ArrayList<>();
        List<BaseCode> baseCodes = baseCodeRepository.findByTypeIdOrderByRemark(BaseConstant.CITY_CODE);
        for (BaseCode baseCode : baseCodes) {
            // 省
            if ("1".equals(baseCode.getEname())) {
                RegionDataDTO province = packRegionData(baseCode, true);
                // 当前省的市
                for (BaseCode baseCode2 : baseCodes) {
                    if (province.getCode().equals(baseCode2.getEname())) {
                        RegionDataDTO city = packRegionData(baseCode2, true);
                        // 当前市的区县
                        for (BaseCode baseCode3 : baseCodes) {
                            if (city.getCode().equals(baseCode3.getEname())) {
                                RegionDataDTO district = packRegionData(baseCode3, false);
                                city.getChird().add(district);
                            }
                        }
                        province.getChird().add(city);
                    }
                }
                data.add(province);
            }
        }
        return data;
    }

    /**
     * 根据BaseCode对象创建并封装对应的RegionDataDTO对象
     *
     * @param baseCode 基础字典对象
     * @param hasChild 是否需要创建下级对象集合
     * @return RegionDataDTO 封装好的地区数据对象
     */
    private RegionDataDTO packRegionData(BaseCode baseCode, Boolean hasChild) {
        RegionDataDTO region = new RegionDataDTO();
        region.setName(baseCode.getCodeName());
        region.setCode(baseCode.getRemark());
        region.setParCode(baseCode.getEname());
        if (hasChild) {
            ArrayList<RegionDataDTO> child = new ArrayList<>();
            region.setChird(child);
        }
        return region;
    }

    /**
     * 获取工程险二级联动数组
     *
     * @return List集合
     */
    public List<InsAccdntDataDTO> insAccdntDataList() {
        ArrayList<InsAccdntDataDTO> data = new ArrayList<>();
        // 工程险
        List<BaseCode> baseCodes = baseCodeRepository.findByTypeIdAndValid(BaseConstant.C_ACCDNT_TYPE_CODE, true);
        // 出现原因
        List<BaseCode> baseCodes2 = baseCodeRepository.findByTypeIdAndValid(BaseConstant.C_ACCDNT_RSN_CODE, true);
        for (BaseCode baseCode : baseCodes) {
            // 工程险
            InsAccdntDataDTO insAccdnt = new InsAccdntDataDTO();
            insAccdnt.setChird(new ArrayList<>());
            insAccdnt.setName(baseCode.getCodeName());
            insAccdnt.setCode(baseCode.getCodeId());
            for (BaseCode baseCode2 : baseCodes2) {
                // 当前工程险的出现原因
                if (insAccdnt.getCode().equals(baseCode2.getEname())) {
                    InsAccdntDataDTO accdntRsn = new InsAccdntDataDTO();
                    accdntRsn.setName(baseCode2.getCodeName());
                    accdntRsn.setCode(baseCode2.getCodeId());
                    accdntRsn.setParCode(baseCode2.getEname());
                    // 添加到工程险的child集合
                    insAccdnt.getChird().add(accdntRsn);
                }
            }
            data.add(insAccdnt);
        }
        return data;
    }
}
