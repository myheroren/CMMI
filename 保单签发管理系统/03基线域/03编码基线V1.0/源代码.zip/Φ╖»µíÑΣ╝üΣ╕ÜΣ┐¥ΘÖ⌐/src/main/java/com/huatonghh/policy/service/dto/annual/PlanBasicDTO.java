package com.huatonghh.policy.service.dto.annual;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

/**
 * @author : hao.wang
 * @date : 2019/9/2
 * description:
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel("保险需求计划基本信息")
public class PlanBasicDTO implements Serializable {

    private static final long serialVersionUID=-21321668386093313L;

        @ApiModelProperty(value = "保险计划编号,100000001自动递增")
        private String planNo;

        @ApiModelProperty(value = "保险计划名称")
        private String planName;

        @ApiModelProperty(value = "发起公司")
        private String startCompany;

        @ApiModelProperty(value = "发起公司名称")
        private String startCompanyName;

        @ApiModelProperty(value = "发起人")
        private String startUser;

        @ApiModelProperty(value = "发起人姓名")
        private String startUserName;

        @ApiModelProperty(value = "预估总保费(分)")
        @JsonDeserialize(using = AmountJsonDeserializer.class)
        @JsonSerialize(using = AmountJsonSerializer.class)
        private BigInteger estPremium;

        @ApiModelProperty(value = "保险计划状态；例：0暂存、1二级公司审核")
        private Byte status;

        @ApiModelProperty(value = "创建时间，实体关联",example = "2020-10-01 12:18:48")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        private Date createTime;

        @ApiModelProperty(value = "更新时间，实体关联",example = "2020-10-01 12:18:48")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        private Date updateTime;

        @ApiModelProperty(value = "提交审核时间",example = "2020-10-01 12:18:48")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
        @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        private Date applyTime;

        @ApiModelProperty(value = "项目名称")
        private String projName;

        @ApiModelProperty(value = "项目地址")
        private String projAddr;

        @ApiModelProperty(value = "项目详细地址")
        private String projDetailAddr;

        @ApiModelProperty(value = "联系人")
        private String contact;

        @ApiModelProperty(value = "联系电话")
        private String contactNumber;

}
