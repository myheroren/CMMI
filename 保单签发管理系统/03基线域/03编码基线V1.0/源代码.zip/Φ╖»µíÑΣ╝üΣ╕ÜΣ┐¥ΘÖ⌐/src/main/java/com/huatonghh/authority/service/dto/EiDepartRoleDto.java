package com.huatonghh.authority.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Column;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * @author : Sun
 * @description : 部门、也叫分公司
 * @date : 2019/11/4 21:10
 * @version : 1.0
 */
@Data
@ApiModel(value = "公司/部门、也叫分公司")
public class EiDepartRoleDto implements Serializable {

    private static final long serialVersionUID = 4599743566838575095L;

    @ApiModelProperty(value = "部门id")
    private String id;

    @ApiModelProperty(value = "部门名称")
    private String name;

    @ApiModelProperty(value = "公司等级")
    private String level;

    @ApiModelProperty(value = "父id")
    private String parentId;

    @ApiModelProperty(value = "ids")
    private String ids;

    @ApiModelProperty(value = "公司、部门")
    private String type;

    @ApiModelProperty(value = "公司等级")
    private String htLevel;

    @ApiModelProperty(value = "角色id")
    private Integer roleId ;

    @ApiModelProperty(value = "角色名称")
    private String roleName ;

    @Column(name = "position")
    private Byte position;

    public EiDepartRoleDto() {
    }

    public EiDepartRoleDto(String id, String name, String parentId) {
        this.id = id;
        this.name = name;
        this.parentId = parentId;
    }

    public EiDepartRoleDto(String id, String name, String parentId, String ids) {
        this.id = id;
        this.name = name;
        this.parentId = parentId;
        this.ids = ids;
    }

    public EiDepartRoleDto(String id, String name, String parentId,String level, String ids,String type ,String htLevel,Integer roleId,String roleName,Byte position ) {
        this.id = id;
        this.name = name;
        this.parentId = parentId;
        this.level = level;
        this.ids = ids;
        this.type = type;
        this.htLevel = htLevel;
        this.roleId = roleId;
        this.roleName = roleName;
        this.position = position;
    }
}
