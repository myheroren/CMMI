package com.huatonghh.policy.domain.policy.renew;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;


/**
 * description:续保实体
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2020/1/9
 */
@Entity
@Table(name = "policy_renew_info")
@Data
public class PolicyRenewEntity implements Serializable {

    private static final long serialVersionUID = 6769710130522144578L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, unique = true)
    private BigInteger id;

    @Column(name = "policy_no_old")
    private String policyNoOld;

    @Column(name = "policy_id_old")
    private BigInteger policyIdOld;
    /**
     * 新保单号
     */
    @Column(name = "policy_no_new")
    private String policyNoNew;
    /**
     * 新保单编号
     */
    @Column(name = "policy_id_new")
    private BigInteger policyIdNew;
    /**
     * 项目编号
     */
    @Column(name = "project_no_old")
    private BigInteger projectNoOld;
    /**
     * 项目编号
     */
    @Column(name = "project_no_new")
    private BigInteger projectNoNew;
    /**
     * 旧保险公司
     */
    @Column(name = "belong_company_old")
    private String belongCompanyOld;
    /**
     * 新保险公司
     */
    @Column(name = "belong_company_new")
    private String belongCompanyNew;
    /**
     * 发起公司
     */
    @Column(name = "start_company")
    private String startCompany;
    /**
     * 保险类别
     */
    @Column(name = "insurance_category")
    private String insuranceCategory;
    /**
     * 是否提醒
     */
    @Column(name = "remind_display", columnDefinition = "tinyint(1) default 1")
    private Boolean remindDisplay;
    /**
     * 车架号
     */
    @Column(name = "frame_no")
    private String frameNo;
    /**
     * 车牌号
     */
    @Column(name = "plate_no")
    private String plateNo;
    /**
     * 创建时间
     */
    @Column(name = "create_Time")
    private Date createTime;

    @Column(name = "remark")
    private String remark;
    /**
     * 续保状态：0。 发起 1.通过 2.驳回
     */
    @Column(name = "status")
    private Byte status;
    /**
     * 续保通知保险公司时间
     */
    @Column(name = "renew_apply_time")
    private Date renewApplyTime;
    /**
     * 续保完成时间,新保单录入时间
     */
    @Column(name = "renew_end_time")
    private Date renewEndTime;
}
