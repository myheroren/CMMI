package com.huatonghh.policy.domain.policy;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;

/**
 * description:项目预设信息
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/6
 */
@Entity
@Table(name = "policy_coinsurance")
@Data
public class PolicyCoinsurance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "co_id")
    private Integer coId;

    @Column(name = "policy_no")
    private String policyNo;

    @Column(name = "belong_company")
    @ApiModelProperty("归属保险公司")
    private String belongCompany;

    @Column(name = "belong_company_name")
    @ApiModelProperty("归属保险公司名称")
    private String belongCompanyName;

    @Column(name = "proportion")
    @ApiModelProperty("共保比例")
    private String proportion;

    @Column(name = "mainl_flag")
    @ApiModelProperty("主从保标志")
    private Byte mainlFlag;
}
