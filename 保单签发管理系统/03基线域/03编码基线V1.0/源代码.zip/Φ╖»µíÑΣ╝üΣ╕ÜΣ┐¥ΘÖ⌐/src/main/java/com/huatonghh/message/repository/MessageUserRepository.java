package com.huatonghh.message.repository;

import com.huatonghh.message.po.entity.MessageUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

/**
 * 消息用户表(MessageUser)数据库访问层
 *
 * @author wanggl
 * @since 2020-11-02 20:09:22
 */
public interface MessageUserRepository extends JpaRepository<MessageUser, Long> {

    /**
     * 根据消息id与用户编号已读消息
     *
     * @param messageId 消息id
     * @param userCode  用户编号
     */
    @Modifying
    @Query(value = "update MessageUser set read = 1,readTime = current_time where messageId = ?1 and userCode = ?2 and read = 0")
    void readMessage(Long messageId, String userCode);
}
