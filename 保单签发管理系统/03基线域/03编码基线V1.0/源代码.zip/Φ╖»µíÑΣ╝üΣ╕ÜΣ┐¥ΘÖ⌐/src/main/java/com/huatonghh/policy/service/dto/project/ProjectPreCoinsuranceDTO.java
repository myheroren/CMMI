package com.huatonghh.policy.service.dto.project;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * description:项目预设的共保信息
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/9
 */
@Data
public class ProjectPreCoinsuranceDTO {
    @ApiModelProperty("id")
    private Integer coId;
    @ApiModelProperty("项目编号")
    private String projectNo;
    @ApiModelProperty("项目类型")
    private Byte projType;
    @ApiModelProperty("归属保险公司")
    private String belongCompany;
    @ApiModelProperty("归属保险公司名称")
    private String belongCompanyName;
    @ApiModelProperty("共保比例")
    private String proportion;
}
