package com.huatonghh.policy.domain.claim.noncar;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

/**
 * @author : hao.wang
 * @date : 2019/8/22
 * description:
 */
@Data
@Entity
@Table(name = "policy_uncar_claim")
public class ClaimInfo implements Serializable {
    private static final long serialVersionUID = 2191071967514125909L;
    @Id
    @ApiModelProperty("主键")
    private String reportId;

    //---------------------------------报案信息 begin----------------------------------
    @ApiModelProperty("报案号（业务id）")
    //BigInteger.valueOf(System.currentTimeMillis() + RandomUtil.randomInt(100)
    private String reportNo;

    @ApiModelProperty("保单号")
    private String policyNo;

    @ApiModelProperty("报案时间")
    private Date reportTime;

    @ApiModelProperty("报案人姓名")
    private String reportName;

    @ApiModelProperty("报案人电话")
    private String reportTel;

    @ApiModelProperty("报案人证件号码")
    private String reportIdNumber;

    @ApiModelProperty("联系人")
    private String contact;

    @ApiModelProperty("联系人电话")
    private String contactTel;
    //---------------------------------报案信息 end----------------------------------

    //---------------------------------出险信息 begin----------------------------------
    @ApiModelProperty("出险时间")
    private Date accidentTime;

    @ApiModelProperty("索赔金额")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger askForAmount;

    @ApiModelProperty("出险原因类型")
    private String accidentType;

    @ApiModelProperty("出险原因")
    private String accidentReason;

    @ApiModelProperty("出现地址")
    private String address;

    @ApiModelProperty("详细出险地址")
    private String addressDetail;

    @ApiModelProperty("出险经过")
    private String accidentDetail;

    @ApiModelProperty("是否在线理赔")
    private Byte isOnlineClaims;

    @ApiModelProperty(value = "受伤人数")
    private Integer injuredNumber;

    @ApiModelProperty(value = "死亡人数")
    private Integer deathNumber;

    @ApiModelProperty(value = "劳务队名称")
    private String laborTeamName;

    @ApiModelProperty(value = "劳务队合同编号")
    private String laborContractNumber;

    @ApiModelProperty(value = "劳务队合同名称")
    private String laborContractName;
    //---------------------------------出险信息 end----------------------------------

    //---------------------------------理赔信息 begin----------------------------------
    @ApiModelProperty(value = "估损金额")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger preLossAmount;

    @ApiModelProperty(value = "定损金额")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger lossAmount;

    @ApiModelProperty("案件描述")
    private String caseDescription;
    //---------------------------------理赔信息 end----------------------------------

    //---------------------------------支付信息 begin----------------------------------
    @ApiModelProperty("赔付金额")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger claimAmount;

    @ApiModelProperty("结案金额")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger caseAmount;

    @ApiModelProperty("结案时间")
    private Date caseEndingTime;
    //---------------------------------支付信息 begin----------------------------------

    @ApiModelProperty("险类：1责任 2工程 3意外")
    private String insuranceCategory;

    @ApiModelProperty("险种代码：0工程险；1团意险；2安责险；3雇主责任险")
    private String kindCode;

    @ApiModelProperty("创建时间")
    private Date createTime;

    @ApiModelProperty("更新时间")
    private Date updateTime;

    @ApiModelProperty("操作人code")
    private String operatorCode;

    @ApiModelProperty("操作人")
    private String operator;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("理赔状态")
    private Byte claimStatus;// no useage

    @ApiModelProperty("理赔开始时间")
    private Date claimBeginDate;// no useage

    @ApiModelProperty("理赔结束时间")
    private Date claimEndDate;// no useage

    @ApiModelProperty(value = "赔付次数")
    @Column(name = "case_times")
    private String caseTimes;

    @ApiModelProperty("是否关联报案id,0未关联，1已关联")
    @Column(name = "is_related")
    private Byte related;

}

