package com.huatonghh.authority.service.dto.hr.response.xml;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import lombok.Data;


/**
 * @author : Sun
 * @description : <soap:Envelope></soap:Envelope>
 * @date : 2019/11/4 21:08
 * @version : 1.0
 */
@Data
@XStreamAlias("soap:Envelope")
public class XmlSoapEnvelope {

    @XStreamAsAttribute
    @XStreamAlias("xmlns:soap")
    private String xmlns;

    @XStreamAlias("soap:Body")
    private XmlSoapBody xmlSoapBody;

}
