package com.huatonghh.policy.domain.policy;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

/**
 * Description : 保单详细信息-车
 *
 * @author : Sun
 * @version : 1.0
 * @date : 2019/8/31 14:01
 */
@Entity
@Table(name = "policy_car_detail")
@Data
public class PolicyCarDetail implements Serializable {

    private static final long serialVersionUID = 4405247635308103626L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private BigInteger id;

    @Column(name = "policy_no")
    private String policyNo;

    @Column(name = "frame_no")
    private String frameNo;

    @Column(name = "plate_no")
    private String plateNo;

    @Column(name = "engine_no")
    private String engineNo;

    @Column(name = "usage_code")
    private String usageCode;

    @Column(name = "vehicle_model")
    private String vehicleModel;

    @Column(name = "owner_name")
    private String ownerName;


    @Column(name = "fee_prop")
    private String feeProp;

    /**
     * 车船税
     */
    @Column(name = "vehicle_vessel_tax")
    private String vehicleVesselTax;

    /**
     * ncd系数
     */
    @Column(name = "ncd_coef")
    private String ncdCoef;

    /**
     * 自主核保优惠系数
     */
    @Column(name = "auto_underwriting_coef")
    private String autoUnderwritingCoef;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_time")
    private Date updateTime;

    /**
     * 自主渠道系数
     */
    @Column(name = "self_channel_coef")
    private String selfChannelCoef;
    /**
     * 自主系数乘积
     */
    @Column(name = "self_sum_coef")
    private String selfSumCoef;

}
