package com.huatonghh.policy.service.dto.policy;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigInteger;
import java.util.Date;

/**
 * description: 所有保单基本信息，不区分车，非车
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/10
 */
@Data
public class PolicyBaseListDTO {
    @ApiModelProperty(value = "自增id：新增不传、修改必传")
    @JsonSerialize(using = ToStringSerializer.class)
    private BigInteger id;

    @ApiModelProperty(value = "保单号")
    private String policyNo;

    @ApiModelProperty(value = "车或非车标识：1车、0非车，必传")
    private Byte carUncarFlag;

    @ApiModelProperty(value = "保险类别")
    private String insuranceCategory;

    @ApiModelProperty(value = "险种代码；例:车（交强、商业）,非车待定")
    private String kindCode;

    @ApiModelProperty(value = "投保人")
    private String holderName;

    @ApiModelProperty(value = "被保险人")
    private String insuredName;

    @ApiModelProperty(value = "中标项目编号")
    @JsonSerialize(using = ToStringSerializer.class)
    private BigInteger projectNo;

    @ApiModelProperty(value = "发起公司")
    private String startCompany;

    @ApiModelProperty(value = "保险公司")
    private String belongCompany;

    @ApiModelProperty(value = "保费")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger totalPremium;

    @ApiModelProperty(value = "有效起期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyBgnTime;

    @ApiModelProperty(value = "有效止期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyEndTime;

    @ApiModelProperty(value = "保司联系人")
    private String belongCompanyPerson;

    @ApiModelProperty(value = "状态")
    private Byte status;

    @ApiModelProperty(value = "投保日期")
    private Date policyApplyTime;
    @ApiModelProperty(value = "不含税保费")
    private BigInteger freeTaxPremium;
    @ApiModelProperty(value = "保费到账日期")
    private Date premiumArrivalTime;
    @ApiModelProperty(value = "保费应收日期")
    private Date premiumReceivableTime;
    @ApiModelProperty(value = "手续费比例")
    private String feeProp;
    @ApiModelProperty(value = "收入手续费")
    private BigInteger handlingFeeIncome;
    @ApiModelProperty(value = "入账手续费")
    private BigInteger handlingFeeEntryAccount;
    @ApiModelProperty(value = "手续费应收日期")
    private Date handlingFeeReceivableTime;
    @ApiModelProperty(value = "手续费转账日期")
    private Date handlingFeeArrivalTime;
    @ApiModelProperty(value = "项目名称")
    private String proName;

}
