package com.huatonghh.base.service.timing;

import com.huatonghh.common.util.hutool.SpringContextHolder;
import com.huatonghh.policy.service.CountService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/11
 */
@Service
@Slf4j
@AllArgsConstructor
public class CountKindCodeInsert {
    public void batchInsert() {
        CountService countService = SpringContextHolder.getBean(CountService.class);
        countService.batchInsert();
    }
}
