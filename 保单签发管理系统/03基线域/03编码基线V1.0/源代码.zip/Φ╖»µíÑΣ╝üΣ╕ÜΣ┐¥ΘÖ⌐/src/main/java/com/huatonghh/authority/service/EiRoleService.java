package com.huatonghh.authority.service;

import com.huatonghh.authority.constant.AuthorityConstant;
import com.huatonghh.authority.domain.EiDepartRole;
import com.huatonghh.authority.domain.EiRole;
import com.huatonghh.authority.repository.EiDepartRoleRepository;
import com.huatonghh.authority.repository.EiRoleRepository;
import com.huatonghh.authority.service.dto.EiRoleDto;
import com.huatonghh.authority.service.dto.EiRoleListCondition;
import com.huatonghh.common.util.process.ProcessDtoToEntityUtil;
import com.huatonghh.common.util.process.ProcessEntityToDtoUtil;
import com.huatonghh.common.constant.enums.StatusEnum;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.util.system.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


/**
 * @author : Sun
 * @description : 角色管理业务层
 * @date : 2019/11/5 20:23
 * @version : 1.0
 */
@Service
@CacheConfig
@Slf4j
public class EiRoleService {

    private final EiRoleRepository eiRoleRepository;

    private final EiDepartRoleRepository eiDepartRoleRepository;

    private final ProcessDtoToEntityUtil processDtoToEntity;

    private final ProcessEntityToDtoUtil processEntityToDto;

    public EiRoleService(EiRoleRepository eiRoleRepository,EiDepartRoleRepository eiDepartRoleRepository, ProcessDtoToEntityUtil processDtoToEntity, ProcessEntityToDtoUtil processEntityToDto) {
        this.eiRoleRepository = eiRoleRepository;
        this.processDtoToEntity = processDtoToEntity;
        this.processEntityToDto = processEntityToDto;
        this.eiDepartRoleRepository = eiDepartRoleRepository;

    }


    /**
     * @author Sun
     * @description 角色列表查询，角色不会有条件。并且先不加分页
     * @date 2019/11/5 20:23
     * @return java.util.List<com.huatonghh.authority.service.dto.EiRoleDto>
     **/
    @Cacheable(cacheNames = AuthorityConstant.EI_ROLES_BY_LOGIN_CACHE, key = "methodName", unless="#result == null || #result.size() == 0")
    public List<EiRoleDto> roleList() {
        List<EiRole> eiRoleList = eiRoleRepository.findAllByValid(true);
        return eiRoleList.stream().map(eiRole -> processEntityToDto.role(eiRole, 0)).collect(Collectors.toList());
    }

    /**
     * @author Sun
     * @description 角色列表查询，角色不会有条件。并且先不加分页
     * @date 2019/11/5 20:23
     * @return java.util.List<com.huatonghh.authority.service.dto.EiRoleDto>
     **/
//    @Cacheable(cacheNames = AuthorityConstant.EI_ROLES_BY_LOGIN_CACHE, key = "methodName", unless="#result == null || #result.size() == 0")
    @Transactional(rollbackFor = RuntimeException.class)
    public PageInfo<EiRoleDto> rolePageList(EiRoleListCondition eiRoleListCondition) {
        List<EiRole> eiRoleList = eiRoleRepository.findAllByCompanyId(eiRoleListCondition.getCompanyId(),true,eiRoleListCondition.getPageNum()-1,eiRoleListCondition.getPageSize());
        List<EiRole> eiRoleTotle = eiRoleRepository.findAllSizeByCompanyId(eiRoleListCondition.getCompanyId(),true);

        List<EiRoleDto> eiRoleListLazy = eiRoleList.stream().map(eiRole -> processEntityToDto.role(eiRole, 0)).collect(Collectors.toList());
        for (EiRoleDto eiRoleDto:eiRoleListLazy) {
            eiRoleDto.setCompanyId(eiRoleListCondition.getCompanyId());
        }
        return PageInfo.of(eiRoleListCondition.getPageNum(),eiRoleListCondition.getPageSize(),eiRoleListLazy,Long.valueOf(eiRoleTotle.size()));
    }

    /**
     * @author Sun
     * @description 角色信息保存，可直接存储角色对应菜单信息
     * @date 2019/11/5 20:24
     * @param eiRoleDto:
     * @return com.huatonghh.authority.service.dto.EiRoleDto
     **/
    @CacheEvict(cacheNames = AuthorityConstant.EI_ROLES_BY_LOGIN_CACHE, allEntries = true)
    @Transactional(rollbackFor = RuntimeException.class)
    public EiRoleDto saveRole(EiRoleDto eiRoleDto) {

        EiRole eiRole = processDtoToEntity.role(eiRoleDto, 1);
        eiRole = eiRoleRepository.save(eiRole);
        EiDepartRole eiDepartRole = new EiDepartRole();
        eiDepartRole.setCompanyId(eiRoleDto.getCompanyId());
        eiDepartRole.setRoleId(eiRole.getRoleId());
        eiDepartRoleRepository.save(eiDepartRole);
        return processEntityToDto.role(eiRole, 1);
    }


    /**
     * @author Sun
     * @description 获取角色详细信息，此接口也可以获取角色配置的菜单权限列表
     * @date 2019/11/5 20:24
     * @param roleId: 角色id
     * @return com.huatonghh.authority.service.dto.EiRoleDto
     **/
    @Cacheable(cacheNames = AuthorityConstant.EI_ROLES_BY_LOGIN_CACHE, key = "methodName + args[0]", unless="#result == null")
    public EiRoleDto queryRoleInfo(Integer roleId) {
        Optional<EiRole> eiRoleOptional = eiRoleRepository.findOneWithAuthoritiesByRoleId(roleId);
        return eiRoleOptional.map(eiRole -> processEntityToDto.role(eiRole, 1)).orElse(null);
    }


    /**
     * @author Sun
     * @description 清除缓存
     * @date 2019/11/5 20:25
     **/
    @CacheEvict(cacheNames = AuthorityConstant.EI_ROLES_BY_LOGIN_CACHE, allEntries = true)
    public void clearCache() {
        log.info("清除缓存成功！！！");
    }


    /**
     * @author Sun
     * @description 删除角色、角色菜单中间表、用户角色中间表，以及角色和用户的缓存
     * @date 2019/11/5 20:25
     * @param roleId: 角色id
     **/
    @Caching(evict = {
        @CacheEvict(cacheNames = AuthorityConstant.EI_ROLES_BY_LOGIN_CACHE, allEntries = true),
        @CacheEvict(cacheNames = AuthorityConstant.EI_USERS_BY_LOGIN_CACHE, allEntries = true)
    })
    @Transactional(rollbackFor = Exception.class)
    public void delete(Integer roleId) {
        try {
            // 用户存在角色，是否可以删除角色？
            eiRoleRepository.deleteUserRoleByRoleId(roleId);
            eiDepartRoleRepository.deleteDepartRoleByRoleId(roleId);
            eiRoleRepository.deleteById(roleId);

        } catch (Exception e) {
            log.error(StatusEnum.AUTHORITY_DELETE_ROLE_ERROR.getMessage() + ": {}", e.getMessage());
            throw new BusinessException(StatusEnum.AUTHORITY_DELETE_ROLE_ERROR);
        }
    }

}
