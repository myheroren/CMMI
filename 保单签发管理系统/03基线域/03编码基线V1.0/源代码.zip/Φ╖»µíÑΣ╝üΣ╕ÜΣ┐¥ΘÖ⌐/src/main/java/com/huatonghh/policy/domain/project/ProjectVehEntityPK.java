package com.huatonghh.policy.domain.project;

import lombok.Data;

import javax.persistence.Id;
import java.io.Serializable;
import java.math.BigInteger;


@Data
public class ProjectVehEntityPK implements Serializable {

    @Id
    private BigInteger projNo;

    @Id
    private String frameNo;

}
