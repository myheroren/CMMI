package com.huatonghh.base.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author Binary Wang(https://github.com/binarywang)
 */
@Data
@ConfigurationProperties(prefix = "weixin-cp")
public class WxCpProperties {
    private String corpId;
    private Integer agentId;
    private String agentSecret;
    private String token;
    private String encodingAesKey;
}
