package com.huatonghh.policy.service.dto.claim.form;

import lombok.Data;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * @author : wh
 * description : 汇总保单详情
 * @version : 1.0
 * @date : 2020/3/31 11:20
 */
@Data
public class ClaimHighwayPolicyDTO {
    private Integer proId;
    /**
     * 项目名称
     */
    private String proName;
    /**
     * 工程类别
     */
    private Byte engType;
    private String engTypeName;
    private String policyNos;
    /**
     * 施工合同数，mysql count()，对应java BigInteger
     */
    private BigInteger countContract;
    /**
     * 购买保险份数
     */
    private BigInteger countPolicy;
    /**
     * 支付保险费额
     */
    private BigDecimal totalPremium;


}
