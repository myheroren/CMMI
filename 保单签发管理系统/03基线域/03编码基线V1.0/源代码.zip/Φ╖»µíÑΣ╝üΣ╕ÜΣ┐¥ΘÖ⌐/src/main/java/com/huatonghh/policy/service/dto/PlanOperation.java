package com.huatonghh.policy.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author ghy
 * Date: 2020/11/6 14:13
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel("计划详情操作符")
public class PlanOperation {

    @ApiModelProperty("暂存")
    private boolean save;

    @ApiModelProperty("提交审批")
    private boolean commit;

    @ApiModelProperty("撤回")
    private boolean recall;

    @ApiModelProperty("驳回")
    private boolean reject;

    @ApiModelProperty("通过")
    private boolean pass;

    @ApiModelProperty("再次提交")
    private boolean commitAgain;

    @ApiModelProperty("授权")
    private boolean empower;
}
