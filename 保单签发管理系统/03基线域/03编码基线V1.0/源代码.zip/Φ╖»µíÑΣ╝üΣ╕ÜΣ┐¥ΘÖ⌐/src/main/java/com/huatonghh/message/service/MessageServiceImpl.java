package com.huatonghh.message.service;

import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.util.BeanCopierUtils;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.common.util.system.PageParam;
import com.huatonghh.message.constant.MessageConstant;
import com.huatonghh.message.po.dto.*;
import com.huatonghh.message.po.entity.*;
import com.huatonghh.message.repository.MessageRepository;
import com.huatonghh.message.repository.MessageThirdPartyRepository;
import com.huatonghh.message.repository.MessageUserRepository;
import com.huatonghh.message.service.sender.EmailSender;
import com.huatonghh.message.service.sender.MessageSender;
import com.huatonghh.message.service.sender.SmsSender;
import com.querydsl.core.types.ExpressionUtils;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.Projections;
import com.querydsl.core.types.QBean;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 消息主体service实现类
 *
 * @author wanggl
 * @since 2020-11-02 20:09:22
 */
@Service
@Transactional(rollbackFor = RuntimeException.class, propagation = Propagation.REQUIRED)
public class MessageServiceImpl implements MessageService {

    private final Logger logger = LoggerFactory.getLogger(MessageServiceImpl.class);

    private final JPAQueryFactory jpaQueryFactory;

    private final MessageRepository messageRepository;

    private final MessageThirdPartyRepository messageThirdPartyRepository;

    private final MessageUserRepository messageUserRepository;

    private final Map<String, MessageSender> messageSenders = new HashMap<>(8);

    public MessageServiceImpl(MessageRepository messageRepository,
                              MessageThirdPartyRepository messageThirdPartyRepository,
                              MessageUserRepository messageUserRepository,
                              SmsSender smsSender,
                              EmailSender emailSender, JPAQueryFactory jpaQueryFactory) {
        this.messageRepository = messageRepository;
        this.messageThirdPartyRepository = messageThirdPartyRepository;
        this.messageUserRepository = messageUserRepository;
        this.jpaQueryFactory = jpaQueryFactory;

        messageSenders.put("sms", smsSender);
        messageSenders.put("email", emailSender);
    }


    /**
     * 发送消息
     *
     * @param messageDTO 消息及用户信息对象
     */
    @Override
    public void sendMessage(MessageDTO messageDTO) {
        // 存储消息主体信息
        Message message = new Message();
        BeanCopierUtils.copy(messageDTO, message);
        messageRepository.save(message);

        // 遍历并存储用户信息
        messageDTO.getUsers().forEach(user -> {
            MessageUser messageUser = new MessageUser();
            messageUser.setMessageId(message.getId());
            messageUser.setUserCode(user.getUserCode());
            messageUser.setRead(MessageConstant.NO);
            messageUserRepository.save(messageUser);

            // 发送第三方消息
            List<ThirdParty> thirdParties = user.getThirdParties();
            if (!CollectionUtils.isEmpty(thirdParties)) {
                // 遍历发送方式，发送并保存发送结果
                for (ThirdParty thirdParty : thirdParties) {
                    MessageSender sender = messageSenders.get(thirdParty.getType());
                    if (null == sender) {
                        logger.error("第三方消息发送类型不正确！");
                        continue;
                    }
                    MessageThirdPartyDTO thirdPartyDTO = new MessageThirdPartyDTO();
                    BeanCopierUtils.copy(message, thirdPartyDTO);
                    thirdPartyDTO.setUrl(thirdParty.getUrl());
                    thirdPartyDTO.setUserInfo(thirdParty.getUserInfo());
                    boolean success = sender.sendMessage(thirdPartyDTO);
                    MessageThirdParty messageThirdParty = new MessageThirdParty();
                    BeanCopierUtils.copy(thirdPartyDTO, messageThirdParty);
                    messageThirdParty.setMessageId(messageUser.getMessageId());
                    messageThirdParty.setTimes(1);
                    messageThirdParty.setSuccess(success ? MessageConstant.YES : MessageConstant.NO);
                    messageThirdParty.setCreateTime(null);
                    messageThirdPartyRepository.save(messageThirdParty);
                }
            }
        });
    }

    /**
     * 改变消息状态为已读
     *
     * @param messageId 消息id
     * @param userCode  用户编号
     */
    @Override
    public void read(Long messageId, String userCode) {
        messageUserRepository.readMessage(messageId, userCode);
    }

    /**
     * 条件分页查询用户消息列表
     *
     * @param param 消息查询对象
     * @return 分页列表
     */
    @Override
    public PageInfo<MessageVO> messageList(PageParam<MessageQuery> param) {
        MessageQuery params = param.getParams();
        QMessage message = QMessage.message;

        QMessageUser messageUser = QMessageUser.messageUser;

        Predicate predicate = message.eq(message);
        // 动态条件拼装
        predicate = StringUtils.isEmpty(params.getUserCode()) ? predicate
            : ExpressionUtils.and(predicate, messageUser.userCode.eq(params.getUserCode()));

        predicate = StringUtils.isEmpty(params.getSource()) ? predicate
            : ExpressionUtils.and(predicate, message.source.eq(params.getSource()));

        predicate = StringUtils.isEmpty(params.getType()) ? predicate
            : ExpressionUtils.and(predicate, message.type.eq(params.getType()));

        predicate = StringUtils.isEmpty(params.getTitle()) ? predicate
            : ExpressionUtils.and(predicate, message.title.eq(params.getTitle()));

        predicate = StringUtils.isEmpty(params.getSender()) ? predicate
            : ExpressionUtils.and(predicate, message.sender.eq(params.getSender()));

        predicate = null == params.getBeginTime() ? predicate
            : ExpressionUtils.and(predicate, message.createTime.goe(params.getBeginTime()));

        predicate = null == params.getEndTime() ? predicate
            : ExpressionUtils.and(predicate, message.createTime.loe(params.getEndTime()));

        QBean<MessageVO> qBean = Projections.bean(MessageVO.class, message.id, message.serviceCode, message.source,
            message.type, message.title, message.content, message.path, message.url, message.sender, messageUser.userCode,
            messageUser.read, messageUser.readTime, message.createTime);

        long count = jpaQueryFactory.select(qBean).from(messageUser)
            .join(message).on(messageUser.messageId.eq(message.id))
            .where(predicate)
            .fetchCount();
        if (count <= 0) {
            return PageInfo.of(param.getPageNum(), param.getPageSize(), new ArrayList<>(), 0L);
        }

        List<MessageVO> list = jpaQueryFactory.select(qBean).from(messageUser)
            .join(message).on(messageUser.messageId.eq(message.id))
            .where(predicate)
            .orderBy(message.createTime.desc())
            .offset(param.getOffset())
            .limit(param.getLimit())
            .fetch();
        return PageInfo.of(param.getPageNum(), param.getPageSize(), list, count);
    }

    /**
     * 向云之家开放平台推送代办消息
     */
    @Async
    @Override
    public void sendMessage2CloudHome(CloudUpcomingDTO cLoudUpcomingDTO) {
        String token = getToken();
        String body = JSONUtil.toJsonStr(cLoudUpcomingDTO);
        String respJson = HttpUtil.post(MessageConstant.sendMsgUrl + token, body);
        JSONObject resp = JSONUtil.parseObj(respJson);
        String success = resp.getStr("success");
        if (success.equals("false")) {
            logger.error("error:{},errorCode:{}, data:{}", resp.getStr("error"), resp.getStr("errorCode"), resp.get("data"));
            logger.error("待办创建失败!");
        }
    }

    /**
     * 获取token
     *
     * @return
     */
    public String getToken() {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("appId", MessageConstant.appId);
        paramMap.put("secret", MessageConstant.secret);
        paramMap.put("timestamp", System.currentTimeMillis());
        paramMap.put("scope", MessageConstant.app);

        String respJson = HttpUtil.post(MessageConstant.getTokenUrl, paramMap);
        JSONObject resp = JSONUtil.parseObj(respJson);
        boolean success = (boolean) resp.get("success");
        if (success) {
            String dataJson = resp.getStr("data");
            JSONObject data = JSONUtil.parseObj(dataJson);
            return data.getStr("accessToken");
        } else {
            logger.error("error:{},errorCode:{}", resp.getStr("error"), resp.getStr("errorCode"));
            throw new BusinessException("云之家token获取失败!");
        }
    }
}
