package com.huatonghh.policy.service.dto.count;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigInteger;
import java.util.Date;

/**
 * description:工程险项目
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/11
 */
@Data
@ApiModel("工程险项目维度统计结果")
public class CountEngDTO {
    @ApiModelProperty("工程险项目")
    private String eng;
    @ApiModelProperty("保费")
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger totalPremium;
    @ApiModelProperty("日期 yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date createTime;
}
