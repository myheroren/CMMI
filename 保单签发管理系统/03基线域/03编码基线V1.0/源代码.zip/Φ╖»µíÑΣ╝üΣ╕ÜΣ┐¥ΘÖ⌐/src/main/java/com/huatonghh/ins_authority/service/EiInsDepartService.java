package com.huatonghh.ins_authority.service;

import com.google.common.collect.Lists;
import com.huatonghh.common.service.dto.ResponseIntegerKeyValueDto;
import com.huatonghh.common.util.process.ProcessDtoToEntityUtil;
import com.huatonghh.common.util.process.ProcessEntityToDtoUtil;
import com.huatonghh.common.constant.enums.StatusEnum;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.ins_authority.constant.InsAuthorityConstant;
import com.huatonghh.ins_authority.domain.EiInsDepart;
import com.huatonghh.ins_authority.domain.EiInsDepartBase;
import com.huatonghh.ins_authority.repository.EiInsDepartBaseRepository;
import com.huatonghh.ins_authority.repository.EiInsDepartRepository;
import com.huatonghh.ins_authority.service.dto.EiInsDepartDto;
import com.huatonghh.ins_authority.service.dto.EiInsDepartTreeDto;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * @author : Sun
 * @description : 部门管理业务层
 * @date : 2019/11/5 21:37
 * @version : 1.0
 */
@Service
@CacheConfig
@Slf4j
@AllArgsConstructor
public class EiInsDepartService {

    private final EiInsDepartRepository eiInsDepartRepository;

    private final ProcessDtoToEntityUtil processDtoToEntity;

    private final ProcessEntityToDtoUtil processEntityToDto;

    private final EiInsDepartBaseRepository eiDepartBaseRepository;

    private final ModelMapper modelMapper;

    /**
     * @author Sun
     * @description 获取部门二叉树列表
     * @date 2019/11/5 21:37
     * @param id: 部门id
     * @return java.util.List<com.huatonghh.ins_authority.service.dto.EiInsDepartTreeDto>
     **/
    @Cacheable(cacheNames = InsAuthorityConstant.EI_INS_DEPARTS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null || #result.size() == 0")
    public List<EiInsDepartTreeDto> queryDepartTreeList(Integer id) {
        // 不指定即为查所有部门
        if (id == null) {
            id = InsAuthorityConstant.DEPART_TREE_HEAD_QYBX;
        }
        // 查询所有部门列表
        List<EiInsDepart> eiDepartList = eiInsDepartRepository.findParentDepartById(id);

        // 组装二叉树
        List<EiInsDepartTreeDto> eiDepartTreeDtoList = Lists.newArrayList();
        for (EiInsDepart eiDepart : eiDepartList) {
            // 获取最高层级部门
            if (id.equals(eiDepart.getId())) {
                EiInsDepartTreeDto eiDepartTreeDto = new EiInsDepartTreeDto();
                eiDepartTreeDto.setId(eiDepart.getId());
                eiDepartTreeDto.setName(eiDepart.getName());
                eiDepartTreeDto.setParentId(eiDepart.getParentId());
                // 放入新treeDto集合，并返回
                eiDepartTreeDto.setChildren(getChild(eiDepartTreeDto.getId(), eiDepartList));
                eiDepartTreeDtoList.add(eiDepartTreeDto);
            }
        }
        return eiDepartTreeDtoList;
    }


    /**
     * @author Sun
     * @description ei_depart 递归方法
     * @date 2019/11/5 21:38
     * @param id:
     * @param eiDepartList:
     * @return java.util.List<com.huatonghh.ins_authority.service.dto.EiInsDepartTreeDto>
     **/
    private List<EiInsDepartTreeDto> getChild(Integer id, List<EiInsDepart> eiDepartList) {
        List<EiInsDepartTreeDto> childList = Lists.newArrayList();
        for (EiInsDepart eiDepart : eiDepartList) {
            if (id.equals(eiDepart.getParentId())) {
                EiInsDepartTreeDto treeDepartDto = new EiInsDepartTreeDto();
                treeDepartDto.setId(eiDepart.getId());
                treeDepartDto.setName(eiDepart.getName());
                treeDepartDto.setParentId(eiDepart.getParentId());
                childList.add(treeDepartDto);
            }
        }
        // 递归，把子菜单的子菜单再循环一遍
        for (EiInsDepartTreeDto treeDepartDto : childList) {
            treeDepartDto.setChildren(getChild(treeDepartDto.getId(), eiDepartList));
        }
        // 递归退出条件
        if (childList.size() == 0) {
            return null;
        }
        return childList;
    }


    /**
     * @author Sun
     * @description 根据部门id，查询所有子部门列表
     * @date 2019/11/5 21:38
     * @param id:
     * @return java.util.List<com.huatonghh.ins_authority.service.dto.EiInsDepartDto>
     **/
    @Cacheable(cacheNames = InsAuthorityConstant.EI_INS_DEPARTS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null || #result.size() == 0")
    public List<EiInsDepartDto> queryDepartListById(Integer id) {
        // 查询所有部门列表
        List<EiInsDepart> eiDepartList = eiInsDepartRepository.findParentDepartById(id);
        List<EiInsDepartDto> eiDepartDtoList = Lists.newArrayList();
        for (EiInsDepart eiDepart : eiDepartList) {
            // 1
            EiInsDepartDto depart = processEntityToDto.departIns(eiDepart, 1);

            eiDepartDtoList.add(depart);
        }
        return eiDepartDtoList;
    }


    /**
     * @author Sun
     * @description 清除缓存
     * @date 2019/11/5 21:38
     **/
    @CacheEvict(cacheNames = InsAuthorityConstant.EI_INS_DEPARTS_BY_LOGIN_CACHE, allEntries = true)
    public void clearCache() {
        log.info("清除缓存成功！！！");
    }


    /**
     * @author Sun
     * @description 删除部门，可能会造成子级丢失、暂不做处理
     * @date 2019/11/5 21:38
     * @param departId:
     **/
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(cacheNames = InsAuthorityConstant.EI_INS_DEPARTS_BY_LOGIN_CACHE, allEntries = true)
    public void delete(Integer departId) {
        try {
            Optional<EiInsDepart> byId = eiInsDepartRepository.findById(departId);
            if (byId.isPresent()) {
                EiInsDepart eiDepart = byId.get();
                // 先删除中间表
                eiInsDepartRepository.deleteDepartUser(eiDepart.getIds());
                eiInsDepartRepository.deleteDepart(eiDepart.getIds());
            }
        } catch (Exception e) {
            log.error(StatusEnum.AUTHORITY_DELETE_DEPART_ERROR.getMessage() + ": {}", e.getMessage());
            throw new BusinessException(StatusEnum.AUTHORITY_DELETE_DEPART_ERROR);
        }
    }


    /**
     * @author Sun
     * @description 部门信息保存
     * @date 2019/11/5 21:38
     * @param eiDepartDto:
     * @return com.huatonghh.ins_authority.service.dto.EiInsDepartDto
     **/
    @CacheEvict(cacheNames = InsAuthorityConstant.EI_INS_DEPARTS_BY_LOGIN_CACHE, allEntries = true)
    @Transactional(rollbackFor = RuntimeException.class)
    public EiInsDepartDto saveDepart(EiInsDepartDto eiDepartDto) {
        EiInsDepart eiDepart = processDtoToEntity.departIns(eiDepartDto, 0);
        // 校验父部门是否存在
        Integer parentId = eiDepart.getParentId();
        if (parentId == 0) {
            EiInsDepartBase eiInsDepartBase = modelMapper.map(eiDepart, EiInsDepartBase.class);
            eiInsDepartBase = eiDepartBaseRepository.save(eiInsDepartBase);
            eiInsDepartBase.setIds(eiDepart.getId().toString() + ";");
            eiInsDepartBase = eiDepartBaseRepository.save(eiInsDepartBase);
            eiDepart = modelMapper.map(eiInsDepartBase, EiInsDepart.class);
            return processEntityToDto.departIns(eiDepart, 0);
        } else {
            Optional<EiInsDepart> byId = eiInsDepartRepository.findById(parentId);
            if (!byId.isPresent()) {
                throw new BusinessException("父部门不存在");
            }
            EiInsDepartBase eiInsDepartBase = modelMapper.map(eiDepart, EiInsDepartBase.class);
            eiInsDepartBase = eiDepartBaseRepository.save(eiInsDepartBase);
            eiInsDepartBase.setIds(byId.get().getIds() + eiInsDepartBase.getId() + ";");
            eiInsDepartBase = eiDepartBaseRepository.save(eiInsDepartBase);
            eiDepart = modelMapper.map(eiInsDepartBase, EiInsDepart.class);
            return processEntityToDto.departIns(eiDepart, 0);
        }
    }


    public Optional<EiInsDepart> findById(Integer id) {
        return eiInsDepartRepository.findById(id);
    }


    /**
     * @author Sun
     * @description 保险公司-获取部门信息，并校验是否存在
     * @date 2019/11/6 14:14
     * @param departId: 部门id
     * @return com.huatonghh.ins_authority.domain.EiInsDepart
     **/
    @Cacheable(cacheNames = InsAuthorityConstant.EI_INS_DEPARTS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null")
    public EiInsDepart findByIdCheckOptional(Integer departId) {
        Optional<EiInsDepart> eiDepartOptional = eiInsDepartRepository.findById(departId);
        if(!eiDepartOptional.isPresent()) {
            throw new BusinessException("保险公司未检索到该部门：", departId.toString());
        }
        return eiDepartOptional.get();
    }


    /**
     * @author Sun
     * description 根据保险公司说部门id，获取部门id、名称key value数据集， 并返回部门名称
     * @date 2019/11/6 15:56
     * @param departId: 部门id
     * @return java.lang.String
     **/
    @Cacheable(cacheNames = InsAuthorityConstant.EI_INS_DEPARTS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null")
    public String queryNameById(Integer departId) {
        List<ResponseIntegerKeyValueDto> responseIntegerKeyValueDtoList = eiInsDepartRepository.queryNameById(departId);
        if(responseIntegerKeyValueDtoList != null && responseIntegerKeyValueDtoList.size() > 0) {
            return responseIntegerKeyValueDtoList.get(0).getValue();
        }
        return null;
    }

    /**
     * @param departId: 部门id
     * @return java.lang.String
     * @author Sun
     * @description 根据保险公司说部门id，获取部门id、名称key value数据集， 并返回部门名称
     * @date 2019/11/6 15:56
     **/
    @Cacheable(cacheNames = InsAuthorityConstant.EI_INS_DEPARTS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null")
    public String queryNameById(String departId) {
        List<ResponseIntegerKeyValueDto> responseIntegerKeyValueDtoList = eiInsDepartRepository.queryNameById(Integer.valueOf(departId));
        if (responseIntegerKeyValueDtoList != null && responseIntegerKeyValueDtoList.size() > 0) {
            return responseIntegerKeyValueDtoList.get(0).getValue();
        }
        return null;
    }

    /**
     * @param departName: 部门名称
     * @return com.huatonghh.ins_authority.domain.EiInsDepart
     * @author Sun
     * @description 保险公司-获取部门信息，并校验是否存在
     * @date 2019/11/6 14:14
     **/
    public EiInsDepart findByName(String departName) {
        return eiInsDepartRepository.findOneByName(departName).orElse(null);
    }

    public List<EiInsDepart> queryInsDepart() {
        return eiInsDepartRepository.findAll();
    }
}
