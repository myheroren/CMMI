package com.huatonghh.ins_authority.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author : Sun
 * @description : 
 * @date : 2019/11/5 21:39
 * @version : 1.0
 */
@Data
@ApiModel(value = "保险公司部门二叉树对象")
public class EiInsDepartTreeDto implements Serializable {

    private static final long serialVersionUID = 3757152911583699840L;

    @ApiModelProperty(value = "部门id")
    private Integer id;

    @ApiModelProperty(value = "部门名称")
    private String name;

    @ApiModelProperty(value = "父部门id。根部门为0")
    private Integer parentId;

    @ApiModelProperty(value = "子部门集合")
    private List<EiInsDepartTreeDto> children;

    public EiInsDepartTreeDto(Integer id, String name, Integer parentId, List<EiInsDepartTreeDto> children) {
        this.id = id;
        this.name = name;
        this.parentId = parentId;
        this.children = children;
    }

    public EiInsDepartTreeDto() {
    }

}
