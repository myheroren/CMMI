package com.huatonghh.empower.service;

import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.common.util.system.PageParam;
import com.huatonghh.empower.service.dto.FileQuery;
import com.huatonghh.empower.service.dto.PolicyBaseInfoDTO;
import com.huatonghh.empower.service.dto.PolicyEngineeringDTO;
import com.huatonghh.empower.service.dto.PolicySaveDTO;
import com.huatonghh.file.service.dto.FiAuditFileDto;
import com.huatonghh.policy.domain.project.ProjectEntity;
import com.huatonghh.policy.service.dto.project.ProjectDTO;

import java.util.List;

/**
 * @author ghy
 * Date: 2021/1/6 17:14
 */
public interface EmpowerService {

    /**
     * 授权列表-组装DTO列表
     *
     * @param pageParam
     * @return
     */
    PageInfo<ProjectDTO> list(PageParam<EmpowerQuery> pageParam);

    /**
     * 授权列表-分页条件查询
     *
     * @param pageParam
     * @return
     */
    List<ProjectEntity> getPageList(PageParam<EmpowerQuery> pageParam);

    /**
     * 授权文件展示
     *
     * @return
     */
    List<FiAuditFileDto> fileList(FileQuery fileQuery);

    /**
     * 页面录入保单
     *
     * @return
     */
    Object savePolicy(PolicySaveDTO policySaveDTO);

    /**
     * 保存保单基本信息跟工程险特殊字段信息
     *
     */
    void savePolicyAndEngineering(PolicyBaseInfoDTO policyBaseInfoDTO, PolicyEngineeringDTO policyEngineeringDTO, String startCompany);
}
