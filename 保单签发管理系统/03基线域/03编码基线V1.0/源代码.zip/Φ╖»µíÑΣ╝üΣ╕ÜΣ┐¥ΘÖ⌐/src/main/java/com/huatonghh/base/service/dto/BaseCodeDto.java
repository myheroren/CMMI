package com.huatonghh.base.service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;


/**
 * Description : 基础代码Dto
 * @author : Sun
 * @date : 2019/9/11 15:29
 * @version : 1.0
 */
@Data
public class BaseCodeDto {

    @ApiModelProperty(value = "id")
    private Integer id;

    @ApiModelProperty(value = "类型代码")
    @NotNull
    @JsonProperty("typeId")
    private String typeId;

    @ApiModelProperty(value = "类型名称")
    @NotNull
    @JsonProperty("typeName")
    private String typeName;

    @ApiModelProperty(value = "代码值")
    private String codeId;

    @ApiModelProperty(value = "中文名称名称")
    private String codeName;

    @ApiModelProperty(value = "英文名称")
    private String ename;

    @ApiModelProperty(value = "备注字段")
    private String remark;

    @ApiModelProperty(value = "是否有效")
    private boolean valid;

    public BaseCodeDto() {
    }

    public BaseCodeDto(String typeId, String typeName) {
        this.typeId = typeId;
        this.typeName = typeName;
    }
}
