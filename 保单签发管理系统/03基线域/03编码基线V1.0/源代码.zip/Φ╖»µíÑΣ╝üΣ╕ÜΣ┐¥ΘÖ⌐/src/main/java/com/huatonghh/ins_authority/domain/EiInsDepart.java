package com.huatonghh.ins_authority.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * @author : Sun
 * @description : 保险公司部门表
 * @date : 2019/11/5 21:31
 * @version : 1.0
 */
@Entity
@Table(name = "ei_ins_depart")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Data
public class EiInsDepart implements Serializable {

    private static final long serialVersionUID = 5813085354936672142L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "parent_id")
    private Integer parentId;

    @Column(name = "ids")
    private String ids;

    @JsonIgnore
    @ManyToMany
    @JoinTable(
        name = "ei_ins_depart_user",
        joinColumns = {@JoinColumn(name = "depart_id", referencedColumnName = "id")},
        inverseJoinColumns = {@JoinColumn(name = "user_id", referencedColumnName = "id")})
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @BatchSize(size = 30)
    private Set<EiInsUser> authorities = new HashSet<>();


    @Override
    public String toString() {
        return "EiInsDepart{" +
            "id=" + id +
            ", name='" + name + '\'' +
            ", parentId=" + parentId +
            ", ids='" + ids + '\'' +
            '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof EiInsDepart)) {
            return false;
        }
        EiInsDepart that = (EiInsDepart) o;
        return Objects.equals(id, that.id) &&
            Objects.equals(name, that.name) &&
            Objects.equals(parentId, that.parentId) &&
            Objects.equals(ids, that.ids);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, parentId, ids);
    }
}
