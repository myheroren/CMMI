package com.huatonghh.fund.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author ghy
 * Date: 2021/1/6 9:14
 */
@Data
@ApiModel("基金使用记录DTO")
@NoArgsConstructor
@AllArgsConstructor
public class FundDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 所属保险公司
     */
    @ApiModelProperty("所属保险公司")
    private Integer belongCompany;

    /**
     * 总额
     */
    @ApiModelProperty("基金总额")
    private BigDecimal total;

    /**
     * 已使用的
     */
    @ApiModelProperty("使用基金数")
    private BigDecimal used;

    /**
     * 剩余的
     */
    @ApiModelProperty("剩余基金数")
    private BigDecimal left;

}
