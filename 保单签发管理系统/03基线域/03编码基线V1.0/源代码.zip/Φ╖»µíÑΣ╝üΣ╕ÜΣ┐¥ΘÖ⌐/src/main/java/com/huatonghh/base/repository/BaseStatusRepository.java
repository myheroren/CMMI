package com.huatonghh.base.repository;

import com.huatonghh.base.domain.BaseStatus;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/7
 */
public interface BaseStatusRepository extends JpaRepository<BaseStatus, String> {
}
