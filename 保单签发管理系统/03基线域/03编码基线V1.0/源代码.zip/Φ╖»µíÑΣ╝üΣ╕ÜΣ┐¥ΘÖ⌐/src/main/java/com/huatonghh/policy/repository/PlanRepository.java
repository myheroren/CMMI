package com.huatonghh.policy.repository;

import com.huatonghh.policy.domain.plan.PlanEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

/**
 * @author hao.wang
 */

public interface PlanRepository extends JpaRepository<PlanEntity, String>, JpaSpecificationExecutor {

    PlanEntity findByPlanNo(String planNo);

    /**
     * 根据发起公司和有效状态查询
     *
     * @param startCompany 发起公司
     * @param valid        有效状态
     * @return 计划列表
     */
    List<PlanEntity> findAllByStartCompanyAndIsValidOrderByCreateTimeDesc(String startCompany, Boolean valid);

    /**
     * 查自己发起的
     *
     * @param startUser 发起人
     * @param valid     有效状态
     * @return 计划
     */
    List<PlanEntity> findAllByStartUserAndIsValidOrderByCreateTimeDesc(String startUser, Boolean valid);


}
