package com.huatonghh.policy.domain.policy;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

/**
 * Description : 保单基本信息
 *
 * @author : Sun
 * @version : 1.0
 * @date : 2019/8/31 14:01
 */
@Entity
@Table(name = "policy_main")
@Data
public class PolicyMain implements Serializable {

    private static final long serialVersionUID = -4483461902206656052L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private BigInteger id;

    @Column(name = "policy_no")
    private String policyNo;

    @Column(name = "car_uncar_flag")
    private Byte carUncarFlag;

    /**
     * 保险类别: 1责任保险 2工程保险 3意外伤害保险
     */
    @Column(name = "insurance_category")
    private String insuranceCategory;

    /**
     * 险种类型：0工程险；1团意险；2安责险；3雇主责任险
     */
    @Column(name = "kind_code")
    private String kindCode;

    /**
     * 项目组织
     */
    @Column(name = "project_name")
    private String projectName;

    /**
     * 投保人，中文
     */
    @Column(name = "holder_name")
    private String holderName;

    /**
     * 投保人证件类型:1统一社会信用代码，2组织机构代码
     */
    @Column(name = "holder_certificate_type")
    private String holderCertificateType;
    /**
     * 投保人证件号码
     */
    @Column(name = "holder_certificate_number")
    private String holderCertificateNumber;


    /**
     * 被保险人，中文
     */
    @Column(name = "insured_name")
    private String insuredName;

    /**
     * 被保人证件类型：:统一社会信用代码，组织机构代码
     */
    @Column(name = "insured_certificate_type")
    private String insuredCertificateType;

    /**
     * 被保人证件号码
     */
    @Column(name = "insured_certificate_number")
    private String insuredCertificateNumber;

    /**
     * 发起公司id
     */
    @Column(name = "start_company")
    private String startCompany;

    /**
     * 归属保险公司
     */
    @Column(name = "belong_company")
    private String belongCompany;
    /**
     * 归属保险公司name
     */
    @Column(name = "belong_company_name")
    private String belongCompanyName;

    /**
     * 含税保费
     */
    @Column(name = "total_premium")
    private BigInteger totalPremium;

    /**
     * 不含税保费
     */
    private BigInteger freeTaxPremium;
    /**
     * 保费到账日期
     */
    private Date premiumArrivalTime;
    /**
     * 保费应收日期
     */
    private Date premiumReceivableTime;
    /**
     * 投保日期
     */
    @Column(name = "policy_apply_time")
    private Date policyApplyTime;
    @Column(name = "policy_bgn_time")
    private Date policyBgnTime;
    @Column(name = "policy_end_time")
    private Date policyEndTime;

    @Column(name = "create_time")
    private Date createTime;
    @Column(name = "update_time")
    private Date updateTime;
    /**
     * 保司联系人
     */
    @Column(name = "belong_company_person")
    private String belongCompanyPerson;
    /**
     * 保司联系电话
     */
    @Column(name = "belong_company_phone")
    private String belongCompanyPhone;

    /**
     * 状态 0未生效，1生效,2过期，-2注销，-22注销申请，-1退保，-11退保申请
     */
    @Column(name = "status", columnDefinition = "tinyint(2) default 0")
    private Byte status;

    /**
     * 是否显示
     */
    @Column(name = "remind_display", columnDefinition = "tinyint(1) default 1")
    private Boolean remindDisplay;
    /**
     * 是否提醒
     */
    private Boolean remindStatus;

    /**
     * 总保额
     */
    @Column(name = "total_amount")
    private BigInteger totalAmount;

    /**
     * 历史保单导入批次号
     */
    @Column(name = "import_batch_no")
    private BigInteger importBatchNo;

    /**
     * 距离过期天数
     */
    @Column(name = "expiration_days")
    private Integer expirationDays;

    /**
     * 续保状态（续保管理用到）
     */
    @Column(name = "renew_status")
    private Byte renewStatus;


    /**
     * 项目合同金额
     */
    @Column(name = "project_contract_amount")
    private BigInteger projectContractAmount;

    /**
     * 费率
     */
    @Column(name = "rate")
    private BigDecimal rate;

    /**
     * 可计提的防灾防损基金
     */
    @Column(name = "total_fund")
    private BigInteger totalFund;

    /**
     * 已使用的防灾防损基金
     */
    @Column(name = "used_fund")
    private BigInteger usedFund;

    /**
     * 剩余的防灾防损基金
     */
    @Column(name = "left_fund")
    private BigInteger leftFund;

}
