package com.huatonghh.excel.util;

import com.alibaba.excel.converters.Converter;
import com.alibaba.excel.enums.CellDataTypeEnum;
import com.alibaba.excel.metadata.CellData;
import com.alibaba.excel.metadata.GlobalConfiguration;
import com.alibaba.excel.metadata.property.ExcelContentProperty;
import org.apache.commons.lang3.StringUtils;

import java.math.BigInteger;

/**
 * @author : Sun
 * @description : 
 * @date : 2019/11/5 21:20
 * @version : 1.0
 */
public class BigIntegerConverter implements Converter<BigInteger> {
    @Override
    public Class supportJavaTypeKey() {
        return null;
    }

    @Override
    public CellDataTypeEnum supportExcelTypeKey() {
        return null;
    }

    @Override
    public BigInteger convertToJavaData(CellData cellData, ExcelContentProperty contentProperty, GlobalConfiguration globalConfiguration) {
        // TODO: 使用TYPE = "STRING"/"NUMBER"判断
        if(StringUtils.isNotBlank(cellData.getStringValue())) {
            return new BigInteger(cellData.getStringValue());
        }
        if(cellData.getNumberValue() != null) {
            return cellData.getNumberValue().toBigInteger();
        }
        return null;
    }

    @Override
    public CellData convertToExcelData(BigInteger value, ExcelContentProperty contentProperty, GlobalConfiguration globalConfiguration) {
        return new CellData(value.toString());
    }
}
