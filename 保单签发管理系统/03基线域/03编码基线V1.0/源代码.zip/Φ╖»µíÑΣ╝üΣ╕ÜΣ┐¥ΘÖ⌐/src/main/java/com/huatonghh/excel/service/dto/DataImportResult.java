package com.huatonghh.excel.service.dto;

import lombok.Data;

import java.math.BigInteger;
import java.util.List;

/**
 * @author : wh
 * description : 数据导入结果
 * @version : 1.0
 * @date : 2020/7/9 15:17
 */
@Data
public class DataImportResult {
    private BigInteger importBatchNo;
    private Integer totalNum;
    private Integer successNum;
    private Integer failNum;
    /**
     * 错误数据id
     */
    private BigInteger failId;
    private List<Object> failList;

    public static DataImportResult init() {
        DataImportResult result = new DataImportResult();
        result.setImportBatchNo(BigInteger.valueOf(System.currentTimeMillis()));
        result.setFailNum(0);
        result.setSuccessNum(0);
        return result;
    }
}
