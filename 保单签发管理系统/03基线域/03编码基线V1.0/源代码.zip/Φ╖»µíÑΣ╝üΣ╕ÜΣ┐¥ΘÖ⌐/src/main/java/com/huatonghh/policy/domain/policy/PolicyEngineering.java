package com.huatonghh.policy.domain.policy;


import lombok.Data;

import javax.persistence.*;
import java.math.BigInteger;

/**
 * description: 工程险信息
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/22
 */
@Entity
@Table(name = "policy_engineering")
@Data
public class PolicyEngineering {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private BigInteger id;
    @Column(name = "policy_no")
    private String policyNo;
    /**
     * 基本项目名称
     */
    @Column(name = "eng_name")
    private String engName;
    /**
     * 工程类别
     */
    @Column(name = "eng_type")
    private String engType;

    /**
     * 施工合同数
     */
    @Column(name = "contract")
    private String contract;
    /**
     * 工程造价
     */
    @Column(name = "eng_cost")
    private BigInteger engCost;
    /**
     * 所属标段
     */
    @Column(name = "belong_bid")
    private String belongBid;
    /**
     * 期次
     */
    @Column(name = "period")
    private Integer period;
    /**
     * 保证期
     */
    @Column(name = "assure_data")
    private String assureData;
    /**
     * 防火防损比例
     */
    @Column(name = "prevention_prop")
    private String preventionProp;
    /**
     * 赔偿限额，第三者责任部分
     */
    @Column(name = "limit_third")
    private String limitThird;
    /**
     * 免赔条件，第三者责任部分
     */
    @Column(name = "deductible_third")
    private String deductibleThird;
    /**
     * 免赔条件，物质部分
     */
    @Column(name = "deductible_material")
    private String deductibleMaterial;
    /**
     * 特别约定
     */
    @Column(name = "special_form")
    private String specialForm;

}

//  /**
//     * 基本项目id
//     */
//@Column(name = "pro_id")
//private Integer proId;
//    /**
//     * 项目类别
//     */
//    @Column(name = "pro_type")
//    private String proType;
//    /**
//     * 基本项目名称
//     */
//    @Column(name = "pro_name")
//    private String proName;
//    /**
//     * 项目别称
//     */
//    @Column(name = "pro_alias")
//    private String proAlias;
//    /**
//     * 基本项目联系电话
//     */
//    @Column(name = "pro_tel")
//    private String proTel;
//    /**
//     * 基本项目联系人
//     */
//    @Column(name = "pro_contact")
//    private String proContact;
//
