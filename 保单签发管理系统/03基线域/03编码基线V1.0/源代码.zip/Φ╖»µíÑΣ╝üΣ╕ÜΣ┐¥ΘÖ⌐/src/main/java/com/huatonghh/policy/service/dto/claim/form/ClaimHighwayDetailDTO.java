package com.huatonghh.policy.service.dto.claim.form;

import lombok.Data;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * description:公路工程一切险分类汇总表
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/9
 */
@Data
public class ClaimHighwayDetailDTO {
    /**
     * 索赔次数
     */
    private BigInteger countApply;
    /**
     * 损失额/估损金额
     */
    private BigDecimal preLossAmount;
    /**
     * 索赔金额
     */
    private BigDecimal askForAmount;
    /**
     * 赔偿额
     */
    private BigDecimal payAmount;

}
