package com.huatonghh.excel.util;

import com.huatonghh.common.constant.MathConstant;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * @author : wh
 * description : 数字格式转化
 * @version : 1.0
 * @date : 2020/5/18 18:37
 */
public class NumberFormatUtils {

    /**
     * 元转分，四舍五入
     *
     * @param yuan 元
     * @return 分
     */
    public static BigInteger yuanToCent(String yuan) {
        if (null == yuan || StringUtils.isBlank(yuan)) {
            return null;
        }

        BigDecimal a = new BigDecimal(yuan).setScale(2, BigDecimal.ROUND_HALF_UP);
        return a.multiply(MathConstant.BIG_DECIMAL_ONE_HUNDRED).toBigInteger();
    }

    /**
     * 分转元，四舍五入
     *
     * @param cent 分
     * @return 元
     */
    public static String centToYuan(BigInteger cent) {
        String bigStr = MathConstant.ZERO;
        if (cent != null && cent.compareTo(MathConstant.BIG_INTEGER_ZERO) != 0) {
            BigDecimal a = new BigDecimal(cent.toString());
            bigStr = a.divide(MathConstant.BIG_DECIMAL_ONE_HUNDRED, 2, BigDecimal.ROUND_HALF_UP).toString();
        }
        return bigStr;
    }


}
