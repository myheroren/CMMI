package com.huatonghh.excel.service.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.huatonghh.excel.util.DateConverter;
import lombok.Data;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.util.Date;

/**
 * description: 历史保单导入
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/9
 */
@Data
@ContentRowHeight(20)
@HeadRowHeight(20)
@ColumnWidth(15)
public class PolicyImportData implements Comparable {
    @ExcelProperty(value = "承保公司", index = 0)
    private String belongCompanyName;
    @ExcelProperty(value = "保单号", index = 1)
    private String policyNo;
    @ExcelProperty(value = "投保人", index = 2)
    private String holderName;
    @ExcelProperty(value = "被保险人", index = 3)
    private String insuredName;
    @ExcelProperty(value = "险种类别", index = 4)
    private String insuranceCategory;
    @ExcelProperty(value = "险种", index = 5)
    private String kindCode;
    @ExcelProperty(value = "业务员", index = 6)
    private String belongCompanyPerson;
    @ExcelProperty(value = "投保日期", index = 7, converter = DateConverter.class)
    private Date policyApplyTime;
    @ExcelProperty(value = "保险起期", index = 8, converter = DateConverter.class)
    private Date policyBgnTime;
    @ExcelProperty(value = "保险止期", index = 9, converter = DateConverter.class)
    private Date policyEndTime;
    @ExcelProperty(value = "含税保费", index = 10)
    private String totalPremium;
    @ExcelProperty(value = "不含税保费", index = 11)
    private String freeTaxPremium;

    @ExcelProperty(value = "车船税", index = 12)
    private String vehicleVesselTax;
    @ExcelProperty(value = "车牌", index = 13)
    private String plateNo;
    @ExcelProperty(value = "NCD系数", index = 14)
    private String ncdCoef;
    @ExcelProperty(value = "自主渠道系数", index = 15)
    private String selfChannelCoef;
    @ExcelProperty(value = "自主核保优惠系数", index = 16)
    private String autoUnderwritingCoef;
    @ExcelProperty(value = "自主系数乘积", index = 17)
    private String selfSumCoef;

    @ExcelProperty(value = "项目全称", index = 18)
    private String proName;
    @ExcelProperty(value = "承保份额", index = 19)
    private String proportion;
    @ExcelProperty(value = "缴费期", index = 20)
    private String periodNo;
    @ExcelProperty(value = "手续费比例", index = 21)
    private String feeProp;
    @ExcelProperty(value = "手续费金额（元）", index = 22)
    private String handlingFee;
    @ExcelProperty(value = "入账手续费", index = 23)
    private String handlingFeeEntryAccount;
    @ExcelProperty(value = "应收日期", index = 24, converter = DateConverter.class)
    private Date handlingFeeReceivableTime;
    @ExcelProperty(value = "转账日期", index = 25, converter = DateConverter.class)
    private Date handlingFeeArrivalTime;

    @ExcelProperty(value = "备注", index = 26)
    private String remark;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        PolicyImportData that = (PolicyImportData) o;

        return new EqualsBuilder()
            .append(policyNo, that.policyNo)
            .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
            .append(policyNo)
            .toHashCode();
    }


    @Override
    public int compareTo(Object o) {
        if (this.policyNo.equals(o.toString())) {
            return 0;
        }
        return -1;
    }
}
