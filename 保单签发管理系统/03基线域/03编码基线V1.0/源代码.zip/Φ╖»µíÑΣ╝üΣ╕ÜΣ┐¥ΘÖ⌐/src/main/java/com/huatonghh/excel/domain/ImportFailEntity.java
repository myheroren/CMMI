package com.huatonghh.excel.domain;

import lombok.Data;

import javax.persistence.*;
import java.math.BigInteger;

/**
 * description:导入失败数据
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/5
 */
@Entity
@Table(name = "import_fail")
@Data
public class ImportFailEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private BigInteger id;

    private BigInteger importBatchNo;
    /**
     * 错误数据，List数据json串
     */
    private String data;
    /**
     * 数据类型，1、保单 2、车
     */
    private String type;
}
