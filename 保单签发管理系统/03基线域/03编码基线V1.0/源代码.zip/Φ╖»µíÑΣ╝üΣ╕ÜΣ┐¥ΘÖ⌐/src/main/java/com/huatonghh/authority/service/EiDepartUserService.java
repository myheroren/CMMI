package com.huatonghh.authority.service;

import com.huatonghh.authority.domain.EiDepartUser;
import com.huatonghh.authority.repository.EiDepartUserRepository;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;


/**
 * @author : Sun
 * @description : 部门管理业务层
 * @date : 2019/11/5 20:11
 * @version : 1.0
 */
@Service
@CacheConfig
@Slf4j
public class EiDepartUserService {

    private final EiDepartUserRepository eiDepartUserRepository;

    private final ModelMapper modelMapper;

    public EiDepartUserService(EiDepartUserRepository eiDepartUserRepository, ModelMapper modelMapper) {
        this.eiDepartUserRepository = eiDepartUserRepository;
        this.modelMapper = modelMapper;
    }


    /**
     * @author Sun
     * @description 插入关系表
     * @date 2019/11/5 20:09
     * @param listEiDepartUser:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiDepartTreeDto>
     **/
    @Transactional(rollbackFor = RuntimeException.class)
    public List<EiDepartUser>  saveAll(List<EiDepartUser> listEiDepartUser) {

        return eiDepartUserRepository.saveAll(listEiDepartUser);
    }

    /**
     * @author Sun
     * @description 插入关系表
     * @date 2019/11/5 20:09
     * @param eiDepartUser:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiDepartTreeDto>
     **/
    @Transactional(rollbackFor = RuntimeException.class)
    public EiDepartUser  save(EiDepartUser eiDepartUser) {

        return eiDepartUserRepository.save(eiDepartUser);
    }

    /**
     * @author Sun
     * @description 插入关系表
     * @date 2019/11/5 20:09
     * @param eiDepartUser:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiDepartTreeDto>
     **/
    @Transactional(rollbackFor = RuntimeException.class)
    public void  delete(EiDepartUser eiDepartUser) {

        eiDepartUserRepository.delete(eiDepartUser);
    }
}
