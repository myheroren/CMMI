package com.huatonghh.excel.service.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.huatonghh.excel.util.DateConverter;
import lombok.Data;

import java.util.Date;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/9
 */
@Data
@ContentRowHeight(20)
@HeadRowHeight(20)
@ColumnWidth(15)
public class PolicyData {
    @ExcelProperty(value = "承保公司（全-股份有限公司）", index = 0)
    private String belongCompanyName;
    @ExcelProperty(value = "2018保单-从18年开始（可选）", index = 1)
    private String policyNo8;
    @ExcelProperty(value = "2019保单（除了工程险）", index = 2)
    private String policyNo9;
    @ExcelProperty(value = "保单号", index = 3)
    private String policyNo;
    @ExcelProperty(value = "发起公司", index = 4)
    private String startCompanyName;
    @ExcelProperty(value = "投保人", index = 5)
    private String holderName;
    @ExcelProperty(value = "被保险人", index = 6)
    private String insuredName;
    @ExcelProperty(value = "险种类别", index = 7)
    private String insuranceCategory;
    @ExcelProperty(value = "险种", index = 8)
    private String kindCode;

    @ExcelProperty(value = "业务员", index = 9)
    private String salesman;
    @ExcelProperty(value = "投保日期", index = 10, converter = DateConverter.class)
    private Date policyApplyTime;

    @ExcelProperty(value = "保险起期", index = 11, converter = DateConverter.class)
    private Date policyBgnTime;
    @ExcelProperty(value = "保险止期", index = 12, converter = DateConverter.class)
    private Date policyEndTime;
    @ExcelProperty(value = "保费到账日期", index = 13, converter = DateConverter.class)
    private Date premiumArrivalTime;
    @ExcelProperty(value = "保费应收日期", index = 14, converter = DateConverter.class)
    private Date premiumReceivableTime;
    @ExcelProperty(value = "含税保费", index = 15)
    private String totalPremium;
    @ExcelProperty(value = "不含税保费", index = 16)
    private String freeTaxPremium;
    @ExcelProperty(value = "手续费比例", index = 17)
    private String feeProp;
    @ExcelProperty(value = "收入手续费", index = 18)
    private String handlingFeeIncome;
    @ExcelProperty(value = "入账手续费", index = 19)
    private String handlingFeeEntryAccount;
    @ExcelProperty(value = "手续费应收日期", index = 20, converter = DateConverter.class)
    private Date handlingFeeReceivableTime;
    @ExcelProperty(value = "手续费转账日期", index = 21, converter = DateConverter.class)
    private Date handlingFeeArrivalTime;
    @ExcelProperty(value = "车牌", index = 22)
    private String plateNo;
    @ExcelProperty(value = "项目名称", index = 23)
    private String proName;
    @ExcelProperty(value = "车船税", index = 24)
    private String vehicleVesselTax;
}
