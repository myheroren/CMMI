package com.huatonghh.ins_authority.service;

import com.google.common.collect.Lists;
import com.huatonghh.common.constant.enums.StatusEnum;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.service.dto.ResponseIntegerKeyValueDto;
import com.huatonghh.common.util.process.ProcessDtoToEntityUtil;
import com.huatonghh.common.util.process.ProcessEntityToDtoUtil;
import com.huatonghh.ins_authority.constant.InsAuthorityConstant;
import com.huatonghh.ins_authority.domain.EiInsDepart;
import com.huatonghh.ins_authority.domain.EiInsDepartBase;
import com.huatonghh.ins_authority.repository.EiInsDepartBaseRepository;
import com.huatonghh.ins_authority.repository.EiInsDepartRepository;
import com.huatonghh.ins_authority.service.dto.EiInsDepartDto;
import com.huatonghh.ins_authority.service.dto.EiInsDepartTreeDto;
import com.huatonghh.ins_authority.service.dto.EiInsDepartVO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * @author : Sun
 * @description : 部门管理业务层
 * @date : 2019/11/5 21:37
 * @version : 1.0
 */
@Service
@CacheConfig
@Slf4j
@AllArgsConstructor
public class EiInsDepartV2Service {

    private final EiInsDepartRepository eiDepartRepository;

    private final ProcessDtoToEntityUtil processDtoToEntity;

    private final ProcessEntityToDtoUtil processEntityToDto;

    private final EiInsDepartBaseRepository eiDepartBaseRepository;

    private final ModelMapper modelMapper;


    @Cacheable(cacheNames = InsAuthorityConstant.EI_INS_DEPARTS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null || #result.size() == 0")
    public List<EiInsDepartVO> queryDepartListById(Integer id) {
        // 查询所有部门列表
        List<EiInsDepart> eiDepartList = eiDepartRepository.findParentDepartById(id);
        List<EiInsDepartVO> eiDepartDtoList = Lists.newArrayList();
        for (EiInsDepart eiDepart : eiDepartList) {
            EiInsDepartVO depart = modelMapper.map(eiDepart,EiInsDepartVO.class);
            eiDepartDtoList.add(depart);
        }
        return eiDepartDtoList;
    }


    /**
     * @author Sun
     * @description 清除缓存
     * @date 2019/11/5 21:38
     **/
    @CacheEvict(cacheNames = InsAuthorityConstant.EI_INS_DEPARTS_BY_LOGIN_CACHE, allEntries = true)
    public void clearCache() {
        log.info("清除缓存成功！！！");
    }





    public Optional<EiInsDepart> findById(Integer id) {
        return eiDepartRepository.findById(id);
    }




}
