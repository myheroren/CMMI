package com.huatonghh.policy.web.rest.claim;


import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.message.po.dto.MessageVO;
import com.huatonghh.policy.service.claim.noncar.UnCarClaimService;
import com.huatonghh.policy.service.dto.claim.form.ClaimMessageDTO;
import com.huatonghh.policy.service.dto.claim.noncar.*;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.math.BigInteger;
import java.util.List;

/**
 * @author : hao.wang
 * @date : 2019/8/23
 * description: 非车理赔
 */
@AllArgsConstructor
@RestController
@RequestMapping("api/noncar-claim/v1")
@Api(tags = "18、非车理赔", value = "非车理赔")
public class UnCarClaimController {

    private final UnCarClaimService claimService;

    @Transactional(rollbackFor = RuntimeException.class)
    @PostMapping(value = "/save")
    @ApiOperation(value = "理赔报案", notes = "理赔报案", httpMethod = "POST")
    @Timed
    public ApiResponse<String> save(@RequestBody @Valid ClaimBasicDTO basicDTO) {
        return ApiResponse.ofSuccess(claimService.save(basicDTO));
    }

    @Transactional(rollbackFor = RuntimeException.class)
    @PostMapping(value = "/update")
    @ApiOperation(value = "理赔修改", notes = "理赔修改", httpMethod = "POST")
    @Timed
    public ApiResponse<BigInteger> update(@RequestBody ClaimBasicDTO basicDTO) {
        claimService.update(basicDTO);
        return ApiResponse.ofSuccess(null);
    }

    @Transactional(rollbackFor = RuntimeException.class)
    @GetMapping(value = "/{reportId}")
    @ApiOperation(value = "理赔详情", notes = "根据报案主键查询", httpMethod = "GET")
    @Timed
    public ApiResponse<ClaimDetailDTO> detail(@PathVariable("reportId") String reportId) {
        return ApiResponse.ofSuccess(claimService.detail(reportId));
    }

//    @Transactional(rollbackFor = RuntimeException.class)
//    @GetMapping(value = "list")
//    @ApiOperation(value = "保单理赔列表", notes = "根据保单号查询", httpMethod = "GET")
//    @Timed
//    public ApiResponse<List<PolicyClaimDTO>> listByPolicy(@RequestParam("policyNo") String policyNo) {
//        return ApiResponse.ofSuccess(claimService.listByPolicy(policyNo));
//    }

    @Transactional(rollbackFor = RuntimeException.class)
    @PostMapping(value = "list")
    @ApiOperation(value = "理赔列表", notes = "分页查询", httpMethod = "POST")
    @Timed
    public ApiResponse<PageInfo<ClaimListDTO>> list(@RequestBody @Valid ClaimListQuery query) {
        return ApiResponse.ofSuccess(claimService.list(query));
    }

    @GetMapping(value = "reportInfoAssociationList/{policyNo}/{reportId}")
    @ApiOperation(value = "报案号关联待选列表", notes = "报案号关联待选列表", httpMethod = "GET")
    public ApiResponse<List<ReportAssociationDTO>> reportInfoAssociationList(@PathVariable("policyNo") String policyNo, @PathVariable("reportId") String reportId) {
        return ApiResponse.ofSuccess(claimService.reportInfoAssociationList(policyNo, reportId));
    }

    @GetMapping(value = "associate/{reportId}/{reportNo}")
    @ApiOperation(value = "报案号与报案id关联", notes = "报案号与报案id关联", httpMethod = "GET")
    public ApiResponse associate(@PathVariable("reportId") String reportId, @PathVariable("reportNo") String reportNo) {
        claimService.associate(reportId, reportNo);
        return ApiResponse.ofSuccess(null);
    }

    @PostMapping(value = "sendMsg")
    @ApiOperation(value = "11、发送消息", notes = "理赔详情发送消息")
    @ApiOperationSupport(order = 11)
    public ApiResponse<Object> sendMsg(@RequestBody ClaimMessageDTO claimMessageDTO) {
        claimService.sendMsg(claimMessageDTO);
        return ApiResponse.ofSuccess(null);
    }

    @GetMapping(value = "queryMsg")
    @ApiOperation(value = "12、查询消息", notes = "理赔详情查询一个理赔报案下面的消息列表")
    @ApiOperationSupport(order = 12)
    public ApiResponse<List<MessageVO>> queryMsg(@RequestParam String reportId) {
        return ApiResponse.ofSuccess(claimService.queryMsg(reportId));
    }

    public List<ClaimListDTO> claimList(ClaimListQuery query) {
        return claimService.claimList(query);
    }
}
