package com.huatonghh.base.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author wanggl
 * @date 2020/6/3 19:09
 */
@Data
@ApiModel(value = "工程险二级菜单数据")
public class InsAccdntDataDTO {
    @ApiModelProperty(value = "险种名称 or 出现原因")
    private String name;

    @ApiModelProperty(value = "代码")
    private String code;

    @ApiModelProperty(value = "所属险种代码")
    private String parCode;

    @ApiModelProperty(value = "出现原因数组")
    private List<InsAccdntDataDTO> chird;
}
