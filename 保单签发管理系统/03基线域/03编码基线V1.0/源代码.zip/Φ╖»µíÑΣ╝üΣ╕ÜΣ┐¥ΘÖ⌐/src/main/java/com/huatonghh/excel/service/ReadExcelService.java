package com.huatonghh.excel.service;

import com.huatonghh.authority.service.EiDepartService;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.excel.service.dto.PolicyImportData;
import com.huatonghh.excel.util.NumberFormatUtils;
import com.huatonghh.ins_authority.domain.EiInsDepart;
import com.huatonghh.ins_authority.service.EiInsDepartService;
import com.huatonghh.policy.constant.PolicyConstant;
import com.huatonghh.policy.domain.policy.PolicyCarDetail;
import com.huatonghh.policy.domain.policy.PolicyMain;
import com.huatonghh.policy.repository.policy.PolicyMainRepository;
import com.huatonghh.policy.service.PolicyService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Map;
import java.util.Optional;
import java.util.Set;


/**
 * @author : wh
 * @version : 1.0
 * description :
 * @date : 2019/11/5 21:19
 */
@Service
@Slf4j
@AllArgsConstructor
public class ReadExcelService {
    private final PolicyService policyService;

    private final ModelMapper modelMapper;

    private final EiDepartService eiDepartService;

    private final EiInsDepartService eiInsDepartService;

    private final PolicyMainRepository policyMainRepository;

    public void importPolicy(Set<PolicyImportData> policyImportDatas, Map<String, String> insuranceCategoryMap, Map<String, String> kindCodeMap, BigInteger importBatchNo, Integer successNum) {
        //待入库数据
        ArrayList<PolicyMain> policyMainInsertList = new ArrayList<>();
        ArrayList<PolicyMain> policyMainUpdateList = new ArrayList<>();
        ArrayList<PolicyCarDetail> policyCarDetailInsertList = new ArrayList<>();
        ArrayList<PolicyCarDetail> policyCarDetailUpdateList = new ArrayList<>();
        for (PolicyImportData data : policyImportDatas) {
            //  保单导入，是否需要先根据保单号查库，有则修改，无则新增
            Optional<PolicyMain> policyMainOptional = policyMainRepository.findByPolicyNo(data.getPolicyNo());
            PolicyMain policyMain = policyMainOptional.orElseGet(PolicyMain::new);

            policyMain.setImportBatchNo(importBatchNo);
            policyMain.setBelongCompanyName(data.getBelongCompanyName());
            //  根据投保人
            if (StringUtils.isNotBlank(data.getHolderName())) {
                String startCompany = eiDepartService.queryIdByName(data.getHolderName());
                policyMain.setStartCompany(startCompany);
            }

            if (StringUtils.isNotBlank(data.getBelongCompanyName())) {
                EiInsDepart depart = eiInsDepartService.findByName(data.getBelongCompanyName());
                if (null == depart) {
                    // 不存在，报错
                    throw new BusinessException("保险公司不存在:" + data.getBelongCompanyName());
                }
                policyMain.setBelongCompany(depart.getId() + "");
            }
            policyMain.setStatus(policyService.getPolicyStatus(data.getPolicyBgnTime(), data.getPolicyEndTime()));
            policyMain.setPolicyNo(data.getPolicyNo());
            policyMain.setHolderName(data.getHolderName());
            policyMain.setInsuredName(data.getInsuredName());
            policyMain.setBelongCompanyPerson(data.getBelongCompanyPerson());
            policyMain.setPolicyApplyTime(data.getPolicyApplyTime());
            policyMain.setPolicyBgnTime(data.getPolicyBgnTime());
            policyMain.setPolicyEndTime(data.getPolicyEndTime());
            // 含税保费，元转分
            if (StringUtils.isNotBlank(data.getTotalPremium())) {
                policyMain.setTotalPremium(NumberFormatUtils.yuanToCent(data.getTotalPremium()));
            }
            // 不含税保费，元转分
            if (StringUtils.isNotBlank(data.getFreeTaxPremium())) {
                policyMain.setFreeTaxPremium(NumberFormatUtils.yuanToCent(data.getFreeTaxPremium()));
            }
            //  根据险种判断是车还是非车

            // 险种类别
            policyMain.setInsuranceCategory(insuranceCategoryMap.get(data.getInsuranceCategory()));
            // 险种
            policyMain.setKindCode(kindCodeMap.get(data.getKindCode()));
            policyMain.setCarUncarFlag(PolicyConstant.POLICY_CAR_UN);

            if (policyMainOptional.isPresent()) {
                policyMainUpdateList.add(policyMain);
            } else {
                policyMainInsertList.add(policyMain);
            }
            successNum++;

        }

        policyService.batchInsertPolicyMain(policyMainInsertList);
        policyService.batchUpdatePolicyMain(policyMainUpdateList);
        policyService.batchInsertPolicyCarDetail(policyCarDetailInsertList);
        policyService.batchUpdatePolicyCarDetail(policyCarDetailUpdateList);
    }
}
