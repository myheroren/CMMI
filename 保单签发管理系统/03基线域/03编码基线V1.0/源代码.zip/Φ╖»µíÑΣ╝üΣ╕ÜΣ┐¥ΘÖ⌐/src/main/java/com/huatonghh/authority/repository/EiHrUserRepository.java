package com.huatonghh.authority.repository;

import com.huatonghh.authority.domain.EiHrUser;
import com.huatonghh.authority.domain.EiUser;
import com.huatonghh.common.service.dto.ResponseStringKeyValueDto;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


/**
 * @author : Sun
 * @description : 交投集团-用户-数据仓库
 * @date : 2019/11/4 19:52
 * @version : 1.0
 */
@Repository
public interface EiHrUserRepository extends JpaRepository<EiHrUser, String> {

}
