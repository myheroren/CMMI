package com.huatonghh.policy.service.dto.annual;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * @Author 居炎明
 * @Description //TODO
 * @Date 17:08 2020/9/25
 **/
@Data
@ApiModel("保险计划查询")
public class PlanListQuery {

    @ApiModelProperty("当前页数")
    @NotNull(message = "当前页数不能为空！")
    public Integer pageNo;

    @ApiModelProperty("每页显示数据条数")
    @NotNull(message = "分页大小不能为空！")
    public Integer pageSize;

    @ApiModelProperty("计划编号")
    private String planNo;

    @ApiModelProperty("保险计划状态，0暂存,1审核中,2被驳回,3审核完成,4招标完成")
    private String status;

    @ApiModelProperty("计划名称")
    private String planName;

    @ApiModelProperty("发起人")
    private String startUser;

    @ApiModelProperty("发起人中文")
    private String startUserName;

    @ApiModelProperty("发起公司id")
    private String startCompany;

    @ApiModelProperty("发起公司")
    private String startCompanyName;

    @ApiModelProperty(value = "开始时间",example = "2020-10-01 12:18:48")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startTime;

    @ApiModelProperty(value = "结束时间",example = "2020-10-01 12:18:48")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endTime;

}
