package com.huatonghh.ins_authority.rest;

import com.huatonghh.authority.service.EiAuthorityService;
import com.huatonghh.authority.service.dto.EiAuthorityDto;
import com.huatonghh.authority.service.dto.EiAuthorityTreeDto;
import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.ins_authority.service.EiInsAuthorityService;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;


/**
 * @author : Sun
 * @description : 权限管理
 * @date : 2019/11/4 21:31
 * @version : 1.0
 */
@RestController
@RequestMapping("/api/ins_authority/v1")
@Api(tags="13、Ins.菜单权限管理", value = "Ins.菜单权限")
@Slf4j
public class EiInsAuthorityController {

    private final EiInsAuthorityService eiAuthorityService;

    public EiInsAuthorityController(EiInsAuthorityService eiAuthorityService) {
        this.eiAuthorityService = eiAuthorityService;
    }

    @GetMapping("/tree_list")
    @ApiOperation(value = "1、获取菜单权限二叉树列表", notes = "用于配置菜单，生成可勾选的二叉树", httpMethod = "GET")
    @Timed
    public ApiResponse<List<EiAuthorityTreeDto>> queryAuthorityTreeList(@RequestParam(name = "id", required = false) Integer id) {
        List<EiAuthorityDto> eiAuthorityDtos = eiAuthorityService.queryAuthorityTreeList();
        return ApiResponse.ofSuccess(eiAuthorityService.processTreeList(eiAuthorityDtos, id));
    }

    @PostMapping("/save")
    @ApiOperation(value = "2、菜单权限信息保存", httpMethod = "POST")
    @Timed
    public ApiResponse<EiAuthorityDto> saveAuthority(@RequestBody @Valid EiAuthorityDto eiAuthorityDto) {
        return ApiResponse.ofSuccess(eiAuthorityService.saveAuthority(eiAuthorityDto));
    }

    @DeleteMapping("/delete/{id}")
    @ApiOperation(value = "4、删除菜单", httpMethod = "DELETE")
    @Timed
    public void delete(@PathVariable(value = "id") Integer id) {
        eiAuthorityService.delete(id);
    }

    @PutMapping("/sort")
    @ApiOperation(value = "5、更新菜单顺序", httpMethod = "PUT")
    @Timed
    public ApiResponse updateSort(@RequestBody List<EiAuthorityTreeDto> eiAuthorityTreeDtoList) {
        eiAuthorityService.updateSort(eiAuthorityTreeDtoList);
        return ApiResponse.ofSuccess(null);
    }

}
