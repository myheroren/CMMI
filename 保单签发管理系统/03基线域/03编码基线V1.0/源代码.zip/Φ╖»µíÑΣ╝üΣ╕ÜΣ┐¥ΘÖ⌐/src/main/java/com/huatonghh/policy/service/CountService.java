package com.huatonghh.policy.service;

import cn.hutool.core.date.DateUtil;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.repository.DynamicQuery;
import com.huatonghh.policy.domain.count.CountEng;
import com.huatonghh.policy.domain.count.CountKindCode;
import com.huatonghh.policy.repository.count.CountEngRepository;
import com.huatonghh.policy.repository.count.CountInsurerKindRepository;
import com.huatonghh.policy.repository.count.CountInsurerRepository;
import com.huatonghh.policy.repository.count.CountKindCodeRepository;
import com.huatonghh.policy.service.dto.count.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * description: 统计
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/11
 */
@Slf4j
@Service
@AllArgsConstructor
public class CountService {

    private final CountKindCodeRepository countKindCodeRepository;
    private final CountInsurerRepository countInsurerRepository;
    private final CountEngRepository countEngRepository;
    private final CountInsurerKindRepository countInsurerKindRepository;
    private final DynamicQuery dynamicQuery;
    private final ModelMapper modelMapper;

    public List<CountKindCodeDTO> findKindCode(CountKindCodeRequest request) {
        check(request);
        if (null == request.getBeginDate() || request.getEndDate() == null) {
            throw new BusinessException("险种统计需指定起止日期");
        }
        List<CountKindCode> list = countKindCodeRepository.findAllGroupByKindCode(request.getBeginDate(), request.getEndDate());
        if (null == list || list.isEmpty()) {
            return null;
        }
        return list.stream().map(l -> modelMapper.map(l, CountKindCodeDTO.class)).collect(Collectors.toList());
    }

    public List<CountEngDTO> findEng(CountKindCodeRequest request) {
        check(request);
        List<CountEng> list = countEngRepository.findAllGroupByEng(request.getBeginDate(), request.getEndDate());
        if (null == list || list.isEmpty()) {
            return null;
        }
        return list.stream().map(l -> modelMapper.map(l, CountEngDTO.class)).collect(Collectors.toList());
    }

    public List<CountInsurerDTO> findBelong(CountKindCodeRequest request) {
        check(request);
        return dynamicQuery.nativeQueryListModel(CountInsurerDTO.class,this.getCountBelongCompanySql(DateUtil.format(request.getBeginDate(), "yyyy-MM-dd"), DateUtil.format(request.getEndDate(), "yyyy-MM-dd")));

        //return countInsurerRepository.findAllByBelongCompany(request.getBeginDate(), request.getEndDate());
/*
        List<Object> list = countInsurerRepository.findAllByBelongCompany(request.getBeginDate(), request.getEndDate());
            if (null == list || list.isEmpty()) {
                return null;
        }
        return list.stream().map(l -> modelMapper.map(l, CountInsurerDTO.class)).collect(Collectors.toList());*/
    }


    public List<CountInsurerVO> findInsurerKind(CountKindCodeRequest request) {
        check(request);
        // todo 分转元,nativeQueryListMap 换成 nativeQueryListModel
        return dynamicQuery.nativeQueryListModel(CountInsurerVO.class,this.getCountInsurerSql(DateUtil.format(request.getBeginDate(), "yyyy-MM-dd"), DateUtil.format(request.getEndDate(), "yyyy-MM-dd")));
    }
    private String getCountBelongCompanySql(String beginTime, String endTime) {
        StringBuilder sql = new StringBuilder();
        sql.append("select c.belong_company as belongCompany,SUM(c.total_premium)  as totalPremium \n" +
            "\t,c.create_time as createTime\n" +
            "\tfrom count_insurer c \n" +
            "\twhere  1=1 \n" +
            "\tand c.type =1 ")
            .append(" AND c.create_time  >= STR_TO_DATE ( '").append(beginTime).append("', '%Y-%m-%d' )  ")
            .append(" AND c.create_time  <= STR_TO_DATE ( '").append(endTime).append("', '%Y-%m-%d' )  ")
            .append(" GROUP BY  c.belong_company;");
        return sql.toString();
    }
    private String getCountInsurerSql(String beginTime, String endTime) {
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT c.start_company belongCompany,sum(c.total_premium) totalPremium,")
            .append(" MAX(CASE  c.kind_code WHEN '1' THEN c.total_premium ELSE 0 END ) carPremium,")
            .append(" MAX(CASE  c.kind_code WHEN '2' THEN c.total_premium ELSE 0 END ) liabilityPremium,")
            .append(" MAX(CASE  c.kind_code WHEN '3' THEN c.total_premium ELSE 0 END ) engPremium,")
            .append(" MAX(CASE  c.kind_code WHEN '4' THEN c.total_premium ELSE 0 END ) accidentPremium,")
            .append(" MAX(CASE  c.kind_code WHEN '5' THEN c.total_premium ELSE 0 END ) assetsPremium,")
            .append(" MAX(CASE  c.kind_code WHEN '6' THEN c.total_premium ELSE 0 END ) goodsPremium,")
            .append(" MAX(CASE  c.kind_code WHEN '9' THEN c.total_premium ELSE 0 END ) elsePremium")
            .append(" FROM count_insurer_kind c where 1=1 ")
            .append(" AND c.create_time  >= STR_TO_DATE ( '").append(beginTime).append("', '%Y-%m-%d' )  ")
            .append(" AND c.create_time  <= STR_TO_DATE ( '").append(endTime).append("', '%Y-%m-%d' )  ")
            .append(" GROUP BY  c.start_company;");
        return sql.toString();
    }

    public void batchInsert() {
        countKindCodeRepository.batchInsert();
        countInsurerRepository.batchInsert();
        countEngRepository.batchInsert();
        countInsurerKindRepository.batchInsert();
    }

    private void check(CountKindCodeRequest request) {
        if (null == request.getBeginDate() || request.getEndDate() == null) {
            throw new BusinessException("保险公司统计需指定起止日期");
        }
    }
}
