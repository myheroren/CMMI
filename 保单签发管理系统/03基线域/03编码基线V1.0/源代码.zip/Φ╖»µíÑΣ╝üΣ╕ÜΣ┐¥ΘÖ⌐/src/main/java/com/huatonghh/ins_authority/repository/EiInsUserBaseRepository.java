package com.huatonghh.ins_authority.repository;

import com.huatonghh.common.service.dto.ResponseIntegerKeyValueDto;
import com.huatonghh.ins_authority.domain.EiInsUser;
import com.huatonghh.ins_authority.domain.EiInsUserBase;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @author : Sun
 * @description : 用户-数据仓库
 * @date : 2019/11/5 21:33
 * @version : 1.0
 */
@Repository
public interface EiInsUserBaseRepository extends JpaRepository<EiInsUserBase, Integer> {

    /**
     * 根据用户id，只获取用户信息
     *
     * @author Sun
     * @date 2019/11/5 21:33
     * @param id:
     * @return java.util.Optional<com.huatonghh.ins_authority.domain.EiInsUser>
     **/
    Optional<EiInsUserBase> findOneById(Integer id);


    /**
     * 根据用户名，只获取用户信息
     *
     * @author Sun
     * @date 2019/11/5 21:33
     * @param userName:
     * @return java.util.Optional<com.huatonghh.ins_authority.domain.EiInsUser>
     **/
    Optional<EiInsUserBase> findOneByUserName(String userName);


    /**
     * 根据用户id获取用户信息，懒加载获取角色信息
     *
     * @author Sun
     * @date 2019/11/5 21:33
     * @param id:
     * @return java.util.Optional<com.huatonghh.ins_authority.domain.EiInsUser>
     **/
    @EntityGraph(attributePaths = "authorities")
    Optional<EiInsUser> findOneWithAuthoritiesById(Integer id);


    /**
     * 根据用户名获取用户信息，懒加载获取角色信息
     *
     * @author Sun
     * @date 2019/11/5 21:33
     * @param user:
     * @return java.util.Optional<com.huatonghh.ins_authority.domain.EiInsUser>
     **/
    @EntityGraph(attributePaths = "authorities")
    Optional<EiInsUserBase> findOneWithAuthoritiesByUserName(String user);


    /**
     * 删除用户对应的部门中间表
     *
     * @author Sun
     * @date 2019/11/5 21:34
     * @param userId:
     **/
    @Modifying
    @Query(nativeQuery = true, value = "delete from ei_ins_depart_user where user_id = :userId")
    void deleteDepartUserByUserId(@Param("userId") Integer userId);


    /**
     * 根据部门id获取其下用户列表
     *
     * @author Sun
     * @date 2019/11/5 21:34
     * @param id:
     * @return java.util.List<com.huatonghh.ins_authority.domain.EiInsUser>
     **/
    @Query(nativeQuery = true, value = "SELECT DISTINCT u.* FROM ei_ins_user u LEFT JOIN ei_ins_depart_user du ON u.id = du.user_id WHERE IF (?1 != '', du.depart_id = ?1, 0 = 0)")
    List<EiInsUserBase> findDepartLowerUserList(Integer id);

    @Query(nativeQuery = true, value = "SELECT DISTINCT u.* FROM ei_ins_user u ,ei_ins_depart ed,ei_ins_depart_user du WHERE u.id = du.user_id  and ed.id = ?1 and du.depart_id = ed.id order by u.id limit ?2,?3")
    List<EiInsUserBase> findDepartLowerUserListPage(String id, Integer PageNo, Integer pageSize);


    @Query(nativeQuery = true, value = "SELECT count(1) FROM ei_ins_user u ,ei_ins_depart ed,ei_ins_depart_user du WHERE u.id = du.user_id  and ed.id = ?1 and du.depart_id = ed.id")
    Integer findDepartLowerUserListTotle(String id);


    /**
     * 修改用户所属部门
     *
     * @author Sun
     * @date 2019/11/5 21:34
     * @param departId:
     * @param userId:
     **/
    @Modifying
    @Query(nativeQuery = true, value = "INSERT INTO ei_ins_depart_user VALUES (?1, ?2)")
    void batchDeleteBaseCodes(Integer departId, Integer userId);


    /**
     * 根据公司id查询公司下员工的登录账户及中文名字
     *
     * @author Sun
     * @date 2019/11/5 21:34
     * @param id:
     * @return java.util.List<com.huatonghh.ins_authority.domain.EiInsUser>
     **/
    @Query(nativeQuery = true, value = "SELECT u.* FROM ei_ins_depart_user d, ei_ins_user u WHERE d.depart_id = ?1 AND d.user_id = u.id")
    List<EiInsUserBase> findUserListByDepart(Integer id);


    /**
     * 根据保险公司登录账户，获取用户中文名、名称key value数据集
     *
     * @author Sun
     * @date 2019/11/6 15:51
     * @param id: 登录账户
     * @return java.util.List<com.huatonghh.common.service.dto.ResponseIntegerKeyValueDto>
     **/
    @Query(value = "SELECT DISTINCT new com.huatonghh.common.service.dto.ResponseIntegerKeyValueDto( d.id, d.name ) FROM EiInsUser d WHERE d.id = :id")
    List<ResponseIntegerKeyValueDto> queryNameById(@Param("id") Integer id);

}
