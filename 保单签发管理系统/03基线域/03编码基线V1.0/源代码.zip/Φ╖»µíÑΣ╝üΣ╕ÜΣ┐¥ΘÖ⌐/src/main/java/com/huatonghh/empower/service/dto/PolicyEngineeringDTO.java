
package com.huatonghh.empower.service.dto;

import lombok.Data;

@Data
@SuppressWarnings("unused")
public class PolicyEngineeringDTO {

    /**
     * 所属保单号
     */
    private String policyNo;

    /**
     * 项目地址
     */
    private String projectAddress;

    /**
     * 项目详细地址
     */
    private String detailAddress;

    /**
     * 项目名
     */
    private String projectName;
    /**
     * 保险期限（天数）
     */
    private Integer insurancePeriod;

    /**
     * 累计赔偿限额（三者责任累计赔偿限额）(安责、雇主、工程)
     */
    private Double accumulativeCompensationLimit;
    /**
     * 单次事故赔偿限额(安责、雇主、工程)
     */
    private Double singleCompensationLimit;
    /**
     * 每人每次事故赔偿限额(安责、雇主、工程)
     */
    private Double perPersonSingleCompensationLimit;
    /**
     * 意外身故残疾保额(团意险)
     */
    private Double accidentalDeathDisabilityCoverage;
    /**
     * 意外医疗保额(团意险)
     */
    private Double accidentalMedicalCoverage;
    /**
     * 48小时疾病身故保额(团意险)
     */
    private Double diseaseDeathInsurance;

}
