package com.huatonghh.excel.service.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.huatonghh.excel.util.DateConverter;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * description: 车辆基本信息
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/25
 */
@Data
@ContentRowHeight(20)
@HeadRowHeight(20)
@ColumnWidth(15)
public class VehMainData {
    @ExcelProperty(value = {"车辆信息统计表", "填报单位"}, index = 0)
    private String startCompanyName;
    @ExcelProperty(value = {"车辆信息统计表", "投保人名称（全称）"}, index = 1)
    private String holderName;
    @ExcelProperty(value = {"车辆信息统计表", "被保险人名称（全称）"}, index = 2)
    private String insuredName;
    @ExcelProperty(value = {"车辆信息统计表", "车牌号"}, index = 3)
    private String plateNo;
    @ExcelProperty(value = {"车辆信息统计表", "车架号"}, index = 4)
    private String frameNo;
    @ExcelProperty(value = {"车辆信息统计表", "发动机号"}, index = 5)
    private String engineNo;
    @ExcelProperty(value = {"车辆信息统计表", "初登日期（YYYY/MM/DD）"}, index = 6, converter = DateConverter.class)
    @JsonFormat(pattern = "yyyy/MM/dd", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy/MM/dd")
    private Date registerTime;
    @ExcelProperty(value = {"车辆信息统计表", "使用性质"}, index = 7)
    private String usageCode;
    @ExcelProperty(value = {"车辆信息统计表", "车主"}, index = 8)
    private String ownerName;
    @ExcelProperty(value = {"车辆信息统计表", "车主证件类型"}, index = 9)
    private String ownerCertificateType;
    @ExcelProperty(value = {"车辆信息统计表", "车主证件号码"}, index = 10)
    private String ownerCertificateCode;
    @ExcelProperty(value = {"车辆信息统计表", "投保人证件类型"}, index = 11)
    private String holderCertificateType;
    @ExcelProperty(value = {"车辆信息统计表", "投保人证件号码"}, index = 12)
    private String holderCertificateCode;
    @ExcelProperty(value = {"车辆信息统计表", "被保险人证件类型"}, index = 13)
    private String insuredCertificateType;
    @ExcelProperty(value = {"车辆信息统计表", "被保险人证件号码"}, index = 14)
    private String insuredCertificateCode;
    @ExcelProperty(value = {"车辆信息统计表", "车辆种类"}, index = 15)
    private String vehicleType;
    @ExcelProperty(value = {"车辆信息统计表", "交管车辆种类"}, index = 16)
    private String trafficType;
    @ExcelProperty(value = {"车辆信息统计表", "车辆型号"}, index = 17)
    private String vehicleModel;
    @ExcelProperty(value = {"车辆信息统计表", "核定载客数"}, index = 18)
    private Integer approvalSeatCount;

}
