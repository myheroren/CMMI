package com.huatonghh.authority.security;

import com.google.common.collect.Lists;
import com.huatonghh.authority.constant.AuthorityConstant;
import com.huatonghh.authority.domain.EiUser;
import com.huatonghh.common.constant.enums.StatusEnum;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.service.RedisService;
import com.huatonghh.common.util.hutool.SpringUtil;
import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.ins_authority.domain.EiInsUser;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Utility class for Spring Security.
 */

public final class SecurityUtils {

    private static RedisService redisService = SpringUtil.getBean(RedisService.class);

    private SecurityUtils() {
    }

    /**
     * Get the login of the current user.
     *
     * @return the login of the current user.
     */
    public static Optional<String> getCurrentUserLogin() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        return Optional.ofNullable(securityContext.getAuthentication())
            .map(authentication -> {
                if (authentication.getPrincipal() instanceof UserDetails) {
                    UserDetails springSecurityUser = (UserDetails) authentication.getPrincipal();
                    return springSecurityUser.getUsername();
                } else if (authentication.getPrincipal() instanceof String) {
                    return (String) authentication.getPrincipal();
                }
                return null;
            });
    }

    /**
     * Get the JWT of the current user.
     *
     * @return the JWT of the current user.
     */
    public static Optional<String> getCurrentUserJWT() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        return Optional.ofNullable(securityContext.getAuthentication())
            .filter(authentication -> authentication.getCredentials() instanceof String)
            .map(authentication -> (String) authentication.getCredentials());
    }

    /**
     * Check if a user is authenticated.
     *
     * @return true if the user is authenticated, false otherwise.
     */
    public static boolean isAuthenticated() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        return Optional.ofNullable(securityContext.getAuthentication())
            .map(authentication -> {
                List<GrantedAuthority> authorities = new ArrayList<>();
                    authorities.addAll(authentication.getAuthorities());
                return authorities.stream()
                    .noneMatch(grantedAuthority -> grantedAuthority.getAuthority().equals(AuthorityConstant.ANONYMOUS));
            })
            .orElse(false);
    }

    /**
     * If the current user has a specific authority (security role).
     * <p>
     * The name of this method comes from the {@code isUserInRole()} method in the Servlet API.
     *
     * @param authority the authority to check.
     * @return true if the current user has the authority, false otherwise.
     */
    public static boolean isCurrentUserInRole(String authority) {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        return Optional.ofNullable(securityContext.getAuthentication())
            .map(authentication -> {
                List<GrantedAuthority> authorities = new ArrayList<>();
                    authorities.addAll(authentication.getAuthorities());
                return authorities.stream()
                    .anyMatch(grantedAuthority -> grantedAuthority.getAuthority().equals(authority));
            })
            .orElse(false);
    }


    /**
     * @author Sun
     * @description 获取登录账号角色，并加入反参
     * @date 2019/11/4 20:03
     * @return java.util.List<java.lang.String>
     **/
    public static List<String> getLoginRole() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        List<GrantedAuthority> authorities = Lists.newArrayList();
        Optional.ofNullable(securityContext.getAuthentication())
            .map(authentication -> authorities.addAll(authentication.getAuthorities()));

        // 此方法转为List<String>，方便前端拿取
        List<String> loginRoles = Lists.newArrayList();
        authorities.forEach(grantedAuthority -> {
            loginRoles.add(grantedAuthority.getAuthority());
        });
        return loginRoles;
    }

    /**
     * @author juyanming
     * @description 获取登录账号角色，并加入反参
     * @date 2019/12/14 20:03
     * @return java.util.List<java.lang.String>
     **/
    public static List<String> getLoginRole_() {
        String user = loginUser();
        // 此方法转为List<String>，方便前端拿取
        List<String> loginRoles = Lists.newArrayList();

        String roleId = (String)redisService.get(user+"_"+AuthorityConstant.USER_ROLE);
        if(roleId==null||"".equals(roleId)){
            throw new BusinessException("登录超时或未登录");
        }else{
            loginRoles.add(roleId);
        }
        return loginRoles;
    }

    /**
     * @author juyanming
     * @description 获取登录账号公司，并加入反参
     * @date 2019/12/14 20:03
     * @return java.util.List<java.lang.String>
     **/
    public static String getLoginCompany() {
        String user = loginUser();
        String companyId = (String)redisService.get(user+"_"+AuthorityConstant.USER_COMPANY);
        if(companyId==null||"".equals(companyId)){
            throw new BusinessException("登录超时或未登录");
        }
        return companyId;
    }


    /**
     * @author Sun
     * @description 根据登录角色list获取第一个角色，也就是我们定义的那个登录角色
     * @date 2019/11/5 15:21
     * @return java.lang.String
     **/
    public static String loginRole() {
        List<String> loginRoleList = getLoginRole();
        if(loginRoleList.isEmpty()){
            throw new BusinessException("未登录");
        }else {
            return loginRoleList.get(0);
        }
    }


    /**
     * @author Sun
     * @description 根据token获取登录账号
     * @date 2019/11/5 20:34
     * @return java.lang.String
     **/
    public static String loginUser() {
        Optional<String> currentUserLogin = SecurityUtils.getCurrentUserLogin();
        if(currentUserLogin.isPresent()) {
            return currentUserLogin.get();
        } else {
            throw new BusinessException(StatusEnum.USER_NOT_LOGIN);
        }
    }

}
