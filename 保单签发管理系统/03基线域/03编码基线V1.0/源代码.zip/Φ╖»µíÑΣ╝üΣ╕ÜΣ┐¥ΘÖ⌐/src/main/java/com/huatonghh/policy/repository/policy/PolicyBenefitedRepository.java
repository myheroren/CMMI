package com.huatonghh.policy.repository.policy;

import com.huatonghh.policy.domain.policy.PolicyBenefited;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * 保单受益人表(PolicyBenefited)表数据库访问层
 *
 * @author 居炎明
 * @since 2020-03-01 21:40:28
 */
@Repository
public interface PolicyBenefitedRepository extends JpaRepository<PolicyBenefited,String> {

}
