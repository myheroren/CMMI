package com.huatonghh.policy.service.dto.claim.noncar;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author : wh
 * description :理赔报表查询
 * @version : 1.0
 * @date : 2020/3/10 01:46
 */
@Data
public class ClaimFormQuery {
    @ApiModelProperty("当前页数")
    public Integer pageNo;
    @ApiModelProperty("每页显示数据条数")
    public Integer pageSize;
    @ApiModelProperty(value = "查询起期")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date beginTime;
    @ApiModelProperty(value = "查询止期")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date endTime;
}
