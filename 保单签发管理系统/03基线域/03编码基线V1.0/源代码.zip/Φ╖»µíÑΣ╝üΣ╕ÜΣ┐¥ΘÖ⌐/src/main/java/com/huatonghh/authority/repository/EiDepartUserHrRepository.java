package com.huatonghh.authority.repository;

import com.huatonghh.authority.domain.EiDepart;
import com.huatonghh.authority.domain.EiDepartUser;
import com.huatonghh.authority.domain.EiDepartUserHr;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Set;


/**
 * @author : Sun
 * @description : 交投集团-公司部门-数据仓库
 * @date : 2019/11/4 19:44
 * @version : 1.0
 */
@Repository
public interface EiDepartUserHrRepository extends JpaRepository<EiDepartUserHr, String> {

    /**
     * 查询某个用户所属部门信息
     *
     * @author Sun
     * @date 2019/11/4 19:50
     * @param id: 用户id
     * @return java.util.Set<com.huatonghh.authority.domain.EiDepart>
     **/
    @Query(nativeQuery = true, value = "SELECT d.* FROM ei_depart_user_hr du, ei_depart d WHERE du.depart_id = d.id AND du.user_id = ?1")
    Set<EiDepart> findDepartByUserId(String id);


    /**
     * 先删除部门员工中间表，才可以删除部门表
     *
     * @author Sun
     * @date 2019/11/4 19:51
     * @param id: 部门id
     **/
    @Modifying
    @Query(nativeQuery = true, value = "DELETE du FROM ei_depart d, ei_depart_user_hr du WHERE d.ids LIKE CONCAT(:id ,'%') and d.id = du.depart_id")
    void deleteDepartUser(@Param("id") String id);


    /**
     * 新增部门用户中间表信息
     *
     * @author Sun
     * @date 2019/11/4 19:51
     * @param departId: 部门id
     * @param userId: 用户id
     **/
    @Modifying
    @Query(nativeQuery = true, value = "INSERT INTO ei_depart_user_hr VALUES (?1, ?2 ,?3)")
    void insert(String companyId, String departId, String userId);

    /**
     * 新增部门用户中间表信息
     *
     * @author Sun
     * @date 2019/11/4 19:51
     * @param companyId: 部门id
     * @param userId: 用户id
     **/
    @Modifying
    @Query(nativeQuery = true, value = "INSERT INTO ei_depart_user VALUES (?1, ?2 )")
    void addDepartUser(String companyId, String userId);

}
