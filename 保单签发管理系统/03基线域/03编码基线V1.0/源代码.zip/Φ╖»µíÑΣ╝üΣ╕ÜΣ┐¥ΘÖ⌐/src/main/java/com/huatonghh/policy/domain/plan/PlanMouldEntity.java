package com.huatonghh.policy.domain.plan;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/9/30
 */
@Entity
@Table(name = "ins_plan_mould")
@Data
public class PlanMouldEntity implements Serializable {
    private static final long serialVersionUID = -5659288237415067653L;
    @Id
    private BigInteger batchNo;
    private String planName;
    private BigInteger lastGatherPlanNo;
    private Date startTime;
    private Date endTime;
    private Date gatherEndTime;
    private Date createTime;
    private Date updateTime;
    private String riskKinds;
    private String companies;
    private String startUser;
    @Column(name = "start_user_tel")
    private String startUserTel;
    @Column(name = "is_valid")
    private Boolean valid;
    public List<String> getLimitCompanies() {
        if (StringUtils.isNotBlank(this.companies)) {
            String[] components = this.companies.split(",");
            return Arrays.asList(components);
        }
        return null;
    }

    public List<String> getLimitRiskKinds() {
        if (StringUtils.isNotBlank(this.riskKinds)) {
            String[] components = this.riskKinds.split(",");
            return Arrays.asList(components);
        }
        return null;
    }
}
