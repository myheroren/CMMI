package com.huatonghh.authority.domain;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author : Sun
 * @description : 交投集团-部门公司-数据库映射实体
 * @date : 2019/11/4 19:41
 * @version : 1.0
 */
@Entity
@Table(name = "ei_depart_hr")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Data
public class EiHrDepart implements Serializable {

    private static final long serialVersionUID = 2382896980380725919L;

    @Id
    @Column(name = "id")
    private String id;

    @Column(name = "name")
    private String name;

    @Column(name = "level")
    private String level;

    @Column(name = "parent_id")
    private String parentId;

    @Column(name = "ids")
    private String ids;

    @ApiModelProperty(value = "公司、部门")
    private String type;

}
