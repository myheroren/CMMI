package com.huatonghh.policy.repository.policy;

import com.huatonghh.policy.domain.policy.PolicyVehRiskPlan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author : Sun
 * @description :
 * @date : 2019/11/5 21:45
 * @version : 1.0
 */
public interface PolicyVehRiskPlanRepository extends JpaRepository<PolicyVehRiskPlan, Integer> {

    /**
     * findByPolicyNo
     *
     * @author Sun
     * @date 2019/11/5 21:45
     * @param policyNo:
     * @return java.util.List<com.huatonghh.plan.domain.policy.PolicyVehRiskPlan>
     **/
    List<PolicyVehRiskPlan> findByPolicyNo(String policyNo);


    /**
     * deleteByPolicyNo
     *
     * @author Sun
     * @date 2019/11/5 21:45
     * @param policyNo:
     **/
    @Modifying
    @Query("delete from PolicyVehRiskPlan d where d.policyNo = :policyNo")
    @Transactional(rollbackFor = RuntimeException.class)
    void deleteByPolicyNo(@Param("policyNo") String policyNo);

}
