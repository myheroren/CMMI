package com.huatonghh.base.constant;

/**
 * @author : Sun
 * @version : 1.0
 * @description : 字典管理类文件注释
 * @date : 2019/11/5 20:51
 */
public final class BaseConstant {

    /**
     * 字典管理相应的缓存key值定义
     */
    public static final String BASE_CODE_CACHE = "lq_baseCode";

    /**
     * 通知保险公司，理赔报案
     */
    public static final String REMIND_UN_CAR_CLAIM_REPORT = "UNCAR_CLAIM_REPORT";
    public static final String REMIND_CAR_CLAIM_REPORT = "CAR_CLAIM_REPORT";

    /**
     * 通知企业，理赔进度
     */
    public static final String REMIND_UNCAR_CLAIM_UPDATE = "UNCAR_CLAIM_UPDATE";
    public static final String REMIND_CAR_CLAIM_UPDATE = "CAR_CLAIM_UPDATE";

    public static final String REMIND_ANNUAL_PLAN = "ANNUAL_PLAN";
    public static final String REMIND_GATHER_PLAN = "GATHER_PLAN";
    public static final String REMIND_UN_PLAN_PROJECT = "UN_PLAN_PROJECT";
    public static final String REMIND_INS_ENDORSEMENT_CAR = "INS_ENDO_CAR";
    public static final String REMIND_INS_ENDORSEMENT_UN_CAR = "INS_ENDO_UN_CAR";
    public static final String REMIND_EI_ENDORSEMENT_CAR = "EI_ENDO_CAR";
    public static final String REMIND_EI_ENDORSEMENT_UN_CAR = "EI_ENDO_UN_CAR";

    /**
     * 续保完成通知
     */
    public static final String REMIND_EI_RENEW_DOWN_CAR = "RENEW_DOWN_CAR";
    public static final String REMIND_EI_RENEW_CAR = "RENEW_EI_CAR";
    public static final String REMIND_INS_RENEW_CAR = "RENEW_INS_CAR";

    /**
     * 退保、注销提醒
     */
    public static final String REMIND_INS_RETURN_CAR = "RETURN_APPLY_INS_CAR";
    public static final String REMIND_INS_RETURN_UN_CAR = "RETURN_APPLY_INS_UN_CAR";

    public static final String REMIND_INS_RETURN_CANCEL_CAR = "RETURN_CANCEL_INS_CAR";
    public static final String REMIND_INS_RETURN_CANCEL_UN_CAR = "RETURN_CANCEL_INS_UN_CAR";

    public static final String REMIND_EI_RETURN_CAR = "RETURN_DOWN_EI_CAR";
    public static final String REMIND_EI_RETURN_UN_CAR = "RETURN_DOWN_EI_UN_CAR";


    /**
     * 车转移
     */
    public static final String REMIND_CAR_TRANSFER_APPLY = "CAR_TRANSFER_APPLY";
    public static final String REMIND_CAR_TRANSFER_APPLY_CANCEL = "CAR_TRANSFER_APPLY_CANCEL";
    public static final String REMIND_CAR_TRANSFER_CONFIRM = "CAR_TRANSFER_CONFIRM";

    /**
     * 消息类型
     * 1年度计划 2项目 3保单 4汇总计划 5批单,6续保,7退保，8注销,9车转移
     */
    public static final Byte REMIND_TYPE_PLAN = 1;
    public static final Byte REMIND_TYPE_PROJECT = 2;
    public static final Byte REMIND_TYPE_POLICY = 3;
    public static final Byte REMIND_TYPE_PLAN_GATHER = 4;
    public static final Byte REMIND_TYPE_ENDORSEMENT = 5;
    public static final Byte REMIND_TYPE_RENEW = 6;
    public static final Byte REMIND_TYPE_CAR = 9;

    public static final String REMIND_HTTP_ANNUAL_PLAN = "annualPlanHttp";
    public static final String REMIND_HTTP_GATHER_PLAN = "gatherPlanHttp";
    public static final String REMIND_HTTP_UN_PLAN_PROJECT = "unPlanProjectHttp";
    public static final String REMIND_HTTP_INS_ENDO_CAR = "ins_endoCarHttp";
    public static final String REMIND_HTTP_INS_ENDO_UN_CAR = "ins_endoUnCarHttp";
    public static final String REMIND_HTTP_EI_ENDO_CAR = "ei_endoCarHttp";
    public static final String REMIND_HTTP_EI_ENDO_UN_CAR = "ei_endoUnCarHttp";

    public static final String REMIND_HTTP_EI_UN_CAR_CLAIM = "uncarClaimsHttp";
    public static final String REMIND_HTTP_EI_CAR_CLAIM = "carClaimsHttp";
    public static final String REMIND_HTTP_INS_UN_CAR_CLAIM = "ins_uncarClaimsHttp";
    public static final String REMIND_HTTP_INS_CAR_CLAIM = "ins_carClaimsHttp";

    public static final String REMIND_HTTP_INS_UN_CAR_POLICY = "ins_uncarPolicyHttp";
    public static final String REMIND_HTTP_INS_CAR_POLICY = "ins_carPolicyHttp";
    public static final String REMIND_HTTP_EI_CAR_POLICY = "carPolicyHttp";
    public static final String REMIND_HTTP_EI_UN_CAR_POLICY = "uncarPolicyHttp";

    public static final String REMIND_HTTP_CAR_DETAIL = "CAR_DETAIL";


    // 理赔状态BaseCode
    public static final String CLAIM_STATUS = "claimStatus";

    public static final String REMIND_HTTP = "remindHttp";
    public static final String REMIND_CONTENT = "remindContent";

    /**
     * 车辆使用性质
     * 交管车辆种类
     * 车辆种类
     * 车主证件类型
     */
    public static final String VEHICLE_USAGE = "vehicle_usage";
    public static final String TRAFFIC_TYPE = "trafficType";
    public static final String VEHICLE_TYPE = "vehicleType";
    public static final String OWNER_CERTIFICATE_TYPE = "ownerCertificateType";
    public static final String KIND_CODE = "kind_code";
    public static final String RISK_CODE = "risk_code";
    /**
     * 基础字典typeId
     */
    public static final String CITY_CODE = "city_code";
    public static final String C_ACCDNT_TYPE_CODE = "c_accdnt_type_code";
    public static final String C_ACCDNT_RSN_CODE = "c_accdnt_rsn_code";
    public BaseConstant() {
    }
}
