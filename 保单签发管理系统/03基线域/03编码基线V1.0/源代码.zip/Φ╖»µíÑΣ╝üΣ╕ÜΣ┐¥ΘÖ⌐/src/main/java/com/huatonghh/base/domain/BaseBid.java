package com.huatonghh.base.domain;

import lombok.Data;

import javax.persistence.*;

/**
 * description: 项目信息
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/22
 */
@Entity
@Table(name = "base_bid")
@Data
public class BaseBid {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String tel;
    private String contact;
}
