package com.huatonghh.authority.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author : Sun
 * @description : Cas登录xml报文
 * @date : 2019/11/4 21:09
 * @version : 1.0
 */
@Data
@ApiModel(value = "Cas登录xml报文")
public class CasLoginDto implements Serializable {

    private static final long serialVersionUID = -4712406688448762465L;

    @NotNull(message = "Cas登录xml报文不能为空")
    @ApiModelProperty(value = "xml")
    private String casLoginXml;

}
