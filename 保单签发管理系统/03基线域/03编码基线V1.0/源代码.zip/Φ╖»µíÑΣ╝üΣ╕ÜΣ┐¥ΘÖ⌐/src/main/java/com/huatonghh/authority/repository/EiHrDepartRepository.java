package com.huatonghh.authority.repository;

import com.huatonghh.authority.domain.EiHrDepart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


/**
 * @author : Sun
 * @description : HR人力资源同步-交投集团-公司部门-数据仓库
 * @date : 2019/11/4 19:44
 * @version : 1.0
 */
@Repository
public interface EiHrDepartRepository extends JpaRepository<EiHrDepart, String> {

}
