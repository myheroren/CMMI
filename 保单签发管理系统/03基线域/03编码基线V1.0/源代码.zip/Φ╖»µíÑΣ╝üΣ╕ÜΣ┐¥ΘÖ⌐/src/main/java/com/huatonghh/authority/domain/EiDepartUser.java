package com.huatonghh.authority.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * @author : Sun
 * @description : 交投集团-部门公司-数据库映射实体
 * @date : 2019/11/4 19:41
 * @version : 1.0
 */
@Entity
@Table(name = "ei_depart_user")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Data
@IdClass(EiDepartUserKey.class)
public class EiDepartUser implements Serializable {

    private static final long serialVersionUID = 2382896980380725919L;

    @Id
    @Column(name = "depart_id")
    private String departId;

    @Id
    @Column(name = "user_id")
    private String userId;


}
