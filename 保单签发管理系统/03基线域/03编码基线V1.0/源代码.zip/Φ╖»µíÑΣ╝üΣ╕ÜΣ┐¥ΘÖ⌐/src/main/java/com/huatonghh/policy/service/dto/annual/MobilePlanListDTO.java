package com.huatonghh.policy.service.dto.annual;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigInteger;

/**
 * description: 移动端计划列表
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2020/1/6
 */
@Data
@ApiModel("移动端计划、项目列表")
public class MobilePlanListDTO {
    @ApiModelProperty(value = "流程id")
    private String processId;
    @ApiModelProperty(value = "任务id")
    private String taskId;
    @ApiModelProperty(value = "计划编号")
    @JsonSerialize(using = ToStringSerializer.class)
    private String planNo;
    @ApiModelProperty("计划名称")
    private String planName;
    @ApiModelProperty("发起公司id")
    private String startCompany;
    @ApiModelProperty("发起公司名字")
    private String startCompanyName;
    @ApiModelProperty("计划类别 2计划汇总前，3计划汇总后")
    private Byte planType;
    @ApiModelProperty("前端显示状态")
    private Byte mainStatus;
    @ApiModelProperty("预估总保费")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger estPremium;
}
