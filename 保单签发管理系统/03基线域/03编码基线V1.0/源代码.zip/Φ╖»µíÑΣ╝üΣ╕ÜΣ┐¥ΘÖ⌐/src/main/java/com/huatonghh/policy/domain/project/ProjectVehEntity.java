package com.huatonghh.policy.domain.project;

import lombok.Data;

import javax.persistence.*;
import java.math.BigInteger;



@Entity
@Table(name = "ins_project_veh")
@IdClass(ProjectVehEntityPK.class)
@Data
public class ProjectVehEntity {

    @Id
    private BigInteger projNo;

    @Id
    private String frameNo;

}
