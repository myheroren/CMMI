package com.huatonghh.message.po.dto;

import com.google.common.base.MoreObjects;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * @author wanggl
 * @date 2020-11-03 15:52
 */
@ApiModel("消息发送参数对象")
public class MessageDTO implements Serializable {

    private static final long serialVersionUID = -4218832205921759229L;

    @ApiModelProperty(value = "消息业务编号，调用方指定")
    private String serviceCode;

    @ApiModelProperty(value = "消息来源，例如：lq")
    private String source;

    @ApiModelProperty(value = "消息类型、所属模块")
    private String type;

    @ApiModelProperty(value = "标题")
    private String title;

    @ApiModelProperty(value = "内容")
    private String content;

    @ApiModelProperty(value = "相对路径")
    private String path;

    @ApiModelProperty(value = "如果是内网环境，此处传内网url")
    private String url;

    @ApiModelProperty(value = "发送者")
    private String sender;

    @ApiModelProperty(value = "接收消息用户", required = true)
    @NotNull
    private List<MessageUserDTO> users;

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public List<MessageUserDTO> getUsers() {
        return users;
    }

    public void setUsers(List<MessageUserDTO> users) {
        this.users = users;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
            .add("serviceCode", serviceCode)
            .add("source", source)
            .add("type", type)
            .add("title", title)
            .add("content", content)
            .add("path", path)
            .add("url", url)
            .add("sender", sender)
            .add("users", users)
            .toString();
    }
}
