package com.huatonghh.base.service.timing;

import com.huatonghh.common.util.hutool.SpringContextHolder;
import com.huatonghh.policy.repository.policy.PolicyMainRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/20
 */
@Service
@Slf4j
@AllArgsConstructor
public class RenewRemindService {
    public void renewRemind() {
        PolicyMainRepository policyMainRepository = SpringContextHolder.getBean(PolicyMainRepository.class);
        policyMainRepository.batchUpdatePolicyExpirationDays();
        policyMainRepository.batchUpdatePolicyRenewStatus();
    }
}
