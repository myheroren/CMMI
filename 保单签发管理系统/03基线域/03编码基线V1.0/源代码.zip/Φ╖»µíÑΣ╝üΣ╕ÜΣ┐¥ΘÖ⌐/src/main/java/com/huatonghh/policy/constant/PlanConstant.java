package com.huatonghh.policy.constant;

/**
 * @author : hao.wang
 * @date : 2019/8/27
 * description:
 */
public class PlanConstant {
    /**
     * 1交投集团,2保险公司
     */
    public static final String ENTERPRISE_GROUP = "1";
    public static final String INSURANCE_COMPANY = "2";

    /**
      * 计划状态，0暂存,1审核中,2被驳回,3审核完成,4招标完成
    */
    public static final Byte PLAN_STATUS_SAVE = 0;
    public static final Byte PLAN_STATUS_CHECKING = 1;
    public static final Byte PLAN_STATUS_REJECT = 2;
    public static final Byte PLAN_STATUS_CHECKED = 3;
    public static final Byte PLAN_STATUS_DONE = 4;


    /**
     * 计划状态，1暂存,2二级公司审批,3一级公司审批,4被驳回,5重提交,6审核完成
     */
    public static final Byte PLAN_NODE_SAVE = 1;
    public static final Byte PLAN_NODE_SECOND = 2;
    public static final Byte PLAN_NODE_FIRST = 3;
    public static final Byte PLAN_NODE_REJECT_BY_SECOND = 4;
    public static final Byte PLAN_NODE_REJECT_BY_FIRST = 5;
    public static final Byte PLAN_NODE_RESUBMIT = 6;
    public static final Byte PLAN_NODE_CHECKED = 7;

    //是否待办
    public static final Byte PLAN_IS_TODO = 1;
    public static final Byte PLAN_NOT_TODO = 0;
    //发起计划还未暂存时
    public static final Byte PLAN_SAVE_TODO = 2;

    /**
     * 1三级提交、11二级提交、21财务提交
     */
    public static final Byte PLAN_STATUS_THIRD_APPLY = 1;
    public static final Byte PLAN_STATUS_SECOND_APPLY = 11;
    public static final Byte PLAN_STATUS_FINANCE_APPLY = 21;

    public static final Byte PLAN_STATUS_THIRD_APPLY_RECALL = 31;
    public static final Byte PLAN_STATUS_SECOND_APPLY_RECALL = 41;
    public static final Byte PLAN_STATUS_FINANCE_APPLY_RECALL = 51;

    public static final Byte PLAN_STATUS_THIRD_MANAGER_PASS = 2;
    public static final Byte PLAN_STATUS_THIRD_MANAGER_REJECT = -2;
    public static final Byte PLAN_STATUS_THIRD_LEADER_PASS = 3;
    public static final Byte PLAN_STATUS_THIRD_LEADER_REJECT = -3;

    public static final Byte PLAN_STATUS_SECOND_STAFF_PASS = 12;
    public static final Byte PLAN_STATUS_SECOND_STAFF_REJECT = -12;
    public static final Byte PLAN_STATUS_SECOND_MANAGER_PASS = 13;
    public static final Byte PLAN_STATUS_SECOND_MANAGER_REJECT = -13;
    public static final Byte PLAN_STATUS_SECOND_LEADER_PASS = 14;
    public static final Byte PLAN_STATUS_SECOND_LEADER_REJECT = -14;
    // 分配保险公司提交
    public static final Byte PLAN_STATUS_FINANCE_STAFF_PASS = 28;
    public static final Byte PLAN_STATUS_FINANCE_STAFF_REJECT = -21;
    public static final Byte PLAN_STATUS_FINANCE_MANAGER_PASS = 29;
    public static final Byte PLAN_STATUS_FINANCE_MANAGER_REJECT = -29;
    public static final Byte PLAN_STATUS_FINANCE_LEADER_PASS = 30;
    public static final Byte PLAN_STATUS_FINANCE_LEADER_REJECT = -30;
    // 22提交方案，23统保
    public static final Byte PLAN_STATUS_FINANCE_STAFF_SOLUTION = 22;
    public static final Byte PLAN_STATUS_FINANCE_STAFF_UNIFIED = 23;

    public static final Byte PLAN_STATUS_FINANCE_MANAGER_SOLUTION_PASS = 24;
    public static final Byte PLAN_STATUS_FINANCE_MANAGER_SOLUTION_REJECT = -24;

    public static final Byte PLAN_STATUS_DEMAND_STAFF_SOLUTION_PASS = 25;
    public static final Byte PLAN_STATUS_DEMAND_STAFF_SOLUTION_REJECT = -25;
    public static final Byte PLAN_STATUS_DEMAND_MANAGER__SOLUTION_PASS = 26;
    public static final Byte PLAN_STATUS_DEMAND_MANAGER__SOLUTION_REJECT = -26;
    public static final Byte PLAN_STATUS_DEMAND_LEADER_SOLUTION_PASS = 27;
    public static final Byte PLAN_STATUS_DEMAND_LEADER_SOLUTION_REJECT = -27;


    /**
     * 计划类型，2年度，3汇总
     */
    public static final Byte PLAN_TYPE_PROJECT = 0;
    public static final Byte PLAN_TYPE_YEAR = 2;
    public static final Byte PLAN_TYPE_GATHER = 3;

    /**
     * 项目类型，1计划外项目,2年度汇总前，3年度汇总后,4中标项目
     */
    public static final Byte PROJECT_TYPE_PLAN_ELSE = 1;
    public static final Byte PROJECT_TYPE_YEAR = 2;
    public static final Byte PROJECT_TYPE_GATHER = 3;
    public static final Byte PROJECT_TYPE_BID = 4;

    /**
     * 文件所属类型
     * 1计划，2项目，3保单,4计划批次,5报案，6理赔,7批单,8方案，9分配
     */
    public static final Byte BELONG_TYPE_PLAN = 1;
    public static final Byte BELONG_TYPE_PROJECT = 2;
    public static final Byte BELONG_TYPE_POLICY = 3;
    public static final Byte BELONG_TYPE_BATCH = 4;
    public static final Byte BELONG_TYPE_REPORT = 5;
    public static final Byte BELONG_TYPE_CLAIM = 6;
    public static final Byte BELONG_TYPE_ENDORSEMENT = 7;
    public static final Byte BELONG_TYPE_SOLUTION = 8;
    public static final Byte BELONG_TYPE_ASSIGN = 9;

    /**
     * 任务类型，1计划，2项目
     */
    public static final Byte TASK_PLAN = 1;
    public static final Byte TASK_PROJECT = 2;

    /**
     * 项目公司经办人 -> 直属公司经办人 -> 集团公司经办人
     */
    public static final String WORK_FLOW_THRID = "activitiThridApprovalProcess";

    /**
     * 直属公司经办人 -> 集团公司经办人
     */
    public static final String WORK_FLOW_SECOND = "activitiSecondApprovalProcess";

    /**
     * 审核结果
     * 3 三级员工 驳回，跳转至财务专员，
     * 4需确认方案，跳转至二级员工，
     * 5需确认方案，跳转至三级员工
     * 6统保返回
     * 7自行确认
     * 8提交需求
     * <p>
     * 10.二级员工 驳回，跳转至财务专员，
     */
    public static final String CHECK_CODE_END = "-1";
    public static final String CHECK_CODE_REJECT = "0";
    public static final String CHECK_CODE_PASS = "1";
    public static final String CHECK_CODE_RECALL = "2";
    public static final String CHECK_CODE_SKIP_FINANCE = "3";
    public static final String CHECK_CODE_SKIP_SECOND = "4";
    public static final String CHECK_CODE_SKIP_THIRD = "5";
    public static final String CHECK_CODE_UNIFIED = "6";
    public static final String CHECK_CODE_SELF = "7";
    public static final String CHECK_CODE_AUTOCOMPLETE = "8";
    public static final String CHECK_CODE_SOLUTION = "9";
    public static final String CHECK_CODE_SECOND_SKIP_FINANCE = "10";
    public static final String CHECK_CODE_SKIP_FINANCE_STAFF = "11";
    public static final String CHECK_CODE_SKIP_THIRD_LEADER = "12";


    /**
     * 0. 走工作流的默认配置
     * 1. 根据前端传入，手动分配
     */
    public static final Byte ASSIGN_CODE_DEFAULT = 0;
    public static final Byte ASSIGN_CODE_MODIFY = 1;

    /**
     * 解决方案状态
     * 0财务公司未发起方案，1待二级员工确认方案，2二级方案不可行需财务另出，3.二级确认可行
     * 未发起0和确认不可行2并且有task时，财务显示发送给二级员工按钮
     * 方案待确认1时并且有task时，二级显示确认按钮
     */
    public static final Byte SOLUTION_NO = 0;
    public static final Byte SOLUTION_CONFIRM_ING = 1;
    public static final Byte SOLUTION_CONFIRM_NO = 2;
    public static final Byte SOLUTION_CONFIRM_CAN = 3;
    public static final Byte SOLUTION_NO_NEED = -1;

    /**
     * 权限
     * 员工，经理，领导
     */
    public static final String ROLE_GROUP = "1";
    public static final String ROLE_INSURER = "2";

    /**
     * 华通设置的公司层级
     * 1 财务 2 二级 3三级以及三级以下
     */
    public static final String HT_LEVEL_FINANCE = "1";
    public static final String HT_LEVEL_SECOND = "2";
    public static final String HT_LEVEL_THIRD = "3";

    public static final Integer HT_LEVEL_FINANCE_WORKER_ROLE = 34;
    public static final Integer HT_LEVEL_SECOND_WORKER_ROLE = 35;
    public static final Integer HT_LEVEL_THIRD_WORKER_ROLE = 36;

    /**
     * 领导1
     * 员工2
     * 经理3
     */
    public static final Byte HT_POSITION_LEADER = 1;
    public static final Byte HT_POSITION_STAFF = 2;
    public static final Byte HT_POSITION_MANAGER = 3;
    public static final Byte HT_POSITION_WORKER = 4;

    public static final String COMPANY = "Company";
    public static final String DEPART = "Depart";

    public static final String BASE_CODE_RISK = "kind_code";

    public static final String KIND_CAR = "1";

    /**
     * 计划汇总状态
     * 0汇总前
     * 1可汇总
     * 2已汇总
     */
    public static final Byte GATHER_STATUS_BEFORE = 0;
    public static final Byte GATHER_STATUS_CAN = 1;
    public static final Byte GATHER_STATUS_DONE = 2;

    /**
     * 1补充计划 财务员工发起，需求公司提交
     * 2汇总计划 需求领导审核通过年度计划，二级员工提交汇总计划
     * 3方案  二级领导审核通过汇总计划
     * 4中标 需求员工确认通过方案
     * 5保单 财务领导审核通过
     */
    public static final String TACHE_DEMAND = "1";
    public static final String TACHE_GATHER = "2";
    public static final String TACHE_SOLUTION = "3";
    public static final String TACHE_BID = "4";
    public static final String TACHE_SELF = "5";
    public static final String TACHE_POLICY = "6";

    /**
     * 默认排序时间戳字段
     */
    public static final String COLUMN_CURRENT = "current_timestamp";

    /**险种
     * 车险1
     * 工程险5
     */
    public static final String RISK_CAR = "1";
    public static final String INSURANCE_CATEGORY_ENGINEERING = "5";

}
