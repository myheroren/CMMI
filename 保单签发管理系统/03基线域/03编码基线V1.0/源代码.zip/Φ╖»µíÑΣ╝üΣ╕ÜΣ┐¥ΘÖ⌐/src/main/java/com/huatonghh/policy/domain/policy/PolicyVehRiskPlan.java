package com.huatonghh.policy.domain.policy;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;

/**
 * Description : 保单车辆管理-方案信息
 * @author : Sun
 * @date : 2019/8/31 14:01
 * @version : 1.0
 */
@Entity
@Table(name = "policy_veh_risk_plan")
@Data
public class PolicyVehRiskPlan implements Serializable {

    private static final long serialVersionUID = -5158527832153002974L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "policy_no")
    private String policyNo;

    @Column(name = "kind_code")
    private String kindCode;

    @Column(name = "risk_code")
    private String riskCode;

    @Column(name = "risk_name")
    private String riskName;

    @Column(name = "amount")
    private BigInteger amount;

    @Column(name = "premium")
    private BigInteger premium;

    @Column(name = "main_additional_flag")
    private Boolean mainAdditionalFlag;

    @Column(name = "is_deductible")
    private Boolean deductible;

    @Column(name = "sort_no")
    private Integer sortNo;

}
