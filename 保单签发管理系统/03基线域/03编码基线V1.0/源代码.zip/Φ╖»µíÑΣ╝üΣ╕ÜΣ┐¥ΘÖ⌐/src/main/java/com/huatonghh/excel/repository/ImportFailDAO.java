package com.huatonghh.excel.repository;

import com.huatonghh.excel.domain.ImportFailEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigInteger;
import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/5
 */
public interface ImportFailDAO extends JpaRepository<ImportFailEntity, BigInteger> {

    /**
     * 根据批次号查询
     *
     * @param batchNo 批次号
     * @return 失败数据
     */
    List<ImportFailEntity> findByImportBatchNo(BigInteger batchNo);
}
