package com.huatonghh.authority.domain;

import lombok.Data;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.io.Serializable;

/**
 * @author : Sun
 * @description : 交投集团-部门公司-数据库映射实体
 * @date : 2019/11/4 19:41
 * @version : 1.0
 */

public class EiDepartUserKey implements Serializable {

    private static final long serialVersionUID = 2382896980380725919L;

    private String departId;

    private String userId;


}
