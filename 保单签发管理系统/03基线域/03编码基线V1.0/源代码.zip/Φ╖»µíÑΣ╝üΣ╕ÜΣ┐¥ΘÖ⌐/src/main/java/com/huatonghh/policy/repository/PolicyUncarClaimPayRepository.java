package com.huatonghh.policy.repository;

import com.huatonghh.policy.domain.claim.noncar.ClaimPay;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * (PolicyUncarClaimPay)非车理赔支付信息数据库访问层
 *
 * @author wanggl
 * @since 2020-11-12 15:58:06
 */
public interface PolicyUncarClaimPayRepository extends JpaRepository<ClaimPay, Long> {
    /**
     * 根据报案号查询所有支付信息
     *
     * @param reportNo 报案号
     * @return list
     */
    List<ClaimPay> findAllByReportNo(String reportNo);

    /**
     * 根据报案号查询所有支付信息
     *
     * @param reportNo 报案号
     * @return list
     */
    ClaimPay findAllByReportNoAndSerialNumber(String reportNo, String serialNumber);
}
