package com.huatonghh.base.service;

import com.huatonghh.base.domain.BaseEng;
import com.huatonghh.base.repository.BaseEngRepository;
import com.huatonghh.common.exception.BusinessException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * description: 基础项目信息
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/22
 */
@Service
@Slf4j
@AllArgsConstructor
public class BaseEngService {

    private final BaseEngRepository baseProjectRepository;

    private final ModelMapper modelMapper;

    public Integer save(BaseEng eng) {
        if (null != this.findByName(eng.getName())) {
            throw new BusinessException("项目名称已存在");
        }
        BaseEng baseProject = modelMapper.map(eng, BaseEng.class);
        baseProject.setValid(true);
        return baseProjectRepository.save(baseProject).getId();
    }

    public void update(BaseEng eng) {
        BaseEng old = this.checkExist(eng.getId());
        modelMapper.map(eng, old);
        old.setValid(true);
        baseProjectRepository.save(old);
    }

    public BaseEng findById(Integer id) {
        return this.checkExist(id);
    }

    public List<BaseEng> findAll() {
        return baseProjectRepository.allOrderByTime();
    }

    public BaseEng findByName(String name) {
        List<BaseEng> list = baseProjectRepository.findAllByNameAndValid(name, true);
        if (null == list || list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    public BaseEng checkExist(Integer id) {
        if (null == id) {
            throw new BusinessException("数据不存在");
        }
        Optional<BaseEng> op = baseProjectRepository.findById(id);
        if (op.isPresent()) {
            return op.get();
        }
        throw new BusinessException("数据不存在");
    }

}
