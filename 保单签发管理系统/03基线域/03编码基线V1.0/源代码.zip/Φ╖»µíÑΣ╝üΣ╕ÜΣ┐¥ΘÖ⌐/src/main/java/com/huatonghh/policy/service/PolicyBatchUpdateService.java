package com.huatonghh.policy.service;

import com.huatonghh.policy.repository.policy.PolicyMainRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/29
 */
@Service
@Slf4j
@AllArgsConstructor
public class PolicyBatchUpdateService {

    private final PolicyMainRepository policyMainRepository;

    public void batchUpdatePolicyEffective() {
        policyMainRepository.batchUpdatePolicyEffective();
    }

    public void batchUpdatePolicyOverdue() {
        policyMainRepository.batchUpdatePolicyOverdue();
    }
}
