package com.huatonghh.authority.service.dto.hr.response;

import lombok.Data;


/**
 * @author : Sun
 * @description : 查询公司信息-返回相应状态信息
 * @date : 2019/11/4 21:05
 * @version : 1.0
 */
@Data
public class RetResponse {

    /** 返回代码 */
    private String retCode;

    /** 返回的技术/业务响应信息 */
    private String retMessage;

}
