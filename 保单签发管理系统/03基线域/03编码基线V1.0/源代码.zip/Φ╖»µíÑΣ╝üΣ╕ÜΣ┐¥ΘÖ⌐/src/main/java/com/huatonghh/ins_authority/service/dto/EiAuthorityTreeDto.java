package com.huatonghh.ins_authority.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author : Sun
 * @description : 菜单权限二叉树对象
 * @date : 2019/11/4 21:10
 * @version : 1.0
 */
@Data
@ApiModel(value = "菜单权限二叉树对象")
public class EiAuthorityTreeDto implements Serializable {

    private static final long serialVersionUID = -1598099675538119276L;

    @ApiModelProperty(value = "菜单id")
    private Integer id;

    @ApiModelProperty(value = "前端路由组件")
    private String component;

    @ApiModelProperty(value = "路由名称")
    private String name;

    @ApiModelProperty(value = "状态")
    private String status;

    @ApiModelProperty(value = "标题")
    private String title;

    @ApiModelProperty(value = "图标")
    private String icon;

    @ApiModelProperty(value = "是否生效")
    private Boolean visible;

    @ApiModelProperty(value = "父菜单id。根菜单为0")
    private Integer parentId;

    @ApiModelProperty(value = "子菜单集合")
    private List<EiAuthorityTreeDto> children;

    public EiAuthorityTreeDto(Integer id, String component, Integer parentId, List<EiAuthorityTreeDto> children) {
        this.id = id;
        this.component = component;
        this.parentId = parentId;
        this.children = children;
    }

    public EiAuthorityTreeDto() {
    }

}
