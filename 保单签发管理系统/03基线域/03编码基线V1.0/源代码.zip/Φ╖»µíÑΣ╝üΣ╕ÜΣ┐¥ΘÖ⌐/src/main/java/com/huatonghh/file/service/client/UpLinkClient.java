package com.huatonghh.file.service.client;

import com.huatonghh.file.service.AuditFileService;
import com.huatonghh.file.service.dto.FiAuditFileDto;
import com.huatonghh.policy.constant.PlanConstant;
import com.huatonghh.policy.constant.enums.UploadLinkEnum;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/21
 */
@Service
@AllArgsConstructor
public class UpLinkClient {
    private final AuditFileService auditFileService;
//    private final PlanService planService;

    public void uploadAuditFile(FiAuditFileDto fiAuditFileDto) {
        // 附件上传环节
        // 判断上传的类型
        // 批次类型
        if (PlanConstant.BELONG_TYPE_BATCH.equals(fiAuditFileDto.getBelongType())) {
            fiAuditFileDto.setUploadLink(UploadLinkEnum.BELONG_TYPE_PLAN_BATCH.desc());
        }
        // 计划类型
        if (PlanConstant.BELONG_TYPE_PLAN.equals(fiAuditFileDto.getBelongType())) {
//            PlanEntity plan = planService.checkExist(new BigInteger(fiAuditFileDto.getBelongId()));
//            if (PlanConstant.PLAN_STATUS_SAVE.equals(plan.getStatus())) {
//                if (PlanConstant.PLAN_TYPE_YEAR.equals(plan.getPlanType())) {
//                    // 计划待补充
//                    fiAuditFileDto.setUploadLink(UploadLinkEnum.BELONG_TYPE_PLAN_ANNUAL.desc());
//                }
//            }

        }

        auditFileService.saveAuditFile(fiAuditFileDto);

    }
}
