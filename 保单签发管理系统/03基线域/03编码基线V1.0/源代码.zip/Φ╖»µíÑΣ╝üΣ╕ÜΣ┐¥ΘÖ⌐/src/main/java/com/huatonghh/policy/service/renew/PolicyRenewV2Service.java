package com.huatonghh.policy.service.renew;

import cn.hutool.core.util.StrUtil;
import com.huatonghh.authority.service.dto.EiDepartDto;
import com.huatonghh.base.constant.BaseConstant;
import com.huatonghh.base.service.BaseRemindService;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.repository.DynamicQuery;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.ins_authority.service.EiInsUserService;
import com.huatonghh.ins_authority.service.dto.EiInsUserDto;
import com.huatonghh.policy.domain.policy.renew.PolicyRenewEntity;
import com.huatonghh.policy.repository.renew.PolicyRenewV2Repository;
import com.huatonghh.policy.service.client.UserClient;
import com.huatonghh.policy.service.dto.policy.PolicyListCondition;
import com.huatonghh.policy.service.dto.renew.PolicyRenewListDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * description:续保服务层
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2020/1/9
 */
@Service
@Slf4j
@AllArgsConstructor
public class PolicyRenewV2Service {

    private final PolicyRenewV2Repository policyRenewV2Repository;

    private final UserClient userClient;

    private final DynamicQuery dynamicQuery;

    private final EiInsUserService insUserService;

    private final BaseRemindService remindService;

    @Transactional(rollbackFor = RuntimeException.class)
    public void hideRenew(BigInteger id) {
        PolicyRenewEntity entity = this.checkExist(id);
        entity.setRemindDisplay(false);
        policyRenewV2Repository.save(entity);
    }

    /**
     * 企业续保列表，查当前公司以及以下公司需要续保的保单
     *
     * @param condition 条件
     * @return 列表
     */
    public PageInfo<PolicyRenewListDTO> listRenewPage(PolicyListCondition condition) {
        // 字段
        StringBuilder sql = this.getRenewListField();
        // from
        this.getRenewListFrom(sql);
        // 条件
        this.conditionSql(sql, condition);
        // 查续保
        PageInfo<PolicyRenewListDTO> page = queryPageList(sql, condition.getPageNum(), condition.getPageSize());
        return page;
    }

    public PageInfo<PolicyRenewListDTO> queryPageList(StringBuilder sql, Integer pageNum, Integer pageSize) {
        long total = dynamicQuery.nativeQueryCount("select count(1) from (" + sql + ") a");
        sql.append(" limit ?1, ?2 ");
        List<PolicyRenewListDTO> list = dynamicQuery.nativeQueryListModel(PolicyRenewListDTO.class, sql.toString(),
            (pageNum - 1) * pageSize, pageSize);

        return PageInfo.of(pageNum, pageSize, list, total);
    }

    private StringBuilder getRenewListField() {
        StringBuilder sql = new StringBuilder();
        sql.append("select DISTINCT r.id, r.policy_no_old policyNoOld");
        sql.append(" ,r.plate_no plateNo");
        sql.append(" ,r.frame_no frameNo");
        sql.append(" ,m.holder_name holderName");
        sql.append(" ,m.insured_name insuredName");
        sql.append(" ,m.insurance_category insuranceCategory");
        sql.append(" ,m.kind_code kindCode");
        sql.append(" ,m.policy_bgn_time policyBgnTime");
        sql.append(" ,m.policy_end_time policyEndTime");
        sql.append(" ,r.status status");
        sql.append(" ,r.belong_company_new belongCompanyNew");
        sql.append(" ,DATEDIFF(m.policy_end_time,CURDATE( )) AS remainingDueDays");
        return sql;
    }

    private void getRenewListFrom(StringBuilder sql) {
        // 当前公司
        EiDepartDto departDto = userClient.getCurrentGroupCompany();
        sql.append(" from policy_renew_info r left join policy_main m on r.policy_no_old = m.policy_no\n" +
            " , ei_depart d1, ei_depart d2\n" +
            " WHERE 1=1");
        sql.append(" AND d1.id = m.start_company");
        sql.append(" AND d1.ids LIKE CONCAT(d2.ids,'%') ");
        sql.append(StrUtil.format("  and d1.id='{}'", departDto.getId()));
    }

    private void conditionSql(StringBuilder sql, PolicyListCondition condition) {
        // 发起公司
        if (StringUtils.isNotBlank(condition.getStartCompany())) {
            sql.append(StrUtil.format(" and d1.id='{}'", condition.getStartCompany()));
        }
        if (StringUtils.isNotBlank(condition.getPolicyNo())) {
            sql.append(StrUtil.format(" AND m.policy_no = '{}' ", condition.getPolicyNo()));
        }
        if (StringUtils.isNotBlank(condition.getInsuranceCategory())) {
            sql.append(StrUtil.format(" AND m.insurance_category = '{}' ", condition.getInsuranceCategory()));
        }
        if (null != condition.getCarUncarFlag()) {
            sql.append(StrUtil.format(" AND m.car_uncar_flag = '{}' ", condition.getCarUncarFlag()));
        }
        if (StringUtils.isNotBlank(condition.getHolderName())) {
            sql.append(StrUtil.format(" AND m.holder_name = '{}' ", condition.getHolderName()));
        }
        if (null != (condition.getExpirationDays())) {
            sql.append(StrUtil.format(" AND DATEDIFF(m.policy_end_time,CURDATE( )) < '{}' ", condition.getExpirationDays()));
        }


        sql.append(" and r.remind_display =1");
        sql.append(" order by r.current_timestamp");
    }

    /**
     * 批量插入续保
     */
    public void batchInsertCarRenew() {
        policyRenewV2Repository.batchInsertCarRenew();
    }

    public List<PolicyRenewEntity> listByPolicy(String policyNo) {
        List<PolicyRenewEntity> result = new ArrayList<>();
        List<PolicyRenewEntity> list1 = policyRenewV2Repository.findAllByPolicyNoNewOrderByIdDesc(policyNo);
        List<PolicyRenewEntity> list2 = policyRenewV2Repository.findAllByPolicyNoOldOrderByIdDesc(policyNo);
        if (list1 != null && list1.size() > 0) {
            result.addAll(list1);
        }
        if (list2 != null && list2.size() > 0) {
            result.addAll(list2);
        }
        if (result.size() <= 0) {
            return null;
        }
        return result;
    }

    /**
     * 通知保险公司续保
     *
     * @param policyNo      保单号
     * @param belongCompany 保险公司
     * @param date          数据
     */
    public void reportInsRenew(String policyNo, String belongCompany, String date) {

        if (StringUtils.isBlank(belongCompany) || StringUtils.isBlank(policyNo)) {
            return;
        }
        List<EiInsUserDto> user = insUserService.queryDepartLowerUserList(Integer.valueOf(belongCompany));
        if (null == user || user.isEmpty()) {
            return;
        }
        List<String> users = user.stream().map(EiInsUserDto::getUserName).collect(Collectors.toList());
        remindService.renewReport(null, policyNo, users, BaseConstant.REMIND_INS_RENEW_CAR, date, true);
    }

    private PolicyRenewEntity checkExist(BigInteger id) {
        if (null == id) {
            throw new BusinessException("续保不存在");
        }
        Optional<PolicyRenewEntity> op = policyRenewV2Repository.findById(id);
        if (op.isPresent()) {
            return op.get();
        }
        throw new BusinessException("续保不存在");
    }
}

 /* if (StringUtils.isNotBlank(condition.getHolderName())) {
            sql.append(StrUtil.format(" AND m.holder_name = '{}' ", condition.getHolderName()));
        }
        if (null != condition.getHasEndDays()) {
            sql.append(" AND  m.policy_end_time >= CURDATE() and m.policy_end_time <= DATE_ADD(CURDATE(), INTERVAL ");
            sql.append(condition.getHasEndDays());
            sql.append(" DAY)");
        }*/
// sql.append(" AND  m.policy_end_time >= CURDATE() and m.policy_end_time <= DATE_ADD(CURDATE(), INTERVAL " + condition.getHasEndDays() + " DAY)");
         /* if (StringUtils.isNotBlank(condition.getKindCode())) {
            sql.append(StrUtil.format(" AND m.kind_code = '{}' ", condition.getKindCode()));
        }*/
