package com.huatonghh.excel.service.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import lombok.Data;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/14
 */
@Data
@ContentRowHeight(20)
@HeadRowHeight(20)
@ColumnWidth(15)
public class ProjectData {
    @ExcelProperty(value = "项目编号", index = 0)
    private String projNo;
    @ExcelProperty(value = "险种类别", index = 1)
    private String riskKind;
    @ExcelProperty(value = "发起公司", index = 2)
    private String startCompanyName;
    @ExcelProperty(value = "发起人", index = 3)
    private String startUserName;
    @ExcelProperty(value = "投保数量", index = 4)
    private Integer insureNumber;
    @ExcelProperty(value = "预计保额（元）", index = 5)
    private String estAmount;
    @ExcelProperty(value = "预计保费（元）", index = 6)
    private String estPremium;
    @ExcelProperty(value = "状态", index = 7)
    private String mainStatus;
    @ExcelProperty(value = "环节", index = 8)
    private String currentTache;
    @ExcelProperty(value = "备注", index = 9)
    private String remark;
}
