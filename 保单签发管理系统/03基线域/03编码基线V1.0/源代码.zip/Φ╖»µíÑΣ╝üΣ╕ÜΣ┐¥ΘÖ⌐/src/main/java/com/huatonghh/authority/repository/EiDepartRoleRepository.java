package com.huatonghh.authority.repository;


import com.huatonghh.authority.domain.EiDepartRole;
import com.huatonghh.authority.domain.EiRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;


/**
 * @author : Sun
 * @description : 交投集团-公司部门-数据仓库
 * @date : 2019/11/4 19:44
 * @version : 1.0
 */
@Repository
public interface EiDepartRoleRepository extends JpaRepository<EiDepartRole, String> {


    /**
     * 删除角色对应的用户中间表
     *
     * @author Sun
     * @date 2019/11/4 19:54
     * @param roleId: 角色id
     **/
    @Modifying
    @Query(nativeQuery = true, value = "delete from ei_depart_role where role_id = :roleId")
    void deleteDepartRoleByRoleId(@Param("roleId") Integer roleId);
}
