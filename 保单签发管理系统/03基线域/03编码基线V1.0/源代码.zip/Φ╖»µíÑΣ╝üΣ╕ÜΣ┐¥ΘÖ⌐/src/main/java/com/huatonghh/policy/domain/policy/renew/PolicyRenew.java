package com.huatonghh.policy.domain.policy.renew;//package com.huatonghh.plan.domain.policy.renew;
//
//import java.util.Date;
//import java.io.Serializable;
//import io.swagger.annotations.Api;
//import io.swagger.annotations.ApiModelProperty;
//import lombok.NoArgsConstructor;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import java.io.Serializable;
//import java.math.BigInteger;
//import java.time.LocalDateTime;
//import java.util.Date;
//
///**
// * 保单-续保(PolicyRenew)表实体类
// *
// * @author 居炎明
// * @since 2019-10-21 20:43:43
// */
//@Entity
//@Table(name = "policy_renew")
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//@Api(description = "保单-续保")
//public class PolicyRenew implements Serializable {
//
//        private static final long serialVersionUID=674744938002950246L;
//        @ApiModelProperty(value = "主键")
//        @Id
//        @GeneratedValue(strategy = GenerationType.IDENTITY)
//        @Column(name = "id",nullable = false,unique = true)
//        private BigInteger id;
//
//
//        @ApiModelProperty(value = "保单号")
//        @Column(name = "policy_No")
//        private String policyNo;
//
//        @ApiModelProperty(value = "保单编号")
//        @Column(name = "policy_Id")
//        private BigInteger policyId;
//
//        @ApiModelProperty(value = "发起时间")
//        @Column(name = "create_Time")
//        private Date createTime;
//
//        @ApiModelProperty(value = "续保说明")
//        @Column(name = "remark")
//        private String remark;
//
//        @ApiModelProperty(value = "续保状态：0。 发起 1.通过 2.驳回")
//        @Column(name = "status")
//        private Byte status;
//
//        @ApiModelProperty(value = "操作人")
//        @Column(name = "operator")
//        private String operator;
//
//        @ApiModelProperty(value = "发起原因")
//        @Column(name = "start_Reason")
//        private String startReason;
//
//        @ApiModelProperty(value = "续保时间")
//        @Column(name = "end_Time")
//        private Date endTime;
//
//        @ApiModelProperty(value = "新保单号")
//        @Column(name = "policy_No_New")
//        private String policyNoNew;
//
//        @ApiModelProperty(value = "新保单编号")
//        @Column(name = "policy_Id_New")
//        private BigInteger policyIdNew;
//
//        @ApiModelProperty(value = "项目编号")
//        @Column(name = "project_No")
//        private BigInteger projectNo;
//
//        @ApiModelProperty(value = "保险公司")
//        @Column(name = "belong_Company")
//        private String belongCompany;
//
//        @ApiModelProperty(value = "发起人")
//        @Column(name = "start_user")
//        private String startUser;
//
//
//}
