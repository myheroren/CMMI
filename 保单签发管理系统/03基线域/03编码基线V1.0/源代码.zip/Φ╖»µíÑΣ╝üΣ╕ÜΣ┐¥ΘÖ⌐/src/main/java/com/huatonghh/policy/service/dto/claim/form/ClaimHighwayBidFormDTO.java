package com.huatonghh.policy.service.dto.claim.form;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author : wh
 * description : 标段统计表
 * @version : 1.0
 * @date : 2020/5/25 15:59
 */
@Data
public class ClaimHighwayBidFormDTO {
    @ApiModelProperty(value = "填报项目单位名称")
    private String startCompanyName;
    @ApiModelProperty(value = "工程类别")
    private String engType;
    @ApiModelProperty(value = "工程类别名称")
    private String engTypeName;
    @ApiModelProperty(value = "标段")
    private String belongBid;
    @ApiModelProperty(value = "是否投保一切险，")
    private String allInsured;
    @ApiModelProperty(value = "承保单位")
    private String belongCompanyName;

    @ApiModelProperty(value = "保费")
    private String totalPremium;
    @ApiModelProperty(value = "保额")
    private String totalAmount;

    @ApiModelProperty(value = "出险次数")
    private Integer countClaim;
    @ApiModelProperty(value = "出险估损额")
    private String preLossAmount;

    @ApiModelProperty(value = "索赔次数")
    private Integer countApply;
    @ApiModelProperty(value = "索赔额")
    private String askForAmount;

    @ApiModelProperty(value = "赔偿次数")
    private Integer countGetClaim;
    @ApiModelProperty(value = "赔偿额")
    private String payAmount;

}
