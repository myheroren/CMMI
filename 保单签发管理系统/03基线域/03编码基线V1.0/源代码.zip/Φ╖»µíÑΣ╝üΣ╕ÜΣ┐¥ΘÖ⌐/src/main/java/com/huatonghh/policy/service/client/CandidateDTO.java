package com.huatonghh.policy.service.client;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/30
 */
@Data
@ApiModel("候选人")
public class CandidateDTO {
    @ApiModelProperty("用户id")
    private String userId;
    @ApiModelProperty("登录账户")
    private String account;
    @ApiModelProperty("真是姓名")
    private String realName;
    @ApiModelProperty("执行角色")
    private String groupId;
}
