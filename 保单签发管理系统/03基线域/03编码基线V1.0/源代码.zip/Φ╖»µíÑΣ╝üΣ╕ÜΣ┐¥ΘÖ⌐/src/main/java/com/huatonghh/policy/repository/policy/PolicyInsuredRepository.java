package com.huatonghh.policy.repository.policy;

import com.huatonghh.policy.domain.policy.PolicyInsured;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/25
 */
public interface PolicyInsuredRepository extends JpaRepository<PolicyInsured, Integer> {
    /**
     * 根据保单号
     *
     * @param policyNo 保单号
     * @return 被保险人列表
     */
    List<PolicyInsured> findAllByPolicyNo(String policyNo);
}
