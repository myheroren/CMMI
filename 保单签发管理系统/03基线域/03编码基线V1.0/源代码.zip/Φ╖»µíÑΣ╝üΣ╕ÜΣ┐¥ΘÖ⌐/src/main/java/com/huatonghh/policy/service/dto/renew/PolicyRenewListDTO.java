package com.huatonghh.policy.service.dto.renew;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigInteger;
import java.util.Date;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2020/1/9
 */
@Data
@ApiModel("续保列表")
public class PolicyRenewListDTO {
    @ApiModelProperty(value = "续保编号")
    private BigInteger id;
    @ApiModelProperty(value = "保单号")
    private String policyNoOld;
    @ApiModelProperty(value = "状态")
    private Byte status;
    @ApiModelProperty(value = "距离到期时间")
    private Integer remainingDueDays;
    @ApiModelProperty(value = "车：车架号")
    private String frameNo;
    @ApiModelProperty(value = "车：车牌号")
    private String plateNo;
    @ApiModelProperty(value = "发起公司")
    private String startCompany;
    @ApiModelProperty(value = "新保险公司")
    private String belongCompanyNew;
    @ApiModelProperty(value = "保险类别")
    private String insuranceCategory;
    @ApiModelProperty(value = "险种类别")
    private String kindCode;
    @ApiModelProperty(value = "投保人")
    private String holderName;
    @ApiModelProperty(value = "被保险人")
    private String insuredName;
    @ApiModelProperty(value = "有效起期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyBgnTime;
    @ApiModelProperty(value = "有效止期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyEndTime;
}
