package com.huatonghh.policy.domain.project;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;
import java.math.BigInteger;

/**
 * description:项目预设信息
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/6
 */
@Entity
@Table(name = "project_pre_coinsurance")
@Data
public class ProjectPreCoinsurance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "co_id")
    private Integer coId;
    @Column(name = "project_no")
    private BigInteger projectNo;
    @Column(name = "proj_type")
    private Byte projType;
    @Column(name = "belong_company")
    @ApiModelProperty("归属保险公司")
    private String belongCompany;
    @Column(name = "belong_company_name")
    @ApiModelProperty("归属保险公司名称")
    private String belongCompanyName;
    @Column(name = "proportion")
    @ApiModelProperty("共保比例")
    private String proportion;
}
