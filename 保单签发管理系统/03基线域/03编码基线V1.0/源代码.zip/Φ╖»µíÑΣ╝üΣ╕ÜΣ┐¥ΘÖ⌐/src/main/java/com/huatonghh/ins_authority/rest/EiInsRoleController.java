package com.huatonghh.ins_authority.rest;

import com.huatonghh.authority.service.dto.EiRoleDto;
import com.huatonghh.authority.service.dto.EiRoleListCondition;
import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.ins_authority.service.EiInsRoleService;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;


/**
 * @author : Sun
 * @description : 角色管理相关接口，角色增删改查、为角色添加权限
 * @date : 2019/11/5 20:22
 * @version : 1.0
 */
@RestController
@RequestMapping("/api/ins_role/v1")
@Api(tags="12、ins.保险公司角色管理", value = "角色相关接口")
@Slf4j
public class EiInsRoleController {

    private final EiInsRoleService eiRoleService;

    public EiInsRoleController(EiInsRoleService eiRoleService) {
        this.eiRoleService = eiRoleService;
    }

    @GetMapping("/page_list")
    @ApiOperation(value = "1、角色列表查询", notes = "无分页", httpMethod = "GET")
    @Timed
    public ApiResponse<List<EiRoleDto>> queryRoleList() {
        return ApiResponse.ofSuccess(eiRoleService.roleList());
    }

    @PostMapping("/list_page")
    @ApiOperation(value = "6、角色列表查询", notes = "有分页", httpMethod = "POST")
    @Timed
    public ApiResponse<PageInfo<EiRoleDto>> queryRoleListPage(@RequestBody @Valid EiRoleListCondition eiRoleListCondition) {
        return ApiResponse.ofSuccess(eiRoleService.rolePageList(eiRoleListCondition));
    }

    @PostMapping("/save")
    @ApiOperation(value = "2、角色信息保存", httpMethod = "POST")
    @Timed
    public ApiResponse<EiRoleDto> saveRole(@RequestBody @Valid EiRoleDto eiRoleDto) {
        return ApiResponse.ofSuccess(eiRoleService.saveRole(eiRoleDto));
    }

    @GetMapping("/info/{roleId}")
    @ApiOperation(value = "3、获取角色详细信息", notes = "此接口也可以获取角色配置的菜单权限列表", httpMethod = "GET")
    @Timed
    public ApiResponse<EiRoleDto> queryRoleInfo(@PathVariable(value = "roleId") Integer roleId) {
        return ApiResponse.ofSuccess(eiRoleService.queryRoleInfo(roleId));
    }

    @DeleteMapping("/delete/{roleId}")
    @ApiOperation(value = "5、删除角色", httpMethod = "DELETE")
    @Timed
    public void delete(@PathVariable(value = "roleId") Integer roleId) {
        eiRoleService.delete(roleId);
    }


}
