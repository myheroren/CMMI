//package com.huatonghh.authority.service;
//
//import cn.hutool.http.HttpRequest;
//import cn.hutool.http.HttpResponse;
//import com.alibaba.fastjson.JSONObject;
//import com.huatonghh.authority.service.dto.EiDepartDto;
//import com.huatonghh.authority.service.dto.hr.request.SheadRequest;
//import com.huatonghh.authority.service.dto.hr.request.depart.DepartBody;
//import com.huatonghh.authority.service.dto.hr.request.depart.DepartRequest;
//import com.huatonghh.authority.service.dto.hr.request.dept.DeptBody;
//import com.huatonghh.authority.service.dto.hr.request.dept.DeptRequest;
//import com.huatonghh.authority.service.dto.hr.request.xml.XmlArgZero;
//import com.huatonghh.authority.service.dto.hr.request.xml.XmlSelectAll;
//import com.huatonghh.authority.service.dto.hr.request.xml.XmlSoapenvBody;
//import com.huatonghh.authority.service.dto.hr.request.xml.XmlSoapenvEnvelope;
//import com.huatonghh.authority.service.dto.hr.response.depart.DepartArrayList;
//import com.huatonghh.authority.service.dto.hr.response.depart.DepartResponse;
//import com.huatonghh.authority.service.dto.hr.response.dept.DeptArrayList;
//import com.huatonghh.authority.service.dto.hr.response.dept.DeptResponse;
//import com.huatonghh.authority.service.dto.hr.response.xml.XmlSoapEnvelope;
//import com.huatonghh.common.exception.BusinessException;
//import com.thoughtworks.xstream.XStream;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.stream.Collectors;
//
///**
// * Description : 人力资源数据对接
// * @author : Sun
// * @date : 2019/10/29 14:47
// * @version : 1.0
// */
//@Service
//@Slf4j
//public class HrService {
//
//
//    /**
//     * Description : 组装请求公司JSON报文
//     * @author : Sun
//     * @date : 2019/10/29 16:19
//     */
//    public String processCompanyJson() {
//        DepartBody bodyJson = new DepartBody();
//        bodyJson.setWorkType("All");
//
//        SheadRequest sheadJson = new SheadRequest();
//        sheadJson.setServiceId("TB_STA_gongsiService");
//        sheadJson.setTargetId("HR");
//        sheadJson.setRequestId("people");
//
//        DepartRequest requestJson = new DepartRequest();
//        requestJson.setComPanyBody(bodyJson);
//        requestJson.setSheadRequest(sheadJson);
//        String requestJsonString = JSONObject.toJSONString(requestJson);
//        log.info("process请求Json串：", requestJsonString);
//        return requestJsonString;
//    }
//
//
//    /**
//     * Description : 根据JSON组装通用请求xml报文
//     * @author : Sun
//     * @date : 2019/10/29 16:19
//     */
//    public String processXml(String requestJsonString) {
//        XStream xstream = new XStream();
//        xstream.autodetectAnnotations(true);
//
//        XmlArgZero xmlArgZero = new XmlArgZero();
//        xmlArgZero.setXmlns("");
//        xmlArgZero.setJsonRequest(requestJsonString);
//
//        XmlSelectAll xmlSelectAll = new XmlSelectAll();
//        xmlSelectAll.setXmlArgZero(xmlArgZero);
//        xmlSelectAll.setXmlns("http://service.ws.standard.ft.com/");
//
//        XmlSoapenvBody xmlSoapenvBody = new XmlSoapenvBody();
//        xmlSoapenvBody.setXmlSelectAll(xmlSelectAll);
//
//        XmlSoapenvEnvelope xmlSoapenvEnvelope = new XmlSoapenvEnvelope();
//        xmlSoapenvEnvelope.setXmlnsXsi("http://www.w3.org/2001/XMLSchema-instance");
//        xmlSoapenvEnvelope.setXmlnsSoapenv("http://schemas.xmlsoap.org/soap/envelope/");
//        xmlSoapenvEnvelope.setXmlnsXsd("http://www.w3.org/2001/XMLSchema");
//        xmlSoapenvEnvelope.setXmlSoapenvBody(xmlSoapenvBody);
//
//        String requestXml = xstream.toXML(xmlSoapenvEnvelope);
//        log.info("process请求XML串：", requestXml);
//        return requestXml;
//    }
//
//
//
//    /**
//     * Description : 对xml进行post请求，返回响应XML串
//     * @author : Sun
//     * @date : 2019/10/29 16:27
//     */
//    public String httpRequestPost(String url, String requestXml) {
//        HttpResponse execute = HttpRequest.post(url)
//            .body(requestXml)
//            .execute();
//        String responseXMl = execute.body();
//        log.info("get响应XML串：", responseXMl);
//        return responseXMl;
//    }
//
//
//    /**
//     * Description : 接收反参，解析xml为对象，并返回jsonResponse
//     * @author : Sun
//     * @date : 2019/10/29 16:31
//     */
//    public String parseResponseXml(String responseXMl) {
//        XStream xstreamResponse = new XStream();
//        xstreamResponse.processAnnotations(XmlSoapEnvelope.class);
//        xstreamResponse.setClassLoader(XmlSoapEnvelope.class.getClassLoader());
//        XmlSoapEnvelope xmlSoapEnvelope = (XmlSoapEnvelope) xstreamResponse.fromXML(responseXMl);
//
//        // 根据对象获取【return】的值
//        String responseBody = xmlSoapEnvelope.getXmlSoapBody().getXmlNsSelectAllResponse().getJsonResponse();
//
//        // 将【return】的Json串解析为JavaBean
//        String replaceLeft = responseBody.replaceAll("\"\\[", "[");
//        String replaceRight = replaceLeft.replaceAll("]\"", "]");
//        log.info("get响应JSON串：", replaceRight);
//        return replaceRight;
//    }
//
//
//
//    /**
//     * Description : 根据响应的Json对象，获取保存实体对象集合
//     *                 公司数据CompanyArrayList
//     * @author : Sun
//     * @date : 2019/10/29 17:18
//     */
//    public List<EiDepartDto> parseResponseArrayList(DepartResponse companyResponse) {
//        if(!"000000".equals(companyResponse.getSheadResponse().getRet().get(0).getRetCode())) {
//            throw new BusinessException("解析返回代码时：数据异常");
//        }
//        List<DepartArrayList> arrayList = companyResponse.getSheadResponse().getArrayList();
//
//        List<EiDepartDto> eiDepartDtos = arrayList.stream().map(company -> {
//            EiDepartDto depart = new EiDepartDto();
//            depart.setId(company.getCHid());
//            depart.setName(company.getCName());
//            depart.setLevel(company.getCLevel());
//            depart.setParentId(company.getCSuperiorHid());
//            return depart;
//        }).collect(Collectors.toList());
//
//        return eiDepartDtos;
//    }
//
//
//
//    /**
//     * Description : 递归组装ids
//     * @author : Sun
//     * @date : 2019/10/14 15:38
//     */
//    public List<EiDepartDto>  recursiveProcess(EiDepartDto e, List<EiDepartDto> list) {
//        for (EiDepartDto child : list) {
//            if(e.getId().equals(child.getParentId())) {
//                child.setIds(e.getIds() + child.getId() + ";");
//                list = recursiveProcess(child, list);
//            }
//        }
//        return list;
//    }
//
//
//    /**
//     * @author Sun
//     * @description 组装请求部门JSON报文：主要部门、剩余部门
//     * @date 2019/11/27 14:56
//     * @return java.lang.String
//     **/
//    public String processDeptJson(String companyId, String deptId) {
//        DeptBody deptBody = new DeptBody();
//        deptBody.setWorkType("Dept");
//        deptBody.setComPanyId(companyId);
//        deptBody.setMainDeptId("-1");
//        // deptId为空，则查询的是主要部门，deptId不为空，则查询的是主要部门下的其他部门
//        if(StringUtils.isNotBlank(deptId)) {
//            deptBody.setDeptId(deptId);
//        }
//
//        SheadRequest sheadJson = new SheadRequest();
//        sheadJson.setServiceId("TB_STA_gongsiService");
//        sheadJson.setTargetId("HR");
//        sheadJson.setRequestId("people");
//
//        DeptRequest requestJson = new DeptRequest();
//        requestJson.setDeptBody(deptBody);
//        requestJson.setSheadRequest(sheadJson);
//        String requestJsonString = JSONObject.toJSONString(requestJson);
//        log.info("process请求Json串：", requestJsonString);
//        return requestJsonString;
//    }
//
//
//    /**
//     * Description : 根据响应的Json对象，获取保存实体对象集合
//     *                 主要部门、剩余部门DeptArrayList
//     * @author : Sun
//     * @date : 2019/10/29 17:18
//     */
//    public List<EiDepartDto> parseResponseArrayListDept(DeptResponse deptResponse) {
//        if(!"000000".equals(deptResponse.getSheadResponse().getRet().get(0).getRetCode())) {
//            throw new BusinessException("解析返回代码时：数据异常");
//        }
//        List<DeptArrayList> arrayList = deptResponse.getSheadResponse().getArrayList();
//
//        return arrayList.stream().map(dept -> {
//            EiDepartDto depart = new EiDepartDto();
//            depart.setId(dept.getCHid());
//            depart.setName(dept.getCName());
//            depart.setLevel(dept.getCLevel());
//            depart.setParentId(dept.getCSuperiorHid());
//            return depart;
//        }).collect(Collectors.toList());
//    }
//
//}
