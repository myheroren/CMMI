package com.huatonghh.policy.service.dto.renew;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

/**
 * Description : 保单信息保存实体
 * @author : juyanming
 * @date : 2019/10/21 11:41
 * @version : 1.0
 */

@Data
@ApiModel("续保信息保存实体")
public class PolicyRenewDTO implements Serializable {

        private static final long serialVersionUID=674744938002950246L;

        @ApiModelProperty(value = "自增id：新增不传、修改必传")
        @JsonSerialize(using = ToStringSerializer.class)
        private BigInteger id;

        @ApiModelProperty(value = "保单号")
        @NotNull(message = "保单号不能为空")
        private String policyNo;

        @ApiModelProperty(value = "保单编号")
        private BigInteger policyId;

        @ApiModelProperty(value = "发起时间")
        private Date createTime;

        @ApiModelProperty(value = "续保说明")
        private String remark;

        @ApiModelProperty(value = "续保状态：0。 发起 1.通过 2.驳回")
        private Byte status;

        @ApiModelProperty(value = "操作人")
        private String operator;

        @ApiModelProperty(value = "发起原因")
        private String startReason;

        @ApiModelProperty(value = "续保时间")
        private Date endTime;

        @ApiModelProperty(value = "新保单号")
        private String policyNoNew;

        @ApiModelProperty(value = "新保单编号")
        private BigInteger policyIdNew;

        @ApiModelProperty(value = "项目编号")
        @NotNull(message = "项目编号不能为空")
        private BigInteger projectNo;

        @ApiModelProperty(value = "保险公司")
        private String belongCompany;

        @ApiModelProperty(value = "发起人")
        private String startUser;


}
