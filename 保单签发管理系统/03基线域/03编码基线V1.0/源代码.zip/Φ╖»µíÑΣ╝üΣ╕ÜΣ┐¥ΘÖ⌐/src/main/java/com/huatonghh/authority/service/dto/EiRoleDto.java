package com.huatonghh.authority.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * @author : Sun
 * @description : 角色
 * @date : 2019/11/4 21:11
 * @version : 1.0
 */
@Data
@ApiModel(value = "角色")
public class EiRoleDto implements Serializable {

    private static final long serialVersionUID = 5644670566104743521L;

    @ApiModelProperty(value = "公司ID")
    private String companyId;

    @ApiModelProperty(value = "角色ID")
    private Integer roleId;

    @ApiModelProperty(value = "角色名称")
    private String roleName;

    @ApiModelProperty(value = "描述")
    private String remark;

    @ApiModelProperty(value = "职位")
    private Byte position;

    @ApiModelProperty(value = "是否生效")
    private Boolean valid;

    @ApiModelProperty(value = "角色所属权限")
    private Set<EiAuthorityDto> authorities = new HashSet<>();

}
