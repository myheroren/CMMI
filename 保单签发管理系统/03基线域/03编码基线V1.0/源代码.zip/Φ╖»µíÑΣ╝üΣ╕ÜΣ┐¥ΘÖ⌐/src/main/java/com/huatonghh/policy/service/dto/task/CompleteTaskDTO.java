package com.huatonghh.policy.service.dto.task;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/15
 */
@Data
@ApiModel("完成任务")
public class CompleteTaskDTO {
    @ApiModelProperty("任务")
    @NotBlank(message = "当前任务不能为空！")
    private String taskId;

    @ApiModelProperty("审核结果 0驳回，1通过，-1结束，9提交方案 项目特有的：6统保返回，7自行问询")
    @NotBlank(message = "审核结果不能为空！")
    private String code;

    @ApiModelProperty("业务主键")
    @NotNull(message = "业务主键不能为空！")
    private String businessId;

    @ApiModelProperty("意见")
    private String idea;

    @ApiModelProperty("备注")
    private String msg;

    @ApiModelProperty("发起公司id")
    private String startCompany;
}
