package com.huatonghh.policy.service.dto.claim.form;

import lombok.Data;

import java.math.BigInteger;
import java.util.Date;

/**
 * description:理赔明细表
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/9
 */
@Data
public class ClaimDetailFormDTO {
    /**
     * 被保险人
     */
    private String insuredName;
    /**
     * 项目类别
     */
    private Byte engType;
    /**
     * 出险时间
     */
    private Date accidentTime;
    /**
     * 出险地点
     */
    private String address;
    /**
     * 案件简况
     */
    private String accidentReason;
    /**
     * 估损金额
     */
    private BigInteger preLossAmount;
    /**
     * 保险类别,一切险，第三者
     */
    private Byte insureType;
    /**
     * 受理时间
     */
    private Date claimBeginDate;
    /**
     * 申请人
     */
    private String reportName;
    /**
     * 索赔金额
     */
    private BigInteger askForAmount;
    /**
     * 是否获赔
     */
    private String compensateEnd;
    /**
     * 获赔人
     */
    private String receiveName;
    /**
     * 获赔时间
     */
    private Date receiveTime;
    /**
     * 获赔金额
     */
    private BigInteger payAmount;
    /**
     * 理赔状态
     */
    private Byte claimStatus;
}
