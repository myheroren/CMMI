
package com.huatonghh.empower.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

@Data
@SuppressWarnings("unused")
public class PolicyBaseInfoDTO {

    @ApiModelProperty("保单号")
    private String policyNo;

    @ApiModelProperty("险种大类")
    private String insuranceCategory;

    @ApiModelProperty("险种类型")
    private String kindCode;//险种类型：0工程险；1团意险；2安责险；3雇主责任险

    @ApiModelProperty("项目组织")
    private String projectName;

    @ApiModelProperty("投保人")
    private String holderName;

    @ApiModelProperty("投保人证件类型")
    private String holderCertificateType;

    @ApiModelProperty("投保人证件号码")
    private String holderCertificateNumber;

    @ApiModelProperty("被保人")
    private String insuredName;

    @ApiModelProperty("被保人证件类型")
    private String insuredCertificateType;

    @ApiModelProperty("被保人证件号码")
    private String insuredCertificateNumber;

    @ApiModelProperty("保险公司")
    private String belongCompany;

    @ApiModelProperty("保险公司名称")
    private String belongCompanyName;

    @ApiModelProperty("保费")
    private Double totalPremium;

    @ApiModelProperty("保额")
    private Double totalAmount;

    @ApiModelProperty(value = "项目合同金额")
    private Double projectContractAmount;

    @ApiModelProperty(value = "费率")
    private Double rate;

    @ApiModelProperty(value = "可计提的防灾防损基金")
    private Double totalFund;

    @ApiModelProperty(value = "已使用的防灾防损基金")
    private Double usedFund;

    @ApiModelProperty(value = "已使用的防灾防损基金")
    private Double leftFund;

    @ApiModelProperty("签单日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyApplyTime;

    @ApiModelProperty("保险起期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyBgnTime;

    @ApiModelProperty("保险止期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyEndTime;

}
