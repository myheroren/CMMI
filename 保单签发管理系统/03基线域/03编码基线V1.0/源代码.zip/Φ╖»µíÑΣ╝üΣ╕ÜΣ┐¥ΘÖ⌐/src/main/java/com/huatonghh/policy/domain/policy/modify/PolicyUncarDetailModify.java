package com.huatonghh.policy.domain.policy.modify;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

/**
 * Description : 保单详细信息-非车
 * @author : Sun
 * @date : 2019/8/31 14:01
 * @version : 1.0
 */
@Entity
@Table(name = "policy_uncar_detail_modify")
@Data
public class PolicyUncarDetailModify implements Serializable {

    private static final long serialVersionUID = 8107940585756947653L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private BigInteger id;

    @Column(name = "policy_no")
    private String policyNo;

    @Column(name = "policy_id")
    private BigInteger policyId;

    @Column(name = "main_risk_duty")
    private String mainRiskDuty;

    @Column(name = "total_amount")
    private BigInteger totalAmount;

    @Column(name = "fee_prop")
    private String feeProp;

    @Column(name = "issue_date")
    private Date issueDate;

    @Column(name = "coinsurance_detail")
    private String coinsuranceDetail;

    @Column(name = "paid_in_date")
    private Date paidInDate;

    @Column(name = "payment_type")
    private Byte paymentType;



    @Column(name = "subordinate_bid")
    private String subordinateBid;

    @Column(name = "engineering_name")
    private String engineeringName;

    @Column(name = "guaranty_period")
    private String guarantyPeriod;



    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_time")
    private Date updateTime;

}
