package com.huatonghh.policy.service.dto.project;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

/**
 * @author : hao.wang
 * @date : 2019/7/2
 * description:
 */
@Data
@ApiModel("保险项目查询")
public class ProjectListQuery {
    @ApiModelProperty("当前页数")
    @NotNull(message = "当前页数不能为空！")
    public Integer pageNo;
    @ApiModelProperty("每页显示数据条数")
    @NotNull(message = "分页大小不能为空！")
    public Integer pageSize;
    @ApiModelProperty("项目编号")
    private String projNo;
    @ApiModelProperty("保险类别")
    private String riskKind;
    @ApiModelProperty("项目状态,多个状态用,分割")
    private String status;
    @ApiModelProperty("前端显示状态,多个状态用_分割")
    private String mainStatus;
    @ApiModelProperty("项目类别 ,多个用,分割 1计划外项目，2计划内项目汇总前,3计划内项目汇总后,4中标项目")
    private String projType;
    @ApiModelProperty("发起日期起")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date startTime1;
    @ApiModelProperty("发起日期至")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startTime2;
    @ApiModelProperty("创建时间日期起")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime1;
    @ApiModelProperty("创建时间至")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date createTime2;
    @ApiModelProperty("发起人")
    private String startUser;
    @ApiModelProperty("发起人姓名")
    private String startUserName;
    @ApiModelProperty("发起公司id")
    private String startCompany;
    @ApiModelProperty("发起公司")
    private String startCompanyName;
    @ApiModelProperty("当前公司")
    private String currentCompany;
    @ApiModelProperty("当前用户")
    private String currentUser;

    @ApiModelProperty(value = "排序方式，0，代表逆序，1表示正序")
    private Integer range;
    @ApiModelProperty(value = "排序字段名称，必须是驼峰标志")
    private String column;
    @ApiModelProperty(value = "勾选")
    private List<String> ids;
}
