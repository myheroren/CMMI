package com.huatonghh.policy.service;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.huatonghh.authority.service.EiUserService;
import com.huatonghh.authority.service.dto.EiUserDto;
import com.huatonghh.base.constant.BaseConstant;
import com.huatonghh.base.domain.BaseCode;
import com.huatonghh.base.service.BaseCodeService;
import com.huatonghh.base.service.BaseRemindService;
import com.huatonghh.common.constant.enums.StatusEnum;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.repository.DynamicQuery;
import com.huatonghh.common.util.DateFormatUtil;
import com.huatonghh.common.util.hutool.ClassUtils;
import com.huatonghh.common.util.hutool.LineToHumpTool;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.file.domain.FiAuditFile;
import com.huatonghh.file.repository.FiAuditFileRepository;
import com.huatonghh.file.service.AuditFileService;
import com.huatonghh.file.service.dto.FiAuditFileDto;
import com.huatonghh.ins_authority.service.EiInsUserService;
import com.huatonghh.ins_authority.service.dto.EiInsUserDto;
import com.huatonghh.policy.constant.PlanConstant;
import com.huatonghh.policy.constant.PolicyConstant;
import com.huatonghh.policy.domain.policy.*;
import com.huatonghh.policy.repository.policy.*;
import com.huatonghh.policy.service.client.UserClient;
import com.huatonghh.policy.service.dto.PolicyFundDTO;
import com.huatonghh.policy.service.dto.claim.form.ClaimHighwayPolicyDTO;
import com.huatonghh.policy.service.dto.policy.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFactory;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.validation.Valid;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author : Sun
 * @version : 1.0
 * @description : 保单管理-业务层
 * @date : 2019/11/5 21:46
 */
@Service
@CacheConfig
@Slf4j
@AllArgsConstructor
public class PolicyService {

    private final PolicyMainRepository policyMainRepository;

    private final PolicyUncarDetailRepository policyUncarDetailRepository;

    private final ModelMapper modelMapper;

    private final DynamicQuery dynamicQuery;

    private final MapperFactory mapperFactory;

    private final FiAuditFileRepository fiAuditFileRepository;

    private final AuditFileService fileService;

    private final PolicyVehRiskPlanRepository policyVehRiskPlanRepository;

    private final PolicyEngineeringService policyEngineeringService;

    private final PolicyPayPeriodService payPeriodService;

    private final PolicyInsuredService insuredService;

    private final BaseRemindService baseRemindService;

    private final EiInsUserService insUserService;

    private final EiUserService eiUserService;

    private final UserClient userClient;

    private final PolicyCoinsuranceRepository policyCoinsuranceRepository;

    private final BaseCodeService baseCodeService;

    @PersistenceContext
    private final EntityManager entityManager;

    public PolicyMain findById(BigInteger id) {
        Optional<PolicyMain> op = policyMainRepository.findById(id);
        if (op.isPresent()) {
            return op.get();
        }
        return null;
    }

    /**
     * @param savePolicyDto:
     * @param flag:
     * @author Sun
     * @description 保存保单信息：基本信息、非车/车信息
     * @date 2019/11/5 21:46
     **/
    @Transactional(rollbackFor = RuntimeException.class)
    public void savePolicy(SavePolicyDto savePolicyDto, int flag) {
        // 获取保单号：新增时校验是否存在此保单、保存车 非车信息时，使用基本信息保单号
        String policyNo = savePolicyDto.getPolicyNo();
        PolicyMain policyMain = modelMapper.map(savePolicyDto, PolicyMain.class);
        // 校验保单
        this.checkPolicySaveOrUpdate(policyMain, flag);
        if (null == policyMain.getStatus()) {
            policyMain.setStatus(this.getPolicyStatus(policyMain.getPolicyBgnTime(), policyMain.getPolicyEndTime()));
        }
        // 保单大险种
        BaseCode baseCode = baseCodeService.queryBaseCode(BaseConstant.KIND_CODE, savePolicyDto.getKindCode());
        if (null != baseCode) {
            policyMain.setInsuranceCategory(baseCode.getRemark());
        }

        // 保存保单基本信息
        policyMain.setCreateTime(DateUtil.date());
        policyMainRepository.save(policyMain);

        // 车或非车标识：1车、0非车
        if (PolicyConstant.POLICY_CAR.equals(savePolicyDto.getCarUncarFlag()) && savePolicyDto.getSavePolicyCarDto() != null) {
            SavePolicyCarDto savePolicyCarDto = savePolicyDto.getSavePolicyCarDto();
            PolicyCarDetail policyCarDetail = modelMapper.map(savePolicyCarDto, PolicyCarDetail.class);
            // 保单号：使用基本信息中的保单号
            policyCarDetail.setPolicyNo(policyNo);
            if (flag == 1) {
                policyCarDetail.setId(null);
            } else {
                if (policyCarDetail.getId() == null) {
                    throw new BusinessException(StatusEnum.POLICY_CAR_NEED_ID);
                }
            }

            // 获取方案列表
            List<PolicyVehRiskPlanDto> policyVehRiskPlanDtoList = savePolicyCarDto.getPolicyVehRiskPlanDtoList();
            if (policyVehRiskPlanDtoList != null && !policyVehRiskPlanDtoList.isEmpty()) {
                // 删除现有的方案
                policyVehRiskPlanRepository.deleteByPolicyNo(policyNo);

                // Dto转换为entity
                mapperFactory.classMap(PolicyVehRiskPlanDto.class, PolicyVehRiskPlan.class).byDefault().register();
                List<PolicyVehRiskPlan> policyVehRiskPlans = mapperFactory.getMapperFacade().mapAsList(policyVehRiskPlanDtoList, PolicyVehRiskPlan.class);
                // 使用主保单号，省着传错的进来
                for (PolicyVehRiskPlan policyVehRiskPlan : policyVehRiskPlans) {
                    policyVehRiskPlan.setPolicyNo(policyNo);
                }
                // 保存
                policyVehRiskPlanRepository.saveAll(policyVehRiskPlans);
            }
        }
        if (PolicyConstant.POLICY_CAR_UN.equals(savePolicyDto.getCarUncarFlag()) && savePolicyDto.getSavePolicyUncarDto() != null) {
            PolicyUncarDetail policyUncarDetail = modelMapper.map(savePolicyDto.getSavePolicyUncarDto(), PolicyUncarDetail.class);
            // 保单号：使用基本信息中的保单号
            policyUncarDetail.setPolicyNo(policyNo);
            if (flag == 1) {
                policyUncarDetail.setId(null);
            } else {
                if (policyUncarDetail.getId() == null) {
                    throw new BusinessException(StatusEnum.POLICY_UNCAR_NEED_ID);
                }
            }
            policyUncarDetailRepository.save(policyUncarDetail);
        }

        // 保存保单附件列表信息
        try {
            savePolicyFileAuditDetail(savePolicyDto);
        } catch (Exception e) {
            throw new BusinessException("保存附件列表信息异常");
        }

        // 工程险信息
        if (null != savePolicyDto.getEngineeringInfo()) {
            policyEngineeringService.save(savePolicyDto.getEngineeringInfo());
        }
        // 缴费期次信息
        payPeriodService.save(savePolicyDto.getPayPeriodInfos());
        // 被保险人信息
        insuredService.saveAll(savePolicyDto.getInsuredInfos());
        // 共保信息
        if (null != savePolicyDto.getCoinsuranceInfos() && !savePolicyDto.getCoinsuranceInfos().isEmpty()) {
            List<PolicyCoinsurance> pcs = savePolicyDto.getCoinsuranceInfos().stream().map(c -> modelMapper.map(c, PolicyCoinsurance.class)).collect(Collectors.toList());
            policyCoinsuranceRepository.saveAll(pcs);
        }

    }

    /**
     * 保存保单基础信息
     *
     * @param basicDTO 保单基础信息
     * @return 保单主键
     */
    public BigInteger savePolicyBasic(PolicyBasicDTO basicDTO) {
        PolicyMain policyMain = modelMapper.map(basicDTO, PolicyMain.class);
        return policyMainRepository.save(policyMain).getId();
    }


    private void checkPolicySaveOrUpdate(PolicyMain policyMain, int flag) {
        Optional<PolicyMain> byPolicyNo = policyMainRepository.findByPolicyNo(policyMain.getPolicyNo());
        if (flag == 1) {
            // 校验是否存在该保单信息
            if (byPolicyNo.isPresent()) {
                throw new BusinessException(StatusEnum.POLICY_EXIST_DETAIL, policyMain.getPolicyNo());
            }
            policyMain.setId(null);
        } else {
            if (policyMain.getId() == null) {
                throw new BusinessException(StatusEnum.POLICY_MAIN_NEED_ID);
            }
            if (byPolicyNo.isPresent()) {
                // 编辑时判断保单号是否重复
                if (!policyMain.getId().equals(byPolicyNo.get().getId())) {
                    throw new BusinessException(StatusEnum.POLICY_EXIST_DETAIL, policyMain.getPolicyNo());
                }
            }
        }
    }

    public Byte getPolicyStatus(Date bgnTime, Date endTime) {
        Byte result;
        Date current = DateUtil.date();
        // 当前日期在生效日期之前，状态为待生效
        if (current.before(bgnTime)) {
            result = PolicyConstant.POLICY_STATUS_VALID_BEFORE;
        } else {
            result = PolicyConstant.POLICY_STATUS_VALID;
        }
        // 当前日期在保单止期之后，为过期（新增时一般不会录入过期保单）
        if (current.after(endTime)) {
            result = PolicyConstant.POLICY_STATUS_OVERDUE;
        }
        return result;
    }

    /**
     * @param savePolicyDto:
     * @author Sun
     * @description 保存保单附件列表信息
     * @date 2019/11/5 21:46
     **/
    private void savePolicyFileAuditDetail(SavePolicyDto savePolicyDto) throws Exception {
        List<FiAuditFileDto> fiAuditFileDtos = savePolicyDto.getFiAuditFileDtos();
        String belongId;
        Byte belongType;
        if (fiAuditFileDtos == null || fiAuditFileDtos.isEmpty()) {
            return;
        } else {
            belongId = fiAuditFileDtos.get(0).getBelongId();
            belongType = fiAuditFileDtos.get(0).getBelongType();
        }

        // 判断所有
        for (FiAuditFileDto fiAuditFileDto : fiAuditFileDtos) {
            if (!belongId.equals(fiAuditFileDto.getBelongId())) {
                throw new BusinessException(StatusEnum.POLICY_BELONG_ID_DIFFERENT);
            }
            if (!PlanConstant.BELONG_TYPE_POLICY.equals(fiAuditFileDto.getBelongType())) {
                throw new BusinessException(StatusEnum.POLICY_BELONG_ID_NOT_CORRECT);
            }
        }

        // 删除现有关联附件信息
        fiAuditFileRepository.deleteByBelongIdAndType(belongId, belongType);

        // Dto转换为entity
        mapperFactory.classMap(FiAuditFileDto.class, FiAuditFile.class).byDefault().register();
        List<FiAuditFile> fiAuditFiles = mapperFactory.getMapperFacade().mapAsList(fiAuditFileDtos, FiAuditFile.class);
        fiAuditFileRepository.saveAll(fiAuditFiles);
        log.info("保存保单附件列表信息success!!!");
    }


    public PolicyUncarDetail getUnCarPolicyDetail(String policyNo) {
        Optional<PolicyUncarDetail> op = policyUncarDetailRepository.findByPolicyNo(policyNo);
        if (op.isPresent()) {
            return op.get();
        }
        return null;
    }

    /**
     * @param policyNo:
     * @return com.huatonghh.plan.service.dto.policy.SavePolicyDto
     * @author Sun
     * @description 根据保单号获取保单详情
     * @date 2019/11/5 21:46
     **/
    public SavePolicyDto queryPolicyDetail(String policyNo) {
        // 定义反参
        SavePolicyDto savePolicyDto;
        SavePolicyCarDto savePolicyCarDto;
        SavePolicyUncarDto savePolicyUncarDto;

        // 获取保单基本信息
        Optional<PolicyMain> policyMainOptional = policyMainRepository.findByPolicyNo(policyNo);
        if (!policyMainOptional.isPresent()) {
            throw new BusinessException(StatusEnum.POLICY_NO_DETAIL + policyNo);
        }

        // 组装前端基本信息实体
        PolicyMain policyMain = policyMainOptional.get();
        savePolicyDto = modelMapper.map(policyMain, SavePolicyDto.class);

//        {
//            Optional<PolicyUncarDetail> byPolicyNo = policyUncarDetailRepository.findByPolicyNo(policyNo);
//            if (byPolicyNo.isPresent()) {
//                PolicyUncarDetail policyUncarDetail = byPolicyNo.get();
//                savePolicyUncarDto = modelMapper.map(policyUncarDetail, SavePolicyUncarDto.class);s
//                savePolicyDto.setSavePolicyUncarDto(savePolicyUncarDto);
//            }
//        }

        // 获取附件信息列表
        savePolicyDto.setFiAuditFileDtos(fileService.listFiAuditFileDto(policyNo, PlanConstant.BELONG_TYPE_POLICY, true));
        return savePolicyDto;
    }


    public List<ClaimHighwayPolicyDTO> allEngPolicy() {
        String sql = "SELECT \n" +
            "p.pro_id proId\n" +
            ",p.pro_name proName\n" +
            ",e.eng_type engType\n" +
            ",co.code_name engTypeName\n" +
            ",group_concat(p.policy_no) policyNos\n" +
            ",count(p.policy_no) countPolicy\n" +
            ",count(e.contract) countContract\n" +
            ",sum(p.total_premium) totalPremium \n" +
            "from policy_main p , policy_engineering e,base_code co\n" +
            "where p.insurance_category ='5'\n" +
            "and p.policy_no = e.policy_no\n" +
            "and co.type_id ='eng_type'\n" +
            "and co.code_id = e.eng_type\n" +
            "GROUP BY p.pro_id,e.eng_type";
        return dynamicQuery.nativeQueryListModel(ClaimHighwayPolicyDTO.class, sql);
    }

    /**
     * @param policy:
     * @return com.huatonghh.common.util.system.PageInfo<com.huatonghh.plan.service.dto.policy.PolicyListDto>
     * @author Sun
     * @description 保单分页列表
     * SELECT * FROM policy_main m LEFT JOIN policy_car_detail cd ON m.policy_no = cd.policy_no WHERE m.policy_no = 'string1';
     * SELECT * FROM policy_main m LEFT JOIN policy_uncar_detail ud ON m.policy_no = ud.policy_no WHERE m.policy_no = 'string2';
     * @date 2019/11/5 21:47
     **/
    public PageInfo<PolicyListDto> queryPageList(PolicyListCondition policy) {
        // 获取分页信息
        Integer pageNum = policy.getPageNum();
        Integer pageSize = policy.getPageSize();

        // 保单号
        String policyNo = policy.getPolicyNo();
        // 车或非车标识：1车、0非车，必传
        Byte carUncarFlag = policy.getCarUncarFlag();
        // 保险类别：车1、企业工程23456
        String insuranceCategory = policy.getInsuranceCategory();
        // 险种代码；例:车（交强、商业）,非车待定
        String kindCode = policy.getKindCode();
        // 所属分公司
        String startCompany = policy.getStartCompany();
        // 保险公司
        String belongCompany = policy.getBelongCompany();
        // 中标项目编号
        BigInteger projectNo = policy.getProjectNo();
        // 投保人
        String holderName = policy.getHolderName();
        // 创建、投保查询起始日期
        Date startCreateTime = policy.getStartCreateTime();
        // 创建、投保查询终止日期
        Date endCreateTime = policy.getEndCreateTime();
        // 状态
        Byte status = policy.getStatus();
        // 排序的列名称
        String column = LineToHumpTool.humpToLines(policy.getColumn());

        // 组装通用sql
        StringBuilder sql = new StringBuilder();
        processQuerySql(carUncarFlag, startCompany, startCreateTime, endCreateTime, sql);

        // 查询结果
        long total;
        List<PolicyListDto> policyCarListDtos;
        if (StringUtils.isNotBlank(startCompany)) {
            total = dynamicQuery.nativeQueryCount("select count(1) from (" + sql + ") a",
                carUncarFlag, policyNo, insuranceCategory, kindCode, belongCompany,
                projectNo, holderName, status, startCreateTime, endCreateTime,
                startCompany);
            if (policy.getRange().equals(0)) {
                sql.append(" order by m." + column + " desc limit ?12, ?13 ");
            } else {
                sql.append(" order by m." + column + " asc limit ?12, ?13 ");
            }

            policyCarListDtos = dynamicQuery.nativeQueryListModel(PolicyListDto.class, sql.toString(),
                carUncarFlag, policyNo, insuranceCategory, kindCode, belongCompany,
                projectNo, holderName, status, startCreateTime, endCreateTime,
                startCompany, (pageNum - 1) * pageSize, pageSize);
        } else {
            total = dynamicQuery.nativeQueryCount("select count(1) from (" + sql + ") a",
                carUncarFlag, policyNo, insuranceCategory, kindCode, belongCompany,
                projectNo, holderName, status, startCreateTime, endCreateTime);

            if (policy.getRange().equals(0)) {
                sql.append(" order by m." + column + " desc limit ?11, ?12 ");
            } else {
                sql.append(" order by m." + column + " asc limit ?11, ?12 ");
            }

            policyCarListDtos = dynamicQuery.nativeQueryListModel(PolicyListDto.class, sql.toString(),
                carUncarFlag, policyNo, insuranceCategory, kindCode, belongCompany,
                projectNo, holderName, status, startCreateTime, endCreateTime,
                (pageNum - 1) * pageSize, pageSize);
        }
        return PageInfo.of(pageNum, pageSize, policyCarListDtos, total);
    }


    /**
     * @param carUncarFlag:
     * @param startCompany:
     * @param startCreateTime:
     * @param endCreateTime:
     * @param sql:
     * @author Sun
     * @description 组装查询sql
     * @date 2019/11/5 21:47
     **/
    private void processQuerySql(Byte carUncarFlag, String startCompany, Date startCreateTime, Date endCreateTime, StringBuilder sql) {
        sql.append(" SELECT ");
        sql.append(" m.id as id, ");
        sql.append(" m.policy_no as policyNo, ");
        sql.append(" m.car_uncar_flag as carUncarFlag, ");
        sql.append(" m.insurance_category as insuranceCategory, ");
        sql.append(" m.kind_code as kindCode, ");
        sql.append(" m.holder_name as holderName, ");
        sql.append(" m.insured_name as insuredName, ");
        sql.append(" m.project_no as projectNo, ");
        sql.append(" m.start_company as startCompany, ");
        sql.append(" m.belong_company as belongCompany, ");
        sql.append(" m.total_premium as totalPremium, ");
        sql.append(" m.policy_bgn_time as policyBgnTime, ");
        sql.append(" m.policy_end_time as policyEndTime, ");
        sql.append(" m.create_time as createTime, ");
        sql.append(" m.belong_company_person as belongCompanyPerson, ");
        sql.append(" m.belong_company_phone as belongCompanyPhone, ");
        sql.append(" m.status as status, ");

        if (PolicyConstant.POLICY_CAR.equals(carUncarFlag)) {
            sql.append(" cd.frame_no as frameNo, ");
            sql.append(" cd.plate_no as plateNo, ");
            sql.append(" cd.engine_no as engineNo, ");
            sql.append(" cd.usage_code as usageCode, ");
            sql.append(" cd.vehicle_model as vehicleModel, ");
            sql.append(" cd.owner_name as ownerName, ");
            sql.append(" cd.vehicle_vessel_tax as vehicleVesselTax, ");
            sql.append(" cd.ncd_coef as ncdCoef, ");
            sql.append(" cd.auto_underwriting_coef as autoUnderwritingCoef ");
            sql.append(" FROM policy_main m LEFT JOIN policy_car_detail cd ");
            sql.append(" ON m.policy_no = cd.policy_no ");
        } else {
            sql.append(" ud.main_risk_duty as mainRiskDuty, ");
            sql.append(" ud.total_amount as totalAmount, ");
            sql.append(" ud.fee_prop as feeProp, ");
            sql.append(" ud.issue_date as issueDate, ");
            sql.append(" ud.coinsurance_detail as coinsuranceDetail, ");
            sql.append(" ud.paid_in_date as paidInDate, ");
            sql.append(" ud.payment_type as paymentType, ");
            sql.append(" ud.subordinate_bid as subordinateBid, ");
            sql.append(" ud.engineering_name as engineeringName, ");
            sql.append(" ud.guaranty_period as guarantyPeriod ");
            sql.append(" FROM policy_main m LEFT JOIN policy_uncar_detail ud ");
            sql.append(" ON m.policy_no = ud.policy_no ");
        }

        if (StringUtils.isNotBlank(startCompany)) {
            sql.append(" , ei_depart d1, ei_depart d2 ");
        }

        sql.append(" WHERE ");
        sql.append(" IF (?1 is not NULL, m.car_uncar_flag = ?1, 0 = 0) ");
        sql.append(" AND IF (?2 != '', m.policy_no = ?2, 0 = 0) ");
        sql.append(" AND IF (?3 != '', m.insurance_category = ?3, 0 = 0) ");
        sql.append(" AND IF (?4 != '', m.kind_code = ?4, 0 = 0) ");
        sql.append(" AND IF (?5 != '', m.belong_company = ?5, 0 = 0) ");
        sql.append(" AND IF (?6 != '', m.project_no = ?6, 0 = 0) ");
        sql.append(" AND IF (?7 != '', m.holder_name = ?7, 0 = 0) ");
        sql.append(" AND IF (?8 is not NULL, m.status = ?8, 0 = 0) ");
        if (startCreateTime != null && endCreateTime != null) {
            sql.append(" AND m.create_time BETWEEN ?9 AND ?10 ");
        } else {
            sql.append(" AND IF (?9 != '', m.create_time >= ?9, 0 = 0) ");
            sql.append(" AND IF (?10 != '', m.create_time < ?10, 0 = 0) ");
        }

        if (StringUtils.isNotBlank(startCompany)) {
            sql.append(" AND d1.id = m.start_company ");
            sql.append(" AND d2.id = ?11 ");
            sql.append(" AND d1.ids LIKE CONCAT(d2.ids,'%') ");
        }
    }

    private PolicyMain checkPolicyExist(String policyNo) {
        Optional<PolicyMain> op = policyMainRepository.findByPolicyNo(policyNo);
        if (op.isPresent()) {
            return op.get();
        }
        throw new BusinessException("保单不存在");
    }

    /**
     * 退保、注销确认
     *
     * @param policyNo 保单号
     */
    public void returnConfirm(String policyNo) {
        PolicyMain policyMain = checkPolicyExist(policyNo);
        String option = "";
        String remindContent = "";
        if (PolicyConstant.POLICY_CAR.equals(policyMain.getCarUncarFlag())) {
            remindContent = BaseConstant.REMIND_EI_RETURN_CAR;
        } else {
            remindContent = BaseConstant.REMIND_EI_RETURN_UN_CAR;
        }

        if (PolicyConstant.POLICY_STATUS_RETURN_BEFORE.equals(policyMain.getStatus())) {
            policyMain.setStatus(PolicyConstant.POLICY_STATUS_RETURN);
            option = "退保";
        }
        if (PolicyConstant.POLICY_STATUS_CANCEL_BEFORE.equals(policyMain.getStatus())) {
            policyMain.setStatus(PolicyConstant.POLICY_STATUS_CANCEL);
            option = "注销";
        }
        policyMain.setUpdateTime(DateUtil.date());
        policyMainRepository.save(policyMain);

        List<String> users = getEiUserByPolicy(policyMain);
        if (null == users || users.isEmpty()) {
            return;
        }
        baseRemindService.returnPolicy(policyMain.getPolicyNo(), option, users, remindContent, BaseConstant.REMIND_TYPE_POLICY);
    }

    public void returnCancel(PolicyReturnDTO returnDTO) {
        PolicyMain policyMain = checkPolicyExist(returnDTO.getPolicyNo());
        String option = "";
        String remindContent = "";
        if (PolicyConstant.POLICY_CAR.equals(policyMain.getCarUncarFlag())) {
            remindContent = BaseConstant.REMIND_INS_RETURN_CANCEL_CAR;
        } else {
            remindContent = BaseConstant.REMIND_INS_RETURN_CANCEL_UN_CAR;
        }
        if (PolicyConstant.POLICY_STATUS_RETURN_BEFORE.equals(policyMain.getStatus())) {
            option = "退保";
            policyMain.setStatus(PolicyConstant.POLICY_STATUS_VALID);
        }
        if (PolicyConstant.POLICY_STATUS_CANCEL_BEFORE.equals(policyMain.getStatus())) {
            option = "注销";
            policyMain.setStatus(PolicyConstant.POLICY_STATUS_VALID);
        }
        policyMain.setUpdateTime(DateUtil.date());
        policyMainRepository.save(policyMain);
        List<String> users = getInsUserByPolicy(policyMain);
        if (null == users || users.isEmpty()) {
            return;
        }
        // 取消退保、注销提醒
        baseRemindService.returnPolicy(policyMain.getPolicyNo(), option, users, remindContent, BaseConstant.REMIND_TYPE_POLICY);
    }

    public void returnApply(PolicyReturnDTO returnDTO) {
        PolicyMain policyMain = checkPolicyExist(returnDTO.getPolicyNo());
        String option = "";
        String remindContent = "";
        if (PolicyConstant.POLICY_CAR.equals(policyMain.getCarUncarFlag())) {
            remindContent = BaseConstant.REMIND_INS_RETURN_CAR;
        } else {
            remindContent = BaseConstant.REMIND_INS_RETURN_UN_CAR;
        }
        // 退保
        if (PolicyConstant.POLICY_RETURN.equals(returnDTO.getOption())) {
            policyMain.setStatus(PolicyConstant.POLICY_STATUS_RETURN_BEFORE);
            option = "退保";
        }
        // 注销
        if (PolicyConstant.POLICY_CANCEL.equals(returnDTO.getOption())) {
            policyMain.setStatus(PolicyConstant.POLICY_STATUS_CANCEL_BEFORE);
            option = "注销";
        }
        policyMain.setUpdateTime(DateUtil.date());
        policyMainRepository.save(policyMain);
        List<String> users = getInsUserByPolicy(policyMain);
        if (null == users || users.isEmpty()) {
            return;
        }
        // 退保申请提醒
        baseRemindService.returnPolicy(policyMain.getPolicyNo(), option, users, remindContent, BaseConstant.REMIND_TYPE_POLICY);

    }

    public List<String> getEiUserByPolicy(PolicyMain policy) {
        String startCompany = policy.getStartCompany();
        if (StringUtils.isBlank(startCompany)) {
            return null;
        }
        List<EiUserDto> userDtos = eiUserService.queryDepartLowerUserList(startCompany);
        if (null == userDtos || userDtos.isEmpty()) {
            return null;
        }
        return userDtos.stream().map(EiUserDto::getUserName).collect(Collectors.toList());
    }


    public List<String> getInsUserByPolicy(PolicyMain policy) {
        String belong = policy.getBelongCompany();
        if (StringUtils.isBlank(belong)) {
            return null;
        }
        List<EiInsUserDto> userDtos = insUserService.queryDepartLowerUserList(Integer.valueOf(belong));
        if (null == userDtos || userDtos.isEmpty()) {
            return null;
        }
        return userDtos.stream().map(EiInsUserDto::getUserName).collect(Collectors.toList());
    }

    /**
     * @param jointCar:
     * @author Sun
     * @description 车险新增保单
     * @date 2019/11/5 21:47
     **/
    @Transactional(rollbackFor = RuntimeException.class)
    public void saveJointCarPolicyDto(SaveJointCarPolicyDto jointCar) {
        // 交强险种信息
        if (jointCar.isJq()) {
            // todo 交强险,如果是录入生效保单，则需要判断是否已经有生效的保单

            SavePolicyDto jqPolicy = new SavePolicyDto();
            SavePolicyCarDto jqPolicyCar = new SavePolicyCarDto();
            processCommonCarPolicy(jointCar, jqPolicy, jqPolicyCar);

            // 依次同步附件中的保单号
            List<FiAuditFileDto> fiAuditFileDtos = jqPolicy.getFiAuditFileDtos();
            if (null != fiAuditFileDtos && !fiAuditFileDtos.isEmpty()) {
                fiAuditFileDtos = fiAuditFileDtos.stream().peek(fiAuditFileDto -> fiAuditFileDto.setBelongId(jointCar.getJqPolicyNo())).collect(Collectors.toList());
                jqPolicy.setFiAuditFileDtos(fiAuditFileDtos);
            }

            // 加工交强特有信息
            jqPolicy.setKindCode(PolicyConstant.KIND_JQ);
            jqPolicy.setPolicyNo(jointCar.getJqPolicyNo());
            jqPolicyCar.setPolicyNo(jointCar.getJqPolicyNo());
            jqPolicy.setPolicyBgnTime(jointCar.getJqPolicyBgnTime());
            jqPolicy.setPolicyEndTime(jointCar.getJqPolicyEndTime());
            jqPolicy.setTotalPremium(jointCar.getJqTotalPremium());
            jqPolicy.setFreeTaxPremium(jointCar.getJqFreeTaxPremium());
            jqPolicy.setHandlingFee(jointCar.getJqHandlingFee());
            jqPolicyCar.setFeeProp(jointCar.getJqFeeProp());
            jqPolicyCar.setVehicleVesselTax(jointCar.getJqVehicleVesselTax());
            jqPolicy.setSavePolicyCarDto(jqPolicyCar);
            savePolicy(jqPolicy, 1);
        }

        // 商业险种信息
        if (jointCar.isSy()) {
            SavePolicyDto syPolicy = new SavePolicyDto();
            SavePolicyCarDto syPolicyCar = new SavePolicyCarDto();
            processCommonCarPolicy(jointCar, syPolicy, syPolicyCar);

            // 依次同步附件中的保单号
            List<FiAuditFileDto> fiAuditFileDtos = syPolicy.getFiAuditFileDtos();
            if (null != fiAuditFileDtos && !fiAuditFileDtos.isEmpty()) {
                fiAuditFileDtos = fiAuditFileDtos.stream().peek(fiAuditFileDto -> fiAuditFileDto.setBelongId(jointCar.getSyPolicyNo())).collect(Collectors.toList());
                syPolicy.setFiAuditFileDtos(fiAuditFileDtos);
            }

            // 加工商业特有信息
            syPolicy.setKindCode(PolicyConstant.KIND_SY);
            syPolicy.setPolicyNo(jointCar.getSyPolicyNo());
            syPolicyCar.setPolicyNo(jointCar.getSyPolicyNo());
            syPolicy.setPolicyBgnTime(jointCar.getSyPolicyBgnTime());
            syPolicy.setPolicyEndTime(jointCar.getSyPolicyEndTime());
            syPolicy.setTotalPremium(jointCar.getSyTotalPremium());
            syPolicy.setFreeTaxPremium(jointCar.getSyFreeTaxPremium());
            syPolicy.setHandlingFee(jointCar.getSyHandlingFee());
            syPolicyCar.setFeeProp(jointCar.getSyFeeProp());
            syPolicyCar.setNcdCoef(jointCar.getSyNcdCoef());
            syPolicyCar.setAutoUnderwritingCoef(jointCar.getSyAutoUnderwritingCoef());
            syPolicy.setSavePolicyCarDto(syPolicyCar);
            syPolicyCar.setPolicyVehRiskPlanDtoList(jointCar.getPolicyVehRiskPlanDtoList());
            savePolicy(syPolicy, 1);
        }


        // 货运险险种信息
        if (jointCar.isHw()) {
            SavePolicyDto hwPolicy = new SavePolicyDto();
            SavePolicyCarDto hwPolicyCar = new SavePolicyCarDto();
            processCommonCarPolicy(jointCar, hwPolicy, hwPolicyCar);

            // 依次同步附件中的保单号
            List<FiAuditFileDto> fiAuditFileDtos = hwPolicy.getFiAuditFileDtos();
            if (null != fiAuditFileDtos && !fiAuditFileDtos.isEmpty()) {
                fiAuditFileDtos = fiAuditFileDtos.stream().peek(fiAuditFileDto -> fiAuditFileDto.setBelongId(jointCar.getHwPolicyNo())).collect(Collectors.toList());
                hwPolicy.setFiAuditFileDtos(fiAuditFileDtos);
            }
            // 加工货运险特有信息
            hwPolicy.setKindCode(PolicyConstant.KIND_HW);
            hwPolicy.setPolicyNo(jointCar.getHwPolicyNo());
            hwPolicyCar.setPolicyNo(jointCar.getHwPolicyNo());
            hwPolicy.setPolicyBgnTime(jointCar.getHwPolicyBgnTime());
            hwPolicy.setPolicyEndTime(jointCar.getHwPolicyEndTime());
            hwPolicy.setTotalPremium(jointCar.getHwTotalPremium());
            hwPolicy.setFreeTaxPremium(jointCar.getHwFreeTaxPremium());
            hwPolicy.setHandlingFee(jointCar.getHwHandlingFee());
            // 手续费比例
            hwPolicyCar.setFeeProp(jointCar.getHwFeeProp());
            hwPolicy.setSavePolicyCarDto(hwPolicyCar);
            savePolicy(hwPolicy, 1);
        }
    }


    /**
     * @param jointCar:
     * @param policy:
     * @param policyCar:
     * @author Sun
     * @description 组装通用信息
     * @date 2019/11/5 21:47
     **/
    private void processCommonCarPolicy(@RequestBody @Valid SaveJointCarPolicyDto jointCar, SavePolicyDto policy, SavePolicyCarDto policyCar) {
        // 组装必要信息
        policy.setCarUncarFlag(jointCar.getCarUncarFlag());
        policy.setInsuranceCategory(jointCar.getInsuranceCategory());

        // 组装项目信息
        policy.setProjectNo(jointCar.getProjectNo());
        policy.setStartCompany(jointCar.getStartCompany());
        policy.setBelongCompany(jointCar.getBelongCompany());
        policy.setBelongCompanyPerson(jointCar.getBelongCompanyPerson());
        policy.setBelongCompanyPhone(jointCar.getBelongCompanyPhone());

        // 组装基本信息
        policy.setHolderName(jointCar.getHolderName());
        policy.setInsuredName(jointCar.getInsuredName());
        policyCar.setFrameNo(jointCar.getFrameNo());
        policyCar.setPlateNo(jointCar.getPlateNo());
        policyCar.setEngineNo(jointCar.getEngineNo());
        policyCar.setUsageCode(jointCar.getUsageCode());
        policyCar.setVehicleModel(jointCar.getVehicleModel());
        policyCar.setOwnerName(jointCar.getOwnerName());

        // 附件信息
        List<FiAuditFileDto> fiAuditFileDtos = jointCar.getFiAuditFileDtos();
        policy.setFiAuditFileDtos(fiAuditFileDtos);
    }

    public StringBuilder processMobileQuerySql(Byte type) {
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT ");
        sql.append(" pm.id as id, ");
        sql.append(" pm.policy_no as policyNo, ");
        sql.append(" pm.car_uncar_flag as carUncarFlag, ");
        sql.append(" pm.insurance_category as insuranceCategory, ");
        sql.append(" pm.kind_code as kindCode, ");
        sql.append(" pm.policy_bgn_time as policyBgnTime, ");
        sql.append(" pm.policy_end_time as policyEndTime, ");
        sql.append(" pm.status as status, ");
        if (PolicyConstant.POLICY_CAR.equals(type)) {
            sql.append(" pcd.plate_no as plateNo ");
            sql.append(" FROM policy_main pm LEFT JOIN policy_car_detail pcd ");
            sql.append(" ON pm.policy_no = pcd.policy_no ");
        } else {
            sql.append(" pud.main_risk_duty as mainRiskDuty ");
            sql.append(" FROM policy_main pm LEFT JOIN policy_uncar_detail pud ");
            sql.append(" ON pm.policy_no = pud.policy_no ");
        }
        sql.append(" , ei_depart d1, ei_depart d2 ");
        // 加工WHERE条件
        sql.append(StrUtil.format(" WHERE pm.car_uncar_flag = {} ", type));
        sql.append(" AND d1.id = pm.start_company ");
        sql.append(StrUtil.format(" AND d2.id = '{}' ", userClient.getCurrentGroupCompany().getId()));
        sql.append(" AND d1.ids LIKE CONCAT(d2.ids,'%') ");
        sql.append(" order by pm.current_timestamp desc");
        return sql;
    }

    /**
     * @param policy: 保单列表查询条件
     * @return com.huatonghh.common.util.system.PageInfo<com.huatonghh.plan.service.dto.policy.PolicyListDto>
     * @author Sun
     * @description v2保单列表
     * @date 2019/11/5 10:50
     **/
    public StringBuilder processQuerySql(PolicyListCondition policy) {

        //排序的列名称
        String column = LineToHumpTool.humpToLines(policy.getColumn());
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT ");
        sql.append(" pm.id as id, ");
        sql.append(" pm.policy_no as policyNo, ");
        sql.append(" pm.car_uncar_flag as carUncarFlag, ");
        sql.append(" pm.insurance_category as insuranceCategory, ");
        sql.append(" pm.kind_code as kindCode, ");
        sql.append(" pm.project_name as projectName, ");
        sql.append(" pm.holder_name as holderName, ");
        sql.append(" pm.insured_name as insuredName, ");
        sql.append(" pm.policy_bgn_time as policyBgnTime, ");
        sql.append(" pm.policy_end_time as policyEndTime, ");
        sql.append(" pm.total_premium as totalPremium, ");
        sql.append(" pm.start_company as startCompany, ");
        sql.append(" pm.belong_company as belongCompany, ");
        sql.append(" pm.status as status, ");


        if (CollectionUtils.isNotEmpty(policy.getIds())) {
            sql.append(" pud.main_risk_duty as mainRiskDuty ");
            sql.append(" FROM policy_main pm LEFT JOIN policy_uncar_detail pud ");
            sql.append(" ON pm.policy_no = pud.policy_no ");
            sql.append("where pm.id in (");
            sql.append(StringUtils.join(policy.getIds(), ","));
            sql.append(")");
        } else {
            // 获取车、非车特有列表字段
            if (PolicyConstant.POLICY_CAR.equals(policy.getCarUncarFlag())) {
                sql.append(" pcd.frame_no as frameNo, ");
                sql.append(" pcd.plate_no as plateNo ");
                sql.append(" FROM policy_main pm LEFT JOIN policy_car_detail pcd ");
                sql.append(" ON pm.policy_no = pcd.policy_no ");
            } else if (PolicyConstant.POLICY_CAR_UN.equals(policy.getCarUncarFlag())) {
                sql.append(" pud.main_risk_duty as mainRiskDuty ");
                sql.append(" FROM policy_main pm LEFT JOIN policy_uncar_detail pud ");
                sql.append(" ON pm.policy_no = pud.policy_no ");
            }

//            // 发起公司不为空，就要查询当前公司及其所有子公司列表
//            if (StringUtils.isNotBlank(policy.getStartCompany())) {
//                sql.append(" , ei_depart d1, ei_depart d2 ");
//            }

            // 加工WHERE条件
            sql.append(StrUtil.format(" WHERE pm.car_uncar_flag = {} ", policy.getCarUncarFlag()));
            if (StringUtils.isNotBlank(policy.getPolicyNo())) {
                sql.append(StrUtil.format(" AND pm.policy_no like '{}' ", "%"+policy.getPolicyNo()+"%"));
            }
            if (StringUtils.isNotBlank(policy.getInsuranceCategory())) {
                sql.append(StrUtil.format(" AND pm.insurance_category = '{}' ", policy.getInsuranceCategory()));
            }
            if (StringUtils.isNotBlank(policy.getKindCode())) {
                sql.append(StrUtil.format(" AND pm.kind_code = '{}' ", policy.getKindCode()));
            }
            if (StringUtils.isNotBlank(policy.getBelongCompany())) {
                sql.append(StrUtil.format(" AND pm.belong_company = '{}' ", policy.getBelongCompany()));
            }
            if (policy.getProjectNo() != null) {
                sql.append(StrUtil.format(" AND pm.project_no = {} ", policy.getProjectNo()));
            }
            if (StringUtils.isNotBlank(policy.getHolderName())) {
                sql.append(StrUtil.format(" AND pm.holder_name like '{}' ", "%"+policy.getHolderName()+"%"));
            }
            if (policy.getStatus() != null) {
                sql.append(StrUtil.format(" AND pm.status = {} ", policy.getStatus()));
            }
            // 保险起期
            if (policy.getStartBgnTime() != null) {
                sql.append(StrUtil.format(" AND pm.policy_bgn_time >= '{}' ", DateFormatUtil.dateToStr(policy.getStartBgnTime(), "yyyy-MM-dd HH:mm:ss")));
            }
            if (policy.getEndBgnTime() != null) {
                sql.append(StrUtil.format(" AND pm.policy_bgn_time <= '{}' ", DateFormatUtil.dateToStr(policy.getEndBgnTime(), "yyyy-MM-dd HH:mm:ss")));
            }
//            if (StringUtils.isNotBlank(policy.getStartCompany())) {
//                sql.append(" AND d1.id = pm.start_company ");
//                sql.append(StrUtil.format(" AND d2.id = '{}' ", policy.getStartCompany()));
//                sql.append(" AND d1.ids LIKE CONCAT(d2.ids,'%') ");
//            }
            // 默认逆序
            String descType = "desc";
            if (policy.getRange().equals(1)) {
                descType = "asc";
            }
            if (PolicyConstant.POLICY_CAR.equals(policy.getCarUncarFlag())) {
                if (PlanConstant.COLUMN_CURRENT.equals(column)) {
                    sql.append(" order by pm." + column + " " + descType);
                } else if (ClassUtils.containsField(new PolicyMain(), policy.getColumn())) {
                    sql.append(" order by pm." + column + " " + descType);
                } else if (ClassUtils.containsField(new PolicyCarDetail(), policy.getColumn())) {
                    sql.append(" order by pcd." + column + " " + descType);
                }
            } else if (PolicyConstant.POLICY_CAR_UN.equals(policy.getCarUncarFlag())) {
                if (PlanConstant.COLUMN_CURRENT.equals(column)) {
                    sql.append(" order by pm." + column + " " + descType);
                } else if (ClassUtils.containsField(new PolicyMain(), policy.getColumn())) {
                    sql.append(" order by pm." + column + " " + descType);
                } else if (ClassUtils.containsField(new PolicyUncarDetail(), policy.getColumn())) {
                    sql.append(" order by pud." + column + " " + descType);
                }
            }
        }

        return sql;
    }

    /**
     * @param policy: 保单列表查询条件
     * @return com.huatonghh.common.util.system.PageInfo<com.huatonghh.plan.service.dto.policy.PolicyListDto>
     * @author Sun
     * @description v2保单列表
     * @date 2019/11/5 10:50
     **/
    public StringBuilder processQueryRenewSql(PolicyListCondition policy) {

        //排序的列名称
        String column = LineToHumpTool.humpToLines(policy.getColumn());
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT ");
        sql.append(" pm.id as id, ");
        sql.append(" pm.policy_no as policyNo, ");
        sql.append(" pm.car_uncar_flag as carUncarFlag, ");
        sql.append(" pm.project_name as projectName, ");
        sql.append(" pm.insurance_category as insuranceCategory, ");
        sql.append(" pm.kind_code as kindCode, ");
        sql.append(" pm.holder_name as holderName, ");
        sql.append(" pm.insured_name as insuredName, ");
        sql.append(" pm.policy_bgn_time as policyBgnTime, ");
        sql.append(" pm.policy_end_time as policyEndTime, ");
        sql.append(" pm.total_premium as totalPremium, ");
        sql.append(" pm.start_company as startCompany, ");
        sql.append(" pm.belong_company as belongCompany, ");
        sql.append(" pm.belong_company_name as belongCompanyName, ");
        sql.append(" pm.status as status, ");
        sql.append(" pm.expiration_days as expirationDays, ");
        sql.append(" pm.renew_status as renewStatus, ");


        if (CollectionUtils.isNotEmpty(policy.getIds())) {
            sql.append(" pud.main_risk_duty as mainRiskDuty ");
            sql.append(" FROM policy_main pm LEFT JOIN policy_uncar_detail pud ");
            sql.append(" ON pm.policy_no = pud.policy_no ");
            sql.append("where pm.id in (");
            sql.append(StringUtils.join(policy.getIds(), ","));
            sql.append(")");
        } else {
            // 获取车、非车特有列表字段
            if (PolicyConstant.POLICY_CAR.equals(policy.getCarUncarFlag())) {
                sql.append(" pcd.frame_no as frameNo, ");
                sql.append(" pcd.plate_no as plateNo ");
                sql.append(" FROM policy_main pm LEFT JOIN policy_car_detail pcd ");
                sql.append(" ON pm.policy_no = pcd.policy_no ");
            } else if (PolicyConstant.POLICY_CAR_UN.equals(policy.getCarUncarFlag())) {
                sql.append(" pud.main_risk_duty as mainRiskDuty ");
                sql.append(" FROM policy_main pm LEFT JOIN policy_uncar_detail pud ");
                sql.append(" ON pm.policy_no = pud.policy_no ");
            }

            // 发起公司不为空，就要查询当前公司及其所有子公司列表
//            if (StringUtils.isNotBlank(policy.getStartCompany())) {
//                sql.append(" , ei_depart d1, ei_depart d2 ");
//            }

            // 加工WHERE条件
            sql.append(StrUtil.format(" WHERE pm.car_uncar_flag = {} ", policy.getCarUncarFlag()));
            if (StringUtils.isNotBlank(policy.getPolicyNo())) {
                sql.append(StrUtil.format(" AND pm.policy_no like '{}' ", "%"+policy.getPolicyNo()+"%"));
            }
            if (StringUtils.isNotBlank(policy.getHolderName())) {
                sql.append(StrUtil.format(" AND pm.holder_name like '{}' ", "%"+policy.getHolderName()+"%"));
            }
            if (StringUtils.isNotBlank(policy.getBelongCompany())) {
                sql.append(StrUtil.format(" AND pm.belong_company = '{}' ", policy.getBelongCompany()));
            }
            if (policy.getRenewStatus() != null) {
                sql.append(StrUtil.format(" AND pm.renew_status = {} ", policy.getRenewStatus()));
            }
            if (policy.getExpirationDays() != null) {
                sql.append(StrUtil.format(" AND pm.expiration_days <= {} ", policy.getExpirationDays()));
            }
            if (StringUtils.isNotBlank(policy.getKindCode())) {
                sql.append(StrUtil.format(" AND pm.kind_code = '{}' ", policy.getKindCode()));
            }
//            if (StringUtils.isNotBlank(policy.getStartCompany())) {
//                sql.append(" AND d1.id = pm.start_company ");
//                sql.append(StrUtil.format(" AND d2.id = '{}' ", policy.getStartCompany()));
//                sql.append(" AND d1.ids LIKE CONCAT(d2.ids,'%') ");
//            }
            if (policy.getRenewStatus() == null) {
                sql.append(" AND pm.renew_status is not null");
            } else if (policy.getRenewStatus() == 1) {
                //已续保
                sql.append(" AND pm.renew_status = 1");
            } else {
                //未续保
                sql.append(" AND pm.renew_status = 0");
            }
            // 默认逆序
            String descType = "desc";
            if (policy.getRange().equals(1)) {
                descType = "asc";
            }
            if (PolicyConstant.POLICY_CAR.equals(policy.getCarUncarFlag())) {
                if (PlanConstant.COLUMN_CURRENT.equals(column)) {
                    sql.append(" order by pm." + column + " " + descType);
                } else if (ClassUtils.containsField(new PolicyMain(), policy.getColumn())) {
                    sql.append(" order by pm." + column + " " + descType);
                } else if (ClassUtils.containsField(new PolicyCarDetail(), policy.getColumn())) {
                    sql.append(" order by pcd." + column + " " + descType);
                }
            } else if (PolicyConstant.POLICY_CAR_UN.equals(policy.getCarUncarFlag())) {
                if (PlanConstant.COLUMN_CURRENT.equals(column)) {
                    sql.append(" order by pm." + column + " " + descType);
                } else if (ClassUtils.containsField(new PolicyMain(), policy.getColumn())) {
                    sql.append(" order by pm." + column + " " + descType);
                } else if (ClassUtils.containsField(new PolicyUncarDetail(), policy.getColumn())) {
                    sql.append(" order by pud." + column + " " + descType);
                }
            }
        }

        return sql;
    }


    /**
     * 查询sql 增加公司名称
     *
     * @param policy 查询参数
     * @return sql
     */
    public StringBuilder processQuerySqlWithCompany(PolicyListCondition policy) {

        //排序的列名称
        String column = LineToHumpTool.humpToLines(policy.getColumn());
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT ");
        sql.append(" pm.id as id, ");
        sql.append(" pm.policy_no as policyNo, ");
        sql.append(" pm.car_uncar_flag as carUncarFlag, ");
        sql.append(" pm.insurance_category as insuranceCategory, ");
        sql.append(" pm.kind_code as kindCode, ");
        sql.append(" pm.project_name as projectName, ");
        sql.append(" pm.holder_name as holderName, ");
        sql.append(" pm.insured_name as insuredName, ");
        sql.append(" pm.policy_bgn_time as policyBgnTime, ");
        sql.append(" pm.policy_end_time as policyEndTime, ");
        sql.append(" pm.total_premium as totalPremium, ");
        sql.append(" t1.name as startCompany, ");
        sql.append(" pm.belong_company_name as belongCompany, ");
        sql.append(" pm.status as status, ");
        // 获取车、非车特有列表字段
        if (PolicyConstant.POLICY_CAR.equals(policy.getCarUncarFlag())) {
            sql.append(" pcd.frame_no as frameNo, ");
            sql.append(" pcd.plate_no as plateNo ");
            sql.append(" FROM policy_main pm LEFT JOIN policy_car_detail pcd ");
            sql.append(" ON pm.policy_no = pcd.policy_no ");
        } else if (PolicyConstant.POLICY_CAR_UN.equals(policy.getCarUncarFlag())) {
            sql.append(" pud.main_risk_duty as mainRiskDuty ");
            sql.append(" FROM policy_main pm LEFT JOIN policy_uncar_detail pud ");
            sql.append(" ON pm.policy_no = pud.policy_no ");
            sql.append(" left join ei_depart t1 ");
            sql.append(" on pm.start_company = t1.id ");
        }

//        // 发起公司不为空，就要查询当前公司及其所有子公司列表
//        if (StringUtils.isNotBlank(policy.getStartCompany())) {
//            sql.append(" , ei_depart d1, ei_depart d2 ");
//        }
        if (CollectionUtils.isNotEmpty(policy.getIds())) {
            sql.append("where pm.id in (");
            sql.append(StringUtils.join(policy.getIds(), ","));
            sql.append(")");
        } else {
            // 加工WHERE条件
            sql.append(StrUtil.format(" WHERE pm.car_uncar_flag = {} ", policy.getCarUncarFlag()));
            if (StringUtils.isNotBlank(policy.getPolicyNo())) {
                sql.append(StrUtil.format(" AND pm.policy_no = '{}' ", policy.getPolicyNo()));
            }
            if (StringUtils.isNotBlank(policy.getInsuranceCategory())) {
                sql.append(StrUtil.format(" AND pm.insurance_category = '{}' ", policy.getInsuranceCategory()));
            }
            if (StringUtils.isNotBlank(policy.getKindCode())) {
                sql.append(StrUtil.format(" AND pm.kind_code = '{}' ", policy.getKindCode()));
            }
            if (StringUtils.isNotBlank(policy.getBelongCompany())) {
                sql.append(StrUtil.format(" AND pm.belong_company = '{}' ", policy.getBelongCompany()));
            }
            if (policy.getProjectNo() != null) {
                sql.append(StrUtil.format(" AND pm.project_no = {} ", policy.getProjectNo()));
            }
            if (StringUtils.isNotBlank(policy.getHolderName())) {
                sql.append(StrUtil.format(" AND pm.holder_name = '{}' ", policy.getHolderName()));
            }
            if (policy.getStatus() != null) {
                sql.append(StrUtil.format(" AND pm.status = {} ", policy.getStatus()));
            }
            // 保险起期
            if (policy.getStartBgnTime() != null) {
                sql.append(StrUtil.format(" AND pm.policy_bgn_time >= '{}' ", DateFormatUtil.dateToStr(policy.getStartBgnTime(), "yyyy-MM-dd HH:mm:ss")));
            }
            if (policy.getEndBgnTime() != null) {
                sql.append(StrUtil.format(" AND pm.policy_bgn_time <= '{}' ", DateFormatUtil.dateToStr(policy.getEndBgnTime(), "yyyy-MM-dd HH:mm:ss")));
            }
//            if (StringUtils.isNotBlank(policy.getStartCompany())) {
//                sql.append(" AND d1.id = pm.start_company ");
//                sql.append(StrUtil.format(" AND d2.id = '{}' ", policy.getStartCompany()));
//                sql.append(" AND d1.ids LIKE CONCAT(d2.ids,'%') ");
//            }
        }
        // 默认逆序
        String descType = "desc";
        if (policy.getRange().equals(1)) {
            descType = "asc";
        }
        if (PolicyConstant.POLICY_CAR.equals(policy.getCarUncarFlag())) {
            if (PlanConstant.COLUMN_CURRENT.equals(column)) {
                sql.append(" order by pm." + column + " " + descType);
            } else if (ClassUtils.containsField(new PolicyMain(), policy.getColumn())) {
                sql.append(" order by pm." + column + " " + descType);
            } else if (ClassUtils.containsField(new PolicyCarDetail(), policy.getColumn())) {
                sql.append(" order by pcd." + column + " " + descType);
            }
        } else if (PolicyConstant.POLICY_CAR_UN.equals(policy.getCarUncarFlag())) {
            if (PlanConstant.COLUMN_CURRENT.equals(column)) {
                sql.append(" order by pm." + column + " " + descType);
            } else if (ClassUtils.containsField(new PolicyMain(), policy.getColumn())) {
                sql.append(" order by pm." + column + " " + descType);
            } else if (ClassUtils.containsField(new PolicyUncarDetail(), policy.getColumn())) {
                sql.append(" order by pud." + column + " " + descType);
            }
        }
        return sql;
    }

    private void getPolicyFromSql(StringBuilder sql, PolicyListCondition condition) {
        sql.append(" FROM policy_main pm ");
        // 发起公司不为空，就要查询当前公司及其所有子公司列表
        if (StringUtils.isNotBlank(condition.getStartCompany())) {
            sql.append(" , ei_depart d1, ei_depart d2 ");
        }
    }

    private void getPolicyCondition(StringBuilder sql, PolicyListCondition policy) {
        sql.append("where 1=1 ");
        if (StringUtils.isNotBlank(policy.getPolicyNo())) {
            sql.append(StrUtil.format(" AND pm.policy_no = '{}' ", policy.getPolicyNo()));
        }
        if (StringUtils.isNotBlank(policy.getInsuranceCategory())) {
            sql.append(StrUtil.format(" AND pm.insurance_category = '{}' ", policy.getInsuranceCategory()));
        }
        if (StringUtils.isNotBlank(policy.getKindCode())) {
            sql.append(StrUtil.format(" AND pm.kind_code = '{}' ", policy.getKindCode()));
        }
        if (StringUtils.isNotBlank(policy.getBelongCompany())) {
            sql.append(StrUtil.format(" AND pm.belong_company = '{}' ", policy.getBelongCompany()));
        }
        if (policy.getProjectNo() != null) {
            sql.append(StrUtil.format(" AND pm.project_no = {} ", policy.getProjectNo()));
        }
        if (StringUtils.isNotBlank(policy.getHolderName())) {
            sql.append(StrUtil.format(" AND pm.holder_name = '{}' ", policy.getHolderName()));
        }
        if (policy.getStatus() != null) {
            sql.append(StrUtil.format(" AND pm.status = {} ", policy.getStatus()));
        }
        // 保险起期
        if (policy.getStartBgnTime() != null && policy.getEndBgnTime() != null) {
            sql.append(StrUtil.format(" AND pm.policy_bgn_time BETWEEN '{}' AND '{}' ", DateFormatUtil.dateToStr(policy.getStartBgnTime(), "yyyy-MM-dd HH:mm:ss"), DateFormatUtil.dateToStr(policy.getEndBgnTime(), "yyyy-MM-dd HH:mm:ss")));
        }
        if (StringUtils.isNotBlank(policy.getStartCompany())) {
            sql.append(" AND d1.id = pm.start_company ");
            sql.append(StrUtil.format(" AND d2.id = '{}' ", policy.getStartCompany()));
            sql.append(" AND d1.ids LIKE CONCAT(d2.ids,'%') ");
        }
    }

    private StringBuilder getBasePolicyField() {
        StringBuilder sql = new StringBuilder();
        sql.append(" SELECT ");
        sql.append(" pm.id as id, ");
        sql.append(" pm.policy_no as policyNo, ");
        sql.append(" pm.car_uncar_flag as carUncarFlag, ");
        sql.append(" pm.insurance_category as insuranceCategory, ");
        sql.append(" pm.kind_code as kindCode, ");
        sql.append(" pm.holder_name as holderName, ");
        sql.append(" pm.insured_name as insuredName, ");
        sql.append(" pm.policy_bgn_time as policyBgnTime, ");
        sql.append(" pm.policy_end_time as policyEndTime, ");
        sql.append(" pm.total_premium as totalPremium, ");
        sql.append(" pm.start_company as startCompany, ");
        sql.append(" pm.belong_company as belongCompany, ");
        sql.append(" pm.status as status ");

        sql.append(" ,pm.policy_apply_time as policyApplyTime ");
        sql.append(" ,pm.free_tax_premium as freeTaxPremium ");
        sql.append(" ,pm.premium_arrival_time as premiumArrivalTime ");
        sql.append(" ,pm.premium_receivable_time as premiumReceivableTime ");
        sql.append(" ,pm.fee_prop as feeProp ");
        sql.append(" ,pm.handling_fee_income as handlingFeeIncome ");
        sql.append(" ,pm.handling_fee_entry_account as handlingFeeEntryAccount ");
        sql.append(" ,pm.handling_fee_receivable_time as handlingFeeReceivableTime ");
        sql.append(" ,pm.handling_fee_arrival_time as handlingFeeArrivalTime ");
        sql.append(" ,pm.pro_name as proName ");

        return sql;
    }

    public StringBuilder getPolicyQuerySql(PolicyListCondition condition) {
        StringBuilder sql = this.getBasePolicyField();
        this.getPolicyFromSql(sql, condition);
        this.getPolicyCondition(sql, condition);
        return sql;
    }

    public PageInfo<PolicyBaseListDTO> queryPolicyList(PolicyListCondition condition) {
        StringBuilder sql = this.getPolicyQuerySql(condition);
        return this.queryPolicyList(sql, condition.getPageNum(), condition.getPageSize());
    }

    /**
     * @param sql:      StringBuilder 查询sql
     * @param pageNum:  页码
     * @param pageSize: 条目数
     * @return com.huatonghh.common.util.system.PageInfo<com.huatonghh.plan.service.dto.policy.PolicyListDto>
     * @author Sun
     * @description 根据查询sql，分页排序查询保单列表
     * @date 2019/11/5 16:37
     **/
    public PageInfo<PolicyListDto> queryPageList(StringBuilder sql, Integer pageNum, Integer pageSize) {
        long total = dynamicQuery.nativeQueryCount("select count(1) from (" + sql + ") a");
        sql.append(" limit ?1, ?2 ");
        List<PolicyListDto> policyCarListDtos = dynamicQuery.nativeQueryListModel(PolicyListDto.class, sql.toString(),
            (pageNum - 1) * pageSize, pageSize);
        return PageInfo.of(pageNum, pageSize, policyCarListDtos, total);
    }

    public PageInfo<PolicyBaseListDTO> queryPolicyList(StringBuilder sql, Integer pageNum, Integer pageSize) {
        long total = dynamicQuery.nativeQueryCount("select count(1) from (" + sql + ") a");
        sql.append(" limit ?1, ?2 ");
        List<PolicyBaseListDTO> policyCarListDtos = dynamicQuery.nativeQueryListModel(PolicyBaseListDTO.class, sql.toString(),
            (pageNum - 1) * pageSize, pageSize);
        return PageInfo.of(pageNum, pageSize, policyCarListDtos, total);
    }

    public List<PolicyListDto> queryAllPolicy(StringBuilder sql) {
        return dynamicQuery.nativeQueryListModel(PolicyListDto.class, sql.toString());
    }

    public PageInfo<MobilePolicyListDTO> queryAllMobilePolicy(StringBuilder sql, Integer pageNum, Integer pageSize) {
        long total = dynamicQuery.nativeQueryCount("select count(1) from (" + sql + ") a");
        sql.append(" limit ?1, ?2 ");
        List<MobilePolicyListDTO> policyCarListDtos = dynamicQuery.nativeQueryListModel(MobilePolicyListDTO.class, sql.toString(),
            (pageNum - 1) * pageSize, pageSize);
        return PageInfo.of(pageNum, pageSize, policyCarListDtos, total);
    }

    /**
     * @param sql: StringBuilder 查询sql
     * @return com.huatonghh.common.util.system.PageInfo<com.huatonghh.plan.service.dto.policy.PolicyListDto>
     * @author Sun
     * @description 根据查询sql，排序查询保单列表
     * @date 2019/11/5 16:37
     **/
    public List<PolicyListDto> queryList(StringBuilder sql) {
        sql.append("order by pm.create_time desc");
        return dynamicQuery.nativeQueryListModel(PolicyListDto.class, sql.toString());
    }


    @Transactional
    public void batchInsertPolicyMain(List<PolicyMain> policyMains) {
        if (policyMains.size() == 0) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("INSERT INTO policy_main(policy_no, car_uncar_flag, insurance_category, kind_code, holder_name" +
            ", insured_name, start_company, belong_company, total_premium, premium_receivable_time" +
            ", premium_arrival_time, policy_apply_time, policy_bgn_time, policy_end_time, belong_company_person" +
            ", belong_company_phone, status, remind_status, remind_display, free_tax_premium" +
            ", create_time, update_time, belong_company_name,import_batch_no) VALUES ");
        for (PolicyMain policyMain : policyMains) {
            sb.append("(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?" +
                ", ?, ?, ?, ?, ?, ?, ?, ?,?),");
        }
        String sql = sb.toString().substring(0, sb.length() - 1);
        Query query = entityManager.createNativeQuery(sql);
        int paramIndex = 1;
        for (PolicyMain policyMain : policyMains) {
            query.setParameter(paramIndex++, policyMain.getPolicyNo());
            query.setParameter(paramIndex++, policyMain.getCarUncarFlag());
            query.setParameter(paramIndex++, policyMain.getInsuranceCategory());
            query.setParameter(paramIndex++, policyMain.getKindCode());
            query.setParameter(paramIndex++, policyMain.getHolderName());
            query.setParameter(paramIndex++, policyMain.getInsuredName());
            query.setParameter(paramIndex++, policyMain.getStartCompany());
            query.setParameter(paramIndex++, policyMain.getBelongCompany());
            query.setParameter(paramIndex++, policyMain.getTotalPremium());
            query.setParameter(paramIndex++, policyMain.getPremiumReceivableTime());
            query.setParameter(paramIndex++, policyMain.getPremiumArrivalTime());
            query.setParameter(paramIndex++, policyMain.getPolicyApplyTime());
            query.setParameter(paramIndex++, policyMain.getPolicyBgnTime());
            query.setParameter(paramIndex++, policyMain.getPolicyEndTime());
            query.setParameter(paramIndex++, policyMain.getBelongCompanyPerson());
            query.setParameter(paramIndex++, policyMain.getBelongCompanyPhone());
            query.setParameter(paramIndex++, policyMain.getStatus());
            query.setParameter(paramIndex++, policyMain.getRemindStatus());
            query.setParameter(paramIndex++, policyMain.getRemindDisplay());
            query.setParameter(paramIndex++, policyMain.getFreeTaxPremium());
            query.setParameter(paramIndex++, getSqlDate(policyMain.getCreateTime()));
            query.setParameter(paramIndex++, getSqlDate(policyMain.getUpdateTime()));
            query.setParameter(paramIndex++, policyMain.getBelongCompanyName());
            query.setParameter(paramIndex++, policyMain.getImportBatchNo());
        }
        query.executeUpdate();
    }

    @Transactional
    public void batchInsertPolicyCarDetail(List<PolicyCarDetail> policyCarDetails) {
        if (policyCarDetails.size() == 0) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("INSERT INTO policy_car_detail(policy_no, frame_no, plate_no, engine_no, usage_code" +
            ", owner_name, vehicle_model, fee_prop, vehicle_vessel_tax, ncd_coef, auto_underwriting_coef" +
            ", create_time, update_time, self_channel_coef, self_sum_coef) VALUES ");
        for (PolicyCarDetail policyCarDetail : policyCarDetails) {
            sb.append("(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?),");
        }
        String sql = sb.toString().substring(0, sb.length() - 1);
        Query query = entityManager.createNativeQuery(sql);
        int paramIndex = 1;
        for (PolicyCarDetail policyCarDetail : policyCarDetails) {
            query.setParameter(paramIndex++, policyCarDetail.getPolicyNo());
            query.setParameter(paramIndex++, policyCarDetail.getFrameNo());
            query.setParameter(paramIndex++, policyCarDetail.getPlateNo());
            query.setParameter(paramIndex++, policyCarDetail.getEngineNo());
            query.setParameter(paramIndex++, policyCarDetail.getUsageCode());
            query.setParameter(paramIndex++, policyCarDetail.getOwnerName());
            query.setParameter(paramIndex++, policyCarDetail.getVehicleModel());
            query.setParameter(paramIndex++, policyCarDetail.getFeeProp());
            query.setParameter(paramIndex++, policyCarDetail.getVehicleVesselTax());
            query.setParameter(paramIndex++, policyCarDetail.getNcdCoef());
            query.setParameter(paramIndex++, policyCarDetail.getAutoUnderwritingCoef());
            query.setParameter(paramIndex++, getSqlDate(policyCarDetail.getCreateTime()));
            query.setParameter(paramIndex++, getSqlDate(policyCarDetail.getUpdateTime()));
            query.setParameter(paramIndex++, policyCarDetail.getSelfChannelCoef());
            query.setParameter(paramIndex++, policyCarDetail.getSelfSumCoef());
        }
        query.executeUpdate();
    }

    @Transactional
    public void batchUpdatePolicyMain(ArrayList<PolicyMain> policyMains) {
        if (policyMains.size() == 0) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("INSERT INTO policy_main(policy_no, car_uncar_flag, insurance_category, kind_code, holder_name" +
            ", insured_name, start_company, belong_company, total_premium, premium_receivable_time" +
            ", premium_arrival_time, policy_apply_time, policy_bgn_time, policy_end_time, belong_company_person" +
            ", belong_company_phone, status, remind_status, remind_display, free_tax_premium" +
            ", create_time, update_time, belong_company_name,import_batch_no) VALUES ");
        for (PolicyMain policyMain : policyMains) {
            sb.append("(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?" +
                ", ?, ?, ?, ?, ?, ?, ?, ?,?),");
        }
        String sql = sb.toString().substring(0, sb.length() - 1);
        Query query = entityManager.createNativeQuery(sql);
        int paramIndex = 1;
        for (PolicyMain policyMain : policyMains) {
            query.setParameter(paramIndex++, policyMain.getPolicyNo());
            query.setParameter(paramIndex++, policyMain.getCarUncarFlag());
            query.setParameter(paramIndex++, policyMain.getInsuranceCategory());
            query.setParameter(paramIndex++, policyMain.getKindCode());
            query.setParameter(paramIndex++, policyMain.getHolderName());
            query.setParameter(paramIndex++, policyMain.getInsuredName());
            query.setParameter(paramIndex++, policyMain.getStartCompany());
            query.setParameter(paramIndex++, policyMain.getBelongCompany());
            query.setParameter(paramIndex++, policyMain.getTotalPremium());
            query.setParameter(paramIndex++, policyMain.getPremiumReceivableTime());
            query.setParameter(paramIndex++, policyMain.getPremiumArrivalTime());
            query.setParameter(paramIndex++, policyMain.getPolicyApplyTime());
            query.setParameter(paramIndex++, policyMain.getPolicyBgnTime());
            query.setParameter(paramIndex++, policyMain.getPolicyEndTime());
            query.setParameter(paramIndex++, policyMain.getBelongCompanyPerson());
            query.setParameter(paramIndex++, policyMain.getBelongCompanyPhone());
            query.setParameter(paramIndex++, policyMain.getStatus());
            query.setParameter(paramIndex++, policyMain.getRemindStatus());
            query.setParameter(paramIndex++, policyMain.getRemindDisplay());
            query.setParameter(paramIndex++, policyMain.getFreeTaxPremium());
            query.setParameter(paramIndex++, getSqlDate(policyMain.getCreateTime()));
            query.setParameter(paramIndex++, getSqlDate(policyMain.getUpdateTime()));
            query.setParameter(paramIndex++, policyMain.getBelongCompanyName());
            query.setParameter(paramIndex++, policyMain.getImportBatchNo());
        }
        query.executeUpdate();
        sql = "update policy_main, policy_main_tem set" +
            " policy_main.car_uncar_flag=policy_main_tem.car_uncar_flag, " +
            " policy_main.insurance_category=policy_main_tem.insurance_category, " +
            " policy_main.kind_code=policy_main_tem.kind_code, " +
            " policy_main.holder_name=policy_main_tem.holder_name, " +
            " policy_main.insured_name=policy_main_tem.insured_name, " +
            " policy_main.project_no=policy_main_tem.project_no, " +
            " policy_main.start_company=policy_main_tem.start_company, " +
            " policy_main.belong_company=policy_main_tem.belong_company, " +
            " policy_main.total_premium=policy_main_tem.total_premium, " +
            " policy_main.premium_receivable_time=policy_main_tem.premium_receivable_time, " +
            " policy_main.premium_arrival_time=policy_main_tem.premium_arrival_time, " +
            " policy_main.policy_apply_time=policy_main_tem.policy_apply_time, " +
            " policy_main.policy_bgn_time=policy_main_tem.policy_bgn_time, " +
            " policy_main.policy_end_time=policy_main_tem.policy_end_time, " +
            " policy_main.policy_end_time=policy_main_tem.policy_end_time, " +
            " policy_main.belong_company_phone=policy_main_tem.belong_company_phone, " +
            " policy_main.status=policy_main_tem.status, " +
            " policy_main.remind_status=policy_main_tem.remind_status, " +
            " policy_main.remind_display=policy_main_tem.remind_display, " +
            " policy_main.bid_date=policy_main_tem.bid_date, " +
            " policy_main.pro_id=policy_main_tem.pro_id, " +
            " policy_main.pro_name=policy_main_tem.pro_name, " +
            " policy_main.pro_alias=policy_main_tem.pro_alias, " +
            " policy_main.pro_contact=policy_main_tem.pro_contact, " +
            " policy_main.pro_tel=policy_main_tem.pro_tel, " +
            " policy_main.bid_contact=policy_main_tem.bid_contact, " +
            " policy_main.bid_tel=policy_main_tem.bid_tel, " +
            " policy_main.free_tax_premium=policy_main_tem.free_tax_premium, " +
            " policy_main.fee_prop=policy_main_tem.fee_prop, " +
            " policy_main.handling_fee=policy_main_tem.handling_fee, " +
            " policy_main.handling_fee_income=policy_main_tem.handling_fee_income, " +
            " policy_main.handling_fee_entry_account=policy_main_tem.handling_fee_entry_account, " +
            " policy_main.handling_fee_receivable_time=policy_main_tem.handling_fee_receivable_time, " +
            " policy_main.handling_fee_arrival_time=policy_main_tem.handling_fee_arrival_time, " +
            " policy_main.create_time=policy_main_tem.create_time, " +
            " policy_main.update_time=policy_main_tem.update_time, " +
            " policy_main.belong_company_name=policy_main_tem.belong_company_name, " +
            " policy_main.import_batch_no=policy_main_tem.import_batch_no " +
            "where policy_main.policy_no=policy_main_tem.policy_no";
        Query query1 = entityManager.createNativeQuery(sql);
        query1.executeUpdate();
        sql = "truncate table policy_main_tem";
        Query query2 = entityManager.createNativeQuery(sql);
        query2.executeUpdate();
    }

    @Transactional
    public void batchUpdatePolicyCarDetail(ArrayList<PolicyCarDetail> policyCarDetails) {
        if (policyCarDetails.size() == 0) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("INSERT INTO policy_car_detail_tem(policy_no, frame_no, plate_no, engine_no, usage_code" +
            ", owner_name, vehicle_model, fee_prop, vehicle_vessel_tax, ncd_coef, auto_underwriting_coef" +
            ", create_time, update_time, self_channel_coef, self_sum_coef) VALUES ");
        for (PolicyCarDetail policyCarDetail : policyCarDetails) {
            sb.append("(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?),");
        }
        String sql = sb.toString().substring(0, sb.length() - 1);
        Query query = entityManager.createNativeQuery(sql);
        int paramIndex = 1;
        for (PolicyCarDetail policyCarDetail : policyCarDetails) {
            query.setParameter(paramIndex++, policyCarDetail.getPolicyNo());
            query.setParameter(paramIndex++, policyCarDetail.getFrameNo());
            query.setParameter(paramIndex++, policyCarDetail.getPlateNo());
            query.setParameter(paramIndex++, policyCarDetail.getEngineNo());
            query.setParameter(paramIndex++, policyCarDetail.getUsageCode());
            query.setParameter(paramIndex++, policyCarDetail.getOwnerName());
            query.setParameter(paramIndex++, policyCarDetail.getVehicleModel());
            query.setParameter(paramIndex++, policyCarDetail.getFeeProp());
            query.setParameter(paramIndex++, policyCarDetail.getVehicleVesselTax());
            query.setParameter(paramIndex++, policyCarDetail.getNcdCoef());
            query.setParameter(paramIndex++, policyCarDetail.getAutoUnderwritingCoef());
            query.setParameter(paramIndex++, getSqlDate(policyCarDetail.getCreateTime()));
            query.setParameter(paramIndex++, getSqlDate(policyCarDetail.getUpdateTime()));
            query.setParameter(paramIndex++, policyCarDetail.getSelfChannelCoef());
            query.setParameter(paramIndex++, policyCarDetail.getSelfSumCoef());
        }
        query.executeUpdate();
        sql = "update policy_car_detail, policy_car_detail_tem set" +
            " policy_car_detail.frame_no=policy_car_detail_tem.frame_no, " +
            " policy_car_detail.plate_no=policy_car_detail_tem.plate_no, " +
            " policy_car_detail.engine_no=policy_car_detail_tem.engine_no, " +
            " policy_car_detail.usage_code=policy_car_detail_tem.usage_code, " +
            " policy_car_detail.owner_name=policy_car_detail_tem.owner_name, " +
            " policy_car_detail.vehicle_model=policy_car_detail_tem.vehicle_model, " +
            " policy_car_detail.fee_prop=policy_car_detail_tem.fee_prop, " +
            " policy_car_detail.vehicle_vessel_tax=policy_car_detail_tem.vehicle_vessel_tax, " +
            " policy_car_detail.ncd_coef=policy_car_detail_tem.ncd_coef, " +
            " policy_car_detail.auto_underwriting_coef=policy_car_detail_tem.auto_underwriting_coef, " +
            " policy_car_detail.create_time=policy_car_detail_tem.create_time, " +
            " policy_car_detail.update_time=policy_car_detail_tem.update_time, " +
            " policy_car_detail.self_channel_coef=policy_car_detail_tem.self_channel_coef, " +
            " policy_car_detail.self_sum_coef=policy_car_detail_tem.self_sum_coef " +
            "where policy_car_detail_tem.policy_no=policy_car_detail.policy_no";
        Query query1 = entityManager.createNativeQuery(sql);
        query1.executeUpdate();
        sql = "truncate table policy_car_detail_tem";
        Query query2 = entityManager.createNativeQuery(sql);
        query2.executeUpdate();
    }

    private java.sql.Date getSqlDate(Date date) {
        if (date == null) {
            return null;
        }
        return new java.sql.Date(date.getTime());
    }

    /**
     * 更新防灾防损基金
     * @param policyFundDTO
     */
    public void updateFund(PolicyFundDTO policyFundDTO) {
        Optional<PolicyMain> optPolicyMain =  policyMainRepository.findByPolicyNo(policyFundDTO.getPolicyNo());
        if (!optPolicyMain.isPresent()) {
            throw new BusinessException("保单号不存在");
        }
        optPolicyMain.ifPresent(policyMain -> {
            policyMain.setTotalFund(policyFundDTO.getTotalFund());
            policyMain.setUsedFund(policyFundDTO.getUsedFund());
            policyMain.setLeftFund(policyFundDTO.getLeftFund());
            policyMainRepository.save(policyMain);
        });
    }
}
/*
SELECT
p.pro_id proId
,p.pro_name proName
,e.eng_type engType
,co.code_name engTypeName
,group_concat(p.policy_no) policyNos
,count(p.policy_no) countPolicy
,count(e.contract) countContract
,sum(p.total_premium) totalPremium
from policy_main p , policy_engineering e,base_code co
where p.insurance_category ='5'
and p.policy_no = e.policy_no
and co.type_id ='eng_type'
and co.code_id = e.eng_type
GROUP BY p.pro_id,e.eng_type
 */
