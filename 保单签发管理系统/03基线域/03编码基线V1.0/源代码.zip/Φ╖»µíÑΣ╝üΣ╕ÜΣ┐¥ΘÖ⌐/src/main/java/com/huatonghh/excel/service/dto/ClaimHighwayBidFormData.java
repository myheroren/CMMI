package com.huatonghh.excel.service.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import lombok.Data;

/**
 * @author : wh
 * description : 标段统计表
 * @version : 1.0
 * @date : 2020/5/25 15:59
 */
@Data
@ContentRowHeight(20)
@HeadRowHeight(20)
@ColumnWidth(15)
public class ClaimHighwayBidFormData {
    @ExcelProperty(value = "填报项目单位名称", index = 0)
    private String startCompanyName;
    @ExcelProperty(value = "工程类别名称", index = 1)
    private String engTypeName;
    @ExcelProperty(value = "标段", index = 2)
    private String belongBid;
    @ExcelProperty(value = "是否投保一切险", index = 3)
    private String allInsured;
    @ExcelProperty(value = "承保单位", index = 4)
    private String belongCompanyName;
    @ExcelProperty(value = "保险费", index = 5)
    private String totalPremium;
    @ExcelProperty(value = "保额", index = 6)
    private String totalAmount;

    @ExcelProperty(value = {"出险", "出险次数"}, index = 7)
    private String countClaim;
    @ExcelProperty(value = {"出险", "出险估损额"}, index = 8)
    private String preLossAmount;

    @ExcelProperty(value = {"索赔", "索赔次数"}, index = 9)
    private String countApply;
    @ExcelProperty(value = {"索赔", "索赔额"}, index = 10)
    private String askForAmount;

    @ExcelProperty(value = {"赔偿", "赔偿次数"}, index = 11)
    private String countGetClaim;
    @ExcelProperty(value = {"赔偿", "赔偿额"}, index = 12)
    private String payAmount;
}
