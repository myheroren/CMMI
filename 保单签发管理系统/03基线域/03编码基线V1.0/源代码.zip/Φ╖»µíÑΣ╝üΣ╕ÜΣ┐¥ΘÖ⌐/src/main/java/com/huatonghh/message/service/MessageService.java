package com.huatonghh.message.service;

import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.common.util.system.PageParam;
import com.huatonghh.message.po.dto.CloudUpcomingDTO;
import com.huatonghh.message.po.dto.MessageDTO;
import com.huatonghh.message.po.dto.MessageQuery;
import com.huatonghh.message.po.dto.MessageVO;
import org.springframework.validation.annotation.Validated;

/**
 * 消息主体service接口
 *
 * @author wanggl
 * @since 2020-11-02 20:09:22
 */
public interface MessageService {

    /**
     * 发送消息
     *
     * @param messageDTO 消息及用户信息对象
     */
    void sendMessage(@Validated MessageDTO messageDTO);

    /**
     * 改变消息状态为已读
     *
     * @param messageId 消息id
     * @param userCode  用户编号
     */
    void read(Long messageId, String userCode);

    /**
     * 条件分页查询用户消息列表
     *
     * @param param 消息查询对象
     * @return 分页列表
     */
    PageInfo<MessageVO> messageList(PageParam<MessageQuery> param);

    /**
     * 向云之家开放平台推送代办消息
     * @param cLoudUpcomingDTO
     */
    void sendMessage2CloudHome(CloudUpcomingDTO cLoudUpcomingDTO);
}
