package com.huatonghh.ins_authority.service;

import com.google.common.collect.Lists;
import com.huatonghh.authority.constant.AuthorityConstant;
import com.huatonghh.authority.domain.EiAuthority;
import com.huatonghh.authority.repository.EiAuthorityRepository;
import com.huatonghh.authority.service.dto.EiAuthorityDto;
import com.huatonghh.authority.service.dto.EiAuthorityTreeDto;
import com.huatonghh.common.constant.enums.StatusEnum;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.ins_authority.domain.EiInsAuthority;
import com.huatonghh.ins_authority.repository.EiInsAuthorityRepository;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author : Sun
 * @description : 权限管理-业务层
 * @date : 2019/11/4 21:12
 * @version : 1.0
 */
@Service
@CacheConfig
@Slf4j
public class EiInsAuthorityService {

    private final EiInsAuthorityRepository eiAuthorityRepository;

    private final EiInsRoleService eiRoleService;

    private final ModelMapper modelMapper;

    public EiInsAuthorityService(EiInsAuthorityRepository eiAuthorityRepository, EiInsRoleService eiRoleService, ModelMapper modelMapper) {
        this.eiAuthorityRepository = eiAuthorityRepository;
        this.eiRoleService = eiRoleService;
        this.modelMapper = modelMapper;
    }


    /**
     * @author Sun
     * @description 获取菜单权限二叉树列表
     * @date 2019/11/5 19:51
     * @return java.util.List<com.huatonghh.authority.service.dto.EiAuthorityDto>
     **/
    @Cacheable(cacheNames = AuthorityConstant.EI_AUTHORITYS_BY_LOGIN_CACHE, key = "methodName", unless = "#result == null || #result.size() == 0")
    public List<EiAuthorityDto> queryAuthorityTreeList(){
        // 查询所有的菜单列表
        Sort sort = new Sort(Sort.Direction.ASC, "sortNumber");
        List<EiInsAuthority> eiAuthorityList = eiAuthorityRepository.findAll(sort);
        // mapper成前端对象集合
        return eiAuthorityList.stream().map(eiAuthority -> modelMapper.map(eiAuthority, EiAuthorityDto.class)).collect(Collectors.toList());
    }


    /**
     * @author Sun
     * @description 组装菜单二叉树
     * @date 2019/11/5 19:58
     * @param eiAuthorityDtos:
     * @param id:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiAuthorityTreeDto>
     **/
    public List<EiAuthorityTreeDto> processTreeList(List<EiAuthorityDto> eiAuthorityDtos, Integer id) {
        // 组装二叉树
        List<EiAuthorityTreeDto> eiDepartTreeDtoList = Lists.newArrayList();
        if(id == null) {
            id = AuthorityConstant.AUTHORITY_TREE_HEAD;
        }

        for (EiAuthorityDto eiAuthorityDto : eiAuthorityDtos) {
            // 获取最高层级部门
            if(id.equals(eiAuthorityDto.getParentId())){
                EiAuthorityTreeDto eiAuthorityTreeDto = new EiAuthorityTreeDto();
                eiAuthorityTreeDto.setId(eiAuthorityDto.getId());
                eiAuthorityTreeDto.setComponent(eiAuthorityDto.getComponent());
                eiAuthorityTreeDto.setName(eiAuthorityDto.getName());
                eiAuthorityTreeDto.setStatus(eiAuthorityDto.getStatus());
                eiAuthorityTreeDto.setTitle(eiAuthorityDto.getTitle());
                eiAuthorityTreeDto.setIcon(eiAuthorityDto.getIcon());
                eiAuthorityTreeDto.setVisible(eiAuthorityDto.getVisible());
                eiAuthorityTreeDto.setParentId(eiAuthorityDto.getParentId());
                // 放入新treeDto集合，并返回
                eiAuthorityTreeDto.setChildren(getChild(eiAuthorityTreeDto.getId(), eiAuthorityDtos));
                eiDepartTreeDtoList.add(eiAuthorityTreeDto);
            }
        }
        return eiDepartTreeDtoList;
    }


    /**
     * @author Sun
     * @description ei_depart 递归方法
     * @date 2019/11/5 19:58
     * @param id:
     * @param eiAuthorityDtos:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiAuthorityTreeDto>
     **/
    private List<EiAuthorityTreeDto> getChild(Integer id, List<EiAuthorityDto> eiAuthorityDtos) {
        List<EiAuthorityTreeDto> childList = Lists.newArrayList();
        for (EiAuthorityDto eiAuthorityDto : eiAuthorityDtos) {
            if (id.equals(eiAuthorityDto.getParentId())) {
                EiAuthorityTreeDto eiAuthorityTreeDto = new EiAuthorityTreeDto();
                eiAuthorityTreeDto.setId(eiAuthorityDto.getId());
                eiAuthorityTreeDto.setComponent(eiAuthorityDto.getComponent());
                eiAuthorityTreeDto.setName(eiAuthorityDto.getName());
                eiAuthorityTreeDto.setStatus(eiAuthorityDto.getStatus());
                eiAuthorityTreeDto.setTitle(eiAuthorityDto.getTitle());
                eiAuthorityTreeDto.setIcon(eiAuthorityDto.getIcon());
                eiAuthorityTreeDto.setVisible(eiAuthorityDto.getVisible());
                eiAuthorityTreeDto.setParentId(eiAuthorityDto.getParentId());
                childList.add(eiAuthorityTreeDto);
            }
        }
        // 递归，把子菜单的子菜单再循环一遍
        for (EiAuthorityTreeDto eiAuthorityTreeDto : childList) {
            eiAuthorityTreeDto.setChildren(getChild(eiAuthorityTreeDto.getId(), eiAuthorityDtos));
        }
        // 递归退出条件
        if (childList.size() == 0) {
            return null;
        }
        return childList;
    }


    /**
     * @author Sun
     * @description 菜单权限信息保存
     * @date 2019/11/5 19:54
     * @param eiAuthorityDto:
     * @return com.huatonghh.authority.service.dto.EiAuthorityDto
     **/
    @CacheEvict(cacheNames = AuthorityConstant.EI_AUTHORITYS_BY_LOGIN_CACHE, allEntries = true)
    @Transactional(rollbackFor = RuntimeException.class)
    public EiAuthorityDto saveAuthority(EiAuthorityDto eiAuthorityDto) {
        EiInsAuthority eiAuthority = modelMapper.map(eiAuthorityDto, EiInsAuthority.class);
        eiAuthority = eiAuthorityRepository.save(eiAuthority);
        return modelMapper.map(eiAuthority, EiAuthorityDto.class);
    }


    /**
     * @author Sun
     * @description 清除缓存
     * @date 2019/11/5 19:54
     **/
    @CacheEvict(cacheNames = AuthorityConstant.EI_AUTHORITYS_BY_LOGIN_CACHE, allEntries = true)
    public void clearCache() {
        log.info("清除缓存成功！！！");
    }


    /**
     * @author Sun
     * @description 删除菜单
     * @date 2019/11/5 19:54
     * @param id: 菜单id
     **/
    @CacheEvict(cacheNames = AuthorityConstant.EI_AUTHORITYS_BY_LOGIN_CACHE, allEntries = true)
    @Transactional(rollbackFor = Exception.class)
    public void delete(Integer id) {
        try {
            eiAuthorityRepository.deleteRoleAuthorityById(id);
            eiAuthorityRepository.deleteById(id);
        } catch (Exception e) {
            log.error(StatusEnum.AUTHORITY_DELETE_AUTHORITY_ERROR.getMessage() + ": {}", e.getMessage());
            throw new BusinessException(StatusEnum.AUTHORITY_DELETE_AUTHORITY_ERROR);
        }
        // 清除缓存
        this.clearCache();
        eiRoleService.clearCache();
    }


    /**
     * @author Sun
     * @description 菜单排序
     * @date 2019/11/5 19:56
     * @param eiAuthorityTreeDtoList:
     **/
    @CacheEvict(cacheNames = AuthorityConstant.EI_AUTHORITYS_BY_LOGIN_CACHE, allEntries = true)
    public void updateSort(List<EiAuthorityTreeDto> eiAuthorityTreeDtoList) {
        if (!eiAuthorityTreeDtoList.isEmpty()) {
            List<EiInsAuthority> sortAuthorityList = getSortedFunction(eiAuthorityTreeDtoList, 0, 8);
            eiAuthorityRepository.saveAll(sortAuthorityList);
        }
    }


    /**
     * @author Sun
     * @description 递归排序
     * @date 2019/11/5 19:56
     * @param treeList: 排序前list集合
     * @param baseParent: 基础排序号
     * @param times: 顺序差
     * @return java.util.List<com.huatonghh.authority.domain.EiAuthority>
     **/
    private List<EiInsAuthority> getSortedFunction(List<EiAuthorityTreeDto> treeList, int baseParent, int times) {
        List<EiInsAuthority> result = Lists.newArrayList();
        if (treeList != null && treeList.size() > 0) {
            int num = 1;
            for (EiAuthorityTreeDto treeDto : treeList) {
                EiInsAuthority eiAuthority = modelMapper.map(treeDto, EiInsAuthority.class);
                int baseSelf = baseParent + (int) (num++ * Math.pow(10, times));
                eiAuthority.setSortNumber(baseSelf);
                result.addAll(getSortedFunction(treeDto.getChildren(), baseSelf, times - 1));
                result.add(eiAuthority);
            }
        }
        return result;
    }

}
