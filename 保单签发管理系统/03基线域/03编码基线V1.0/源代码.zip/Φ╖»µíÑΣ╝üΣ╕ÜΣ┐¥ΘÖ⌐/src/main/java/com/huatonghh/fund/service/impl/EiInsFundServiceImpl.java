package com.huatonghh.fund.service.impl;

import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.util.BeanCopierUtils;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.common.util.system.PageParam;
import com.huatonghh.fund.domain.EiInsFund;
import com.huatonghh.fund.repository.EiInsFundRepository;
import com.huatonghh.fund.service.EiInsFundService;
import com.huatonghh.fund.service.dto.FundDTO;
import com.huatonghh.policy.service.client.UserClient;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author ghy
 * Date: 2021/1/5 16:53
 */
@Service
@Slf4j
@AllArgsConstructor
@Transactional
public class EiInsFundServiceImpl implements EiInsFundService {

    private final EiInsFundRepository eiInsFundRepository;

    private final UserClient userClient;

    @Override
    public PageInfo<EiInsFund> list(PageParam<Object> pageParam) {
        Integer id = userClient.getCurrentCompanyInfo().getEiInsDepartDto().getId();
        Page<EiInsFund> page = eiInsFundRepository.findEiInsFundsByBelongCompany(id, PageRequest.of(pageParam.getPageNum() - 1, pageParam.getPageSize()));
        if (page.getTotalElements() == 0) {
            throw new BusinessException("没有查到基金使用记录!");
        }
        return PageInfo.of(pageParam, page);
    }

    @Override
    public EiInsFund getLastUsed() {
        Integer id = userClient.getCurrentCompanyInfo().getEiInsDepartDto().getId();
        return eiInsFundRepository.findFirstByBelongCompanyOrderByIdDesc(id);
    }

    @Override
    public void save(FundDTO fundDTO) {
        Integer id = userClient.getCurrentCompanyInfo().getEiInsDepartDto().getId();

        if (fundDTO.getTotal() == null || fundDTO.getTotal().compareTo(new BigDecimal(0)) <= 0) {
            throw new BusinessException("基金总额必须大于0!");
        }
        if (fundDTO.getUsed().compareTo(fundDTO.getTotal()) > 0) {
            throw new BusinessException("使用基金数必须小于基金总额!");
        }
        EiInsFund eiInsFund = new EiInsFund();
        BeanCopierUtils.copy(fundDTO, eiInsFund);
        eiInsFund.setBelongCompany(id);
        BigDecimal left = fundDTO.getTotal().subtract(fundDTO.getUsed());
        eiInsFund.setLeft(left);
        eiInsFund.setCreateTime(new Date());
        eiInsFundRepository.save(eiInsFund);
    }
}
