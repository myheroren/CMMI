package com.huatonghh.base.service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.util.Date;

/**
 * Description : 通知中心Dto
 *
 * @author : Sun
 * @version : 1.0
 * @date : 2019/9/11 11:42
 */
@Data
public class BaseRemindDto {

    @ApiModelProperty(value = "id")
    private Integer id;

    @ApiModelProperty(value = "发起账号id")
    private String sendUserId;

    @ApiModelProperty(value = "发起账号姓名")
    private String sendUserName;

    @ApiModelProperty(value = "接收账号id")
    private String receiveUserId;

    @ApiModelProperty(value = "接收账号姓名")
    private String receiveUserName;

    @ApiModelProperty(value = "保险计划编号")
    private String planNo;

    @ApiModelProperty(value = "项目编号")
    private String projectNo;

    @ApiModelProperty(value = "保单号")
    private String policyNo;

    @ApiModelProperty(value = "赔案号")
    private String claimNo;

    @ApiModelProperty(value = "通知主要的内容")
    private String remindOutline;

    @ApiModelProperty(value = "通知模板：代码定义的常亮名字")
    private String remindContent;

    @ApiModelProperty(value = "通知星级：1不重要、2重要、3紧急通知(目前没啥用)")
    private Byte remindLevel;

    @ApiModelProperty(value = "通知类型：1保险计划、2项目、3保单 4汇总计划,5批单")
    private Byte remindType;

    @ApiModelProperty(value = "已读状态：0未读、1已读")
    private Byte readStatus;

    @ApiModelProperty(value = "是否待办：0不待办，1添加待办")
    private Byte backlogStatus;

    @ApiModelProperty(value = "通知时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;


    @ApiModelProperty(value = "通知内容")
    private String remindMsg;

}
