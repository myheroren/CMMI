package com.huatonghh.policy.service.dto.count;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigInteger;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/11
 */
@Data
@ApiModel("险种维度统计结果")
public class CountKindCodeDTO {
    @ApiModelProperty("险种")
    private String kindCode;
    @ApiModelProperty("保费")
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger totalPremium;
    @ApiModelProperty("手续费")
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger totalHandlingFee;
}
