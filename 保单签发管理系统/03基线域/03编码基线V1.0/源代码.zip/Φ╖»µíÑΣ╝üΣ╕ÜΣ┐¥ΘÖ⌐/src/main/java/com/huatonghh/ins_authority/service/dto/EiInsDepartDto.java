package com.huatonghh.ins_authority.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * @author : Sun
 * @description : 
 * @date : 2019/11/5 21:37
 * @version : 1.0
 */
@Data
@ApiModel(value = "部门、也叫保险公司")
public class EiInsDepartDto implements Serializable {

    private static final long serialVersionUID = -4135145343245048460L;

    @ApiModelProperty(value = "部门id")
    private Integer id;

    @ApiModelProperty(value = "部门名称")
    private String name;

    @ApiModelProperty(value = "父id")
    private Integer parentId;

    @ApiModelProperty(value = "ids")
    private String ids;

    @ApiModelProperty(value = "部门下员工列表")
    private Set<EiInsUserDto> authorities = new HashSet<>();

}
