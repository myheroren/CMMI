package com.huatonghh.policy.web.rest;

import com.huatonghh.authority.constant.AuthorityConstant;
import com.huatonghh.authority.security.SecurityUtils;
import com.huatonghh.base.service.timing.RenewRemindService;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.policy.repository.claim.noncar.UnCarClaimRepository;
import com.huatonghh.policy.service.PolicyService;
import com.huatonghh.policy.service.client.UserClient;
import com.huatonghh.policy.service.dto.policy.PolicyListCondition;
import com.huatonghh.policy.service.dto.policy.PolicyListDto;
import com.huatonghh.policy.service.renew.PolicyRenewV2Service;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.math.BigInteger;
import java.util.List;

/**
 * description:续保控制层
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2020/1/9
 */
@RestController
@RequestMapping("/api/renew/v1")
@Api(tags = "17、续保")
@Slf4j
@AllArgsConstructor
public class PolicyRenewV2Controller {

    private final PolicyRenewV2Service policyRenewV2Service;

    private final RenewRemindService renewRemindService;

    private final PolicyService policyService;

    private final UserClient userClient;

    @PostMapping("/hide/{id}")
    @ApiOperation(value = "取消续保提醒", httpMethod = "POST")
    @Timed
    public ApiResponse hideRenew(@PathVariable(value = "id") BigInteger id) {
        policyRenewV2Service.hideRenew(id);
        return ApiResponse.ofSuccess(null);
    }

//    @PostMapping("/list")
//    @ApiOperation(value = "企业:续保分页列表", httpMethod = "POST")
//    @Timed
//    public ApiResponse<PageInfo<PolicyRenewListDTO>> listRenewPage(@RequestBody @Valid PolicyListCondition condition) {
//        return ApiResponse.ofSuccess(policyRenewV2Service.listRenewPage(condition));
//    }

    @PostMapping("/list")
    @ApiOperation(value = "企业:续保分页列表", httpMethod = "POST")
    @Timed
    public ApiResponse<PageInfo<PolicyListDto>> listRenewPage(@RequestBody @Valid PolicyListCondition policyListCondition) {
        this.check(policyListCondition);
        // 3.组装查询sql
        StringBuilder sql = policyService.processQueryRenewSql(policyListCondition);

        // 4.查询分页列表数据集
        return ApiResponse.ofSuccess(policyService.queryPageList(sql, policyListCondition.getPageNum(), policyListCondition.getPageSize()));
    }

    public List<PolicyListDto> exportList(@RequestBody @Valid PolicyListCondition policyListCondition) {
        this.check(policyListCondition);
        // 3.组装查询sql
        StringBuilder sql = policyService.processQueryRenewSql(policyListCondition);

        // 4.查询分页列表数据集
        return policyService.queryAllPolicy(sql);
    }

    @GetMapping(value = "count_renew")
    @ApiOperation(value = "续保个数", notes = "续保个数", httpMethod = "GET")
    @Timed
    public ApiResponse<Long> allRenewCount() {
        PolicyListCondition condition=new PolicyListCondition();
        condition.setPageNum(1);
        condition.setPageSize(2);
        condition.setStartCompany(userClient.getCurrentGroupCompany().getId());
        condition.setColumn("currentTimestamp");
        condition.setRange(0);
        condition.setCarUncarFlag((byte)1);
        return ApiResponse.ofSuccess(policyRenewV2Service.listRenewPage(condition).getTotal());
    }

    @GetMapping(value = "updateRenewStatus")
    @ApiOperation(value = "手动调用续保状态更新接口", notes = "手动调用续保状态更新接口", httpMethod = "GET")
    public ApiResponse<Long> updateRenewStatus() {
        renewRemindService.renewRemind();
        return ApiResponse.ofSuccess(null);
    }

    private void check(PolicyListCondition policyListCondition) {
        // 1.获取登录角色
        String loginRole = SecurityUtils.loginRole();

        // 2.根据登录角色，获取不同的查询sql
        if (AuthorityConstant.JTJT.equals(loginRole)) {
            // 交投集团登录，如果查询条件中不含集团公司id，不查询
            if (StringUtils.isBlank(policyListCondition.getStartCompany())) {
                throw new BusinessException("请传入集团公司编号");
            }
        } else if (AuthorityConstant.BXGS.equals(loginRole)) {
            // 保险公司登录，如果查询条件中不含保险公司id，不查询
            if (StringUtils.isBlank(policyListCondition.getBelongCompany())) {
                throw new BusinessException("请传入保险公司编号");
            }
        }
    }
}
