package com.huatonghh.authority.security;

import cn.hutool.core.lang.Console;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * Description : 自定义security验证用户
 * @author : Sun
 * @date : 2019/9/24 14:43
 * @version : 1.0
 */
public class LoginAuthenticationProvider extends DaoAuthenticationProvider {

//    private BbwUserRepository bbwUserRepository;

    /**
     * 自定义验证用户认证
     *
     * @param userDetails    用户信息
     * @param authentication 验证信息
     * @throws AuthenticationException 验证错误
     */
    @Override
    protected void additionalAuthenticationChecks(UserDetails userDetails, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
        /** 可用于自定义验证用户信息，获取用户数据后，比对密码等。。
         * 这里可以设定，哪些情况不需要密码，哪些情况需要对错误密码次数强制设定 */
        if (authentication.getCredentials() == null) {
            throw new BadCredentialsException(messages.getMessage(
                "AbstractUserDetailsAuthenticationProvider.badCredentials",
                "Bad credentials"));
        }
        String presentedPassword = authentication.getCredentials().toString();
        String username = userDetails.getUsername();
    }

//    public void setBbwUserRepository(BbwUserRepository bbwUserRepository) {
//        this.bbwUserRepository = bbwUserRepository;
//    }


}
