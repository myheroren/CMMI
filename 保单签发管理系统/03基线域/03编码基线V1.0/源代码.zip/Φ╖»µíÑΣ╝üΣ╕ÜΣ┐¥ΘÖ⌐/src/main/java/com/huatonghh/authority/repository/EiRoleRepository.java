package com.huatonghh.authority.repository;

import com.huatonghh.authority.domain.EiRole;
import io.swagger.models.auth.In;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;


/**
 * @author : Sun
 * @description : 交投集团-角色-数据仓库
 * @date : 2019/11/4 19:45
 * @version : 1.0
 */
@Repository
public interface EiRoleRepository extends JpaRepository<EiRole, Integer> {

    /**
     * 根据角色id查询角色信息
     *
     * @author Sun
     * @date 2019/11/4 19:52
     * @param roleid: 角色id
     * @return java.util.Optional<com.huatonghh.authority.domain.EiRole>
     **/
    Optional<EiRole> findOneByRoleId(Integer roleid);


    /**
     * 懒加载获取角色信息，以及菜单权限信息
     *
     * @author Sun
     * @date 2019/11/4 19:53
     * @param roleid: 角色id
     * @return java.util.Optional<com.huatonghh.authority.domain.EiRole>
     **/
    @EntityGraph(attributePaths = "authorities")
    Optional<EiRole> findOneWithAuthoritiesByRoleId(Integer roleid);


    /**
     * 懒加载获取所有角色信息，以及菜单权限信息
     *
     * @author Sun
     * @date 2019/11/4 19:53
     * @param valid: 角色是否有效
     * @return java.util.List<com.huatonghh.authority.domain.EiRole>
     **/
    List<EiRole> findAllByValid(Boolean valid);

    /**
     * 懒加载获取所有角色信息，以及菜单权限信息
     *
     * @author Sun
     * @date 2019/11/4 19:53
     * @param valid: 角色是否有效
     * @return java.util.List<com.huatonghh.authority.domain.EiRole>
     **/
    @Modifying
    @Query(nativeQuery = true, value = "select er.* from ei_depart_role edr,ei_role er where edr.role_id = er.role_id and edr.company_id = ?1 and er.is_valid = ?2 LIMIT ?3,?4")
    List<EiRole> findAllByCompanyId(String companyId,Boolean valid,Integer pageNum,Integer pageSize);

    @Modifying
    @Query(nativeQuery = true, value = "select er.* from ei_depart_role edr,ei_role er where edr.role_id = er.role_id and edr.company_id = ?1 and er.is_valid = ?2")
    List<EiRole> findAllSizeByCompanyId(String companyId,Boolean valid);

    /**
     * 删除角色对应的用户中间表
     *
     * @author Sun
     * @date 2019/11/4 19:54
     * @param roleId: 角色id
     **/
    @Modifying
    @Query(nativeQuery = true, value = "delete from ei_user_role where role_id = :roleId")
    void deleteUserRoleByRoleId(@Param("roleId") Integer roleId);

}
