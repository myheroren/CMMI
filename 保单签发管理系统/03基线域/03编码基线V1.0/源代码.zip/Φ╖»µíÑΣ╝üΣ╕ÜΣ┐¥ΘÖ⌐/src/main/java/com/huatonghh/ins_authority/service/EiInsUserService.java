package com.huatonghh.ins_authority.service;

import cn.hutool.core.lang.Console;
import com.google.common.collect.Lists;
import com.huatonghh.authority.constant.AuthorityConstant;
import com.huatonghh.authority.domain.EiAuthority;
import com.huatonghh.authority.security.SecurityUtils;
import com.huatonghh.authority.security.jwt.TokenProvider;
import com.huatonghh.authority.service.dto.EiAuthorityDto;
import com.huatonghh.authority.service.dto.EiRoleDto;
import com.huatonghh.authority.service.dto.JWTToken;
import com.huatonghh.common.config.properties.ApplicationProperties;
import com.huatonghh.common.constant.CommonConstants;
import com.huatonghh.common.constant.enums.StatusEnum;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.repository.DynamicQuery;
import com.huatonghh.common.service.RedisService;
import com.huatonghh.common.service.dto.ResponseIntegerKeyValueDto;
import com.huatonghh.common.util.process.ProcessDtoToEntityUtil;
import com.huatonghh.common.util.process.ProcessEntityToDtoUtil;
import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.ei.web.rest.errors.InvalidPasswordException;
import com.huatonghh.ei.web.rest.vm.LoginVM;
import com.huatonghh.ei.web.rest.vm.LoginVerifyVM;
import com.huatonghh.ins_authority.constant.InsAuthorityConstant;
import com.huatonghh.ins_authority.domain.EiInsDepart;
import com.huatonghh.ins_authority.domain.EiInsUser;
import com.huatonghh.ins_authority.domain.EiInsUserBase;
import com.huatonghh.ins_authority.domain.InsRoleUser;
import com.huatonghh.ins_authority.repository.EiInsDepartRepository;
import com.huatonghh.ins_authority.repository.EiInsUserBaseRepository;
import com.huatonghh.ins_authority.repository.EiInsUserRepository;
import com.huatonghh.ins_authority.repository.InsRoleUserRepository;
import com.huatonghh.ins_authority.service.dto.EiInsDepartDto;
import com.huatonghh.ins_authority.service.dto.EiInsUserCondition;
import com.huatonghh.ins_authority.service.dto.EiInsUserDto;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author : Sun
 * @version : 1.0
 * @description : 用户管理业务层
 * @date : 2019/11/5 21:38
 */
@Service
@CacheConfig
@Slf4j
@AllArgsConstructor
public class EiInsUserService {

    private final EiInsUserRepository eiUserRepository;

    private final EiInsUserBaseRepository eiInsUserBaseRepository;

    private final InsRoleUserRepository insRoleUserRepository;

    private final EiInsDepartRepository eiDepartRepository;

    private final DynamicQuery dynamicQuery;

    private final ModelMapper modelMapper;

    private final ProcessDtoToEntityUtil processDtoToEntity;

    private final ProcessEntityToDtoUtil processEntityToDto;

    private final PasswordEncoder passwordEncoder;

    private final TokenProvider tokenProvider;

    private final ApplicationProperties applicationProperties;

    private final RedisService redisService;

    private final AuthenticationManager authenticationManager;

    /**
     * @param loginVM:
     * @return org.springframework.http.ResponseEntity<com.huatonghh.common.util.system.ApiResponse < com.huatonghh.authority.service.dto.JWTToken>>
     * @author Sun
     * @description 登录
     * @date 2019/11/5 21:38
     **/
    public ResponseEntity<ApiResponse<JWTToken>> authorize(LoginVM loginVM) {
        // 保险公司登录标识；
        loginVM.setUsername(AuthorityConstant.INS + loginVM.getUsername());

        UsernamePasswordAuthenticationToken authenticationToken =
            new UsernamePasswordAuthenticationToken(loginVM.getUsername(), loginVM.getPassword());
        Authentication authentication = this.authenticationManager.authenticate(authenticationToken);

        SecurityContextHolder.getContext().setAuthentication(authentication);
        boolean rememberMe = (loginVM.isRememberMe() == null) ? false : loginVM.isRememberMe();
        String jwt = tokenProvider.createToken(authentication, rememberMe);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(AuthorityConstant.AUTHORIZATION_HEADER, AuthorityConstant.PREFIX_TOKEN + jwt);

        // 存储token到redis
        int defaultExpire = applicationProperties.getRedis().getRedisDefaultExpire();
        redisService.set(AuthorityConstant.PREFIX_TOKEN + jwt, loginVM.getUsername(), defaultExpire);

        // 获取登录账号角色，并加入反参
        List<String> loginRoles = SecurityUtils.getLoginRole();
        return new ResponseEntity<>(getApiResponse(jwt, loginRoles), httpHeaders, HttpStatus.OK);
    }


    /**
     * @param loginVM:
     * @return org.springframework.http.ResponseEntity<com.huatonghh.common.util.system.ApiResponse < com.huatonghh.authority.service.dto.JWTToken>>
     * @author Sun
     * @description 登录-验证码
     * @date 2019/11/5 21:39
     **/
    public ResponseEntity<ApiResponse<JWTToken>> authorizeVerify(LoginVerifyVM loginVM) {
        Optional<EiInsUser> eiUserOptional = eiUserRepository.findOneByUserName(loginVM.getUsername());
        if (!eiUserOptional.isPresent()) {
            throw new BusinessException(StatusEnum.USER_NOT_EXISTS);
        }
        EiInsUser eiUser = eiUserOptional.get();
        String verifyKey = CommonConstants.CAPTCHA_CODE_KEY + loginVM.getVerifyuuid();
        String verifyCode = (String) redisService.get(verifyKey);
        if (verifyCode == null || "".equals(verifyCode)) {
            throw new BusinessException(StatusEnum.USER_VERIFYCODE_NOT_EXISTS);
        }
        if (passwordEncoder.matches(loginVM.getPassword(), eiUser.getUserPassword())) {
            if (!verifyCode.equals(loginVM.getVerifycode().toLowerCase())) {
                throw new BusinessException(StatusEnum.USER_ERROR_VERIFYCODE);
            }
        } else {
            throw new BusinessException(StatusEnum.USER_ERROR_PASSWORD);
        }

        // 保险公司登录标识；
        loginVM.setUsername(AuthorityConstant.INS + loginVM.getUsername());
        UsernamePasswordAuthenticationToken authenticationToken =
            new UsernamePasswordAuthenticationToken(loginVM.getUsername(), loginVM.getPassword());
        Authentication authentication = this.authenticationManager.authenticate(authenticationToken);

        SecurityContextHolder.getContext().setAuthentication(authentication);
        boolean rememberMe = (loginVM.isRememberMe() == null) ? false : loginVM.isRememberMe();
        String jwt = tokenProvider.createToken(authentication, rememberMe);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(AuthorityConstant.AUTHORIZATION_HEADER, AuthorityConstant.PREFIX_TOKEN + jwt);

        // 存储token到redis
        int defaultExpire = applicationProperties.getRedis().getRedisDefaultExpire();
        redisService.set(AuthorityConstant.PREFIX_TOKEN + jwt, loginVM.getUsername(), defaultExpire);

        // 获取登录账号角色，并加入反参
        List<String> loginRoles = SecurityUtils.getLoginRole();
        return new ResponseEntity<>(getApiResponse(jwt, loginRoles), httpHeaders, HttpStatus.OK);
    }


    /**
     * @param jwt:        token
     * @param loginRoles: 登录角色
     * @return com.huatonghh.common.util.system.ApiResponse
     * @author Sun
     * @description 获取响应信息
     * @date 2019/11/5 20:36
     **/
    private ApiResponse getApiResponse(String jwt, List<String> loginRoles) {
        return ApiResponse.ofSuccess(new JWTToken(jwt, loginRoles));
    }


    /**
     * @param eiUserCondition:
     * @return com.huatonghh.common.util.system.PageInfo<com.huatonghh.ins_authority.service.dto.EiInsUserDto>
     * @author Sun
     * @description 获取员工分页列表
     * @date 2019/11/5 21:40
     **/
    @Cacheable(cacheNames = InsAuthorityConstant.EI_INS_USERS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null")
    public PageInfo<EiInsUserDto> queryUserListByPage(EiInsUserCondition eiUserCondition) {
        // 根据员工账户名查询分页列表
        String userName = eiUserCondition.getUserName();
        // 获取分页信息
        Integer pageNum = eiUserCondition.getPageNum();
        Integer pageSize = eiUserCondition.getPageSize();
        // 组装查询sql
        StringBuilder sql = new StringBuilder("SELECT ");
        sql.append("u.id as id, ");
        sql.append("u.user_name as userName, ");
        sql.append("u.user_name as userName, ");
        sql.append("u.id_card as idCard, ");
        sql.append("u.phone_no as phoneNo, ");
        sql.append("u.email as email, ");
        sql.append("u.is_valid as valid, ");
        sql.append("u.user_password as userPassword, ");
        sql.append("u.position as position, ");
        sql.append("u.name as name, ");
        sql.append("u.remark as remark ");
        sql.append("FROM ei_ins_user u WHERE ");
        sql.append("IF (?1 != '', u.user_name LIKE CONCAT(?1 ,'%'), 0 = 0) ");

        long total = dynamicQuery.nativeQueryCount("select count(1) from (" + sql + ") a",
            userName);
        sql.append("limit ?2, ?3 ");

        List<EiInsUserDto> eiUserDtoList = dynamicQuery.nativeQueryListModel(EiInsUserDto.class, sql.toString(),
            userName, (pageNum - 1) * pageSize, pageSize);

        return PageInfo.of(pageNum, pageSize, eiUserDtoList, total);
    }


    /**
     * @param userName:
     * @return com.huatonghh.ins_authority.service.dto.EiInsUserDto
     * @author Sun
     * @description 获取某个用户详细信息
     * @date 2019/11/5 21:40
     **/
//    @Cacheable(cacheNames = InsAuthorityConstant.EI_INS_USERS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless="#result == null")
    public EiInsUserDto queryEiUserInfo(String userName) {
        // 懒加载，同时获取用户所属部门信息
        Optional<EiInsUser> eiUserOptional = eiUserRepository.findOneWithAuthoritiesByUserName(userName);
        if (!eiUserOptional.isPresent()) {
            throw new BusinessException(StatusEnum.USER_NOT_LOGIN);
        }
        EiInsUserDto eiUserDto = processEntityToDto.userIns(eiUserOptional.get(), 1);
        if (eiUserDto != null) {
            // 获取员工所属部门信息
            Set<EiInsDepart> departByUserId = eiDepartRepository.findDepartByUserId(eiUserDto.getId());
            Set<EiInsDepartDto> eiDepartDtoList = new HashSet<>();
            departByUserId.forEach(eiDepart -> eiDepartDtoList.add(processEntityToDto.departIns(eiDepart, 0)));
            eiUserDto.setAuthoritiesDepart(eiDepartDtoList);
        }
        return eiUserDto;
    }


    /**
     * @param eiUserDto:
     * @return com.huatonghh.ins_authority.service.dto.EiInsUserDto
     * @author Sun
     * @description 保存员工信息
     * @date 2019/11/5 21:40
     **/
//    @CacheEvict(cacheNames = InsAuthorityConstant.EI_INS_USERS_BY_LOGIN_CACHE, allEntries = true)
    @Transactional(rollbackFor = RuntimeException.class)
    public EiInsUserDto saveEiUser(EiInsUserDto eiUserDto) {
        // 新账户，默认密码；修改账户，使用原密码
        Optional<EiInsUser> eiUserOptional = eiUserRepository.findOneByUserName(eiUserDto.getUserName());
        if (eiUserOptional.isPresent()) {

            EiInsUser oldEiUser = eiUserOptional.get();
            if (eiUserDto.getId() == null) {
                eiUserDto.setId(oldEiUser.getId());
            }
            eiUserDto.setUserPassword(oldEiUser.getUserPassword());
        } else {
            // 设置初始密码；
            eiUserDto.setUserPassword(passwordEncoder.encode(AuthorityConstant.INITIAL_PASSWORD));
        }
        try {

            EiInsUser eiUser = processDtoToEntity.userIns(eiUserDto, 1);
            EiInsUserBase eiInsUserBase = modelMapper.map(eiUser, EiInsUserBase.class);
            eiInsUserBase = eiInsUserBaseRepository.save(eiInsUserBase);

            insRoleUserRepository.deleteByUserId(eiInsUserBase.getId().toString());
            Set<EiRoleDto> authorities = eiUserDto.getAuthorities();
            for (EiRoleDto eiInsRole : authorities) {
                InsRoleUser insRoleUser = new InsRoleUser();
                if (eiInsRole.getRoleId() != null) {
                    insRoleUser.setRoleId(eiInsRole.getRoleId());
                    insRoleUser.setUserId(eiInsUserBase.getId().toString());
                    insRoleUserRepository.save(insRoleUser);
                } else {
                    insRoleUser.setRoleId(10000);
                    insRoleUser.setUserId(eiInsUserBase.getId().toString());
                    insRoleUserRepository.save(insRoleUser);
                }
            }
//            eiUser = eiUserRepository.save(eiUser);

            // 修改完用户、用户角色后，需要更新部门用户表
            Integer userId = eiInsUserBase.getId();
            eiUserRepository.deleteDepartUserByUserId(userId);
            Set<EiInsDepartDto> departList = eiUserDto.getAuthoritiesDepart();
            departList.forEach(eiDepartDto -> eiUserRepository.batchDeleteBaseCodes(eiDepartDto.getId(), userId));
            return processEntityToDto.userIns(eiUser, 1);
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new BusinessException(StatusEnum.AUTHORITY_SAVE_NEW_PASSWORD_ERROR);
        }
    }


    /**
     * @param userName:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiAuthorityDto>
     * @author Sun
     * @description 登录后获取员工权限信息，目前先只写菜单权限
     * @date 2019/11/5 21:40
     **/
    public List<EiAuthorityDto> queryAuthorityByUser(String userName) {
        // 用sql查询某个用户的权限
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT DISTINCT ");
        sql.append("a.id AS id, ");
        sql.append("a.component AS component, ");
        sql.append("a.name AS name, ");
        sql.append("a.valid_status AS status, ");
        sql.append("a.title AS title, ");
        sql.append("a.icon AS icon, ");
        sql.append("a.visible AS visible, ");
        sql.append("a.parent_id AS parentId ,");
        sql.append("a.sort_number AS sortNumber ");
        sql.append("FROM ");
        sql.append("ei_ins_user u, ");
        sql.append("ei_ins_user_role ur, ");
        sql.append("ei_ins_role_authority ra, ");
        sql.append("ei_ins_authority a ");
        sql.append("WHERE ");
        sql.append("u.id = ur.user_id ");
        sql.append("AND ur.role_id = ra.role_id ");
        sql.append("AND ra.authority_id = a.id ");
        sql.append("AND IF (?1 != '', u.user_name = ?1, 0 = 0) ");
        sql.append("order by a.sort_number ");

        // 获取结果
        List<EiAuthority> eiAuthorityList = dynamicQuery.nativeQueryListModel(EiAuthority.class, sql.toString(), userName);

        // mapper成前端对象集合
        return eiAuthorityList.stream().map(eiAuthority -> modelMapper.map(eiAuthority, EiAuthorityDto.class)).collect(Collectors.toList());
    }


    /**
     * @param currentClearTextPassword:
     * @param newPassword:
     * @author Sun
     * @description 修改密码，加了事务，不需要重新save
     * @date 2019/11/5 21:41
     **/
    @CacheEvict(cacheNames = InsAuthorityConstant.EI_INS_USERS_BY_LOGIN_CACHE, allEntries = true)
    @Transactional(rollbackFor = RuntimeException.class)
    public void changePassword(String currentClearTextPassword, String newPassword) {
        SecurityUtils.getCurrentUserLogin()
            .flatMap(eiUserRepository::findOneByUserName)
            .ifPresent(user -> {
                String currentEncryptedPassword = user.getUserPassword();
                if (!passwordEncoder.matches(currentClearTextPassword, currentEncryptedPassword)) {
                    throw new InvalidPasswordException();
                }
                String encryptedPassword = passwordEncoder.encode(newPassword);
                user.setUserPassword(encryptedPassword);
                Console.log("Changed password for User: {}", user);
            });
    }


    /**
     * @author Sun
     * @description 清除缓存
     * @date 2019/11/5 21:41
     **/
    @CacheEvict(cacheNames = InsAuthorityConstant.EI_INS_USERS_BY_LOGIN_CACHE, allEntries = true)
    public void clearCache() {
        log.info("清除缓存成功！！！");
    }


    /**
     * @param userId:
     * @author Sun
     * @description 删除用户
     * @date 2019/11/5 21:41
     **/
    @Caching(evict = {
        @CacheEvict(cacheNames = InsAuthorityConstant.EI_INS_USERS_BY_LOGIN_CACHE, allEntries = true),
        @CacheEvict(cacheNames = InsAuthorityConstant.EI_INS_DEPARTS_BY_LOGIN_CACHE, allEntries = true)
    })
    @Transactional(rollbackFor = Exception.class)
    public void delete(Integer userId) {
        try {
            eiUserRepository.deleteDepartUserByUserId(userId);
            eiUserRepository.deleteById(userId);
        } catch (Exception e) {
            log.error(StatusEnum.AUTHORITY_DELETE_USER_ERROR.getMessage() + ": {}", e.getMessage());
            throw new BusinessException(StatusEnum.AUTHORITY_DELETE_USER_ERROR);
        }
    }


    /**
     * @param departId:
     * @return java.util.List<com.huatonghh.ins_authority.service.dto.EiInsUserDto>
     * @author Sun
     * @description 根据部门id获取其下用户列表
     * @date 2019/11/5 21:41
     **/
    public List<EiInsUserDto> queryDepartLowerUserList(Integer departId) {
        List<EiInsUser> eiUserList = eiUserRepository.findDepartLowerUserList(departId);
        List<EiInsUserDto> eiUserDtoList = Lists.newArrayList();
        eiUserList.forEach(eiUser -> eiUserDtoList.add(processEntityToDto.userIns(eiUser, 0)));
        return eiUserDtoList;
    }

    /**
     * @param departId:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiUserDto>
     * @author Sun
     * @description 根据部门id获取其下用户列表
     * @date 2019/11/5 20:43
     **/
    public PageInfo<EiInsUserDto> queryDepartLowerUserListPage(String departId, Integer pageNo, Integer pageSize) {
        List<EiInsUser> eiUserList = eiUserRepository.findDepartLowerUserListPage(departId, (pageNo - 1) * pageSize, pageSize);
        Integer totle = eiUserRepository.findDepartLowerUserListTotle(departId);
        List<EiInsUserDto> eiUserDtoList = Lists.newArrayList();
        eiUserList.forEach(eiUser -> eiUserDtoList.add(processEntityToDto.userIns(eiUser, 0)));
        return PageInfo.of(pageNo, pageSize, eiUserDtoList, Long.valueOf(totle));
    }


    /**
     * @param accountId: 登录账户
     * @return java.lang.String
     * @author Sun
     * @description 保险公司：根据登录账户，获取账户中文名；生成key value数据集
     * @date 2019/11/6 15:56
     **/
    @Cacheable(cacheNames = InsAuthorityConstant.EI_INS_USERS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null")
    public String queryNameById(Integer accountId) {
        List<ResponseIntegerKeyValueDto> responseIntegerKeyValueDtoList = eiUserRepository.queryNameById(accountId);
        if (responseIntegerKeyValueDtoList != null && responseIntegerKeyValueDtoList.size() > 0) {
            return responseIntegerKeyValueDtoList.get(0).getValue();
        }
        return null;
    }

}
