package com.huatonghh.ins_authority.repository;

import com.huatonghh.ins_authority.domain.InsRoleUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author : Sun
 * @description : 交投集团-用户角色中间表-数据仓库
 * @date : 2019/11/4 20:02
 * @version : 1.0
 */
@Repository
public interface InsRoleUserRepository extends JpaRepository<InsRoleUser, String> {


    void deleteByUserId(String s);
}
