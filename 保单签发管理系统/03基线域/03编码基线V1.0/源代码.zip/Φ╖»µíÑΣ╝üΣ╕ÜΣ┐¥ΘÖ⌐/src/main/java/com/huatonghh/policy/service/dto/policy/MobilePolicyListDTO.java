package com.huatonghh.policy.service.dto.policy;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigInteger;
import java.util.Date;

/**
 * description:手机端保单列表
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2020/1/6
 */
@Data
public class MobilePolicyListDTO {
    @ApiModelProperty(value = "id")
    @JsonSerialize(using = ToStringSerializer.class)
    private BigInteger id;
    @ApiModelProperty(value = "保单号")
    private String policyNo;
    @ApiModelProperty(value = "1车、0非车")
    private Byte carUncarFlag;
    @ApiModelProperty(value = "保险类别")
    private String insuranceCategory;
    @ApiModelProperty(value = "险种代码；例:车（交强、商业）,非车待定")
    private String kindCode;
    @ApiModelProperty(value = "有效起期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyBgnTime;
    @ApiModelProperty(value = "有效止期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyEndTime;
    @ApiModelProperty(value = "车：车牌号")
    private String plateNo;
    @ApiModelProperty(value = "非车：投保产品")
    private String mainRiskDuty;
    @ApiModelProperty(value = "保单状态")
    private Byte status;
}
