package com.huatonghh.base.domain;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

/**
 * @author : Sun
 * @description : 车辆管理-方案套餐
 * @date : 2019/11/5 20:52
 * @version : 1.0
 */
@Entity
@Table(name = "base_template_veh_risk_plan")
@Data
public class TemplateVehRiskPlan implements Serializable {

    private static final long serialVersionUID = -1720355551830686964L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "template_id")
    private Integer templateId;

    @Column(name = "kind_code")
    private String kindCode;

    @Column(name = "risk_code")
    private String riskCode;

    @Column(name = "risk_name")
    private String riskName;

    @Column(name = "amount")
    private String amount;

    @Column(name = "main_additional_flag")
    private Boolean mainAdditionalFlag;

}
