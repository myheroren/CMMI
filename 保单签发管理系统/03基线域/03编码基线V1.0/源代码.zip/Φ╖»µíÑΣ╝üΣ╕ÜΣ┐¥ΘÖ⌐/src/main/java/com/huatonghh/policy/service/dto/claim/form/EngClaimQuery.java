package com.huatonghh.policy.service.dto.claim.form;

import lombok.Data;

import java.util.Date;

/**
 * @author : wh
 * description : 保单号查理赔
 * @version : 1.0
 * @date : 2020/4/1 11:16
 */
@Data
public class EngClaimQuery {
    private String policyNos;
    private Date beginTime;
    private Date endTime;
}
