package com.huatonghh.ins_authority.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;


/**
 * @author wh
 */
@Data
@ApiModel(value = "保险公司")
public class EiInsDepartVO implements Serializable {

    @ApiModelProperty(value = "部门id")
    private Integer id;

    @ApiModelProperty(value = "部门名称")
    private String name;

    @ApiModelProperty(value = "父id")
    private Integer parentId;

    @ApiModelProperty(value = "ids")
    private String ids;

}
