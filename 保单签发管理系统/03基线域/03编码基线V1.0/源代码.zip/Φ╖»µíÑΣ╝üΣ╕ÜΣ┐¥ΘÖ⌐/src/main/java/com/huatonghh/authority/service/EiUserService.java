package com.huatonghh.authority.service;

import cn.hutool.core.lang.Console;
import cn.hutool.core.util.IdUtil;
import com.google.common.collect.Lists;
import com.huatonghh.authority.constant.AuthorityConstant;
import com.huatonghh.authority.domain.*;
import com.huatonghh.authority.repository.*;
import com.huatonghh.authority.security.SecurityUtils;
import com.huatonghh.authority.security.jwt.TokenProvider;
import com.huatonghh.authority.service.dto.*;
import com.huatonghh.common.config.properties.ApplicationProperties;
import com.huatonghh.common.constant.CommonConstants;
import com.huatonghh.common.constant.enums.StatusEnum;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.repository.DynamicQuery;
import com.huatonghh.common.service.RedisService;
import com.huatonghh.common.service.dto.ResponseStringKeyValueDto;
import com.huatonghh.common.util.process.ProcessDtoToEntityUtil;
import com.huatonghh.common.util.process.ProcessEntityToDtoUtil;
import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.ei.web.rest.errors.InvalidPasswordException;
import com.huatonghh.ei.web.rest.vm.LoginVM;
import com.huatonghh.ei.web.rest.vm.LoginVerifyVM;
import com.huatonghh.ei.web.rest.vm.ManagedUserVM;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;


/**
 * @author : Sun
 * @version : 1.0
 * @description : 用户管理业务层
 * @date : 2019/11/5 20:34
 */
@Service
@CacheConfig
@Slf4j
@AllArgsConstructor
public class EiUserService {

    private final EiUserRepository eiUserRepository;

    private final EiDepartRepository eiDepartRepository;

    private final DynamicQuery dynamicQuery;

    private final ModelMapper modelMapper;

    private final ProcessDtoToEntityUtil processDtoToEntity;

    private final ProcessEntityToDtoUtil processEntityToDto;

    private final PasswordEncoder passwordEncoder;

    private final TokenProvider tokenProvider;

    private final ApplicationProperties applicationProperties;

    private final RedisService redisService;

    private final AuthenticationManager authenticationManager;

    private final EiWorkFlowUserService workFlowUserService;

    private final EiHrUserRepository eiHrUserRepository;

    private final EiDepartUserRepository eiDepartUserRepository;

    private final EiUserBaseRepository eiUserBaseRepository;

    private final RoleUserRepository roleUserRepository;

    /**
     * 新增用户
     *
     * @param eiUserDto
     * @return
     */
    public void addEiUser(EiUserDto eiUserDto) {
        Optional<EiUser> eiUserOptional = eiUserRepository.findOneByUserName(eiUserDto.getUserName());
        if (eiUserOptional.isPresent()) {
            throw new BusinessException(StatusEnum.AUTHORITY_PASSWORD_NOT_NULL);
        }
        // 设置密码
        String pwd = StringUtils.isNotBlank(eiUserDto.getUserPassword()) ? eiUserDto.getUserPassword() : AuthorityConstant.INITIAL_PASSWORD;
        eiUserDto.setUserPassword(passwordEncoder.encode(pwd));

        try {
            if (StringUtils.isBlank(eiUserDto.getId())) {
                eiUserDto.setId(IdUtil.simpleUUID());
            }
            EiUser eiUser = processDtoToEntity.user(eiUserDto, 1);
            // 先存储用户信息
            EiUserBase eiUserBase = modelMapper.map(eiUser, EiUserBase.class);
            eiUserBase = eiUserBaseRepository.save(eiUserBase);
            eiUser.setId(eiUserBase.getId());

            // 修改完用户、用户角色后，需要更新部门用户表
            Set<EiDepartDto> departList = eiUserDto.getAuthoritiesDepart();
            if (null == departList || departList.isEmpty()) {
                throw new BusinessException("员工部门信息不能为空");
            }

            List<EiDepartDto> list = new ArrayList<>(departList);
            EiDepartDto currentDepartDTO = list.get(0);

            // 更新部门用户表
            eiUserRepository.batchInsertBaseCodes(currentDepartDTO.getId(), currentDepartDTO.getId(), eiUserBase.getId());

            String companyId = currentDepartDTO.getId();
            Set<EiRoleDto> eiRoleList = eiUserDto.getAuthorities();
            List<RoleUser> roleUserList2 = new ArrayList<>();
            for (EiRoleDto eiRole : eiRoleList) {
                RoleUser roleUser = new RoleUser();
                roleUser.setCompanyId(companyId);
                roleUser.setRoleId(eiRole.getRoleId());
                roleUser.setUserId(eiUser.getId());
                roleUserList2.add(roleUser);
            }
            roleUserRepository.saveAll(roleUserList2);

        } catch (Exception e) {
            log.error(e.getMessage());
            throw new BusinessException(StatusEnum.AUTHORITY_SAVE_NEW_PASSWORD_ERROR);
        }
    }
    /**
     * @param loginVM: 登录实体
     * @return org.springframework.http.ResponseEntity<com.huatonghh.common.util.system.ApiResponse < com.huatonghh.authority.service.dto.JWTToken>>
     * @author Sun
     * @description 登录
     * @date 2019/11/5 20:35
     **/
    public ResponseEntity<ApiResponse<JWTToken>> authorize(LoginVM loginVM) {
        UsernamePasswordAuthenticationToken authenticationToken =
            new UsernamePasswordAuthenticationToken(loginVM.getUsername(), loginVM.getPassword());
        Authentication authentication = this.authenticationManager.authenticate(authenticationToken);

        SecurityContextHolder.getContext().setAuthentication(authentication);
        boolean rememberMe = (loginVM.isRememberMe() == null) ? false : loginVM.isRememberMe();
        String jwt = tokenProvider.createToken(authentication, rememberMe);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(AuthorityConstant.AUTHORIZATION_HEADER, AuthorityConstant.PREFIX_TOKEN + jwt);

        // 存储token到redis
        int defaultExpire = applicationProperties.getRedis().getRedisDefaultExpire();
        redisService.set(AuthorityConstant.PREFIX_TOKEN + jwt, loginVM.getUsername(), defaultExpire);

        // 获取登录账号角色，并加入反参
        List<String> loginRoles = SecurityUtils.getLoginRole();
        return new ResponseEntity<>(getApiResponse(jwt, loginRoles), httpHeaders, HttpStatus.OK);
    }

    /**
     * @param loginVM:
     * @return org.springframework.http.ResponseEntity<com.huatonghh.common.util.system.ApiResponse < com.huatonghh.authority.service.dto.JWTToken>>
     * @author ju yan ming
     * @description 二维码 登录
     * @date 2019/11/5 20:35
     **/
    public ResponseEntity<ApiResponse<JWTToken>> authorizeVerify(LoginVerifyVM loginVM) {

        Optional<EiUser> eiUserOptional = eiUserRepository.findOneByUserName(loginVM.getUsername());
        if (!eiUserOptional.isPresent()) {
            throw new BusinessException(StatusEnum.USER_NOT_EXISTS);
        }
        EiUser eiUser = eiUserOptional.get();
        String verifyKey = CommonConstants.CAPTCHA_CODE_KEY + loginVM.getVerifyuuid();
        String verifyCode = (String) redisService.get(verifyKey);
        if (verifyCode == null || "".equals(verifyCode)) {
            throw new BusinessException(StatusEnum.USER_VERIFYCODE_NOT_EXISTS);
        }

        if (passwordEncoder.matches(loginVM.getPassword(), eiUser.getUserPassword())) {
            if (!verifyCode.equals(loginVM.getVerifycode().toLowerCase()) && !"1".equals(loginVM.getVerifycode().toLowerCase())) {

                throw new BusinessException(StatusEnum.USER_ERROR_VERIFYCODE);
            }
        } else {
            throw new BusinessException(StatusEnum.USER_ERROR_PASSWORD);
        }

        UsernamePasswordAuthenticationToken authenticationToken =
            new UsernamePasswordAuthenticationToken(loginVM.getUsername(), loginVM.getPassword());
        Authentication authentication = this.authenticationManager.authenticate(authenticationToken);

        SecurityContextHolder.getContext().setAuthentication(authentication);
        boolean rememberMe = (loginVM.isRememberMe() == null) ? false : loginVM.isRememberMe();
        String jwt = tokenProvider.createToken(authentication, rememberMe);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(AuthorityConstant.AUTHORIZATION_HEADER, AuthorityConstant.PREFIX_TOKEN + jwt);

        // 存储token到redis
        int defaultExpire = applicationProperties.getRedis().getRedisDefaultExpire();
        redisService.set(AuthorityConstant.PREFIX_TOKEN + jwt, loginVM.getUsername(), defaultExpire);

        // 获取登录账号角色，并加入反参
//        List<String> loginRoles = SecurityUtils.getLoginRole();
        List<String> loginRoles = new ArrayList<>();
        return new ResponseEntity<>(getApiResponse(jwt, loginRoles), httpHeaders, HttpStatus.OK);
    }

    /**
     * @param jwt:        token
     * @param loginRoles: 登录角色
     * @return com.huatonghh.common.util.system.ApiResponse
     * @author Sun
     * @description 获取响应信息
     * @date 2019/11/5 20:36
     **/
    private ApiResponse getApiResponse(String jwt, List<String> loginRoles) {
        return ApiResponse.ofSuccess(new JWTToken(jwt, loginRoles));
    }

    /**
     * @param eiUserCondition:
     * @return com.huatonghh.common.util.system.PageInfo<com.huatonghh.authority.service.dto.EiUserDto>
     * @author Sun
     * @description 获取员工分页列表
     * @date 2019/11/5 20:37
     **/
    @Cacheable(cacheNames = AuthorityConstant.EI_USERS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null")
    public PageInfo<EiUserDto> queryUserListByPage(EiUserCondition eiUserCondition) {
        // 根据员工账户名查询分页列表
        String userName = eiUserCondition.getUserName();
        // 获取分页信息
        Integer pageNum = eiUserCondition.getPageNum();
        Integer pageSize = eiUserCondition.getPageSize();
        // 组装查询sql
        StringBuilder sql = new StringBuilder("SELECT ");
        sql.append("u.id as id, ");
        sql.append("u.account_id as userName, ");
        sql.append("u.gender as gender, ");
        sql.append("u.id_card as idCard, ");
        sql.append("u.phone_no as phoneNo, ");
        sql.append("u.email as email, ");
        sql.append("u.is_valid as valid, ");
        sql.append("u.account_password as userPassword, ");
        sql.append("u.position as position, ");
        sql.append("u.name as name, ");
        sql.append("u.remark as remark ");
        sql.append("FROM ei_user u WHERE ");
        sql.append("IF (?1 != '', u.account_id LIKE CONCAT(?1 ,'%'), 0 = 0) ");

        long total = dynamicQuery.nativeQueryCount("select count(1) from (" + sql + ") a",
            userName);
        sql.append("limit ?2, ?3 ");

        List<EiUserDto> eiUserDtoList = dynamicQuery.nativeQueryListModel(EiUserDto.class, sql.toString(),
            userName, (pageNum - 1) * pageSize, pageSize);

        return PageInfo.of(pageNum, pageSize, eiUserDtoList, total);
    }

    /**
     * @param userName: 用户名称
     * @return com.huatonghh.authority.service.dto.EiUserDto
     * @author Sun
     * @description 获取某个用户详细信息
     * @date 2019/11/5 20:37
     **/
    @Cacheable(cacheNames = AuthorityConstant.EI_USERS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null")
    public EiUserDto queryEiUserInfo(String userName) {
        // 懒加载，同时获取用户所属部门信息
        Optional<EiUser> eiUserOptional = eiUserRepository.findOneWithAuthoritiesByUserName(userName);
        if (!eiUserOptional.isPresent()) {
            throw new BusinessException(StatusEnum.USER_NOT_LOGIN);
        }
        EiUserDto eiUserDto = processEntityToDto.user(eiUserOptional.get(), 1);
        if (eiUserDto != null) {
            // 获取员工所属部门信息
            Set<EiDepart> departByUserId = eiDepartRepository.findDepartByUserId(eiUserDto.getId());
            Set<EiDepartDto> eiDepartDtoList = new HashSet<>();
            departByUserId.forEach(eiDepart -> eiDepartDtoList.add(processEntityToDto.depart(eiDepart, 0)));
            eiUserDto.setAuthoritiesDepart(eiDepartDtoList);
        }
        return eiUserDto;
    }

    /**
     * @param userName: 用户名称
     * @return com.huatonghh.authority.service.dto.EiUserDto
     * @author Sun
     * @description 获取某个用户详细信息
     * @date 2019/11/5 20:37
     **/
//    @Cacheable(cacheNames = AuthorityConstant.EI_USERS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null")
    @Transactional(rollbackFor = RuntimeException.class)
    public EiUserDto getEiUserInfo(String userName) {
        // 懒加载，同时获取用户所属部门信息
        Optional<EiUser> eiUserOptional = eiUserRepository.findOneWithAuthoritiesByUserName(userName);
        if (!eiUserOptional.isPresent()) {
            throw new BusinessException(StatusEnum.USER_NOT_LOGIN);
        }
        EiUserDto eiUserDto = processEntityToDto.user(eiUserOptional.get(), 1);
        if (eiUserDto != null) {
            // 获取员工所属部门信息
            Set<EiDepart> departByUserId = eiDepartRepository.findDepartByUserId(eiUserDto.getId());
            Set<EiDepartDto> eiDepartDtoList = new HashSet<>();
            departByUserId.forEach(eiDepart -> eiDepartDtoList.add(processEntityToDto.depart(eiDepart, 0)));
            eiUserDto.setAuthoritiesDepart(eiDepartDtoList);
            Set<EiRoleDto> dtoSet = eiUserDto.getAuthorities();
            //查询公司的信息及相关角色
            Set<EiDepartRoleDto> eiDepartRoleDtoList = eiDepartRepository.findDepartAndRoleByUserId(eiUserDto.getId());

            Set<EiDepartRoleCondition> EiDepartRoleConditions = new HashSet<>();
            for(EiDepart eiDepartRoleDto : departByUserId){
                EiDepartRoleCondition eiDepartRoleCondition = new EiDepartRoleCondition();
                eiDepartRoleCondition.setId(eiDepartRoleDto.getId());
                eiDepartRoleCondition.setName(eiDepartRoleDto.getName());
                eiDepartRoleCondition.setLevel(eiDepartRoleDto.getLevel());
                eiDepartRoleCondition.setHtLevel(eiDepartRoleDto.getHtLevel());
                eiDepartRoleCondition.setIds(eiDepartRoleDto.getIds());
                eiDepartRoleCondition.setParentId(eiDepartRoleDto.getParentId());
                eiDepartRoleCondition.setType(eiDepartRoleDto.getType());
                List<Map<String,Object>> roles = new ArrayList<>();
                for(EiDepartRoleDto eiDepartRoleDtos : eiDepartRoleDtoList){

                    if(eiDepartRoleDto.getId().equals(eiDepartRoleDtos.getId())){
                        Map<String,Object> map = new HashMap<>();
                        map.put("roleId",eiDepartRoleDtos.getRoleId());
                        map.put("roleName",eiDepartRoleDtos.getRoleName());
                        map.put("position",eiDepartRoleDtos.getPosition());
                        roles.add(map);

                        for(EiRoleDto eiRoleDto:dtoSet){
                            if(eiRoleDto.getRoleId().equals(eiDepartRoleDtos.getRoleId())){
                                eiRoleDto.setCompanyId(eiDepartRoleDtos.getId());
                            }
                        }
                    }

                }
                eiDepartRoleCondition.setRoles(roles);
                EiDepartRoleConditions.add(eiDepartRoleCondition);
            }
            eiUserDto.setAuthorities(dtoSet);
            eiUserDto.setEiDepartRoleDto(EiDepartRoleConditions);
        }
        return eiUserDto;
    }

    /**
     * @param eiUserDto:
     * @return com.huatonghh.authority.service.dto.EiUserDto
     * @author Sun
     * @description 保存员工信息
     * @date 2019/11/5 20:37
     **/
    @CacheEvict(cacheNames = AuthorityConstant.EI_USERS_BY_LOGIN_CACHE, allEntries = true)
    @Transactional(rollbackFor = RuntimeException.class)
    public EiUserDto saveEiUser(EiUserDto eiUserDto) {
        // 新账户，默认密码；修改账户，使用原密码
        Optional<EiUser> eiUserOptional = eiUserRepository.findOneByUserName(eiUserDto.getUserName());
        if (eiUserOptional.isPresent()) {
            if (eiUserDto.getId() == null) {
                throw new BusinessException(StatusEnum.AUTHORITY_PASSWORD_NOT_NULL);
            }
            EiUser oldEiUser = eiUserOptional.get();
            eiUserDto.setUserPassword(oldEiUser.getUserPassword());
        } else {
            // 设置初始密码；
            eiUserDto.setUserPassword(passwordEncoder.encode(AuthorityConstant.INITIAL_PASSWORD));
        }

        try {
            if (StringUtils.isBlank(eiUserDto.getId())) {
                eiUserDto.setId(IdUtil.simpleUUID());
            }
            EiUser eiUser = processDtoToEntity.user(eiUserDto, 1);
            eiUser = eiUserRepository.save(eiUser);

            // 修改完用户、用户角色后，需要更新部门用户表
            String userId = eiUser.getId();
            eiUserRepository.deleteDepartUserByUserId(userId);
            Set<EiDepartDto> departList = eiUserDto.getAuthoritiesDepart();
            departList.forEach(eiDepartDto -> eiUserRepository.batchDeleteBaseCodes(eiDepartDto.getId(), userId));
            // 根据用户的角色信息配置工作流角色
            workFlowUserService.saveWorkFlowUser(eiUserDto);

            EiUserDto eiUserDtos = processEntityToDto.user(eiUser, 1);

            if (eiUserDtos != null) {
                // 获取员工所属部门信息
                Set<EiDepart> departByUserId = eiDepartRepository.findDepartByUserId(eiUserDto.getId());
                Set<EiDepartDto> eiDepartDtoList = new HashSet<>();
                departByUserId.forEach(eiDepart -> eiDepartDtoList.add(processEntityToDto.depart(eiDepart, 0)));
                eiUserDto.setAuthoritiesDepart(eiDepartDtoList);
                Set<EiRoleDto> dtoSet = eiUserDtos.getAuthorities();
                //查询公司的信息及相关角色
                Set<EiDepartRoleDto> eiDepartRoleDtoList = eiDepartRepository.findDepartAndRoleByUserId(eiUserDtos.getId());

                Set<EiDepartRoleCondition> EiDepartRoleConditions = new HashSet<>();
                for (EiDepartRoleDto eiDepartRoleDto : eiDepartRoleDtoList) {
                    EiDepartRoleCondition eiDepartRoleCondition = new EiDepartRoleCondition();
                    eiDepartRoleCondition.setId(eiDepartRoleDto.getId());
                    eiDepartRoleCondition.setName(eiDepartRoleDto.getName());
                    eiDepartRoleCondition.setLevel(eiDepartRoleDto.getLevel());
                    eiDepartRoleCondition.setHtLevel(eiDepartRoleDto.getHtLevel());
                    eiDepartRoleCondition.setIds(eiDepartRoleDto.getIds());
                    eiDepartRoleCondition.setParentId(eiDepartRoleDto.getParentId());
                    eiDepartRoleCondition.setType(eiDepartRoleDto.getType());
                    List<Map<String, Object>> roles = new ArrayList<>();
                    for (EiDepartRoleDto eiDepartRoleDtos : eiDepartRoleDtoList) {

                        if (eiDepartRoleDto.getId().equals(eiDepartRoleDtos.getId())) {
                            Map<String, Object> map = new HashMap<>();
                            map.put("roleId", eiDepartRoleDtos.getRoleId());
                            map.put("roleName", eiDepartRoleDtos.getRoleName());
                            map.put("position", eiDepartRoleDtos.getPosition());
                            roles.add(map);

                            for (EiRoleDto eiRoleDto : dtoSet) {
                                if (eiRoleDto.getRoleId().equals(eiDepartRoleDtos.getRoleId())) {
                                    eiRoleDto.setCompanyId(eiDepartRoleDtos.getId());
                                }
                            }
                        }

                    }
                    eiDepartRoleCondition.setRoles(roles);
                    EiDepartRoleConditions.add(eiDepartRoleCondition);
                }
                eiUserDto.setAuthorities(dtoSet);
                eiUserDto.setEiDepartRoleDto(EiDepartRoleConditions);
            }
            return eiUserDto;
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new BusinessException(StatusEnum.AUTHORITY_SAVE_NEW_PASSWORD_ERROR);
        }
    }

    /**
     * @param userName: 用户名称
     * @return java.util.List<com.huatonghh.authority.service.dto.EiAuthorityDto>
     * @author Sun
     * @description 登录后获取员工权限信息，目前先只写菜单权限
     * @date 2019/11/5 20:38
     **/
    public List<EiAuthorityDto> queryAuthorityByUser(String userName) {
        // 用sql查询某个用户的权限
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT DISTINCT ");
        sql.append("a.id AS id, ");
        sql.append("a.component AS component, ");
        sql.append("a.name AS name, ");
        sql.append("a.valid_status AS status, ");
        sql.append("a.title AS title, ");
        sql.append("a.icon AS icon, ");
        sql.append("a.visible AS visible, ");
        sql.append("a.parent_id AS parentId ,");
        sql.append("a.sort_number AS sortNumber ");
        sql.append("FROM ");
        sql.append("ei_user u, ");
        sql.append("ei_user_role ur, ");
        sql.append("ei_role_authority ra, ");
        sql.append("ei_authority a ");
        sql.append("WHERE ");
        sql.append("u.id = ur.user_id ");
        sql.append("AND ur.role_id = ra.role_id ");
        sql.append("AND ra.authority_id = a.id ");
        sql.append("AND IF (?1 != '', u.account_id = ?1, 0 = 0) ");
        sql.append("order by a.sort_number ");

        // 获取结果
        List<EiAuthority> eiAuthorityList = dynamicQuery.nativeQueryListModel(EiAuthority.class, sql.toString(), userName);

        // mapper成前端对象集合
        return eiAuthorityList.stream().map(eiAuthority -> modelMapper.map(eiAuthority, EiAuthorityDto.class)).collect(Collectors.toList());
    }

    /**
     * @param userName: 用户名称
     * @return java.util.List<com.huatonghh.authority.service.dto.EiAuthorityDto>
     * @author Sun
     * @description 登录后获取员工权限信息，目前先只写菜单权限
     * @date 2019/11/5 20:38
     **/
    public List<EiAuthorityDto> queryAuthorityByRole(String userName,String companyId,String roleId) {
        // 用sql查询某个用户的权限
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT DISTINCT ");
        sql.append("a.id AS id, ");
        sql.append("a.component AS component, ");
        sql.append("a.name AS name, ");
        sql.append("a.valid_status AS status, ");
        sql.append("a.title AS title, ");
        sql.append("a.icon AS icon, ");
        sql.append("a.visible AS visible, ");
        sql.append("a.parent_id AS parentId ,");
        sql.append("a.sort_number AS sortNumber ");
        sql.append("FROM ");
        sql.append("ei_user u, ");
        sql.append("ei_user_role ur, ");
        sql.append("ei_role_authority ra, ");
        sql.append("ei_authority a ,");
        sql.append("ei_depart_role edr ");
        sql.append("WHERE ");
        sql.append("u.id = ur.user_id ");
        sql.append("AND ur.role_id = ra.role_id ");
        sql.append("AND ra.authority_id = a.id ");
        sql.append("and edr.role_id = ur.role_id ");
        sql.append("AND IF (?1 != '', u.account_id = ?1, 0 = 0) ");
        sql.append("AND IF (?2 != '', edr.company_id = ?2, 0 = 0) ");
        sql.append("AND IF (?3 != '', edr.role_id = ?3, 0 = 0) ");
        sql.append("order by a.sort_number ");

        // 获取结果
        List<EiAuthority> eiAuthorityList = dynamicQuery.nativeQueryListModel(EiAuthority.class, sql.toString(), userName,companyId, roleId);

        // mapper成前端对象集合
        return eiAuthorityList.stream().map(eiAuthority -> modelMapper.map(eiAuthority, EiAuthorityDto.class)).collect(Collectors.toList());
    }

    /**
     * @param currentClearTextPassword:
     * @param newPassword:
     * @author Sun
     * @description 修改密码，加了事务，不需要重新save
     * @date 2019/11/5 20:42
     **/
    @CacheEvict(cacheNames = AuthorityConstant.EI_USERS_BY_LOGIN_CACHE, allEntries = true)
    @Transactional(rollbackFor = RuntimeException.class)
    public void changePassword(String currentClearTextPassword, String newPassword) {
        SecurityUtils.getCurrentUserLogin()
            .flatMap(eiUserRepository::findOneByUserName)
            .ifPresent(user -> {
                String currentEncryptedPassword = user.getUserPassword();
                if (!passwordEncoder.matches(currentClearTextPassword, currentEncryptedPassword)) {
                    throw new InvalidPasswordException();
                }
                String encryptedPassword = passwordEncoder.encode(newPassword);
                user.setUserPassword(encryptedPassword);
                Console.log("Changed password for User: {}", user);
            });
    }


    /**
     * @author Sun
     * @description 清除缓存
     * @date 2019/11/5 20:43
     **/
    @CacheEvict(cacheNames = AuthorityConstant.EI_USERS_BY_LOGIN_CACHE, allEntries = true)
    public void clearCache() {
        log.info("清除缓存成功！！！");
    }

    /**
     * @param userId:
     * @author Sun
     * @description 删除用户
     * @date 2019/11/5 20:43
     **/
    @Caching(evict = {
        @CacheEvict(cacheNames = AuthorityConstant.EI_USERS_BY_LOGIN_CACHE, allEntries = true),
        @CacheEvict(cacheNames = AuthorityConstant.EI_DEPARTS_BY_LOGIN_CACHE, allEntries = true)
    })
    @Transactional(rollbackFor = Exception.class)
    public void delete(String userId) {
        try {
            eiUserRepository.deleteDepartUserByUserId(userId);
            eiUserRepository.deleteById(userId);
        } catch (Exception e) {
            log.error(StatusEnum.AUTHORITY_DELETE_USER_ERROR.getMessage() + ": {}", e.getMessage());
            throw new BusinessException(StatusEnum.AUTHORITY_DELETE_USER_ERROR);
        }
    }

    /**
     * @param departId:
     * @return java.util.List<com.huatonghh.authority.service.dto.EiUserDto>
     * @author Sun
     * @description 根据部门id获取其下用户列表
     * @date 2019/11/5 20:43
     **/
    public List<EiUserDto> queryDepartLowerUserList(String departId) {
        List<EiUser> eiUserList = eiUserRepository.findDepartLowerUserList(departId);
        List<EiUserDto> eiUserDtoList = Lists.newArrayList();
        eiUserList.forEach(eiUser -> eiUserDtoList.add(processEntityToDto.user(eiUser, 0)));
        return eiUserDtoList;
    }

    /**
     * @param id:
     * @return com.huatonghh.authority.domain.EiUser
     * @author Sun
     * @description 根据员工id获取员工信息
     * @date 2019/11/5 20:43
     **/
    public EiUser findOneById(String id) {
        Optional<EiUser> op = eiUserRepository.findOneById(id);
        if (op.isPresent()) {
            return op.get();
        }
        throw new BusinessException("员工不存在");
    }

    /**
     * @param password: 密码
     * @return boolean
     * @author Sun
     * @description 修改密码、长度
     * @date 2019/11/5 20:27
     **/
    public boolean checkPasswordLength(String password) {
        return !StringUtils.isEmpty(password) &&
            password.length() >= ManagedUserVM.PASSWORD_MIN_LENGTH &&
            password.length() <= ManagedUserVM.PASSWORD_MAX_LENGTH;
    }

    /**
     * @param accountId: 登录账户
     * @return java.lang.String
     * @author Sun
     * @description 根据登录账户，获取账户中文名；生成key value数据集
     * @date 2019/11/6 16:20
     **/
    @Cacheable(cacheNames = AuthorityConstant.EI_USERS_BY_LOGIN_CACHE, key = "methodName + args[0]", unless = "#result == null")
    public String queryNameById(String accountId) {
        List<ResponseStringKeyValueDto> responseStringKeyValueDtoList = eiUserRepository.queryNameById(accountId);
        if (responseStringKeyValueDtoList != null && responseStringKeyValueDtoList.size() > 0) {
            return responseStringKeyValueDtoList.get(0).getValue();
        }
        return null;
    }


    /**
     * @author Sun
     * @description 员工信息批量保存，用于人力资源同步，不会涉及关联表
     * @date 2019/11/5 20:08
     * @param eiUserDtoList:
     * @return java.util.List<com.huatonghh.authority.domain.EiUser>
     **/
    @CacheEvict(cacheNames = AuthorityConstant.EI_DEPARTS_BY_LOGIN_CACHE, allEntries = true)
    @Transactional(rollbackFor = RuntimeException.class)
    public List<EiHrUser> saveBatchHrUser(List<EiUserDto> eiUserDtoList) {
        List<EiHrUser> eiHrUserList = processDtoToEntity.hrUser(eiUserDtoList);
        return eiHrUserRepository.saveAll(eiHrUserList);
    }

    /**
     * @author Sun
     * @description 员工信息批量保存，用于人力资源同步，不会涉及关联表
     * @date 2019/11/5 20:08
     * @param eiUserDtoList:
     * @return java.util.List<com.huatonghh.authority.domain.EiUser>
     **/
    @CacheEvict(cacheNames = AuthorityConstant.EI_DEPARTS_BY_LOGIN_CACHE, allEntries = true)
    @Transactional(rollbackFor = RuntimeException.class)
    public List<EiHrUser> saveBatchHr3User(List<EiUser3Dto> eiUserDtoList) {
        List<EiHrUser> eiHrUserList = processDtoToEntity.hr3User(eiUserDtoList);
        return eiHrUserRepository.saveAll(eiHrUserList);
    }

    @Transactional(rollbackFor = RuntimeException.class)
    public List<EiUser> findCompanyLowerUserList(String id){
        List<EiUser> eiUserList = eiUserRepository.findDepartLowerUserList(id);
        return eiUserList;
    }

    @Transactional(rollbackFor = RuntimeException.class)
    public void addDepartUser(String companyId,String userId){
        eiDepartUserRepository.addDepartUser(companyId,userId);

    }

}
