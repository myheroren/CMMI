package com.huatonghh.policy.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author ghy
 * Date: 2020/12/15 16:17
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel("授权DTO")
public class EmpowreDTO {

    @ApiModelProperty("计划编号")
    private String planNo;

    @ApiModelProperty("项目编号")
    private String projNo;

    @ApiModelProperty("授权保司")
    private String belongCompany;

    @ApiModelProperty("文件Id")
    private Integer fileId;

    @ApiModelProperty("文件名")
    private String fileName;


}
