package com.huatonghh.base.web.rest;

import com.huatonghh.base.config.WebSocketServer;
import com.huatonghh.common.util.system.ApiResponse;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author : Sun
 * @description : 消息推送
 * @date : 2019/11/5 21:14
 * @version : 1.0
 */
@RestController
@RequestMapping("/checkcenter")
@Slf4j
@Api(tags="32、消息推送", value = "消息推送")
public class CheckCenterController {

    /**
     * @author Sun
     * @description 页面请求
     * @date 2019/11/5 21:15
     * @param cid:
     * @return org.springframework.web.servlet.ModelAndView
     **/
    @GetMapping("/socket/{cid}")
    public ModelAndView socket(@PathVariable String cid) {
        ModelAndView mav=new ModelAndView("/socket");
        mav.addObject("cid", cid);
        return mav;
    }


    /**
     * @author Sun
     * @description 推送数据接口
     * @date 2019/11/5 21:15
     * @param cid:
     * @param message:
     * @return com.huatonghh.common.util.system.ApiResponse
     **/
    @PostMapping
    @ResponseBody
    @RequestMapping("/socket/push/{cid}")
    public ApiResponse pushToWeb(@PathVariable String cid,String message) {
        WebSocketServer.sendInfo(message,cid);
        return ApiResponse.ofSuccess(cid);
    }


    /**
     * @author Sun
     * @description 推送一个对象
     * @date 2019/11/5 21:15
     * @param cid:
     * @param message:
     * @return com.huatonghh.common.util.system.ApiResponse
     **/
    @ResponseBody
    @PostMapping
    @RequestMapping("/socket/push_json/{cid}")
    @CrossOrigin
    public ApiResponse pushToWebJson(@PathVariable String cid, String message) {
        String s = "{\"date\":\"2019-05-02\",\"name\":\"孙大帅" + message + "\",\"address\":\"甲骨文球馆\"}";
        log.info("发送消息：" + s);
        WebSocketServer.sendInfo(s, cid);
        return ApiResponse.ofSuccess(cid);
    }

}
