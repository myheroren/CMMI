package com.huatonghh.authority.service;

import com.huatonghh.authority.constant.EiWorkFlowConstant;
import com.huatonghh.authority.domain.EiWorkFlowUser;
import com.huatonghh.authority.repository.EiWorkFlowUserRepository;
import com.huatonghh.authority.service.dto.EiDepartDto;
import com.huatonghh.authority.service.dto.EiRoleDto;
import com.huatonghh.authority.service.dto.EiUserDto;
import com.huatonghh.policy.constant.PlanConstant;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/11
 */
@Service
@Slf4j
@AllArgsConstructor
public class EiWorkFlowUserService {

    private EiWorkFlowUserRepository workFlowUserRepository;
    private final EiRoleService eiRoleService;

    /**
     * 根据用户的角色设置工作流配置
     *
     * @param eiUserDto 用户
     */
    public void saveWorkFlowUser(EiUserDto eiUserDto) {
        // 删除现有的员工配置，重新插入新的配置
        workFlowUserRepository.delete(eiUserDto.getId());
        // 取所有角色
        Set<EiRoleDto> authorities = eiUserDto.getAuthorities();
        if (null == authorities || authorities.isEmpty()) {
            return;
        }
        List<EiRoleDto> roleList = new ArrayList<>(authorities);
        List<EiWorkFlowUser> workFlowUsers = new ArrayList<>(authorities.size());
        Set<EiDepartDto> departsSet = eiUserDto.getAuthoritiesDepart();
        List<EiDepartDto> departs = new ArrayList<>(departsSet);
        String departId = departs.get(0).getId();
        // 根据员工的角色新建配置
        for (EiRoleDto dto : roleList) {
            EiWorkFlowUser workFlowUser = new EiWorkFlowUser();
            Integer level = null;
            Integer parentLevel = null;
            Byte position = eiRoleService.queryRoleInfo(dto.getRoleId()).getPosition();
            // 员工
            if (PlanConstant.HT_POSITION_STAFF.equals(position)) {
                level = EiWorkFlowConstant.WORK_FLOW_STAFF;
                parentLevel = EiWorkFlowConstant.WORK_FLOW_MANAGER;
            }
            // 经理
            if (PlanConstant.HT_POSITION_MANAGER.equals(position)) {
                level = EiWorkFlowConstant.WORK_FLOW_MANAGER;
                parentLevel = EiWorkFlowConstant.WORK_FLOW_LEADER;
            }
            // 领导
            if (PlanConstant.HT_POSITION_LEADER.equals(position)) {
                level = EiWorkFlowConstant.WORK_FLOW_LEADER;
                parentLevel = EiWorkFlowConstant.WORK_FLOW_DEFAULT;
            }
            workFlowUser.setLevel(level);
            workFlowUser.setParentLevel(parentLevel);
            workFlowUser.setDepartId(departId);
            workFlowUser.setUserId(eiUserDto.getId());
            workFlowUser.setRoleId(dto.getRoleId());
            workFlowUsers.add(workFlowUser);
        }
        workFlowUserRepository.saveAll(workFlowUsers);
    }

}
