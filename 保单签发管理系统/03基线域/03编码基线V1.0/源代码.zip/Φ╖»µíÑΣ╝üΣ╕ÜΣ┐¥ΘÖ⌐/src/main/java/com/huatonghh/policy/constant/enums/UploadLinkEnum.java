package com.huatonghh.policy.constant.enums;

/**
 * @author : hao.wang
 * @date : 2019/9/4
 * description :
 */

public enum UploadLinkEnum {

    /**
     * 计划环节
     * 有taskId的传默认，没有的只有三种情况，11,12,13
     * 项目环节
     */
    BELONG_TYPE_PLAN_BATCH((byte) 11, "发起计划"),
    BELONG_TYPE_PLAN_ANNUAL((byte) 12, "补充计划"),
    BELONG_TYPE_PLAN_GATHER((byte) 13, "汇总计划"),
    BELONG_TYPE_PLAN_SOLUTION((byte) 14, "提交方案"),
    BELONG_TYPE_PLAN_CONFIRM((byte) 15, "确认方案"),
    BELONG_TYPE_PLAN_ASSIGN((byte) 16, "分配保司"),
    BELONG_TYPE_PLAN_DEFAULT((byte) 17, "默认"),

    BELONG_TYPE_PROJECT_SAVE((byte) 21, "发起项目"),


    BELONG_TYPE_Project_DEFAULT((byte) 27, "默认");


    /**
     * 描述
     */
    private String desc;
    /**
     * 代码
     */
    private Byte code;

    UploadLinkEnum(Byte code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String desc() {
        return this.desc;
    }

    public Byte code() {
        return this.code;
    }
}
