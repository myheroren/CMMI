package com.huatonghh.policy.domain.plan;

import java.util.Date;
import java.io.Serializable;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigInteger;

/**
 * 保险计划_主表(InsPlan)表实体类
 *
 * @author juyanming
 * @since 2020-09-23 14:01:29
 */
@Entity
@Table(name = "ins_plan")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Api(tags = "保险计划_主表")
@EntityListeners(AuditingEntityListener.class)
public class PlanEntity implements Serializable {

    private static final long serialVersionUID=559891610470164325L;
    @ApiModelProperty(value = "保险计划编号,如IR20200923001")
    @Id
//    @GenericGenerator(name = "MyIdGenerator", strategy = "com.huatonghh.common.idgenerator.MyIdGenerator")
//    @GeneratedValue(generator = "MyIdGenerator")
    @Column(name = "plan_no",nullable = false,unique = true)
    private String planNo;

    @ApiModelProperty(value = "保险计划名称")
    @Column(name = "plan_name")
    private String planName;

    @ApiModelProperty(value = "发起公司")
    @Column(name = "start_company")
    private String startCompany;

    @ApiModelProperty(value = "发起公司中文名")
    @Column(name = "start_company_name")
    private String startCompanyName;

    @ApiModelProperty(value = "发起人")
    @Column(name = "start_user")
    private String startUser;

    @ApiModelProperty(value = "发起人中文名")
    @Column(name = "start_user_name")
    private String startUserName;

    @ApiModelProperty(value = "预估总保费(分)")
    @Column(name = "est_premium")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger estPremium;

    @ApiModelProperty(value = "处理人名字")
    @Column(name = "handler")
    private String handler;

    @ApiModelProperty(value = "处理人账号")
    @Column(name = "handler_code")
    private String handlerCode;

    @ApiModelProperty(value = "保险计划状态，0暂存,1审核中,2被驳回,3审核完成,4招标完成")
    @Column(name = "status")
    private Byte status;

    @ApiModelProperty(value = "创建时间，实体关联")
    @Column(name = "create_time")
    private Date createTime;

    @ApiModelProperty(value = "更新时间，实体关联")
    @Column(name = "update_time")
    @LastModifiedDate
    private Date updateTime;

    @ApiModelProperty(value = "提交审核时间")
    @Column(name = "apply_time")
    private Date applyTime;

    @ApiModelProperty(value = "项目名称")
    @Column(name = "proj_name")
    private String projName;

    @ApiModelProperty(value = "项目地址")
    @Column(name = "proj_addr")
    private String projAddr;

    @ApiModelProperty(value = "项目详细地址")
    @Column(name = "proj_detail_addr")
    private String projDetailAddr;

    @ApiModelProperty(value = "联系人")
    @Column(name = "contact")
    private String contact;

    @ApiModelProperty(value = "联系电话")
    @Column(name = "contact_number")
    private String contactNumber;

    @ApiModelProperty(value = "是否失效；1有效, 0无效")
    @Column(name = "is_valid")
    private Byte isValid = 1;

    @ApiModelProperty(value = "当前计划是否对以及公司可见,1可见,2不可见")
    @Column(name = "visible_for_first")
    private Byte visibleForFirst;


}
