package com.huatonghh.file.repository;

import com.huatonghh.file.domain.FiFile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author : Sun
 * @description : 文件表-数据仓库
 * @date : 2019/11/5 21:24
 * @version : 1.0
 */
@Repository
public interface FiFileRepository extends JpaRepository<FiFile, Integer> {

}
