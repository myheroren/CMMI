package com.huatonghh.policy.constant;

/**
 * description:车常量
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/3
 */
public class CarConstant {

    /**
     * 转移状态
     * 0初始化 1申请 2完成 3拒绝，
     */
    public static final Byte CAR_TRANSFER_STATUS_INIT = 0;
    public static final Byte CAR_TRANSFER_STATUS_APPLY = 1;
    public static final Byte CAR_TRANSFER_STATUS_DOWN = 2;
    public static final Byte CAR_TRANSFER_STATUS_REFUSE = 3;

}
