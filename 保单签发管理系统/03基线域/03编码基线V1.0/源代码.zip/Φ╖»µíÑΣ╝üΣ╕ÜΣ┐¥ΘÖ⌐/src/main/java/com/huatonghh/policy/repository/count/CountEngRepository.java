package com.huatonghh.policy.repository.count;

import com.huatonghh.policy.domain.count.CountEng;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/11
 */
public interface CountEngRepository extends JpaRepository<CountEng, Integer> {

    /**
     * 根据工程名称分类
     *
     * @param beginDate
     * @param endDate
     * @return
     */
    @Transactional(rollbackFor = RuntimeException.class)
    @Query(value = "select * from count_eng c  where  c.type =1 and c.create_time between :beginDate and :endDate group by c.eng", nativeQuery = true)
    List<CountEng> findAllGroupByEng(@Param("beginDate") Date beginDate, @Param("endDate") Date endDate);

    @Transactional(rollbackFor = RuntimeException.class)
    @Modifying
    @Query(value = "INSERT into count_eng (eng,total_premium,create_time,type)\n" +
        "SELECT m.pro_alias, SUM( m.total_premium ), DATE_FORMAT( m.create_time, \"%Y-%m-%d\" ) create_time ,1\n" +
        "\tFROM policy_main m \n" +
        "\tWHERE 1 = 1 and m.insurance_category = 3\n" +
        "AND to_days(now()) - to_days( m.create_time )<= 1 \n" +
        "and m.pro_alias is not null" +
        "\tGROUP BY \tm.pro_alias, DATE_FORMAT(m.create_time,'%Y-%m-%d')", nativeQuery = true)
    void batchInsert();
}
/*
INSERT into count_eng (eng,total_premium,create_time,type)
SELECT m.pro_alias, SUM( m.total_premium ), DATE_FORMAT( m.create_time, "%Y-%m-%d" ) create_time ,1
        FROM policy_main m
        WHERE 1 = 1 and m.insurance_category = 3
				and m.pro_alias is not null
       --  AND to_days(now()) - to_days( m.create_time )<= 1
        GROUP BY m.pro_alias, DATE_FORMAT(m.create_time,'%Y-%m-%d')
 */
