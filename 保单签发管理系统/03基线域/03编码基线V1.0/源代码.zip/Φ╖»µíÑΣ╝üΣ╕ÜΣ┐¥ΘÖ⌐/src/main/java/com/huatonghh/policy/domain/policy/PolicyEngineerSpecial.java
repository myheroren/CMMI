package com.huatonghh.policy.domain.policy;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

/**
 * (PolicyEngineerSpecial)实体类
 *
 * @author ghy
 * @since 2020-11-11 15:04:34
 */
@Entity
@Table(name = "policy_engineer_special")
@Data
@ApiModel("险种特殊字段信息")
public class PolicyEngineerSpecial implements Serializable {
    private static final long serialVersionUID = 758614156871518113L;
    /**
    * 自增主键
    */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    @ApiModelProperty("自增主键")
    private Long id;

    /**
    * 所属保单号
    */
    @Column(name = "policy_no")
    @ApiModelProperty("所属保单号")
    private String policyNo;

    /**
    * 项目地址
    */
    @Column(name = "project_address")
    @ApiModelProperty("项目地址")
    private String projectAddress;
    /**
     * 项目详细地址
     */
    @Column(name = "detail_address")
    @ApiModelProperty("项目详细地址")
    private String detailAddress;
    /**
    * 项目名
    */
    @Column(name = "project_name")
    @ApiModelProperty("项目名")
    private String projectName;
    /**
    * 保险期限（天数）
    */
    @Column(name = "insurance_period")
    @ApiModelProperty("保险期限（天数）")
    private Integer insurancePeriod;

    /**
    * 0工程险；1团意险；2安责险；3雇主责任险
    */
    @ApiModelProperty("险种类型：0工程险；1团意险；2安责险；3雇主责任险")
    private Byte type;

    /**
    * 累计赔偿限额（三者责任累计赔偿限额）(安责、雇主、工程)
    */
    @Column(name = "accumulative_compensation_limit")
    @ApiModelProperty("累计赔偿限额（三者责任累计赔偿限额）(安责、雇主、工程)")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger accumulativeCompensationLimit;
    /**
    * 单次事故赔偿限额(安责、雇主、工程)
    */
    @Column(name = "single_compensation_limit")
    @ApiModelProperty("单次事故赔偿限额(安责、雇主、工程)")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger singleCompensationLimit;
    /**
    * 每人每次事故赔偿限额(安责、雇主、工程)
    */
    @Column(name = "per_person_single_compensation_limit")
    @ApiModelProperty("每人每次事故赔偿限额(安责、雇主、工程)")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger perPersonSingleCompensationLimit;
    /**
    * 意外身故残疾保额(团意险)
    */
    @Column(name = "accidental_death_disability_coverage")
    @ApiModelProperty("意外身故残疾保额(团意险)")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger accidentalDeathDisabilityCoverage;
    /**
    * 意外医疗保额(团意险)
    */
    @Column(name = "accidental_medical_coverage")
    @ApiModelProperty("意外医疗保额(团意险)")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger accidentalMedicalCoverage;
    /**
    * 48小时疾病身故保额(团意险)
    */
    @Column(name = "disease_death_insurance")
    @ApiModelProperty("48小时疾病身故保额(团意险)")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger diseaseDeathInsurance;
    /**
    * 创建时间
    */
    @Column(name = "create_time")
    @ApiModelProperty("创建时间")
    private Date createTime;
    /**
    * 更新时间
    */
    @Column(name = "update_time")
    @ApiModelProperty("更新时间")
    private Date updateTime;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPolicyNo() {
        return policyNo;
    }

    public void setPolicyNo(String policyNo) {
        this.policyNo = policyNo;
    }

    public String getProjectAddress() {
        return projectAddress;
    }

    public void setProjectAddress(String projectAddress) {
        this.projectAddress = projectAddress;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public Integer getInsurancePeriod() {
        return insurancePeriod;
    }

    public void setInsurancePeriod(Integer insurancePeriod) {
        this.insurancePeriod = insurancePeriod;
    }

    public Object getType() {
        return type;
    }

    public void setType(Byte type) {
        this.type = type;
    }

    public BigInteger getAccumulativeCompensationLimit() {
        return accumulativeCompensationLimit;
    }

    public void setAccumulativeCompensationLimit(BigInteger accumulativeCompensationLimit) {
        this.accumulativeCompensationLimit = accumulativeCompensationLimit;
    }

    public BigInteger getSingleCompensationLimit() {
        return singleCompensationLimit;
    }

    public void setSingleCompensationLimit(BigInteger singleCompensationLimit) {
        this.singleCompensationLimit = singleCompensationLimit;
    }

    public BigInteger getPerPersonSingleCompensationLimit() {
        return perPersonSingleCompensationLimit;
    }

    public void setPerPersonSingleCompensationLimit(BigInteger perPersonSingleCompensationLimit) {
        this.perPersonSingleCompensationLimit = perPersonSingleCompensationLimit;
    }

    public BigInteger getAccidentalDeathDisabilityCoverage() {
        return accidentalDeathDisabilityCoverage;
    }

    public void setAccidentalDeathDisabilityCoverage(BigInteger accidentalDeathDisabilityCoverage) {
        this.accidentalDeathDisabilityCoverage = accidentalDeathDisabilityCoverage;
    }

    public BigInteger getAccidentalMedicalCoverage() {
        return accidentalMedicalCoverage;
    }

    public void setAccidentalMedicalCoverage(BigInteger accidentalMedicalCoverage) {
        this.accidentalMedicalCoverage = accidentalMedicalCoverage;
    }

    public BigInteger getDiseaseDeathInsurance() {
        return diseaseDeathInsurance;
    }

    public void setDiseaseDeathInsurance(BigInteger diseaseDeathInsurance) {
        this.diseaseDeathInsurance = diseaseDeathInsurance;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

}
