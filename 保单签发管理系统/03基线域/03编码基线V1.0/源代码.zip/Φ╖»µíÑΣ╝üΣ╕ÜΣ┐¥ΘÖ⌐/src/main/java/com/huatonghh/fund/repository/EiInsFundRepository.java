package com.huatonghh.fund.repository;

import com.huatonghh.fund.domain.EiInsFund;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface EiInsFundRepository extends JpaRepository<EiInsFund, Integer>, JpaSpecificationExecutor<EiInsFund> {

    Page<EiInsFund> findEiInsFundsByBelongCompany(Integer belongCompany, Pageable page);

    EiInsFund findFirstByBelongCompanyOrderByIdDesc(Integer belongCompany);
}
