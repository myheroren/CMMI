package com.huatonghh.base.service;


import com.huatonghh.base.service.dto.MailDTO;
import lombok.AllArgsConstructor;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/18
 */
@Service
@AllArgsConstructor
public class EMailService {
    private final JavaMailSender mailSender;

    public void sendMail(MailDTO mailDTO) {
        //建立邮件消息
        SimpleMailMessage mailMessage = new SimpleMailMessage();
        //发送方
        mailMessage.setFrom(mailDTO.getFrom());
        //接收方
        mailMessage.setTo(mailDTO.getTo());
        //发送的标题
        mailMessage.setSubject(mailDTO.getSubject());
        //发送的内容
        mailMessage.setText(mailDTO.getContent());
        mailSender.send(mailMessage);

    }
}
