package com.huatonghh.policy.service.dto.policy;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

/**
 * Description : 保存保单详细信息-非车
 * @author : Sun
 * @date : 2019/8/31 14:01
 * @version : 1.0
 */
@Data
@ApiModel("保存保单详细信息-非车")
public class SavePolicyUncarDto implements Serializable {

    private static final long serialVersionUID = 7123524803971823466L;

    @ApiModelProperty(value = "自增id：新增不传、修改必传")
    @JsonSerialize(using = ToStringSerializer.class)
    private BigInteger id;

    @ApiModelProperty(value = "保单号，与基本信息保单号相同，关联基本信息")
    private String policyNo;

    @ApiModelProperty(value = "投保产品")
    private String mainRiskDuty;

    @ApiModelProperty(value = "投保产品1")
    private String insureProduct;

    @ApiModelProperty(value = "总保额")
    @JsonDeserialize(using= AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger totalAmount;

    @ApiModelProperty(value = "手续费比例")
    private String feeProp;

    @ApiModelProperty(value = "签单日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date issueDate;

    @ApiModelProperty(value = "共保信息")
    private String coinsuranceDetail;

    @ApiModelProperty(value = "实收日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date paidInDate;

    @ApiModelProperty(value = "支付类型：见费出单/分期")
    private Byte paymentType;



    @ApiModelProperty(value = "所属标段")
    private String subordinateBid;

    @ApiModelProperty(value = "工程名称")
    private String engineeringName;

    @ApiModelProperty(value = "保证期间")
    private String guarantyPeriod;



    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    @ApiModelProperty(value = "更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

}
