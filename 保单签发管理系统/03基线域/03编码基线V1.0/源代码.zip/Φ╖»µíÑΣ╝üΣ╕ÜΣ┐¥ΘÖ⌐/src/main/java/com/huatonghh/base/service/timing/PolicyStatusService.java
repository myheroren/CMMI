package com.huatonghh.base.service.timing;

import com.huatonghh.common.util.hutool.SpringContextHolder;
import com.huatonghh.policy.repository.policy.PolicyMainRepository;
import com.huatonghh.policy.service.PolicyBatchUpdateService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/29
 */
@Service
@Slf4j
@AllArgsConstructor
public class PolicyStatusService {

    private final PolicyMainRepository policyMainRepository;

    /**
     * 每天判断保单是否过期
     */
    public void updatePolicyStatus() {
        PolicyBatchUpdateService policyRenewService = SpringContextHolder.getBean(PolicyBatchUpdateService.class);
        policyRenewService.batchUpdatePolicyEffective();
        policyRenewService.batchUpdatePolicyOverdue();
    }
}
