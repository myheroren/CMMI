package com.huatonghh.message.constant;

/**
 * 消息模块常量
 *
 * @author wanggl
 * @date 2020-11-03 16:46
 */
public interface MessageConstant {
    /**
     * 否定
     */
    Byte NO = 0;

    /**
     * 肯定
     */
    Byte YES = 1;

    String CLAIM_MSG = "claim_msg";

    String PLAN_MSG = "plan_msg";

    String RENEW_MSG = "renew_msg";

    String EVALUATION_MSG = "evaluation_msg";

    String EMPOWER_MSG = "empower_msg";

    String CLAIM_CHAT_MSG = "claim_chat_msg";

    String getTokenUrl = "https://yunzhijia.com/gateway/oauth2/token/getAccessToken";

    String sendMsgUrl = "https://yunzhijia.com/gateway/newtodo/open/generatetodo.json?accessToken=";

    String getPersonsUrl = "https://yunzhijia.com/gateway/openimport/open/person/get?accessToken=";

    String getAllPersonsUrl = "https://yunzhijia.com/gateway/opendata-control/data/getallpersons?accessToken=";

    String headImg = "https://yunzhijia.com/space/c/photo/load?id=5a2f7ad750f8dd7810e79981";

    String destUrl = "http://116.1.201.123:14680/enterprise_insurance_front/insuranceIndex/messageList";

    String appId = "500631380";

    String eid = "11521";

    String secret = "OzRubrUrCfcf9BYvmjTu";

    String app = "app";
}
