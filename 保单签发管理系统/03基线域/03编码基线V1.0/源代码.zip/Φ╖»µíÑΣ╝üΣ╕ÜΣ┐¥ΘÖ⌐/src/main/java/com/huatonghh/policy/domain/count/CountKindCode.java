package com.huatonghh.policy.domain.count;

import lombok.Data;

import javax.persistence.*;
import java.math.BigInteger;
import java.util.Date;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/11
 */
@Entity
@Table(name = "count_kind_code")
@Data
public class CountKindCode {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String kindCode;
    private BigInteger totalPremium;
    private BigInteger totalHandlingFee;
    private Date createTime;
    private Byte type;
}
