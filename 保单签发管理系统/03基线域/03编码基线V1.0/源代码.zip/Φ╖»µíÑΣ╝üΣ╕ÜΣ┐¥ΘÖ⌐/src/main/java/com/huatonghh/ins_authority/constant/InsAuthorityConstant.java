package com.huatonghh.ins_authority.constant;

/**
 * @author : Sun
 * @description : 保险公司权限类文件注释
 * @date : 2019/11/5 21:31
 * @version : 1.0
 */
public final class InsAuthorityConstant {

    /** 初始化密码admin */
    public static final String INITIAL_PASSWORD = "123456";

    /** 默认查询全部企业保险保险公司部门 */
    public static final Integer DEPART_TREE_HEAD_QYBX = 1;

    /** 保险公司权限管理相应的缓存key值定义 */
    public static final String EI_INS_USERS_BY_LOGIN_CACHE  = "eiInsUsersByLogin";

    public static final String EI_INS_ROLES_BY_LOGIN_CACHE = "eiInsRolesByLogin";

    public static final String EI_INS_DEPARTS_BY_LOGIN_CACHE = "eiInsDepartsByLogin";

    public static final String EI_INS_AUTHORITYS_BY_LOGIN_CACHE = "eiInsAuthoritysByLogin";

    public InsAuthorityConstant() {
    }
}
