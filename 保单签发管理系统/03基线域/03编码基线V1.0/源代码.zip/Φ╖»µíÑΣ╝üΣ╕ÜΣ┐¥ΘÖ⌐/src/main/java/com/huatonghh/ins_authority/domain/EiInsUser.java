package com.huatonghh.ins_authority.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.huatonghh.authority.domain.EiRole;
import lombok.Data;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * @author : Sun
 * @description : 保险公司员工表
 * @date : 2019/11/5 21:31
 * @version : 1.0
 */
@Entity
@Table(name = "ei_ins_user")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Data
public class EiInsUser implements Serializable {

    private static final long serialVersionUID = 8068009758880451334L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "user_name")
    private String userName;

    @Column(name = "user_password")
    private String userPassword;

    @Column(name = "employee_no")
    private String employeeNo;

    @Column(name = "name")
    private String name;

    @Column(name = "position")
    private Byte position;

    @Column(name = "gender")
    private Boolean gender;

    @Column(name = "id_card")
    private String idCard;

    @Column(name = "phone_no")
    private String phoneNo;

    @Column(name = "email")
    private String email;

    @Column(name = "remark")
    private String remark;

    @Column(name = "is_valid")
    private Boolean valid;

    @JsonIgnore
    @ManyToMany
    @JoinTable(
        name = "ei_ins_user_role",
        joinColumns = {@JoinColumn(name = "user_id", referencedColumnName = "id")},
        inverseJoinColumns = {@JoinColumn(name = "role_id", referencedColumnName = "role_id")})
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @BatchSize(size = 40)
    private Set<EiInsRole> authorities = new HashSet<>();


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof EiInsUser)) {
            return false;
        }
        EiInsUser eiInsUser = (EiInsUser) o;
        return Objects.equals(id, eiInsUser.id) &&
            Objects.equals(userName, eiInsUser.userName) &&
            Objects.equals(userPassword, eiInsUser.userPassword) &&
            Objects.equals(employeeNo, eiInsUser.employeeNo) &&
            Objects.equals(position, eiInsUser.position) &&
            Objects.equals(gender, eiInsUser.gender) &&
            Objects.equals(idCard, eiInsUser.idCard) &&
            Objects.equals(phoneNo, eiInsUser.phoneNo) &&
            Objects.equals(email, eiInsUser.email) &&
            Objects.equals(remark, eiInsUser.remark) &&
            Objects.equals(valid, eiInsUser.valid);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, userName, userPassword, employeeNo, position, gender, idCard, phoneNo, email, remark, valid);
    }

    @Override
    public String toString() {
        return "EiInsUser{" +
            "id=" + id +
            ", userName='" + userName + '\'' +
            ", userPassword='" + userPassword + '\'' +
            ", employeeNo='" + employeeNo + '\'' +
            ", position=" + position +
            ", gender=" + gender +
            ", idCard='" + idCard + '\'' +
            ", phoneNo='" + phoneNo + '\'' +
            ", email='" + email + '\'' +
            ", remark='" + remark + '\'' +
            ", valid=" + valid +
            '}';
    }
}
