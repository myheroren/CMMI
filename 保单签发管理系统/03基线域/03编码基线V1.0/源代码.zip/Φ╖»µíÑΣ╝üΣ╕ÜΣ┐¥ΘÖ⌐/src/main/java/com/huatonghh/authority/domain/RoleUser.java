package com.huatonghh.authority.domain;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;



/**
 * @author : Sun
 * @description : 交投集团-用户角色中间表-数据库映射实体
 * @date : 2019/11/4 19:42
 * @version : 1.0
 */
@Entity
@Table(name = "ei_user_role")
@Data
@IdClass(EiRoleUserKey.class)
public class RoleUser
    implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "user_id")
    private String userId;

    @Id
    @Column(name = "role_id")
    private Integer roleId;

    @Id
    @Column(name = "company_id")
    private String companyId;
}
