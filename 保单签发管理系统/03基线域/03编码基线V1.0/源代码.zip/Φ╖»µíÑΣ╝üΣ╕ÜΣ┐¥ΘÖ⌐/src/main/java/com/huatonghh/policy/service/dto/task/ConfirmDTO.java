package com.huatonghh.policy.service.dto.task;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigInteger;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/9/28
 */
@Data
@ApiModel("确认")
public class ConfirmDTO {
    @ApiModelProperty(value = "业务编号")
    @NotNull
    private BigInteger businessId;
    @ApiModelProperty(value = "任务id")
    @NotNull
    private String taskId;
    @ApiModelProperty(value = "是否可行")
    @NotNull
    private Boolean able;
    @ApiModelProperty("备注")
    private String msg;
}
