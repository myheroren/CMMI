package com.huatonghh.excel.constant;

/**
 * @author : Sun
 * @description : 字典管理类文件注释
 * @date : 2019/11/5 21:21
 * @version : 1.0
 */
public final class ExampleConstant {

    public ExampleConstant() {
    }
}
