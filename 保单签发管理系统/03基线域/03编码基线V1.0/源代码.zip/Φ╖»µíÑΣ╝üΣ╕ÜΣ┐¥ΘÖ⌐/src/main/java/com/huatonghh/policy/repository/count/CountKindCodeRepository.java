package com.huatonghh.policy.repository.count;

import com.huatonghh.policy.domain.count.CountKindCode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/11
 */
public interface CountKindCodeRepository extends JpaRepository<CountKindCode, Integer> {

    @Transactional(rollbackFor = RuntimeException.class)
    @Query(value = "select c.id,c.type,sum(c.total_handling_fee) total_handling_fee,c.kind_code,sum(c.total_premium) total_premium,c.create_time from count_kind_code c  where  c.type=1 and c.create_time between :beginDate and :endDate GROUP BY kind_code", nativeQuery = true)
    List<CountKindCode> findAllGroupByKindCode(@Param("beginDate") Date beginDate, @Param("endDate") Date endDate);

    @Transactional(rollbackFor = RuntimeException.class)
    @Modifying
    @Query(value = "INSERT into count_kind_code (kind_code,total_premium,total_handling_fee,create_time,type)\n" +
        "SELECT m.insurance_category, SUM( m.total_premium ), sum(m.handling_fee),DATE_FORMAT( m.create_time, \"%Y-%m-%d\" ) create_time ,1\n" +
        "\tFROM policy_main m \n" +
        "\tWHERE 1 = 1 \n" +
        "AND to_days(now()) - to_days( create_time )<= 1 \n" +
        "\tGROUP BY \tm.insurance_category, DATE_FORMAT(create_time,'%Y-%m-%d')", nativeQuery = true)
    void batchInsert();
}

/*
险种保费手续费插入数据
INSERT into count_kind_code (kind_code,total_premium,total_handling_fee,create_time,type)
        SELECT m.insurance_category, SUM( m.total_premium ), sum(m.handling_fee),
				DATE_FORMAT( m.create_time, "%Y-%m-%d" ) create_time ,1
        FROM policy_main m
        WHERE 1 = 1
        -- AND to_days(now()) - to_days( create_time )<= 1
        GROUP BY m.insurance_category, DATE_FORMAT(create_time,'%Y-%m-%d')
 */
