package com.huatonghh.policy.domain.policy.modify;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

/**
 * Description : 保单详细信息-车
 * @author : Sun
 * @date : 2019/8/31 14:01
 * @version : 1.0
 */
@Entity
@Table(name = "policy_car_detail_modify")
@Data
public class PolicyCarDetailModify implements Serializable {

    private static final long serialVersionUID = 4405247635308103626L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private BigInteger id;

    @Column(name = "policy_no")
    private String policyNo;

    @Column(name = "policy_id")
    private BigInteger policyId;

    @Column(name = "frame_no")
    private String frameNo;

    @Column(name = "plate_no")
    private String plateNo;

    @Column(name = "engine_no")
    private String engineNo;

    @Column(name = "usage_code")
    private String usageCode;

    @Column(name = "vehicle_model")
    private String vehicleModel;

    @Column(name = "owner_name")
    private String ownerName;

    @Column(name = "fee_prop")
    private String feeProp;

    @Column(name = "vehicle_vessel_tax")
    private String vehicleVesselTax;

    @Column(name = "ncd_coef")
    private String ncdCoef;

    @Column(name = "auto_underwriting_coef")
    private String autoUnderwritingCoef;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "update_time")
    private Date updateTime;

}
