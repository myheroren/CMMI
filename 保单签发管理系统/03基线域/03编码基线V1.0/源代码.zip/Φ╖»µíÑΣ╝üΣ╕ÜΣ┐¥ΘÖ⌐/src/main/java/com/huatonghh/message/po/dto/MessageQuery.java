package com.huatonghh.message.po.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.StringJoiner;

/**
 * @author wanggl
 * @date 2020-11-03 10:05
 */
@ApiModel("消息列表查询参数")
public class MessageQuery implements Serializable {

    private static final long serialVersionUID = 4812578696619556587L;

    @ApiModelProperty(value = "消息来源")
    private String source;

    @NotEmpty(message = "用户编号不能为空")
    @ApiModelProperty(value = "用户编号", required = true)
    private String userCode;

    @ApiModelProperty(value = "消息类型")
    private String type;

    @ApiModelProperty(value = "标题")
    private String title;

    @ApiModelProperty(value = "发送者")
    private String sender;

    @ApiModelProperty(value = "起始时间")
    private LocalDateTime beginTime;

    @ApiModelProperty(value = "截止时间")
    private LocalDateTime endTime;

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getUserCode() {
        return userCode;
    }

    public void setUserCode(String userCode) {
        this.userCode = userCode;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public LocalDateTime getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(LocalDateTime beginTime) {
        this.beginTime = beginTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", MessageQuery.class.getSimpleName() + "[", "]")
            .add("source='" + source + "'")
            .add("userCode='" + userCode + "'")
            .add("type='" + type + "'")
            .add("title='" + title + "'")
            .add("sender='" + sender + "'")
            .add("beginTime=" + beginTime)
            .add("endTime=" + endTime)
            .toString();
    }
}
