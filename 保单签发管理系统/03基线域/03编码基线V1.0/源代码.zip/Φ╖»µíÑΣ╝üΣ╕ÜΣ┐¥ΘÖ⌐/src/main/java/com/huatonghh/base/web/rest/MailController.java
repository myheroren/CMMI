package com.huatonghh.base.web.rest;


import com.huatonghh.base.service.EMailService;
import com.huatonghh.base.service.dto.MailDTO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * @author Administrator
 */
@RestController
@RequestMapping(value = "api/mail")
@Api(tags = "31、邮件发送", value = "邮件发送")
@AllArgsConstructor
public class MailController {
    private final EMailService mailService;

    @PostMapping(value = "")
    @ApiOperation(value = "发送", notes = "发送", httpMethod = "POST")
    public void sendMail(@RequestBody MailDTO mailDTO) {
        mailService.sendMail(mailDTO);
    }

}
