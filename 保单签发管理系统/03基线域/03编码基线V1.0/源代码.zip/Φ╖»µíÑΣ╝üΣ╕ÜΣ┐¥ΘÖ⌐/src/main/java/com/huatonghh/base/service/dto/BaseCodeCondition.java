package com.huatonghh.base.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * Description : 
 * @author : Sun
 * @date : 2019/8/30 11:24
 * @version : 1.0
 */
@Data
@ApiModel(value = "基础代码分页查询条件")
public class BaseCodeCondition implements Serializable {

    @ApiModelProperty(value = "基础代码")
//    @NotNull
    private String typeCode;

    /**
     * 页码
     */
    @ApiModelProperty(value = "页码", example = "1")
    @NotNull(message = "分页页码不能为空")
    private Integer pageNum;

    /**
     * 条目数
     */
    @ApiModelProperty(value = "条目数", example = "10")
    @NotNull(message = "分页条目数不能为空")
    private Integer pageSize;


}
