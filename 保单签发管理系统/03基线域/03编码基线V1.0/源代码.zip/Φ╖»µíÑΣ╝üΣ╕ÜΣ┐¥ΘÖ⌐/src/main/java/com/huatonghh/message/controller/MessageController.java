package com.huatonghh.message.controller;

import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.common.util.system.PageParam;
import com.huatonghh.message.po.dto.MessageDTO;
import com.huatonghh.message.po.dto.MessageQuery;
import com.huatonghh.message.po.dto.MessageVO;
import com.huatonghh.message.service.MessageService;
import com.huatonghh.policy.constant.PlanConstant;
import com.huatonghh.policy.service.client.UserClient;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;

/**
 * 消息主体控制层
 *
 * @author wanggl
 * @since 2020-11-02 20:09:22
 */
@Api(tags = "03、消息")
@RestController
@RequestMapping("/api/message")
public class MessageController {

    private final MessageService messageService;

    private final UserClient userClient;

    private final Logger logger = LoggerFactory.getLogger(MessageController.class);

    public MessageController(MessageService messageService, UserClient userClient) {
        this.messageService = messageService;
        this.userClient = userClient;
    }

    @ApiOperation(value = "1:查询用户消息列表", notes = "根据日期排序")
    @ApiOperationSupport(order = 1)
    @PostMapping("list")
    public ApiResponse<PageInfo<MessageVO>> messageList(@RequestBody @Validated PageParam<MessageQuery> param) {
        Integer userCode = userClient.getCurrentCompanyInfo().getEiInsDepartDto().getId();
        if(param.getParams() == null){
            MessageQuery messageQuery = new MessageQuery();
            param.setParams(messageQuery);
        }
        param.getParams().setUserCode(String.valueOf(userCode));
        return ApiResponse.ofSuccess(messageService.messageList(param));
    }

    @ApiOperation(value = "2:消息已读")
    @ApiOperationSupport(order = 2)
    @GetMapping("read")
    public ApiResponse<Object> read(Long messageId) {
        messageService.read(messageId, userClient.getCurrentUserName());
        return ApiResponse.ofSuccess(null);
    }

    @ApiOperation(value = "3:发送消息")
    @PostMapping("send")
    @ApiOperationSupport(order = 3)
    public ApiResponse<Object> sendMessage(@RequestBody @Validated MessageDTO messageDTO) {
        messageService.sendMessage(messageDTO);
        return ApiResponse.ofSuccess(null);
    }
}
