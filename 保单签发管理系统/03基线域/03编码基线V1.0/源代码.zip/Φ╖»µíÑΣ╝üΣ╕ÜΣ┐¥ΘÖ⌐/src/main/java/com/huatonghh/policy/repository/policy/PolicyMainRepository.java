package com.huatonghh.policy.repository.policy;

import com.huatonghh.policy.domain.policy.PolicyMain;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.util.Optional;

/**
 * @author : Sun
 * @version : 1.0
 * @description :
 * @date : 2019/11/5 21:44
 */
public interface PolicyMainRepository extends JpaRepository<PolicyMain, BigInteger> {

    /**
     * findByPolicyNo
     *
     * @param policyNo:
     * @return java.util.Optional<com.huatonghh.plan.domain.policy.PolicyMain>
     * @author Sun
     * @date 2019/11/5 21:44
     **/
    Optional<PolicyMain> findByPolicyNo(String policyNo);

    @Transactional(rollbackFor = RuntimeException.class)
    @Modifying
    @Query("update PolicyMain p set p.remindStatus = :remindStatus  where p.policyNo = :policyNo ")
    void updatePolicyRenewStatus(@Param("policyNo") String policyNo, @Param("remindStatus") Boolean remindStatus);

    /**
     * 批量更新保单生效状态
     */
    @Transactional(rollbackFor = RuntimeException.class)
    @Modifying
    @Query(value = "update policy_main set `status` = 1  where policy_bgn_time < now() and `status` =0 ", nativeQuery = true)
    void batchUpdatePolicyEffective();

    /**
     * 批量更新保单过期状态
     */
    @Transactional(rollbackFor = RuntimeException.class)
    @Modifying
    @Query(value = "update policy_main set `status` = 2  where policy_end_time < now() and `status` =1 ", nativeQuery = true)
    void batchUpdatePolicyOverdue();

    @Transactional(rollbackFor = RuntimeException.class)
    @Modifying
    @Query(value="UPDATE policy_main set expiration_days = if((SELECT DATEDIFF(policy_end_time,CURRENT_DATE)) > 0 ,(SELECT DATEDIFF(policy_end_time,CURRENT_DATE)),null)", nativeQuery = true)
    void batchUpdatePolicyExpirationDays();

    @Transactional(rollbackFor = RuntimeException.class)
    @Modifying
    @Query(value="UPDATE policy_main SET renew_status = IF(expiration_days < 30,0,null)", nativeQuery = true)
    void batchUpdatePolicyRenewStatus();
}
