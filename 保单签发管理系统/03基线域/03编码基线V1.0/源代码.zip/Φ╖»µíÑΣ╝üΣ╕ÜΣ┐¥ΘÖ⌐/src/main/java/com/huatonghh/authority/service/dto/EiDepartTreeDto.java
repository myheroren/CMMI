package com.huatonghh.authority.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author : Sun
 * @description : 部门二叉树对象
 * @date : 2019/11/4 21:10
 * @version : 1.0
 */
@Data
@ApiModel(value = "部门二叉树对象")
public class EiDepartTreeDto implements Serializable {

    private static final long serialVersionUID = 3757152911583699840L;

    @ApiModelProperty(value = "部门id")
    private String id;

    @ApiModelProperty(value = "部门名称")
    private String name;

    @ApiModelProperty(value = "父部门id。根部门为0")
    private String parentId;

    @ApiModelProperty(value = "公司层级")
    private String htLevel;

    @ApiModelProperty(value = "子部门集合")
    private List<EiDepartTreeDto> children;

    public EiDepartTreeDto(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public EiDepartTreeDto(String id, String name, String htLevel) {
        this.id = id;
        this.name = name;
        this.htLevel = htLevel;
    }

    public EiDepartTreeDto(String id, String name, String parentId, List<EiDepartTreeDto> children) {
        this.id = id;
        this.name = name;
        this.parentId = parentId;
        this.children = children;
    }

    public EiDepartTreeDto() {
    }

}
