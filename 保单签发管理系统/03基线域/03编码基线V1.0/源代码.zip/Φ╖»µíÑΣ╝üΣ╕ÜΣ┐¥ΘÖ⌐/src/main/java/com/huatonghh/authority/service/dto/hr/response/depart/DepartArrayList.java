package com.huatonghh.authority.service.dto.hr.response.depart;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;


/**
 * @author : Sun
 * @description : 查询公司信息-数据集
 * @date : 2019/11/4 21:05
 * @version : 1.0
 */
@Data
public class DepartArrayList {

    @JsonProperty(value = "c_hid")
    @JSONField(name ="c_hid")
    private String cHid;

    @JsonProperty(value = "c_level")
    @JSONField(name ="c_level")
    private String cLevel;

    @JsonProperty(value = "c_name")
    @JSONField(name ="c_name")
    private String cName;

    @JsonProperty(value = "c_superior_hid")
    @JSONField(name ="c_superior_hid")
    private String cSuperiorHid;

    @JsonProperty(value = "type")
    @JSONField(name ="type")
    private String type;

}
