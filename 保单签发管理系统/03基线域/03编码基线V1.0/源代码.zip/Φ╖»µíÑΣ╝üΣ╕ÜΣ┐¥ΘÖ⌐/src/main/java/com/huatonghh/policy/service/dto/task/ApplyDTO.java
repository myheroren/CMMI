package com.huatonghh.policy.service.dto.task;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/9/17
 */
@Data
@ApiModel("审核请求信息")
public class ApplyDTO {
    @ApiModelProperty("业务主键")
    @NotNull(message = "业务主键不能为空！")
    private String businessId;

    @ApiModelProperty("备注")
    private String msg;

    @ApiModelProperty("意见")
    private String idea;

    @ApiModelProperty("下级审批人")
    private List<String> limitUserIds;
}
