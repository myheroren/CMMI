package com.huatonghh.message.po.entity;


import com.google.common.base.MoreObjects;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 第三方消息发送表(MessageThirdParty)实体类
 *
 * @author wanggl
 * @since 2020-11-02 20:09:22
 */
@ApiModel("第三方消息发送表实体类")
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "message_third_party")
public class MessageThirdParty implements Serializable {

    private static final long serialVersionUID = 129395446900953824L;

    @ApiModelProperty(value = "自增id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ApiModelProperty(value = "消息id")
    private Long messageId;

    @ApiModelProperty(value = "用户信息")
    private String userInfo;

    @ApiModelProperty(value = "发送方式")
    private String type;

    @ApiModelProperty(value = "url")
    private String url;

    @ApiModelProperty(value = "是否成功（0==未成功，1==成功）")
    private Byte success;

    @ApiModelProperty(value = "发送次数")
    private Integer times;

    @CreatedDate
    @ApiModelProperty(value = "创建时间")
    private LocalDateTime createTime;

    @LastModifiedDate
    @ApiModelProperty(value = "更新时间")
    private LocalDateTime updateTime;

    public MessageThirdParty() {
    }

    public MessageThirdParty(Long id, Long messageId, String userInfo, String type, String url, Byte success, Integer times, LocalDateTime createTime, LocalDateTime updateTime) {
        this.id = id;
        this.messageId = messageId;
        this.userInfo = userInfo;
        this.type = type;
        this.url = url;
        this.success = success;
        this.times = times;
        this.createTime = createTime;
        this.updateTime = updateTime;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMessageId() {
        return messageId;
    }

    public void setMessageId(Long messageId) {
        this.messageId = messageId;
    }

    public String getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(String userInfo) {
        this.userInfo = userInfo;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Byte getSuccess() {
        return success;
    }

    public void setSuccess(Byte success) {
        this.success = success;
    }

    public Integer getTimes() {
        return times;
    }

    public void setTimes(Integer times) {
        this.times = times;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
            .add("id", id)
            .add("messageId", messageId)
            .add("userInfo", userInfo)
            .add("type", type)
            .add("url", url)
            .add("success", success)
            .add("times", times)
            .add("createTime", createTime)
            .add("updateTime", updateTime)
            .toString();
    }
}
