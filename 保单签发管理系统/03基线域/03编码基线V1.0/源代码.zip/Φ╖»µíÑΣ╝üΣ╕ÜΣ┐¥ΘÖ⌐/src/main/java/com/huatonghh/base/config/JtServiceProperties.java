package com.huatonghh.base.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;


/**
 * @author wh
 * 交投服务器信息
 */
@Getter
@Setter
@ConfigurationProperties(prefix = "jt")
public class JtServiceProperties {
    /**
     * 交投服务器后台地址
     */
    private String serviceUrl;

}
