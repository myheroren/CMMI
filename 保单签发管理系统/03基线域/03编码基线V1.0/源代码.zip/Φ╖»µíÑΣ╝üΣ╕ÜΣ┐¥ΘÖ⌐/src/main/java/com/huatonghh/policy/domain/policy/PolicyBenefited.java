package com.huatonghh.policy.domain.policy;

import java.io.Serializable;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

/**
 * 保单受益人表(PolicyBenefited)表实体类
 *
 * @author 居炎明
 * @since 2020-03-02 07:20:39
 */
@Entity
@Table(name = "policy_benefited")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Api(tags = "保单受益人表")
public class PolicyBenefited implements Serializable {

    private static final long serialVersionUID = 963623114657164196L;
    @ApiModelProperty(value = "主键")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false, unique = true)
    private Integer id;

    @ApiModelProperty(value = "受益人所属保单号")
    @Column(name = "policy_no")
    private String policyNo;

    @ApiModelProperty(value = "受益人姓名")
    @Column(name = "benefited_name")
    private String benefitedName;

    @ApiModelProperty(value = "受益人证件类型")
    @Column(name = "benefited_certificate_type")
    private String benefitedCertificateType;

    @ApiModelProperty(value = "受益人证件号")
    @Column(name = "benefited_certificate_number")
    private String benefitedCertificateNumber;

    @ApiModelProperty(value = "第几受益人")
    @Column(name = "position")
    private Integer position;

    @ApiModelProperty(value = "受益比例")
    @Column(name = "position_rate")
    private Integer positionRate;

}
