package com.huatonghh.authority.security;

import cn.hutool.core.util.StrUtil;
import com.google.common.collect.Lists;
import com.huatonghh.authority.constant.AuthorityConstant;
import com.huatonghh.authority.domain.EiUser;
import com.huatonghh.authority.repository.EiUserRepository;
import com.huatonghh.authority.security.jwt.JWTFilter;
import com.huatonghh.ins_authority.domain.EiInsUser;
import com.huatonghh.ins_authority.repository.EiInsUserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author : Sun
 * @description : 用户登录，框架调用的userDetailsService Component
 * @date : 2019/11/4 20:03
 * @version : 1.0
 */
@Component("userDetailsService")
public class DomainUserDetailsServiceImpl implements UserDetailsService {

    private final Logger log = LoggerFactory.getLogger(DomainUserDetailsServiceImpl.class);

    private final EiUserRepository eiUserRepository;

    private final EiInsUserRepository eiInsUserRepository;

    public DomainUserDetailsServiceImpl(EiUserRepository eiUserRepository, EiInsUserRepository eiInsUserRepository) {
        this.eiUserRepository = eiUserRepository;
        this.eiInsUserRepository = eiInsUserRepository;
    }

    @Override
    @Transactional(rollbackFor = RuntimeException.class)
    public UserDetails loadUserByUsername(final String login) {
        log.debug("Authenticating {}", login);
        // 保险公司、交投集团两张登录表
        if(login.startsWith(AuthorityConstant.INS)) {
            String removePrefixLogin = StrUtil.removePrefix(login, AuthorityConstant.INS);
            Optional<EiInsUser> eiInsUserOptional = eiInsUserRepository.findOneWithAuthoritiesByUserName(removePrefixLogin);
            return eiInsUserOptional.map(eiInsUser -> createSpringSecurityEiUser(eiInsUserOptional.get()))
                .orElseThrow(() -> new UsernameNotFoundException("InsUser " + removePrefixLogin + " was not found in the database"));
        }else {
            Optional<EiUser> eiUserOptional = eiUserRepository.findOneWithAuthoritiesByUserName(login);
            return eiUserOptional.map(user -> createSpringSecurityEiUser(eiUserOptional.get()))
                .orElseThrow(() -> new UsernameNotFoundException("User " + login + " was not found in the database"));
        }
    }


    /**
     * @author Sun
     * @description 交投集团账号，登录角色1
     * @date 2019/11/4 20:03
     * @param eiUser: 角色
     * @return org.springframework.security.core.userdetails.User
     **/
    private org.springframework.security.core.userdetails.User createSpringSecurityEiUser(EiUser eiUser) {
        List<GrantedAuthority> grantedAuthorities = Lists.newArrayList();
        grantedAuthorities.add(new SimpleGrantedAuthority(AuthorityConstant.JTJT));
        return new org.springframework.security.core.userdetails.User(eiUser.getUserName(),
            eiUser.getUserPassword(),
            grantedAuthorities);
    }


    /**
     * @author Sun
     * @description ins保险公司账号，角色2
     * @date 2019/11/4 20:03
     * @param eiUser: 角色
     * @return org.springframework.security.core.userdetails.User
     **/
    private org.springframework.security.core.userdetails.User createSpringSecurityEiUser(EiInsUser eiUser) {
        List<GrantedAuthority> grantedAuthorities = Lists.newArrayList();
        grantedAuthorities.add(new SimpleGrantedAuthority(AuthorityConstant.BXGS));
        return new org.springframework.security.core.userdetails.User(eiUser.getUserName(),
            eiUser.getUserPassword(),
            grantedAuthorities);
    }

}
