package com.huatonghh.policy.service.dto.claim.noncar;


import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import com.huatonghh.excel.util.BigIntegerConverter;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.Date;
import java.util.StringJoiner;

/**
 * @author wanggl
 */
@ContentRowHeight(16)
@HeadRowHeight(18)
@HeadFontStyle(fontHeightInPoints = 12)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClaimListExport {

    @ExcelProperty(value = "报案id", converter = BigIntegerConverter.class)
    private String reportId;

    @ExcelProperty(value = "保单号")
    private String policyNo;

    @ExcelProperty(value = "项目组织")
    private String projectName;

    @ExcelProperty(value = "保险公司")
    private String belongCompanyName;

    @ExcelProperty(value = "投保人")
    private String holderName;

    @ExcelProperty(value = "被保人")
    private String insuredName;


    @ExcelProperty(value = "保险起期")
    @DateTimeFormat(value = "yyyy-MM-dd")
    private Date policyBgnTime;

    @ExcelProperty(value = "保险止期")
    @DateTimeFormat(value = "yyyy-MM-dd")
    private Date policyEndTime;

    @ExcelProperty(value = "报案日期")
    @DateTimeFormat(value = "yyyy-MM-dd")
    private Date reportTime;

    @ExcelProperty(value = "理赔状态")
    private String claimStatus;

}
