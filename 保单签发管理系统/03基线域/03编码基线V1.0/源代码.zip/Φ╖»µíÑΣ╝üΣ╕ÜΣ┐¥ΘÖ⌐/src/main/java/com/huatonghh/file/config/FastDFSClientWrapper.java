package com.huatonghh.file.config;

import com.github.tobato.fastdfs.domain.fdfs.StorePath;
import com.github.tobato.fastdfs.domain.proto.storage.DownloadByteArray;
import com.github.tobato.fastdfs.exception.FdfsUnsupportStorePathException;
import com.github.tobato.fastdfs.service.FastFileStorageClient;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.Charset;

/**
 * @author : Sun
 * @description : FastDFS上传下载 Demo、占时不用
 * @date : 2019/11/5 21:22
 * @version : 1.0
 */
@Component
@Slf4j
public class FastDFSClientWrapper {

    private final FastFileStorageClient storageClient;

    public FastDFSClientWrapper(FastFileStorageClient storageClient) {
        this.storageClient = storageClient;
    }

    /**
     * @author Sun
     * @description 上传文件
     * @date 2019/11/5 21:22
     * @param file:
     * @return java.lang.String
     **/
    public String uploadFile(MultipartFile file) throws IOException {
        StorePath storePath = storageClient.uploadFile(file.getInputStream(),file.getSize(), FilenameUtils.getExtension(file.getOriginalFilename()),null);
        return getResAccessUrl(storePath);
    }


    /**
     * @author Sun
     * @description 将一段字符串生成一个文件上传
     * @date 2019/11/5 21:22
     * @param content:
     * @param fileExtension:
     * @return java.lang.String
     **/
    public String uploadFile(String content, String fileExtension) {
        byte[] buff = content.getBytes(Charset.forName("UTF-8"));
        ByteArrayInputStream stream = new ByteArrayInputStream(buff);
        StorePath storePath = storageClient.uploadFile(stream,buff.length, fileExtension,null);
        return getResAccessUrl(storePath);
    }


    /**
     * @author Sun
     * @description 封装图片完整URL地址
     * @date 2019/11/5 21:22
     * @param storePath:
     * @return java.lang.String
     **/
    private String getResAccessUrl(StorePath storePath) {
        return "http://huatonghh.cn:9900/" + storePath.getFullPath();
    }


    /**
     * @author Sun
     * @description 删除文件
     * @date 2019/11/5 21:22
     * @param fileUrl:
     **/
    public void deleteFile(String fileUrl) {
        if (StringUtils.isEmpty(fileUrl)) {
            return;
        }
        try {
            StorePath storePath = StorePath.parseFromUrl(fileUrl);
            storageClient.deleteFile(storePath.getGroup(), storePath.getPath());
        } catch (FdfsUnsupportStorePathException e) {
            log.warn(e.getMessage());
        }
    }


    /**
     * @author Sun
     * @description 文件上传
     *              最后返回fastDFS中的文件名称;group1/M00/01/04/CgMKrVvS0geAQ0pzAACAAJxmBeM793.doc
     * @date 2019/11/5 21:22
     * @param bytes:
     * @param fileSize:
     * @param extension:
     * @return java.lang.String
     **/
    public String uploadFile(byte[] bytes, long fileSize, String extension) {
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
        StorePath storePath = storageClient.uploadFile(byteArrayInputStream, fileSize, extension, null);
        System.out.println(storePath.getGroup() + "==" + storePath.getPath() + "======" + storePath.getFullPath());
        return storePath.getFullPath();
    }


    /**
     * @author Sun
     * @description 下载文件、返回文件字节流大小
     * @date 2019/11/5 21:23
     * @param fileUrl:
     * @return byte[]
     **/
    public byte[] downloadFile(String fileUrl) {
        String group = fileUrl.substring(0, fileUrl.indexOf("/"));
        String path = fileUrl.substring(fileUrl.indexOf("/") + 1);
        DownloadByteArray downloadByteArray = new DownloadByteArray();
        return storageClient.downloadFile(group, path, downloadByteArray);
    }

}
