package com.huatonghh.base.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * Description : 模板管理-主信息
 * @author : Sun
 * @date : 2019/8/31 14:01
 * @version : 1.0
 */
@Data
@ApiModel("模板管理-主")
public class TemplateMainDto implements Serializable {

    private static final long serialVersionUID = -2532201524786475394L;

    @ApiModelProperty(value = "自增id：新增不传、修改传")
    private Integer id;

    @ApiModelProperty(value = "套餐模板名称")
    @NotNull
    private String templateName;

    @ApiModelProperty(value = "模板类型：1.车辆方案套餐，2.其他")
    @NotNull
    private Byte templateType;

    @ApiModelProperty(value = "模板备注")
    private String remark;

    private List<TemplateVehRiskPlanDto> templateVehRiskPlanDtos;

}
