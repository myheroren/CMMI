package com.huatonghh.policy.service.dto.claim.noncar;

import com.huatonghh.policy.domain.claim.noncar.ClaimHistory;
import com.huatonghh.policy.domain.claim.noncar.ClaimPay;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/11
 */
@Data
@ApiModel("非车理赔详情")
public class ClaimDetailDTO {

    private ClaimBasicDTO basicInfo;//from policy_uncar_claim

    private PolicyDTO policyInfo;//from policy_main

    private List<ClaimHistory> claimHistories;//from policy_claim_history

    private List<ClaimPay> payInfo;//from policy_uncar_claim_pay
}
