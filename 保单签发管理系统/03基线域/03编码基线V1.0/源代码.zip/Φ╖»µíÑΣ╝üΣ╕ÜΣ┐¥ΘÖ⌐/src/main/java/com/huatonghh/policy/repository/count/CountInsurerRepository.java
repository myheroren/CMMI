package com.huatonghh.policy.repository.count;

import com.huatonghh.policy.domain.count.CountInsurer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/11
 */
public interface CountInsurerRepository extends JpaRepository<CountInsurer, Integer> {

    /**
     * 根据保险公司分类
     *
     * @param beginDate
     * @param endDate
     * @return
     */
    @Transactional(rollbackFor = RuntimeException.class)
    @Query(value = "select c.belong_company as belongCompany,SUM(c.total_premium)  as totalPremium from count_insurer c  where  c.type =1 and c.create_time between :beginDate and :endDate GROUP BY c.belong_company", nativeQuery = true)
    List findAllByBelongCompany(@Param("beginDate") Date beginDate, @Param("endDate") Date endDate);

    @Transactional(rollbackFor = RuntimeException.class)
    @Modifying
    @Query(value = "INSERT into count_insurer (belong_company,total_premium,create_time,type)\n" +
        "SELECT m.belong_company, SUM( m.total_premium ), DATE_FORMAT( m.create_time, \"%Y-%m-%d\" ) create_time ,1\n" +
        "\tFROM policy_main m \n" +
        "\tWHERE 1 = 1 \n" +
        "AND to_days(now()) - to_days( create_time )<= 1 \n" +
        "\tGROUP BY \tm.belong_company, DATE_FORMAT(create_time,'%Y-%m-%d')", nativeQuery = true)
    void batchInsert();
}

//@Query(value = "select * from count_insurer c  where  c.type =1 and c.create_time between :beginDate and :endDate order by c.create_time", nativeQuery = true)
