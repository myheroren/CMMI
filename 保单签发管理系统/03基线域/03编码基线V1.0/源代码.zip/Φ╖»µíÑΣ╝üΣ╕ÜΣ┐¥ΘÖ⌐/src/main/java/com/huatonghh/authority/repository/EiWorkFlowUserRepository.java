package com.huatonghh.authority.repository;

import com.huatonghh.authority.domain.EiWorkFlowUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/30
 */
public interface EiWorkFlowUserRepository extends JpaRepository<EiWorkFlowUser, Integer> {

    /**
     * 根据部门id和工作流层级
     *
     * @param departId 部门
     * @param level    1领导 2经理 3员工
     * @return 用户
     */
    List<EiWorkFlowUser> findAllByDepartIdAndLevel(String departId, Integer level);

    /**
     * 根据用户id和角色id
     *
     * @param userId 用户id
     * @param roleId 角色id
     * @return 工作流角色
     */
    List<EiWorkFlowUser> findAllByUserIdAndRoleId(String userId, Integer roleId);

    /**
     * 根据userId删除
     *
     * @param userId 用户id
     */
    @Modifying
    @Transactional
    @Query(value = "delete from ei_work_flow_user where user_id = :userId", nativeQuery = true)
    void delete(@Param("userId") String userId);
}
