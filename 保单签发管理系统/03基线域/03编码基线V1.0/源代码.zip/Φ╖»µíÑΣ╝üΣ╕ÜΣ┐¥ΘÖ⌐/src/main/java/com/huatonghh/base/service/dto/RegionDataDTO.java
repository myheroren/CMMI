package com.huatonghh.base.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author wanggl
 * @date 2020/6/3 19:09
 */
@Data
@ApiModel(value = "地区数据传输对象")
public class RegionDataDTO {
    @ApiModelProperty(value = "地区名称")
    private String name;

    @ApiModelProperty(value = "地区代码")
    private String code;

    @ApiModelProperty(value = "上级地区代码")
    private String parCode;

    @ApiModelProperty(value = "下级地区数组")
    private List<RegionDataDTO> chird;
}
