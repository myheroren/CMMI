package com.huatonghh.policy.service.dto.claim.form;

import lombok.Data;

import java.math.BigInteger;
import java.util.Date;

/**
 * @author : wh
 * description : 标段统计
 * @version : 1.0
 * @date : 2020/5/25 14:07
 */
@Data
public class ClaimHighwayBidDTO {
    private BigInteger reportId;
    private String belongCompany;
    private String belongCompanyName;
    /**
     * 总保费
     */
    private BigInteger totalPremium;
    /**
     * 总保费
     */
    private BigInteger totalAmount;
    private Byte claimStatus;
    private Date claimBeginDate;
    private String startCompany;
    /**
     * 工程类别
     */
    private Byte engType;
    /**
     * 标段
     */
    private String belongBid;
    /**
     * 估损额
     */
    private BigInteger preLossAmount;
    /**
     * 索赔额
     */
    private BigInteger askForAmount;
    /**
     * 赔偿额
     */
    private BigInteger payAmount;
}
