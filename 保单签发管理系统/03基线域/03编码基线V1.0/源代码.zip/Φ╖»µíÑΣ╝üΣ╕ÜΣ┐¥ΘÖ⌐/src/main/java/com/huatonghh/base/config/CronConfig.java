package com.huatonghh.base.config;

import cn.hutool.cron.CronUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author : Sun
 * @description :
 * @date : 2019/11/18 15:19
 * @version : 1.0
 */
@Configuration
public class CronConfig {

//    @Bean
//    public void test() {
//        CronUtil.setMatchSecond(true);
//        CronUtil.start();
//    }

}
