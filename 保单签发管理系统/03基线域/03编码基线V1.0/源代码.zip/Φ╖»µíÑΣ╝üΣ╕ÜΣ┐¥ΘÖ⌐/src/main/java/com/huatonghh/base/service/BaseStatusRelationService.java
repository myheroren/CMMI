package com.huatonghh.base.service;

import com.huatonghh.base.domain.BaseStatusRelation;
import com.huatonghh.base.repository.BaseStatusRelationRepository;
import com.huatonghh.common.exception.BusinessException;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/7
 */
@Service
@AllArgsConstructor
public class BaseStatusRelationService {
    private final BaseStatusRelationRepository relationRepository;

    public String nextStatus(String currentStatus, String operation) {
        Optional<BaseStatusRelation> op = relationRepository.findByCurrentStatusAndOperation(currentStatus, operation);
        if (op.isPresent()) {
            return op.get().getNextStatus();
        }
        throw new BusinessException("状态关系配置有误");
    }

}
