package com.huatonghh.policy.web.rest.claim;

import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.policy.service.claim.noncar.ClaimFormService;
import com.huatonghh.policy.service.dto.claim.form.ClaimDetailFormDTO;
import com.huatonghh.policy.service.dto.claim.form.ClaimHighwayBidFormDTO;
import com.huatonghh.policy.service.dto.claim.form.ClaimHighwayFormDTO;
import com.huatonghh.policy.service.dto.claim.noncar.ClaimFormQuery;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author : wh
 * description : 理赔报表展示
 * @version : 1.0
 * @date : 2020/3/10 02:49
 */
@AllArgsConstructor
@RestController
@RequestMapping("api/claim_form/v1")
@Api(tags = "33、理赔报表展示", value = "理赔报表展示")
public class ClaimFormController {

    private final ClaimFormService claimFormService;

    @PostMapping(value = "detail")
    @ApiOperation(value = "理赔出险明细", notes = "理赔出险明细", httpMethod = "POST")
    @Timed
    public ApiResponse<List<ClaimDetailFormDTO>> detail(@RequestBody ClaimFormQuery query) {
        return ApiResponse.ofSuccess(claimFormService.detailForm(query));
    }

    @PostMapping(value = "gather")
    @ApiOperation(value = "公路工程一切险分类汇总", notes = "公路工程一切险分类汇总", httpMethod = "POST")
    @Timed
    public ApiResponse<List<ClaimHighwayFormDTO>> gather(@RequestBody ClaimFormQuery query) {
        return ApiResponse.ofSuccess(claimFormService.gatherForm(query));
    }

    @PostMapping(value = "bid")
    @ApiOperation(value = "公路工程一切险标段统计表", notes = "公路工程一切险标段统计表", httpMethod = "POST")
    @Timed
    public ApiResponse<List<ClaimHighwayBidFormDTO>> bidForm(@RequestBody ClaimFormQuery query) {
        return ApiResponse.ofSuccess(claimFormService.bidForm(query));
    }
}
