package com.huatonghh.base.web.rest;

import com.huatonghh.base.service.BaseCodeService;
import com.huatonghh.base.service.dto.BaseCodeCondition;
import com.huatonghh.base.service.dto.BaseCodeDto;
import com.huatonghh.base.service.dto.InsAccdntDataDTO;
import com.huatonghh.base.service.dto.RegionDataDTO;
import com.huatonghh.common.util.system.ApiResponse;
import com.huatonghh.common.util.system.PageInfo;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * @author : Sun
 * @version : 1.0
 * @description : 基础代码字典管理
 * @date : 2019/11/5 21:04
 */
@RestController
@RequestMapping("/api/base/v1")
@Api(tags = "20、基础代码字典管理", value = "基础代码")
@Slf4j
@AllArgsConstructor
public class BaseCodeController {

    private final BaseCodeService baseCodeService;

    @GetMapping(value = "/all_code")
    @ApiOperation(value = "1、查询所有基础代码", notes = "返回前端，用于日常业务匹配", httpMethod = "GET")
    @Timed
    public ApiResponse<String> allBaseCode() {
        return ApiResponse.ofSuccess(baseCodeService.allBaseCode());
    }

    @PostMapping(value = "/code_list")
    @ApiOperation(value = "2、根据类型查询基础代码", notes = "用于字典管理列表查询", httpMethod = "POST")
    @Timed
    public ApiResponse<PageInfo<BaseCodeDto>> getCodesByTypeCode(@RequestBody @Valid BaseCodeCondition baseCodeCondition) {
        return ApiResponse.ofSuccess(baseCodeService.queryBaseCode(baseCodeCondition));
    }

    @PostMapping(value = "/save")
    @ApiOperation(value = "3、新增或更新基础代码", httpMethod = "POST")
    @Timed
    public ApiResponse saveOrUpdateBaseCode(@RequestBody BaseCodeDto baseCodeDto) {
        baseCodeService.saveOrUpdateBaseCode(baseCodeDto);
        return ApiResponse.ofSuccess(null);
    }

    @DeleteMapping(value = "/delete")
    @ApiOperation(value = "4、删除基础代码", notes = "可进行批量、也可单独删除", httpMethod = "DELETE")
    @Timed
    public ApiResponse batchDeleteBaseCode(int[] ids) {
        baseCodeService.batchDeleteBaseCode(ids);
        return ApiResponse.ofSuccess(null);
    }

    @GetMapping(value = "/type_list")
    @ApiOperation(value = "5、基础代码类型下拉框列表", httpMethod = "GET")
    @Timed
    public ApiResponse<List<BaseCodeDto>> typeList() {
        return ApiResponse.ofSuccess(baseCodeService.typeList());
    }

    @GetMapping(value = "/regionDataList")
    @ApiOperation(value = "7、获取省市区三级联动数组", httpMethod = "GET")
    @Timed
    public ApiResponse<List<RegionDataDTO>> regionDataList() {
        return ApiResponse.ofSuccess(baseCodeService.regionDataList());
    }

    @GetMapping(value = "/InsAccdntDataList")
    @ApiOperation(value = "8、获取工程险二级联动数组", httpMethod = "GET")
    @Timed
    public ApiResponse<List<InsAccdntDataDTO>> insAccdntDataList() {
        return ApiResponse.ofSuccess(baseCodeService.insAccdntDataList());
    }
}
