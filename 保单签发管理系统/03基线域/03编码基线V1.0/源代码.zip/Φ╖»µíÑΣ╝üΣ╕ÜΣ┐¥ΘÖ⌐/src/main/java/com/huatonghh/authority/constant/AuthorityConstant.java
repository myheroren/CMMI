package com.huatonghh.authority.constant;

/**
 * @author : Sun
 * @description : 权限类文件注释
 * @date : 2019/11/4 19:10
 * @version : 1.0
 */
public final class AuthorityConstant {

    /** cas登录时，根据ticket获取用户信息的地址 TODO:可写入yml配置文件中 */
    public final static String CAS_LOGIN_TICKET_HTTP = "http://47.112.107.16:10000/cas/serviceValidate?service=";
    public final static String CAS_LOGOUT = "http://47.112.107.16:10000/cas/logout";

    /** token前缀 */
    public final static String PREFIX_TOKEN = "Bearer ";

    public static final String LOGIN_REGEX = "^[_.@A-Za-z0-9-]*$";

    public static final String SYSTEM_ACCOUNT = "system";
    public static final String ADMIN_ACCOUNT = "admin";
    public static final String DEFAULT_LANGUAGE = "en";
    public static final String ANONYMOUS_USER = "anonymoususer";

    /** 初始化密码admin */
    public static final String INITIAL_PASSWORD = "123456";

    /** 菜单权限如果不传id，则默认查询全部菜单 */
    public static final Integer AUTHORITY_TREE_HEAD = 0;

    /** 默认查询全部部门 */
    public static final Integer DEPART_TREE_HEAD = 1;

    /** 默认查询全部企业保险交投集团部门 */
    public static final String DEPART_TREE_HEAD_QYBX = "15";
    public static final String DEPART_TREE_HEAD_QYBX_GENERAL = "-1";

    /** 权限管理相应的缓存key值定义 */
    public static final String EI_USERS_BY_LOGIN_CACHE  = "lq_company_eiUsersByLogin";

    public static final String EI_ROLES_BY_LOGIN_CACHE = "lq_company_eiRolesByLogin";

    public static final String EI_DEPARTS_BY_LOGIN_CACHE = "lq_company_eiDepartsByLogin";

    public static final String EI_AUTHORITYS_BY_LOGIN_CACHE = "lq_company_eiAuthoritysByLogin";

    /** 是否 懒加载查询 0不是；1是 */
    public static final Integer NO_TLAZY = 0;
    public static final Integer IS_LAZY = 1;

    /** JWTFilter中的权限常亮配置 */
    public static final String AUTHORIZATION_HEADER = "Authorization";
    public static final String INS = "INS:";

    /** 区分交投集团账号、保险公司账号标识 */
    public static final String JTJT = "1";
    public static final String BXGS = "2";

    /** 系统默认登录用户角色 */
    public static final String ADMIN = "ROLE_ADMIN";
    public static final String USER = "ROLE_USER";
    public static final String ANONYMOUS = "ROLE_ANONYMOUS";

    /** 人员信息同步 相应的redis缓存key值定义 */
    public static final String EI_USERS_BY_HR  = "lq_company_eiUsersByHR";

    public static final String EI_DEPARTS_BY_HR = "lq_company_eiDepartsByHR";

    /** 人员信息登录 信息有效期（分钟） */
    public static final Integer EI_USERS_LOGIN_EXPIRATION = 180;
    public static final String USER_ROLE = "USER_ROLE";
    public static final String USER_COMPANY = "USER_COMPANY";

    /**
     * 人员信息同步 信息有效期（分钟）
     */
    public static final Integer EI_USERS_BY_HR_EXPIRATION = 120;

    public static final Integer EI_DEPARTS_BY_HR_EXPIRATION = 120;

}
