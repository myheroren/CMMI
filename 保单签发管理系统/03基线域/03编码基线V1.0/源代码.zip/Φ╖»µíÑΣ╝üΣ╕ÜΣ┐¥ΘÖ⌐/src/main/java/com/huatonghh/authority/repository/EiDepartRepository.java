package com.huatonghh.authority.repository;

import com.huatonghh.authority.domain.EiDepart;
import com.huatonghh.authority.service.dto.EiDepartRoleDto;
import com.huatonghh.authority.service.dto.EiDepartTreeDto;
import com.huatonghh.common.service.dto.ResponseStringKeyValueDto;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;


/**
 * @author : Sun
 * @version : 1.0
 * @description : 交投集团-公司部门-数据仓库
 * @date : 2019/11/4 19:44
 */
@Repository
public interface EiDepartRepository extends JpaRepository<EiDepart, String> {

    /**
     * 根据部门名称，查询部门详细信息
     *
     * @param name: 部门名称
     * @return java.util.Optional<com.huatonghh.authority.domain.EiDepart>
     * @author Sun
     * @date 2019/11/4 19:45
     **/
    Optional<EiDepart> findOneByName(String name);


    /**
     * 根据部门名称，查询部门详细信息
     *
     * @param id: 部门id
     * @return java.util.Optional<com.huatonghh.authority.domain.EiDepart>
     * @author Sun
     * @date 2019/11/4 19:45
     **/
    @Override
    Optional<EiDepart> findById(String id);


    /**
     * 查询二叉树列表时，无需查部门下员工数据
     *
     * @return java.util.List<com.huatonghh.authority.domain.EiDepart>
     * @author Sun
     * @date 2019/11/4 19:46
     **/
    @Override
    List<EiDepart> findAll();


    /**
     * 排序查询所有部门数据
     *
     * @param s: 排序对象
     * @return java.util.List<com.huatonghh.authority.domain.EiDepart>
     * @author Sun
     * @date 2019/11/4 19:47
     **/
    @Override
    @EntityGraph(attributePaths = "authorities")
    List<EiDepart> findAll(Sort s);


    /**
     * 查询下一级子部门
     *
     * @param parentId: 父部门id
     * @return java.util.List<com.huatonghh.authority.domain.EiDepart>
     * @author Sun
     * @date 2019/11/4 19:47
     **/
    List<EiDepart> findAllByParentId(String parentId);

    /**
     * 根据层级和类型查询部门列表
     *
     * @param htLevel ht层级
     * @param type    Company/Depart
     * @return 部门列表
     */
    List<EiDepart> findAllByHtLevelAndType(String htLevel, String type);

    /**
     * 根据部门id，查询所有子部门列表，包含当前公司
     *
     * @param id: 部门id
     * @return java.util.List<com.huatonghh.authority.domain.EiDepart>
     * @author Sun
     * @date 2019/11/4 19:48
     **/
    @EntityGraph(attributePaths = "authorities")
    @Query(value = "select d1 from EiDepart d1, EiDepart d2 WHERE d1.ids LIKE CONCAT(d2.ids, '%') and d2.parentId = :id and d1.type = :type")
    List<EiDepart> findCompanyByParentId(@Param("id") String id,@Param("type") String type);

    /**
     * 根据部门id，查询所有子部门列表，包含当前公司
     *
     * @param id: 部门id
     * @return java.util.List<com.huatonghh.authority.domain.EiDepart>
     * @author Sun
     * @date 2019/11/4 19:48
     **/
    @EntityGraph(attributePaths = "authorities")
    @Query(value = "select d1 from EiDepart d1, EiDepart d2 WHERE d1.ids LIKE CONCAT(d2.ids, '%') and d2.id = :id")
    List<EiDepart> findParentDepartById(@Param("id") String id);


    /**
     * 根据父部门id，查询所有子部门列表，不会包含此父部门id
     *
     * @param id: 父部门id
     * @return java.util.List<com.huatonghh.authority.domain.EiDepart>
     * @author Sun
     * @date 2019/11/4 19:48
     **/
    @EntityGraph(attributePaths = "authorities")
    @Query(value = "select d1 from EiDepart d1, EiDepart d2 WHERE d1.ids LIKE CONCAT(d2.ids, '%') and d2.parentId = :id")
    List<EiDepart> findParentDepartByDepartId(@Param("id") String id);

    /**
     * 根据父部门id，查询所有子部门列表，不会包含此父部门id
     *
     * @param id: 父部门id
     * @return java.util.List<com.huatonghh.authority.domain.EiDepart>
     * @author Sun
     * @date 2019/11/4 19:48
     **/
    @EntityGraph(attributePaths = "authorities")
    @Query(value = "select d1 from EiDepart d1, EiDepart d2 WHERE d1.ids LIKE CONCAT(d2.ids, '%') and d2.parentId = :id and d1.type = :type")
    List<EiDepart> findCompanyByDepartIdAndType(@Param("id") String id, @Param("type") String type);


    /**
     * 查询某个用户所属部门信息
     *
     * @param id: 用户id
     * @return java.util.Set<com.huatonghh.authority.domain.EiDepart>
     * @author Sun
     * @date 2019/11/4 19:50
     **/
    @Query(nativeQuery = true, value = "SELECT d.* FROM ei_depart_user du, ei_depart d WHERE du.depart_id = d.id AND du.user_id = ?1")
    Set<EiDepart> findDepartByUserId(String id);

    /**
     * 查询某个用户所属公司和角色信息
     *
     * @param id: 用户id
     * @return java.util.Set<com.huatonghh.authority.domain.EiDepart>
     * @author Sun
     * @date 2019/11/4 19:50
     **/
    @Query(nativeQuery = false, value = "select new com.huatonghh.authority.service.dto.EiDepartRoleDto(d.id,d.name,d.parentId,d.level,d.ids, d.type,d.htLevel,er.roleId,er.roleName,er.position) from EiDepartRole edr,RoleUser eur, EiDepart d ,EiRole er where edr.companyId = d.id and eur.roleId = edr.roleId and er.roleId = edr.roleId and eur.userId = ?1")
    Set<EiDepartRoleDto> findDepartAndRoleByUserId(String id);

    /**
     * 根据部门id，查询所有子部门列表
     *
     * @param id: 部门id
     * @return java.util.Set<com.huatonghh.authority.domain.EiDepart>
     * @author Sun
     * @date 2019/11/4 19:50
     **/
    @Query(nativeQuery = true, value = "select e.* from ei_depart e where parent_id = ?1")
    Set<EiDepart> findSubDepartById(String id);


    /**
     * 删除当前部门，及其所有子部门
     *
     * @param id: 部门id
     * @author Sun
     * @date 2019/11/4 19:50
     **/
    @Modifying
    @Query(nativeQuery = true, value = "DELETE FROM ei_depart WHERE ids LIKE CONCAT(:id ,'%')")
    void deleteDepart(@Param("id") String id);


    /**
     * 先删除部门员工中间表，才可以删除部门表
     *
     * @param id: 部门id
     * @author Sun
     * @date 2019/11/4 19:51
     **/
    @Modifying
    @Query(nativeQuery = true, value = "DELETE du FROM ei_depart d, ei_depart_user du WHERE d.ids LIKE CONCAT(:id ,'%') and d.id = du.depart_id")
    void deleteDepartUser(@Param("id") String id);


    /**
     * 新增部门用户中间表信息
     *
     * @param departId: 部门id
     * @param userId:   用户id
     * @author Sun
     * @date 2019/11/4 19:51
     **/
    @Modifying
    @Query(nativeQuery = true, value = "INSERT INTO ei_depart_user VALUES (?1, ?2)")
    void insert(String departId, String userId);


    /**
     * 根据部门id，获取部门id、名称key value数据集
     *
     * @param id: 部门id
     * @return java.util.List<com.huatonghh.common.service.dto.ResponseStringKeyValueDto>
     * @author Sun
     * @date 2019/11/6 15:51
     **/
    @Query(value = "SELECT DISTINCT new com.huatonghh.common.service.dto.ResponseStringKeyValueDto( d.id, d.name ) FROM EiDepart d WHERE d.id = :id")
    List<ResponseStringKeyValueDto> queryNameById(@Param("id") String id);

    /**
     * 根据部门name获取部门id
     *
     * @param name
     * @return
     */
    @Query(value = "SELECT DISTINCT new com.huatonghh.common.service.dto.ResponseStringKeyValueDto( d.id, d.name ) FROM EiDepart d WHERE d.name = :name")
    List<ResponseStringKeyValueDto> queryIdByName(@Param("name") String name);


    /**
     * 根据Id查询id和name
     * @return
     */
    @Query("select new com.huatonghh.authority.service.dto.EiDepartTreeDto(e.id, e.name, e.htLevel) from EiDepart e where e.type = 'Company'")
    List<EiDepartTreeDto> findNameAndId();
}
