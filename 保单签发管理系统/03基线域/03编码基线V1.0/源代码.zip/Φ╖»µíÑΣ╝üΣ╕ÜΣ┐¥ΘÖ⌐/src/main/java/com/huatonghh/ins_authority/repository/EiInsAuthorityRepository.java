package com.huatonghh.ins_authority.repository;

import com.huatonghh.ins_authority.domain.EiInsAuthority;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


/**
 * @author : Sun
 * @description : 交投集团-权限菜单-数据仓库
 * @date : 2019/11/4 19:44
 * @version : 1.0
 */
@Repository
public interface EiInsAuthorityRepository extends JpaRepository<EiInsAuthority, Integer> {

    /**
     * 删除菜单对应的角色中间表
     *
     * @author Sun
     * @date 2019/11/4 19:44
     * @param id: 菜单id
     **/
    @Modifying
    @Query(nativeQuery = true, value = "delete from ei_ins_role_authority where authority_id = :id")
    void deleteRoleAuthorityById(@Param("id") Integer id);

}
