package com.huatonghh.policy.service.dto.policy;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.math.BigInteger;

/**
 * description:保单-工程险VO
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/22
 */
@Data
@ApiModel("保单-工程险")
public class PolicyEngineeringDTO {
    @ApiModelProperty(value = "id")
    private BigInteger id;
    @ApiModelProperty(value = "保单号")
    @NotBlank
    private String policyNo;
    @ApiModelProperty(value = "工程类别")
    private String engType;
    @ApiModelProperty(value = "施工合同数")
    private String contract;
    @ApiModelProperty(value = "工程名字")
    private String engName;
    @ApiModelProperty(value = "工程造价")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger engCost;
    @ApiModelProperty(value = "所属标段")
    private String belongBid;
    @ApiModelProperty(value = "保费缴纳期次")
    private Integer period;
    @ApiModelProperty(value = "保证期")
    private String assureData;
    @ApiModelProperty(value = "防火防损费比例")
    private String preventionProp;
    @ApiModelProperty(value = "赔偿限额，第三者责任部分")
    private String limitThird;
    @ApiModelProperty(value = "免赔条件，第三者责任部分")
    private String deductibleThird;
    @ApiModelProperty(value = "免赔条件，物质部分")
    private String deductibleMaterial;
    @ApiModelProperty(value = "特别约定")
    private String specialForm;
}
