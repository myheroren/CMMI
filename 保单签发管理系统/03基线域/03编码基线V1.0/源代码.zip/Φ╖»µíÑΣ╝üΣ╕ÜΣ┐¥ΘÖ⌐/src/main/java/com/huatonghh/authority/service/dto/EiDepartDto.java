package com.huatonghh.authority.service.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * @author : Sun
 * @description : 部门、也叫分公司
 * @date : 2019/11/4 21:10
 * @version : 1.0
 */
@Data
@ApiModel(value = "部门、也叫分公司")
public class EiDepartDto implements Serializable {

    private static final long serialVersionUID = 4599743566838575095L;

    @ApiModelProperty(value = "部门id")
    private String id;

    @ApiModelProperty(value = "部门名称")
    private String name;

    @ApiModelProperty(value = "公司等级")
    private String level;

    @ApiModelProperty(value = "父id")
    private String parentId;

    @ApiModelProperty(value = "ids")
    private String ids;

    @ApiModelProperty(value = "公司、部门")
    private String type;

    @ApiModelProperty(value = "公司等级")
    private String htLevel;

    @ApiModelProperty(value = "部门下员工列表")
    private Set<EiUserDto> authorities = new HashSet<>();

    public EiDepartDto() {
    }

    public EiDepartDto(String id, String name, String parentId) {
        this.id = id;
        this.name = name;
        this.parentId = parentId;
    }

    public EiDepartDto(String id, String name, String parentId, String ids) {
        this.id = id;
        this.name = name;
        this.parentId = parentId;
        this.ids = ids;
    }
}
