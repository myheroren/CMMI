package com.huatonghh.policy.service.dto.count;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigInteger;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/11
 */
@Data
@ApiModel("保险公司险种维度统计结果")
public class CountInsurerKindDTO {
    @ApiModelProperty("保险公司")
    private String belongCompany;
    @ApiModelProperty("总保费")
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger totalPremium;
    @ApiModelProperty("车险保费")
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger carPremium;
    @ApiModelProperty("责任险保费")
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger liabilityPremium;
    @ApiModelProperty("工程险保费")
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger engPremium;
    @ApiModelProperty("意外险保费")
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger accidentPremium;
    @ApiModelProperty("财产险保费")
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger assetsPremium;
    @ApiModelProperty("货运险保费")
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger goodsPremium;
    @ApiModelProperty("其他险保费")
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger elsePremium;

}
