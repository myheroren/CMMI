package com.huatonghh.policy.service.dto.claim.noncar;

import com.huatonghh.policy.domain.plan.PlanEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author ghy
 * Date: 2020/10/20 11:54
 */
@Data
@ApiModel("报案号关联DTO")
public class ReportAssociationDTO {

    @ApiModelProperty("报案号")
    private String reportNo;

    @ApiModelProperty("报案时间")
    private Date reportTime;

    @ApiModelProperty("出险时间")
    private Date accidentTime;

    @ApiModelProperty("出险经过")
    private String accidentDetail;
}
