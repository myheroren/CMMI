package com.huatonghh.excel.service.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import lombok.Data;

/**
 * description:公路工程一切险分类汇总表
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/9
 */
@Data
@ContentRowHeight(20)
@HeadRowHeight(20)
@ColumnWidth(15)
public class ClaimHighwayFormData {
    @ExcelProperty(value = "项目名称", index = 0)
    private String proName;

    @ExcelProperty(value = "工程类别", index = 1)
    private String engTypeName;

    @ExcelProperty(value = "施工合同数", index = 2)
    private String countContract;

    @ExcelProperty(value = "购买保险份数", index = 3)
    private String countPolicy;

    @ExcelProperty(value = "支付保险费额", index = 4)
    private String totalPremium;

    @ExcelProperty(value = "出险次数", index = 5)
    private String countClaim;

    @ExcelProperty(value = "损失额", index = 6)
    private String preLossAmount;

    @ExcelProperty(value = "索赔次数", index = 7)
    private String countApply;

    @ExcelProperty(value = "索赔金额", index = 8)
    private String askForAmount;

    @ExcelProperty(value = "获赔次数", index = 9)
    private String countGetClaim;

    @ExcelProperty(value = "赔偿额", index = 10)
    private String payAmount;

    @ExcelProperty(value = "获赔额占保费比率", index = 11)
    private String ratePremium;

    @ExcelProperty(value = "获赔额占索赔比率", index = 12)
    private String rateAskFor;

}
