package com.huatonghh.policy.service.dto.claim.form;

import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.StringJoiner;

/**
 * @author wanggl
 * @date 2020-11-13 09:59
 */
public class ClaimMessageDTO implements Serializable {

    private static final long serialVersionUID = -6547729446603852691L;

    @ApiModelProperty(value = "理赔报案id", required = true, position = 1)
    @NotNull(message = "理赔报案id必传")
    private String reportId;

    @ApiModelProperty(value = "消息内容", required = true, position = 2)
    @NotNull(message = "消息内容必传")
    private String content;

    public String getReportId() {
        return reportId;
    }

    public void setReportId(String reportId) {
        this.reportId = reportId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", ClaimMessageDTO.class.getSimpleName() + "[", "]")
            .add("reportId=" + reportId)
            .add("content='" + content + "'")
            .toString();
    }
}
