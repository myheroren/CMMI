package com.huatonghh.excel.listener;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.fastjson.JSON;
import com.huatonghh.base.service.BaseCodeService;
import com.huatonghh.base.service.dto.BaseCodeCondition;
import com.huatonghh.base.service.dto.BaseCodeDto;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.excel.domain.ImportFailEntity;
import com.huatonghh.excel.repository.ImportFailDAO;
import com.huatonghh.excel.service.ReadExcelService;
import com.huatonghh.excel.service.dto.DataImportResult;
import com.huatonghh.excel.service.dto.PolicyImportData;
import com.huatonghh.ins_authority.domain.EiInsDepart;
import com.huatonghh.ins_authority.service.EiInsDepartService;
import com.huatonghh.policy.constant.PolicyConstant;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import java.math.BigInteger;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * description: 保单导入
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/8
 */
@Slf4j
public class PolicyImportDataListen extends AnalysisEventListener<PolicyImportData> {

    private final ReadExcelService readExcelService;
    private final Pattern P = Pattern.compile("[\u4e00-\u9fa5]");
    private List<PolicyImportData> errorList = new ArrayList<>();
    ;
    private Integer successNum;
    private final Map<String, String> insuranceCategoryMap;
    private final Map<String, String> kindCodeMap;
    private final EiInsDepartService eiInsDepartService;
    private final ImportFailDAO importFailDAO;

    private final DataImportResult dataImportResult;

    public PolicyImportDataListen(ReadExcelService readExcelService, ImportFailDAO importFailDAO, DataImportResult dataImportResult, BaseCodeService baseCodeService, EiInsDepartService eiInsDepartService) {
        this.readExcelService = readExcelService;
        this.importFailDAO = importFailDAO;
        this.dataImportResult = dataImportResult;
        this.eiInsDepartService = eiInsDepartService;
        //险种与险种细分关系Map
        insuranceCategoryMap = new HashMap<>(16);
        kindCodeMap = new HashMap<>(32);
        //baseCode查询条件
        BaseCodeCondition baseCodeCondition = new BaseCodeCondition();
        baseCodeCondition.setPageNum(1);
        baseCodeCondition.setPageSize(Integer.MAX_VALUE);
        //险种
        baseCodeCondition.setTypeCode("insurance_category");
        List<BaseCodeDto> baseCodes = baseCodeService.queryBaseCode(baseCodeCondition).getList();
        for (BaseCodeDto baseCode : baseCodes) {
            insuranceCategoryMap.put(baseCode.getCodeName(), baseCode.getCodeId());
        }
        //险种细分
        baseCodeCondition.setTypeCode("kind_code");
        baseCodes = baseCodeService.queryBaseCode(baseCodeCondition).getList();
        for (BaseCodeDto baseCode : baseCodes) {
            kindCodeMap.put(baseCode.getCodeName(), baseCode.getCodeId());
        }
        kindCodeMap.put("车险-交强险", PolicyConstant.KIND_JQ);
        kindCodeMap.put("特种车险-交强险", PolicyConstant.KIND_JQ);
        kindCodeMap.put("车险-商业险", PolicyConstant.KIND_SY);
        kindCodeMap.put("特种车险-商业险", PolicyConstant.KIND_SY);
        kindCodeMap.put("补充医疗", "22");
        kindCodeMap.put("道路危险货运承运人责任险", "22");
        kindCodeMap.put("境外保险", "22");
    }

    private final Set<PolicyImportData> dataSet = new HashSet<>();
    /**
     * 每隔500条存储数据库，实际使用中可以3000条，然后清理list ，方便内存回收
     */
    private static final int BATCH_COUNT = 200;


    /**
     * 解析成功条数
     */
    private int invokeNum = 0;

    /**
     * 处理每条数据
     *
     * @param data            数据
     * @param analysisContext 1
     */
    @Override
    public void invoke(PolicyImportData data, AnalysisContext analysisContext) {
        log.info("解析到一条数据:{}", JSON.toJSONString(data));
        if (!checkoutData(data)) {
            return;
        }

        dataSet.add(data);
        invokeNum++;
        if (dataSet.size() >= BATCH_COUNT) {
            readExcelService.importPolicy(dataSet, insuranceCategoryMap, kindCodeMap, dataImportResult.getImportBatchNo(), successNum);
            successNum++;
            dataSet.clear();
        }
    }


    /**
     * 数据解析结束后
     *
     * @param analysisContext 1
     */
    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {
        readExcelService.importPolicy(dataSet, insuranceCategoryMap, kindCodeMap, dataImportResult.getImportBatchNo(), successNum);
        log.info("失败的数据：");
        log.info(errorList.toString());
        log.info("成功解析条数：" + invokeNum);
        log.info("失败条数：" + errorList.size());
        if (errorList.isEmpty()) {
            return;
        }
        // 错误信息存库
        ImportFailEntity failEntity = new ImportFailEntity();
        failEntity.setImportBatchNo(dataImportResult.getImportBatchNo());
        failEntity.setData(JSON.toJSONString(errorList));
        failEntity.setType("2");
        BigInteger id = importFailDAO.save(failEntity).getId();
        dataImportResult.setImportBatchNo(dataImportResult.getImportBatchNo());
        dataImportResult.setFailNum(errorList.size());
        dataImportResult.setFailId(id);
        // log.info("文件解析结束:导入信息为：" + dataImportResult);
    }

    private boolean isContainChinese(String str) {
        Matcher m = P.matcher(str);
        return m.find();
    }

    private boolean checkoutData(PolicyImportData data) {
        if (ObjectUtils.isEmpty(data)) {
            return false;
        }
        if (StringUtils.isNotBlank(data.getBelongCompanyName())) {
            EiInsDepart depart = eiInsDepartService.findByName(data.getBelongCompanyName());
            if (null == depart) {
                errorList.add(data);
                return false;
            }
        }

        if (StringUtils.isBlank(data.getPolicyNo())) {
            log.info("保单号不能为空!");
            errorList.add(data);
            return false;
        }
        if (isContainChinese(data.getPolicyNo())) {
            log.info("保单号不能包含中文!");
            errorList.add(data);
            return false;
        }
        if (StringUtils.isAllBlank(data.getBelongCompanyName())) {
            log.info("承保公司不能为空");
            errorList.add(data);
            return false;
        }
        try {
            if (Double.parseDouble(data.getTotalPremium()) <= 0 ||
                Double.parseDouble(data.getFreeTaxPremium()) <= 0) {
                log.info("保费不能为负数");
                errorList.add(data);
                return false;
            }
        } catch (Exception e) {
            log.info("保费不能为空");
            errorList.add(data);
            return false;
        }
        // 被保人
        if (StringUtils.isBlank(data.getInsuredName())) {
            return false;
        }
        //  险种类别（必填、有效性校验
        if (StringUtils.isBlank(data.getInsuranceCategory())) {
            return false;
        } else {
            if (null == kindCodeMap.get(data.getInsuranceCategory())) {
                return false;
            }
        }
        // 保费起期（必填、有效性校验）、保险止期（必填、有效性校验）
        if (null == data.getPolicyBgnTime() || null == data.getPolicyEndTime()) {
            return false;
        }
        // 含税保费（必填）、不含税保费（必填）
        if (StringUtils.isBlank(data.getTotalPremium()) || StringUtils.isBlank(data.getFreeTaxPremium())) {
            return false;
        }
        return true;
    }

    @Override
    public void invokeHeadMap(Map<Integer, String> headMap, AnalysisContext context) {
        String currentHear = JSON.toJSONString(headMap);
        String rightHead = "{0:\"承保公司\",1:\"保单号\",2:\"投保人\",3:\"被保险人\",4:\"险种类别\",5:\"险种\",6:\"业务员\",7:\"投保日期\",8:\"保险起期\",9:\"保险止期\",10:\"含税保费\",11:\"不含税保费\",12:\"车船税\",13:\"车牌号\",14:\"NCD系数\",15:\"自主渠道系数\",16:\"自主核保优惠系数\",17:\"自主系数乘积\",18:\"项目全称\",19:\"承保份额\",20:\"缴费期\",21:\"手续费比例\",22:\"手续费金额（元）\",23:\"入账手续费\",24:\"应收日期\",25:\"转账日期\",26:\"备注\"}";
        log.info("解析到一条头数据:{}", JSON.toJSONString(headMap));
        if (!rightHead.equals(currentHear)) {
            throw new BusinessException("请使用正确的模板上传数据");
        }
    }
}
