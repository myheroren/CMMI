package com.huatonghh.policy.service;

import com.huatonghh.policy.domain.policy.PolicyCoinsurance;
import com.huatonghh.policy.repository.policy.PolicyCoinsuranceRepository;
import com.huatonghh.policy.service.dto.policy.PolicyCoinsuranceDTO;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/9
 */
@Service
@Slf4j
@AllArgsConstructor
public class PolicyCoinsuranceService {
    private final PolicyCoinsuranceRepository policyCoinsuranceRepository;
    private final ModelMapper modelMapper;

    public List<PolicyCoinsuranceDTO> findByPolicyNo(String policyNo) {
        List<PolicyCoinsurance> cs = policyCoinsuranceRepository.findAllByPolicyNo(policyNo);
        if (null == cs || cs.isEmpty()) {
            return null;
        }
        return cs.stream().map(c -> modelMapper.map(c, PolicyCoinsuranceDTO.class)).collect(Collectors.toList());
    }
}
