package com.huatonghh.fund.service;

import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.common.util.system.PageParam;
import com.huatonghh.fund.domain.EiInsFund;
import com.huatonghh.fund.service.dto.FundDTO;

/**
 * @author ghy
 * Date: 2021/1/5 16:52
 */
public interface EiInsFundService {

    /**
     * 基金使用记录列表查询
     * @return
     */
    PageInfo<EiInsFund> list(PageParam<Object> pageParam);

    EiInsFund getLastUsed();

    void save(FundDTO fundDTO);
}
