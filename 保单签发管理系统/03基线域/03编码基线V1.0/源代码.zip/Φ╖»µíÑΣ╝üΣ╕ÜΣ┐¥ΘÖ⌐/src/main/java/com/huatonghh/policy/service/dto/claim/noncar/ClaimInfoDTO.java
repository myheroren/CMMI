package com.huatonghh.policy.service.dto.claim.noncar;

import com.huatonghh.policy.domain.claim.noncar.ClaimHistory;
import com.huatonghh.policy.domain.claim.noncar.ClaimPay;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.List;

/**
 * description:
 *
 * @author : jym
 * @version : 1.0
 * @date : 2019/10/11
 */
@Data
@ApiModel("北部湾非车理赔详情")
public class ClaimInfoDTO {

    private ClaimBasicDTO basicInfo;
    private PolicyDTO policyInfo;
    private List<ClaimHistory> claimHistories;
    private List<ClaimPay> payInfo;
}
