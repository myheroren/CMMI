package com.huatonghh.base.service.dto;

import lombok.Data;

/**
 * @author : Sun
 * @description : 保险商城-页面渲染id name
 * @date : 2019/11/12 16:50
 * @version : 1.0
 */
@Data
public class IdNameDto {
    
    private String id;
    private String name;

    public IdNameDto() {
    }

    public IdNameDto(String id, String name) {
        this.id = id;
        this.name = name;
    }

}
