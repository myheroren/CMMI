package com.huatonghh.ins_authority.repository;

import com.huatonghh.authority.domain.EiRole;
import com.huatonghh.ins_authority.domain.EiInsRole;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


/**
 * @author : Sun
 * @description : 交投集团-角色-数据仓库
 * @date : 2019/11/4 19:45
 * @version : 1.0
 */
@Repository
public interface EiInsRoleRepository extends JpaRepository<EiInsRole, Integer> {

    /**
     * 根据角色id查询角色信息
     *
     * @author Sun
     * @date 2019/11/4 19:52
     * @param roleid: 角色id
     * @return java.util.Optional<com.huatonghh.authority.domain.EiRole>
     **/
    Optional<EiInsRole> findOneByRoleId(Integer roleid);


    /**
     * 懒加载获取角色信息，以及菜单权限信息
     *
     * @author Sun
     * @date 2019/11/4 19:53
     * @param roleid: 角色id
     * @return java.util.Optional<com.huatonghh.authority.domain.EiRole>
     **/
    @EntityGraph(attributePaths = "authorities")
    Optional<EiInsRole> findOneWithAuthoritiesByRoleId(Integer roleid);

    /**
     * 懒加载获取所有角色信息，以及菜单权限信息
     *
     * @author Sun
     * @date 2019/11/4 19:53
     * @param valid: 角色是否有效
     * @return java.util.List<com.huatonghh.authority.domain.EiRole>
     **/

    List<EiInsRole> findAllByValid(Boolean valid);

    /**
     * 懒加载获取所有角色信息，以及菜单权限信息
     *
     * @author Sun
     * @date 2019/11/4 19:53
     * @param valid: 角色是否有效
     * @return java.util.List<com.huatonghh.authority.domain.EiRole>
     **/
    @Modifying
    @Query(nativeQuery = true, value = "select er.* from ei_ins_role er where er.is_valid = ?1 LIMIT ?2,?3")
    List<EiInsRole> findAllPageByValid(Boolean valid,Integer pageNum,Integer pageSize);

    Integer countByValid(Boolean valid);

    /**
     * 删除角色对应的用户中间表
     *
     * @author Sun
     * @date 2019/11/4 19:54
     * @param roleId: 角色id
     **/
    @Modifying
    @Query(nativeQuery = true, value = "delete from ei_ins_user_role where role_id = :roleId")
    void deleteUserRoleByRoleId(@Param("roleId") Integer roleId);

    /**
     * 懒加载获取所有角色信息，以及菜单权限信息
     *
     * @author Sun
     * @date 2019/11/4 19:53
     * @param valid: 角色是否有效
     * @return java.util.List<com.huatonghh.authority.domain.EiRole>
     **/
    @Modifying
    @Query(nativeQuery = true, value = "select er.* from ei_ins_role er where er.is_valid = ?2 LIMIT ?3,?4")
    List<EiInsRole> findAllByCompanyId(Boolean valid,Integer pageNum,Integer pageSize);

    @Modifying
    @Query(nativeQuery = true, value = "select er.* from ei_ins_role er where  er.is_valid = ?2")
    List<EiInsRole> findAllSizeByCompanyId(Boolean valid);

}
