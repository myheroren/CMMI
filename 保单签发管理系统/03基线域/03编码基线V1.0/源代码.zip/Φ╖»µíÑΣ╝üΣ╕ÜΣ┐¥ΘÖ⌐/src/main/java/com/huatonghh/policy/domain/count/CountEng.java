package com.huatonghh.policy.domain.count;

import lombok.Data;

import javax.persistence.*;
import java.math.BigInteger;
import java.util.Date;

/**
 * description: 统计保险公司
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/11
 */
@Entity
@Table(name = "count_eng")
@Data
public class CountEng {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String eng;
    private BigInteger totalPremium;
    private Date createTime;
    private Byte type;
}
