package com.huatonghh.policy.domain.project;

import lombok.Data;

import javax.persistence.*;
import java.math.BigInteger;
import java.util.Date;

/**
 * @author : hao.wang
 * @date : 2019/9/3
 * description:
 */
@IdClass(ProjectRelationEntityPK.class)
@Entity
@Table(name = "ins_project_relation")
@Data
public class ProjectRelationEntity {
    @Id
    private BigInteger parentProjectNo;
    @Id
    private BigInteger childProjectNo;
    @Column(name = "is_valid")
    private Boolean valid;
    private Date createTime;
    private Date updateTime;
}
