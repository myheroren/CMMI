package com.huatonghh.file.service;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.FileUtil;
import com.google.common.collect.Lists;
import com.huatonghh.authority.service.dto.EiUserDto;
import com.huatonghh.common.config.properties.ApplicationProperties;
import com.huatonghh.common.constant.enums.StatusEnum;
import com.huatonghh.common.exception.BusinessException;
import com.huatonghh.common.util.BeanCopierUtils;
import com.huatonghh.file.constant.FileConstant;
import com.huatonghh.file.domain.FiAuditFile;
import com.huatonghh.file.domain.FiFile;
import com.huatonghh.file.repository.FiAuditFileRepository;
import com.huatonghh.file.repository.FiFileRepository;
import com.huatonghh.file.service.dto.FiAuditFileDto;
import com.huatonghh.ins_authority.service.dto.EiInsUserDto;
import com.huatonghh.policy.constant.PlanConstant;
import com.huatonghh.policy.service.client.CurrentUserDTO;
import com.huatonghh.policy.service.client.UserClient;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.URLEncoder;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


/**
 * @author : Sun
 * @version : 1.0
 * @description : 审批时上传文件的业务方法
 * @date : 2019/11/5 21:27
 */
@Service
@Slf4j
@AllArgsConstructor
public class AuditFileService {

    private final ApplicationProperties applicationProperties;

    private final FiAuditFileRepository fiAuditFileRepository;

    private final FastDFSUpAndDowService fastDFSUpAndDowService;

    private final UserClient userClient;

    private final FiFileRepository fiFileRepository;

    /**
     * @param file:
     * @param fiAuditFileDto:
     * @return java.lang.Integer
     * @author Sun
     * @description 审批环节上传文件，参数：文件流、审核人、上传环节、备注、默认有效
     * @date 2019/11/5 21:27
     **/
    public Integer uploadAuditFile(MultipartFile file, FiAuditFileDto fiAuditFileDto) {
        // 上传文件，并返回文件存储id
        Integer fileId;
        try {
            fileId = fastDFSUpAndDowService.uploadFile(file);
        } catch (Exception e) {
            log.error(StatusEnum.FILE_FASTDFS_UPLOAD_ERROR.getMessage() + ": {}", e.getMessage());
            throw new BusinessException(StatusEnum.FILE_FASTDFS_UPLOAD_ERROR);
        }

        // 存储审批时上传附件的信息
        FiAuditFile fiAuditFile = new FiAuditFile();
        fiAuditFile.setFileId(fileId);
        fiAuditFile.setFileName(file.getName());
        fiAuditFile.setUploadUser(fiAuditFileDto.getUploadUser());
        fiAuditFile.setUploadLink(fiAuditFileDto.getUploadLink());
        fiAuditFile.setRemark(fiAuditFileDto.getRemark());
        fiAuditFile.setBelongId(fiAuditFileDto.getBelongId());
        fiAuditFile.setBelongType(fiAuditFileDto.getBelongType());
        fiAuditFile.setValid(true);
        fiAuditFile.setCreateTime(DateUtil.date());
        try {
            fiAuditFile = fiAuditFileRepository.save(fiAuditFile);
        } catch (Exception e) {
            log.error(StatusEnum.FILE_AUDIT_FILE_ERROR.getMessage() + ": {}", e.getMessage());
            throw new BusinessException(StatusEnum.FILE_AUDIT_FILE_ERROR);
        }
        return fiAuditFile.getFileId();
    }

    /**
     * 根据fileId查询文件信息
     */
    public FiAuditFile selectFileInfo(Integer fileId) {
        Optional<FiAuditFile> optional = fiAuditFileRepository.findByFileId(fileId);
        if (!optional.isPresent()) {
            throw new RuntimeException("文件不存在");
        }
        return optional.get();
    }


    public Integer saveAuditFile(FiAuditFileDto fiAuditFileDto) {
        // 获取文件下载url
        Integer fileId = fiAuditFileDto.getFileId();
        Optional<FiFile> fiFileOptional = fiFileRepository.findById(fileId);
        if (!fiFileOptional.isPresent()) {
            throw new BusinessException(StatusEnum.FILE_SERIALIZABLE_ERROR);
        }
        FiFile fiFile = fiFileOptional.get();

        // 获取文件后缀，并转为小写
        String fileUrl = fiFile.getFileUrl();
        // 判断是否可预览
        Byte view = judgeIsViewMethod(fileUrl);
        log.info("saveAuditFile---------------", view);

        FiAuditFile fiAuditFile = new FiAuditFile();
        BeanCopierUtils.copy(fiAuditFileDto, fiAuditFile);
        fiAuditFile.setPreview(view);
        fiAuditFile.setValid(true);
        fiAuditFile.setCreateTime(DateUtil.date());
        // 上传人
        CurrentUserDTO userDTO = userClient.getCurrentUserInfo();

        if (PlanConstant.ENTERPRISE_GROUP.equals(userDTO.getType())) {
            EiUserDto userDto = userDTO.getEiUserDto();
            fiAuditFile.setUploadUser(userDto.getUserName());
            fiAuditFile.setUploadUserName(userDto.getName());
        } else {
            EiInsUserDto userDto = userDTO.getEiInsUserDto();
            fiAuditFile.setUploadUser(userDto.getUserName());
            fiAuditFile.setUploadUserName(userDto.getName());
        }

        return fiAuditFileRepository.save(fiAuditFile).getFileId();
    }


    private FiAuditFileDto getFiAuditFileDtoByEntity(FiAuditFile fiAuditFile) {
        FiAuditFileDto dto = new FiAuditFileDto();
        BeanCopierUtils.copy(fiAuditFile, dto);
        return dto;
    }


    public List<FiAuditFileDto> listFiAuditFileDto(String belongId, Byte belongType, Boolean valid) {
        List<FiAuditFileDto> fiAuditFileDto = fiAuditFileRepository.findFiAuditFileDto(belongId, belongType, valid);
        for (FiAuditFileDto auditFileDto : fiAuditFileDto) {
            BigInteger fileSize = auditFileDto.getFileSize();
            if (fileSize != null) {
                auditFileDto.setReadableFileSize(FileUtil.readableFileSize(fileSize.longValue()));
            }
            // 取url
            fiFileRepository.findById(auditFileDto.getFileId()).ifPresent(fiFile -> auditFileDto.setFileUrl(applicationProperties.getFdfsPrefixNginx() + fiFile.getFileUrl()));
        }
        return fiAuditFileDto;
    }


    public void updateByBelongIdAndType(String belongId, Byte belongType, String uploadLink) {
        fiAuditFileRepository.updateByBelongIdAndType(belongId, belongType, uploadLink);
    }


    public void updateByBelongIdAndUploadLink(String belongId, String oldUploadLink, String newUploadLink) {
        fiAuditFileRepository.updateByBelongIdAndUploadLink(belongId, oldUploadLink, newUploadLink);
    }


    private List<FiAuditFileDto> listFiAuditFileDtoByEntities(List<FiAuditFile> files) {
        if (null != files && files.size() > 0) {
            List<FiAuditFileDto> list = Lists.newArrayList();
            files.forEach(entity -> {
                FiAuditFileDto dto = getFiAuditFileDtoByEntity(entity);
                list.add(dto);
            });
            return list;
        }
        return null;
    }


    /**
     * @param auditFileId:
     * @param response:
     * @author Sun
     * @description 下载
     * @date 2019/11/5 21:28
     **/
    public void downloadFile(Integer auditFileId, HttpServletResponse response) {
        FiAuditFile fiAuditFile = queryAuditFileOptional(auditFileId);
        fastDFSUpAndDowService.downloadFile(fiAuditFile.getFileId(), response);
    }


    /**
     * @param fileId:
     * @author Sun
     * @description 删除
     * @date 2019/11/5 21:28
     **/
    public void deleteFile(Integer fileId) {
        FiAuditFile fiAuditFile = queryAuditFileOptional(fileId);
        fastDFSUpAndDowService.deleteFile(fiAuditFile.getFileId());
        fiAuditFileRepository.deleteById(fiAuditFile.getAuditId());
    }


    /**
     * @param auditFileId:
     * @return com.huatonghh.file.domain.FiAuditFile
     * @author Sun
     * @description 获取fi_audit_file数据，并判断飞扣
     * @date 2019/11/5 21:28
     **/
    private FiAuditFile queryAuditFileOptional(Integer auditFileId) {
        Optional<FiAuditFile> fiAuditFileOptional = fiAuditFileRepository.findByFileId(auditFileId);
        if (!fiAuditFileOptional.isPresent()) {
            throw new BusinessException(StatusEnum.FILE_SERIALIZABLE_ERROR);
        }
        return fiAuditFileOptional.get();
    }


    /**
     * @param fiAuditFileDtos:
     * @return java.util.List<com.huatonghh.file.service.dto.FiAuditFileDto>
     * @author Sun
     * @description 批量保存文件信息
     * @date 2019/11/5 21:28
     **/
    @Transactional(rollbackFor = RuntimeException.class)
    public List<FiAuditFileDto> batchUploadFileDetail(List<FiAuditFileDto> fiAuditFileDtos) {
        if (fiAuditFileDtos == null || fiAuditFileDtos.isEmpty()) {
            return null;
        }
        // 后续接入请注意哈
        return null;
    }


    /**
     * @param fileUrl:
     * @return java.lang.Byte
     * @author Sun
     * @description 根据文件url，判断是否可预览
     * @date 2019/11/5 21:28
     **/
    private Byte judgeIsViewMethod(String fileUrl) {
        String extension = FilenameUtils.getExtension(fileUrl).toLowerCase();
        if (FileConstant.EXTENSION_DOC.equals(extension) || FileConstant.EXTENSION_DOCX.equals(extension) || FileConstant.EXTENSION_PPT.equals(extension) ||
            FileConstant.EXTENSION_PPTX.equals(extension) || FileConstant.EXTENSION_XLS.equals(extension) || FileConstant.EXTENSION_XLSX.equals(extension)) {
            return 2;
        } else if (extension.matches(FileConstant.EXTENSION_TXT) ||
            extension.matches(FileConstant.EXTENSION_JPG) ||
            extension.matches(FileConstant.EXTENSION_PDF)) {
            // 浏览器可直接在线预览
            return 1;
        } else {
            // 不可预览
            return 0;
        }
    }


    /**
     * @param preview:
     * @param fileId:
     * @return java.lang.String
     * @author Sun
     * @description 返回预览http-url
     * @date 2019/11/5 21:28
     **/
    public String previewFile(Byte preview, Integer fileId) {
        Optional<FiFile> fiFileOptional = fiFileRepository.findById(fileId);
        if (!fiFileOptional.isPresent()) {
            throw new BusinessException(StatusEnum.FILE_SERIALIZABLE_ERROR);
        }
        FiFile fiFile = fiFileOptional.get();
        String fileUrl = fiFile.getFileUrl();

        // 获取FastDfs地址
        String fdfsPrefix = applicationProperties.getFdfsPrefixNginx();
        String fdfsPrefixNginxHttps = applicationProperties.getFdfsPrefixNginxHttps();
        try {
            // 可直接预览
            if (preview == 1) {
                return fdfsPrefixNginxHttps + fileUrl;
                // 微软office预览
            } else if (preview == 2) {
                String encode = URLEncoder.encode(fdfsPrefix + fileUrl, "UTF-8");
                return FileConstant.VIEW_OFFICEAPPS + encode;
            } else {
                return null;
            }
        } catch (UnsupportedEncodingException e) {
            log.error("FastDfs URL编码失败: {}", e.getMessage());
            return null;
        }
    }

    public void copyFile(String oldBelongId, String newBelongId, Byte belongType) {
        List<FiAuditFile> oldFiles = fiAuditFileRepository.findAllByBelongIdAndBelongTypeAndValidOrderByCreateTimeDesc(oldBelongId, belongType, true);
        List<FiAuditFile> newFilesExit = fiAuditFileRepository.findAllByBelongIdAndBelongTypeAndValidOrderByCreateTimeDesc(newBelongId, belongType, true);
        List<FiAuditFile> newFiles = Lists.newArrayList();
        // 去掉重复的
        oldFiles = oldFiles.stream().filter(a -> !newFilesExit.contains(a)).collect(Collectors.toList());
        if (!oldFiles.isEmpty()) {
            oldFiles.forEach(old -> {
                    FiAuditFile file = new FiAuditFile();
                    BeanCopierUtils.copy(old, file);
                    file.setBelongId(newBelongId);
                    file.setAuditId(null);
                    newFiles.add(file);
                }
            );
        }
        fiAuditFileRepository.saveAll(newFiles);
    }

    public void deleteFile(String belongId, Byte belongType) {
        fiAuditFileRepository.deleteByBelongIdAndType(belongId, belongType);
    }
}
