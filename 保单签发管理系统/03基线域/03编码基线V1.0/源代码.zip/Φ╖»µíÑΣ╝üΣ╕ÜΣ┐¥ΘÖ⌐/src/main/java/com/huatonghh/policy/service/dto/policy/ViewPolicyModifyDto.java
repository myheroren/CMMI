package com.huatonghh.policy.service.dto.policy;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

/**
 * Description : 保存保单详细信息-非车
 * @author : juyanming
 * @date : 2019/10/31 14:01
 * @version : 1.0
 */

@Data
@ApiModel("保存保单详细信息-非车")
public class ViewPolicyModifyDto implements Serializable {

    private static final long serialVersionUID = 7123524803971823466L;

    @ApiModelProperty(value = "投保人")
    private String holderName;

    @ApiModelProperty(value = "被保人")
    private String insuredName;

    @ApiModelProperty(value = "有效止期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyEndTime;

    @ApiModelProperty(value = "总保费")
    @JsonDeserialize(using= AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger totalPremium;

    @ApiModelProperty(value = "总保额")
    @JsonDeserialize(using= AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger totalAmount;
}
