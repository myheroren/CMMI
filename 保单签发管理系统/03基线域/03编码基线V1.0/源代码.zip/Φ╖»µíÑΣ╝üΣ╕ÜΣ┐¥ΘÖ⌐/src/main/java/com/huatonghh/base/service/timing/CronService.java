package com.huatonghh.base.service.timing;

import cn.hutool.core.lang.Console;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


/**
 * @author : Sun
 * @description : 
 * @date : 2019/11/18 15:16
 * @version : 1.0
 */
@Service
@Slf4j
@AllArgsConstructor
public class CronService {

    public void cronUtilTest() {
       // Console.log("我是定时任务，我开始执行了");
    }

}
