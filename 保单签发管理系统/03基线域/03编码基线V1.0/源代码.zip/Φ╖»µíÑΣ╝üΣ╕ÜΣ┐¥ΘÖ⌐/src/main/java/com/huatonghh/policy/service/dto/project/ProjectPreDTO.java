package com.huatonghh.policy.service.dto.project;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigInteger;
import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/6
 */
@Data
@ApiModel("项目预设信息")
public class ProjectPreDTO {
    @ApiModelProperty(value = "上限价格")
    private String priceMaxLimit;
    @ApiModelProperty(value = "中标价格")
    private String priceBid;
    @ApiModelProperty(value = "保费上限")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger premiumMaxLimit;
    @ApiModelProperty(value = "中标保费")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger premiumBid;
    @ApiModelProperty(value = "不含税保费")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger premiumTaxFree;
    @ApiModelProperty(value = "手续费")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger handlingFee;
    @ApiModelProperty(value = "手续费比例")
    private String feeProp;
    @ApiModelProperty(value = "手续费关联类型，1含税保费，2不含税保费")
    private Byte feeRelationType;
    @ApiModelProperty(value = "共保信息")
    private List<ProjectPreCoinsuranceDTO> coinsuranceInfos;
}
