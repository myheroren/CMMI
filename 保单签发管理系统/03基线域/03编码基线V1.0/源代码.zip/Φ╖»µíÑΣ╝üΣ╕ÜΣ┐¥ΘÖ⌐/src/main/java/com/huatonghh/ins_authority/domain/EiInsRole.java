package com.huatonghh.ins_authority.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.huatonghh.authority.domain.EiAuthority;
import lombok.Data;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * @author : Sun
 * @description : 保险公司-角色-数据库映射实体
 * @date : 2019/11/4 19:41
 * @version : 1.0
 */
@Entity
@Table(name = "ei_ins_role")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@Data
public class EiInsRole implements Serializable {

    private static final long serialVersionUID = 642843679732062301L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "role_id")
    private Integer roleId;

    @Column(name = "role_name")
    private String roleName;

    @Column(name = "position")
    private Byte position;

    @Column(name = "remark")
    private String remark;

    @Column(name = "is_valid")
    private Boolean valid;

    @JsonIgnore
    @ManyToMany
    @JoinTable(
        name = "ei_ins_role_authority",
        joinColumns = {@JoinColumn(name = "role_id", referencedColumnName = "role_id")},
        inverseJoinColumns = {@JoinColumn(name = "authority_id", referencedColumnName = "id")})
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @BatchSize(size = 40)
    private Set<EiInsAuthority> authorities = new HashSet<>();

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof EiInsRole)) {
            return false;
        }
        EiInsRole eiRole = (EiInsRole) o;
        return Objects.equals(roleId, eiRole.roleId) &&
            Objects.equals(roleName, eiRole.roleName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(roleId, roleName);
    }

    @Override
    public String toString() {
        return "EiRole{" +
            "roleId=" + roleId +
            ", roleName='" + roleName + '\'' +
            '}';
    }

}
