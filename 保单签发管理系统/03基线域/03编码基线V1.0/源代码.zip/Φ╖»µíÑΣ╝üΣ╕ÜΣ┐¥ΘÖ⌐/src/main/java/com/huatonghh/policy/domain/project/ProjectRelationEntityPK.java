package com.huatonghh.policy.domain.project;

import lombok.Data;

import javax.persistence.Id;
import java.io.Serializable;
import java.math.BigInteger;


/**
 * @author hao.wang
 */
@Data
public class ProjectRelationEntityPK implements Serializable {
    @Id
    private BigInteger parentProjectNo;

    @Id
    private BigInteger childProjectNo;


    public ProjectRelationEntityPK() {

    }

    public ProjectRelationEntityPK(BigInteger parentProjectNo, BigInteger childProjectNo) {
        this.parentProjectNo = parentProjectNo;
        this.childProjectNo = childProjectNo;
    }
}
