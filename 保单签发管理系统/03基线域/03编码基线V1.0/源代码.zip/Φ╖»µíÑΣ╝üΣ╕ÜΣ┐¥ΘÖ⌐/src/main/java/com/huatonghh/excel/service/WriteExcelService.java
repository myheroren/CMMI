package com.huatonghh.excel.service;

import com.huatonghh.authority.service.EiUserService;
import com.huatonghh.base.constant.BaseConstant;
import com.huatonghh.base.service.BaseCodeService;
import com.huatonghh.common.util.hutool.MoneyUtils;
import com.huatonghh.common.util.system.PageInfo;
import com.huatonghh.excel.service.dto.*;
import com.huatonghh.ins_authority.service.EiInsDepartService;
import com.huatonghh.policy.domain.policy.PolicyMain;
import com.huatonghh.policy.domain.policy.renew.PolicyRenewEntity;
import com.huatonghh.policy.repository.renew.PolicyRenewV2Repository;
import com.huatonghh.policy.service.PolicyService;
import com.huatonghh.policy.service.claim.noncar.ClaimFormService;
import com.huatonghh.policy.service.client.UserClient;
import com.huatonghh.policy.service.dto.claim.form.ClaimDetailFormDTO;
import com.huatonghh.policy.service.dto.claim.form.ClaimHighwayBidFormDTO;
import com.huatonghh.policy.service.dto.claim.form.ClaimHighwayFormDTO;
import com.huatonghh.policy.service.dto.claim.noncar.ClaimFormQuery;
import com.huatonghh.policy.service.dto.policy.PolicyBaseListDTO;
import com.huatonghh.policy.service.dto.policy.PolicyListCondition;
import com.huatonghh.policy.service.dto.policy.PolicyListDto;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFactory;
import org.apache.commons.compress.utils.Lists;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.List;
import java.util.stream.Collectors;


/**
 * @author : Sun
 * @version : 1.0
 * description :
 * @date : 2019/11/5 21:19
 */
@Service
@Slf4j
@AllArgsConstructor
public class WriteExcelService {

    private final PolicyService policyService;

    private final MapperFactory mapperFactory;

    private final ModelMapper modelMapper;

    private final PolicyRenewV2Repository renewV2Repository;

    private final BaseCodeService baseCodeService;

    private final EiInsDepartService insDepartService;

    private final EiUserService eiUserService;

    private final ClaimFormService claimFormService;

    private final UserClient userClient;

    /**
     * @param policyListCondition:
     * @return java.util.List<com.huatonghh.excel.service.dto.PolicyTestData>
     * @author Sun
     * description 根据查询条件获取保单列表
     * @date 2019/11/5 21:20
     **/
    public List<PolicyTestData> data(PolicyListCondition policyListCondition) {
        PageInfo<PolicyListDto> policyListDtoPageInfo = policyService.queryPageList(policyListCondition);
        List<PolicyListDto> policyListDtos = policyListDtoPageInfo.getList();
        mapperFactory.classMap(PolicyListDto.class, PolicyTestData.class).byDefault().register();
        return mapperFactory.getMapperFacade().mapAsList(policyListDtos, PolicyTestData.class);
    }

    public List<PolicyData> getPolicyData(PolicyListCondition condition) {
        List<Integer> ids = condition.getIds();
        if (null != condition.getIds() && !condition.getIds().isEmpty()) {
            List<PolicyData> policyDataList = Lists.newArrayList();
            ids.forEach(id -> {
                PolicyMain policy = policyService.findById(BigInteger.valueOf(id));
                if (null != policy) {
                    PolicyBaseListDTO dto = modelMapper.map(policy, PolicyBaseListDTO.class);
                    policyDataList.add(this.getPolicyDataByDTO(dto));
                }
            });
            return policyDataList;
        }
        // 设置查全部
        condition.setPageSize(1000000);
        PageInfo<PolicyBaseListDTO> page = policyService.queryPolicyList(condition);
        if (page.getTotal() == 0) {
            return null;
        }
        List<PolicyBaseListDTO> vehMainList = page.getList();
        return vehMainList.stream().map(this::getPolicyDataByDTO).collect(Collectors.toList());
    }

    private PolicyData getPolicyDataByDTO(PolicyBaseListDTO dto) {
        PolicyData data = modelMapper.map(dto, PolicyData.class);
        if (StringUtils.isNotBlank(dto.getBelongCompany())) {
            data.setBelongCompanyName(insDepartService.queryNameById(dto.getBelongCompany()));
        }
        // 发起公司
        data.setStartCompanyName(dto.getHolderName());
        // 险种
        if (StringUtils.isNotBlank(dto.getInsuranceCategory())) {
            data.setInsuranceCategory(baseCodeService.queryCodeName(BaseConstant.KIND_CODE, dto.getInsuranceCategory()));
        }
        // 险别
        if (StringUtils.isNotBlank(dto.getKindCode())) {
            data.setKindCode(baseCodeService.queryCodeName(BaseConstant.RISK_CODE, dto.getKindCode()));
        }

        // 历史关联保单
        List<PolicyRenewEntity> renewEntities = renewV2Repository.findAllByPolicyNoNewOrderByIdDesc(dto.getPolicyNo());
        if (null != renewEntities && !renewEntities.isEmpty()) {
            List<String> policyNos = renewEntities.stream().map(PolicyRenewEntity::getPolicyNoOld).collect(Collectors.toList());
            data.setPolicyNo9(policyNos.toString());
        }

        return data;
    }


    public List<ClaimHighwayFormData> getClaimGatherForm(ClaimFormQuery query) {
        List<ClaimHighwayFormDTO> list = claimFormService.gatherForm(query);
        if (null == list || list.isEmpty()) {
            return null;
        }
        return list.stream().map(this::getClaimHighwayFormData).collect(Collectors.toList());
    }

    private ClaimHighwayFormData getClaimHighwayFormData(ClaimHighwayFormDTO dto) {
        ClaimHighwayFormData data = modelMapper.map(dto, ClaimHighwayFormData.class);
        data.setCountApply(dto.getCountApply().toString());
        data.setCountClaim(dto.getCountClaim().toString());
        data.setCountGetClaim(dto.getCountGetClaim().toString());
        data.setCountPolicy(dto.getCountPolicy().toString());
        data.setCountContract(dto.getCountContract().toString());

        // 钱相关
        data.setAskForAmount(MoneyUtils.cent2Yuan(dto.getAskForAmount()));
        data.setPayAmount(MoneyUtils.cent2Yuan(dto.getPayAmount()));
        data.setTotalPremium(MoneyUtils.cent2Yuan(dto.getTotalPremium()));
        data.setPreLossAmount(MoneyUtils.cent2Yuan(dto.getPreLossAmount()));

        return data;
    }

    public List<ClaimDetailFormData> getClaimDetailForm(ClaimFormQuery query) {
        List<ClaimDetailFormDTO> list = claimFormService.detailForm(query);
        if (null == list || list.isEmpty()) {
            return null;
        }
        return list.stream().map(this::getClaimDetailFormData).collect(Collectors.toList());
    }

    private ClaimDetailFormData getClaimDetailFormData(ClaimDetailFormDTO dto) {
        ClaimDetailFormData data = modelMapper.map(dto, ClaimDetailFormData.class);
        // 项目类别
        if (null != dto.getEngType()) {
            String engName = baseCodeService.queryCodeName("eng_type", dto.getEngType() + "");
            data.setEngTypeName(engName);
        }
        // 保险类别
        if (null != dto.getInsureType()) {
            if (1 == (dto.getInsureType())) {
                data.setInsureType("一切险");
            } else {
                data.setInsureType("第三者险");
            }
        }
        // 估损金额
        data.setPreLossAmount(MoneyUtils.cent2Yuan(dto.getPreLossAmount()));
        // 索赔金额
        data.setAskForAmount(MoneyUtils.cent2Yuan(dto.getAskForAmount()));
        // 获赔金额
        data.setPayAmount(MoneyUtils.cent2Yuan(dto.getPayAmount()));

        return data;
    }

    public List<ClaimHighwayBidFormData> getClaimBidForm(ClaimFormQuery query) {
        List<ClaimHighwayBidFormDTO> list = claimFormService.bidForm(query);
        if (null == list || list.isEmpty()) {
            return null;
        }
        return list.stream().map(this::getClaimBidFormData).collect(Collectors.toList());
    }

    private ClaimHighwayBidFormData getClaimBidFormData(ClaimHighwayBidFormDTO dto) {
        ClaimHighwayBidFormData data = modelMapper.map(dto, ClaimHighwayBidFormData.class);
        data.setTotalAmount(dto.getTotalAmount() + "");
        data.setCountApply(dto.getCountApply() + "");
        data.setCountClaim(dto.getCountClaim() + "");
        data.setCountGetClaim(dto.getCountGetClaim() + "");

        return data;
    }
}
