package com.huatonghh.file.service.dto;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigInteger;

/**
 * @author : Sun
 * @description : 文件表-dto
 * @date : 2019/11/5 21:27
 * @version : 1.0
 */
@Data
@ApiModel(value = "FastDFS上传文件对象")
public class FiFileDto implements Serializable {

    private static final long serialVersionUID = -865369880321004226L;

    @ApiModelProperty(value = "id")
    private Integer fileId;

    @ApiModelProperty(value = "原文件名，含后缀")
    private String fileOriginalName;

    @ApiModelProperty(value = "存储url")
    private String fileUrl;

    @ApiModelProperty(value = "文件大小 long类型")
    @JsonSerialize(using = ToStringSerializer.class)
    private BigInteger fileSize;

    @ApiModelProperty(value = "页面展示的文件大小，带MB KB GB")
    private String fileSizeAndType;

}
