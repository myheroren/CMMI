package com.huatonghh.policy.service.dto.policy;

import java.io.Serializable;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * 保单受益人表(PolicyBenefited)表实体类DTO
 *
 * @author 居炎明
 * @since 2020-03-01 18:25:01
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Api(description = "保单受益人表")
public class PolicyBenefitedDTO implements Serializable {

        private static final long serialVersionUID=-39745062747074547L;
        @ApiModelProperty(value = "主键")
        private Integer id;


        @ApiModelProperty(value = "受益人姓名")
        private String benefitedName;

        @ApiModelProperty(value = "受益人证件类型")
        private String benefitedCertificateType;

        @ApiModelProperty(value = "受益人证件号")
        private String benefitedCertificateNo;

        @ApiModelProperty(value = "受益人邮箱")
        private String benefitedEmail;

        @ApiModelProperty(value = "受益人性别")
        private Integer sex;

        @ApiModelProperty(value = "第几受益人")
        private Integer position;

        @ApiModelProperty(value = "受益比例")
        private Integer positionRate;

        @ApiModelProperty(value = "受益人所属保单号")
        private String policyNo;


}
