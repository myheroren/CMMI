package com.huatonghh.base.config;

import me.chanjar.weixin.cp.api.WxCpService;
import me.chanjar.weixin.cp.api.impl.WxCpServiceImpl;
import me.chanjar.weixin.cp.config.WxCpInMemoryConfigStorage;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author Binary Wang(https://github.com/binarywang)
 */
@Configuration
@EnableConfigurationProperties(WxCpProperties.class)
public class WxCpConfiguration {

    private final WxCpProperties properties;

    public WxCpConfiguration(WxCpProperties properties) {
        this.properties = properties;
    }

    @Bean
    public WxCpService wxCpService() {
        WxCpServiceImpl wxCpService = new WxCpServiceImpl();
        wxCpService.setWxCpConfigStorage(wxMpConfigStorage());
        return wxCpService;
    }

    private WxCpInMemoryConfigStorage wxMpConfigStorage() {
        WxCpInMemoryConfigStorage config = new WxCpInMemoryConfigStorage();
        // 设置微信企业号的appid
        config.setCorpId(properties.getCorpId());
        // 设置微信企业号的app corpSecret
        config.setCorpSecret(properties.getAgentSecret());
        // 设置微信企业号应用ID
        config.setAgentId(properties.getAgentId());
        // 设置微信企业号应用的token
        config.setToken(properties.getToken());
        // 设置微信企业号应用的EncodingAESKey
        config.setAesKey(properties.getEncodingAesKey());
        return config;
    }

}
