package com.huatonghh.policy.service.dto.claim.noncar;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonDeserializer;
import com.huatonghh.common.service.AmountJsonSerializer;
import com.huatonghh.file.service.dto.FiAuditFileDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

/**
 * @author : hao.wang
 * @date :  2019/8/22
 * description :非车理赔报案信息
 */
@Data
@ApiModel("非车理赔报案信息")
public class ReportDTO {
    @ApiModelProperty("报案id")
    private String reportId;

    @ApiModelProperty("保单号")
    @NotBlank(message = "保单号不能为空")
    private String policyNo;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("报案时间")
    private Date reportTime;

    @ApiModelProperty("报案人姓名")
    private String reportName;

    @ApiModelProperty("报案人联系电话")
    private String reportTel;

    @ApiModelProperty("报案人证件号码")
    private String reportIdNumber;

    @ApiModelProperty("联系人")
    private String contact;

    @ApiModelProperty("联系人电话")
    private String contactTel;


    @ApiModelProperty("出险时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date accidentTime;

    @ApiModelProperty("总索赔金额")
    @JsonDeserialize(using = AmountJsonDeserializer.class)
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger askForAmount;

    @ApiModelProperty("出险地址")
    private String address;

    @ApiModelProperty("详细出险地址")
    private String addressDetail;

    @ApiModelProperty("出险原因")
    private String accidentReason;

    @ApiModelProperty("出险原因类型")
    private String accidentType;

    @ApiModelProperty("出险经过")
    private String accidentDetail;

    @ApiModelProperty("是否在线理赔")
    private String isOnlineClaims;

    @ApiModelProperty("备注")
    private String remark;
    @ApiModelProperty(value = "险类 : 1责任，2工程，3意外 ")
    private String insureCategory;
    @ApiModelProperty(value = "附件信息")
    private List<FiAuditFileDto> files;
}
