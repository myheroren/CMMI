package com.huatonghh.base.web.rest;

import com.huatonghh.base.domain.BaseEng;
import com.huatonghh.base.service.BaseEngService;
import com.huatonghh.common.util.system.ApiResponse;
import io.micrometer.core.annotation.Timed;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * description: 基础项目
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/11/22
 */
@RestController
@RequestMapping("/api/base/pro/v1")
@Api(tags = "21、基础项目", value = "基础项目")
@Slf4j
@AllArgsConstructor
public class BaseEndController {

    private final BaseEngService baseProjectService;

    @PostMapping("")
    @ApiOperation(value = "1、新增", httpMethod = "POST")
    @Timed
    public ApiResponse save(@RequestBody @Valid BaseEng baseProjectDTO) {
        return ApiResponse.ofSuccess(baseProjectService.save(baseProjectDTO));
    }

    @PutMapping("")
    @ApiOperation(value = "2、修改", httpMethod = "PUT")
    @Timed
    public ApiResponse update(@RequestBody @Valid BaseEng baseProjectDTO) {
        baseProjectService.update(baseProjectDTO);
        return ApiResponse.ofSuccess(null);
    }

    @GetMapping(value = "")
    @ApiOperation(value = "4、根据id", notes = "根据id", httpMethod = "GET")
    @Timed
    public ApiResponse<BaseEng> findById(@RequestParam("id") Integer id) {
        return ApiResponse.ofSuccess(baseProjectService.findById(id));
    }

    @GetMapping(value = "all")
    @ApiOperation(value = "3、查询", notes = "查询", httpMethod = "GET")
    @Timed
    public ApiResponse<List<BaseEng>> findAll() {
        return ApiResponse.ofSuccess(baseProjectService.findAll());
    }


}
