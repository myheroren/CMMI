package com.huatonghh.policy.service.dto.claim.form;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.huatonghh.common.service.AmountJsonSerializer;
import lombok.Data;

import java.math.BigInteger;

/**
 * description:公路工程一切险分类汇总表
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/9
 */
@Data
public class ClaimHighwayFormDTO {
    /**
     * 项目名称
     */
    private String proName;
    /**
     * 工程类别
     */
    private Byte engType;
    /**
     * 工程类别
     */
    private String engTypeName;
    /**
     * 施工合同数
     */
    private BigInteger countContract;
    /**
     * 购买保险份数
     */
    private BigInteger countPolicy;
    /**
     * 支付保险费额
     */
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger totalPremium;
    /**
     * 出险次数
     */
    private Integer countClaim;
    /**
     * 损失额/估损金额
     */
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger preLossAmount;
    /**
     * 索赔次数
     */
    private Integer countApply;
    /**
     * 索赔金额
     */
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger askForAmount;
    /**
     * 获赔次数
     */
    private Integer countGetClaim;
    /**
     * 赔偿额
     */
    @JsonSerialize(using = AmountJsonSerializer.class)
    private BigInteger payAmount;
    /**
     * 获赔额占保费比率
     */
    private String ratePremium;
    /**
     * 获赔额占索赔比率
     */
    private String rateAskFor;
    /**
     * 备注
     */
    private String remark;

}
