package com.huatonghh.policy.repository.policy;

import com.huatonghh.policy.domain.policy.PolicyCoinsurance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/12/6
 */
public interface PolicyCoinsuranceRepository extends JpaRepository<PolicyCoinsurance, Integer> {
    /**
     * 根据保单号查询
     *
     * @param policyNo 保单号
     * @return 共保列表
     */
    List<PolicyCoinsurance> findAllByPolicyNo(String policyNo);


    /**
     * 根据项目编号删除共保信息
     *
     * @param policyNo 项目编号
     */
    @Modifying
    @Query(value = "delete  from  PolicyCoinsurance p where p.policyNo =:policyNo")
    void deleteByProjectNo(@Param("policyNo") String policyNo);
}

