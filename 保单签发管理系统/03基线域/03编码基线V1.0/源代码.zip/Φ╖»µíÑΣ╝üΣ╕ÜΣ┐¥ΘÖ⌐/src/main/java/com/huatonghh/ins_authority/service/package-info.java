/**
 * Spring Framework configuration files.
 */
package com.huatonghh.ins_authority.service;
