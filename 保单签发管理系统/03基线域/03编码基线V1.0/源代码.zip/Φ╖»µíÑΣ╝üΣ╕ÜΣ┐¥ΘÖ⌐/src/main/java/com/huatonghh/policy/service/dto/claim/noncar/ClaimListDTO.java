package com.huatonghh.policy.service.dto.claim.noncar;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigInteger;
import java.util.Date;

/**
 * description:
 *
 * @author : hao.wang
 * @version : 1.0
 * @date : 2019/10/11
 */
@Data
@ApiModel("非车理赔列表")
public class ClaimListDTO {
    @ApiModelProperty("报案id")
    private String reportId;

    @ApiModelProperty(value = "保单号")
    private String policyNo;

    @ApiModelProperty(value = "报案号")
    private String reportNo;

    @ApiModelProperty(value = "理赔状态 0报案,1立案，2定损，3核损，4理算，5结案")
    private Byte claimStatus;

    @ApiModelProperty(value = "保险类别")
    private String insuranceCategory;

    @ApiModelProperty(value = "险种代码；例:车（交强、商业）,非车待定")
    private String kindCode;

    @ApiModelProperty(value = "项目组织")
    private String projectName;

    @ApiModelProperty(value = "车或非车标识：1车、0非车，必传")
    private Byte carUncarFlag;

    @ApiModelProperty(value = "车牌号")
    private String plateNo;

    @ApiModelProperty(value = "投保人")
    private String holderName;

    @ApiModelProperty(value = "被保险人")
    private String insuredName;

    @ApiModelProperty(value = "被保险人中文")
   // @JsonSerialize(using= BlocDepartJsonSerializer.class)
    private String insuredNameCn;

    @ApiModelProperty(value = "发起公司")
    private String startCompany;

    @ApiModelProperty(value = "保险公司")
    private String belongCompany;

    @ApiModelProperty(value = "发起公司")
    private String startCompanyName;

    @ApiModelProperty(value = "保险公司")
    private String belongCompanyName;

    @ApiModelProperty("出险时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date accidentTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("报案时间")
    private Date reportTime;

    @ApiModelProperty(value = "有效起期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyBgnTime;

    @ApiModelProperty(value = "有效止期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date policyEndTime;

    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    @ApiModelProperty(value = "更新时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;
}
